#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
import math
from os.path import join

import hydra
import lightning as L
import torch
import wandb
from lightning.pytorch.callbacks import Callback, ModelCheckpoint
from lightning.pytorch.loggers import WandbLogger
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import ConcatDataset, DataLoader

from visuomotor.data import load_dataset_cls
from visuomotor.data.datasets import config_to_limit_overrides, get_normalizers
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.models.protocols import Policy
from visuomotor.utils.paths import get_checkpoints_path
from visuomotor.utils.train_utils import validate_config


@hydra.main(version_base=None, config_path="configs", config_name="train_diffpo_eggplant")
def main(config: DictConfig) -> None:
    """Main training loop"""
    validate_config(config)
    DatasetClass = load_dataset_cls(config)

    L.seed_everything(config.train.seed, workers=True)
    if config.train.matmul_precision is not None:
        torch.set_float32_matmul_precision(config.train.matmul_precision)
    datasets = []
    for task_index, path in enumerate(list(config.data.data_path)):
        data_config = OmegaConf.create(config.data)
        data_config.data_path = path
        data_config.task_index = task_index
        dataset = DatasetClass(config=data_config)
        datasets.append(dataset)
        print(f"loaded dataset #{task_index} from {path}. Length {len(dataset)}")
    datasets = ConcatDataset(datasets)

    if config.train.validation_percent > 0:
        seed = torch.Generator().manual_seed(42)
        val_len = int(len(datasets) * config.train.validation_percent)
        train_len = len(datasets) - val_len
        train_dataset, val_dataset = torch.utils.data.random_split(datasets, [train_len, val_len], generator=seed)
    else:
        train_dataset = datasets
        val_dataloader = None

    if len(datasets) == 0:
        print("config.data", config.data)
        raise IndexError("Dataset is length zero")
    train_dataloader = DataLoader(
        train_dataset,
        shuffle=config.train.shuffle,
        batch_size=config.train.batch_size,
        pin_memory=config.train.pin_memory,
        num_workers=config.train.num_workers,
    )

    if config.train.validation_percent > 0:
        val_dataloader = DataLoader(
            val_dataset,
            shuffle=False,
            batch_size=config.train.batch_size,
            pin_memory=config.train.pin_memory,
            num_workers=config.train.num_workers,
        )

    max_epochs = None
    max_steps = -1
    if config.train.max_epochs is None and config.train.max_steps is None:
        raise ValueError("Either max_epochs or max_steps must be specified")
    elif config.train.max_epochs is not None and config.train.max_steps is not None:
        raise ValueError("Only one of max_epochs or max_steps can be specified")
    elif config.train.max_epochs is None:
        max_steps = config.train.max_steps
    elif config.train.max_steps is None:
        # We need to define max_steps so that lr scheduler can work properly but we will not use it for training.
        if config.train.devices == "auto":
            num_gpu = torch.cuda.device_count()
        elif OmegaConf.is_list(config.train.devices):
            num_gpu = len(config.train.devices)
        elif isinstance(config.train.devices, int):
            num_gpu = config.train.devices
        else:
            raise ValueError(f"Incorrect value of {config.train.devices} set for config.train.devices.")
        config.train.max_steps = math.ceil(len(train_dataloader) / (num_gpu)) * config.train.max_epochs
        max_epochs = config.train.max_epochs

    if len(config.data.data_path) > 1:
        project_name = f"{'_'.join(config.data.data_path)}"
    else:
        if "libero" in config.data.data_path[0]:
            project_name = config.data.data_path[0].split("/")[0]
        else:
            project_name = config.data.data_path[0]
    # Remove slashes from project name, to avoid exception.
    project_name = project_name.replace("/", "-")
    if "libero" in config.data.data_path[0]:
        logging_name = f"{config.method_name}_{config.data.data_path[0].split('/')[-1]}_{wandb.util.generate_id()}"
    else:
        logging_name = f"{config.method_name}_{wandb.util.generate_id()}"

    checkpoint_callback = ModelCheckpoint(
        dirpath=get_checkpoints_path(),
        filename=join(project_name, logging_name + "_{step}"),
        every_n_epochs=config.train.checkpoint_interval,
        save_top_k=config.train.local_save_top_k,
    )

    train_callbacks: list[Callback] = [checkpoint_callback]

    if "libero" in config.data.data_path[0] and "simulation" in config and config.simulation.run_sim:
        from visuomotor.ray_train.simulation.simulation_callback_libero import LiberoSimulationCallback

        # Add data path to the simulation config to load initial locations for objects
        OmegaConf.set_struct(config.simulation, False)
        config.simulation["data_path"] = config.data.data_path
        config.simulation["image_randomization"] = config.data.image_randomization
        OmegaConf.set_struct(config.simulation, True)
        sim_callback = LiberoSimulationCallback(config.simulation)
        train_callbacks.append(sim_callback)

    if config.train.stochastic_weighted_average is not None:
        from lightning.pytorch.callbacks import StochasticWeightAveraging

        from visuomotor.models.swa import prepare_swa_config

        swa_config = prepare_swa_config(config.train.stochastic_weighted_average)
        print(f"Setting up StochasticWeightAveraging. Config: {swa_config}")
        swa_callback = StochasticWeightAveraging(**swa_config)
        train_callbacks.append(swa_callback)

    logger = False
    if config.wandb.enable:
        logger = WandbLogger(
            project=project_name,
            name=logging_name,
            log_model="all",
            checkpoint_name=logging_name,
        )

    trainer = L.Trainer(
        logger=logger,
        enable_progress_bar=True,
        strategy=config.train.strategy,
        callbacks=train_callbacks,
        num_nodes=config.train.num_nodes,
        precision=config.train.precision,
        max_epochs=max_epochs,
        max_steps=max_steps,
        gradient_clip_val=config.train.gradient_clip_val,
        accelerator=config.train.accelerator,
        log_every_n_steps=config.train.log_every_n_steps,
        enable_model_summary=config.train.enable_model_summary,
        devices=config.train.devices if config.train.devices else "auto",
    )
    print("building policy...")
    model: Policy = REGISTRY.create_model(config=config, model_type=ModelType.POLICY)

    if config.data.normalize:
        # Compute min/max limits over the dataset(s).
        print("getting normalizer...")
        limit_overrides = config_to_limit_overrides(config)
        model.normalizer = get_normalizers(
            dataset=train_dataset,
            keys=config.data.norm_keys,
            mode=config.data.norm_mode,
            force_compute=config.data.normalize_force_compute,
            limit_overrides=limit_overrides,
        )

    print("\nModel created")
    print(model)
    print("\n\n")
    print(L.pytorch.utilities.model_summary.summarize(model, max_depth=1))
    print("\n\n")

    print("training policy...")
    trainer.fit(model, train_dataloaders=train_dataloader, val_dataloaders=val_dataloader)


if __name__ == "__main__":
    # to run with different config file, use `--config-name` e.g. `python train.py --config-name train_diffpo`
    main()
