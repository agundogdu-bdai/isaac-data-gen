#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Optional

import numpy as np
import numpy.typing as npt
import torch
from einops import rearrange, repeat
from omegaconf import DictConfig

# from pytorch3d.ops import sample_farthest_points
from spatialmath import SE3, SO3


def extract_plane(
    point_cloud: npt.NDArray,
    distance_threshold: float = 0.03,
    ransac_n: int = 3,
    num_iterations: int = 1000,
    return_plane_cloud: bool = False,
) -> npt.NDArray:
    """Extracts the plane from the point cloud unsing the RANSAC algorithm.
    Args:
        point_cloud (npt.NDArray): Input point cloud.
        distance_threshold (float, optional): _Distance threshold for RANSAC. Defaults to 0.03.
        ransac_n (int, optional): Number of points to sample for RANSAC. Defaults to 3.
        num_iterations (int, optional): RANSAc optimization steps. Defaults to 1000.
        return_plane_cloud (bool, optional): If True, returns the plane cloud otherwise return
        the point cloud with plane removed. Defaults to False.

    Returns:
        npt.NDArray: Plane cloud or point cloud with plane removed.
    """
    try:
        import open3d as o3d  # Lazy import to avoid importing at module load time
    except ImportError as e:
        raise ImportError("open3d is required for extract_plane but failed to import") from e
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(point_cloud[:, :3])
    if point_cloud.shape[1] == 6:
        pcd.colors = o3d.utility.Vector3dVector(point_cloud[:, 3:6])
    _, inliers = pcd.segment_plane(
        distance_threshold=distance_threshold, ransac_n=ransac_n, num_iterations=num_iterations
    )
    if return_plane_cloud:
        plane_cloud = pcd.select_by_index(inliers)
        plane_cloud_points = np.asarray(plane_cloud.points)
        if point_cloud.shape[1] == 6:
            plane_cloud_colors = np.asarray(plane_cloud.colors)
            return np.hstack([plane_cloud_points, plane_cloud_colors])
        else:
            return plane_cloud_points
    else:
        outliers = pcd.select_by_index(inliers, invert=True)
        outliers_points = np.asarray(outliers.points)
        if point_cloud.shape[1] == 6:
            outliers_colors = np.asarray(outliers.colors)
            return np.hstack([outliers_points, outliers_colors])
        else:
            return outliers_points


def get_random_transform(config: DictConfig) -> SE3:
    """Generates a random SE3 transform withing the specified limits.

    Args:
        config (DictConfig): Configuration.

    Returns:
        SE3: Random SE3 transform.
    """

    if config.position:
        pos = np.random.uniform(config.pos_limits[0], config.pos_limits[1], size=(3,))
    else:
        pos = np.zeros(3)

    if config.rotation:
        rot = np.random.uniform(config.rot_limits[0], config.rot_limits[1], size=(3,))
        rot = np.deg2rad(rot)
    else:
        rot = np.zeros(3)
    return SE3.Rt(R=SO3.RPY(*rot), t=pos)


def transform_point_cloud(point_cloud: npt.NDArray, transform: SE3) -> npt.NDArray:
    """Transforms the point cloud.

    Args:
        point_cloud (npt.NDArray): Point cloud.
        transform (SE3): Transform.

    Returns:
        npt.NDArray: Transformed point cloud.
    """
    point_cloud = point_cloud.copy()
    point_cloud_random = transform.A @ np.c_[point_cloud[:, :3], np.ones(point_cloud.shape[0])].T
    point_cloud[:, :3] = point_cloud_random.T[:, :3]
    return point_cloud


def sample_point_cloud(config: DictConfig, point_cloud: npt.NDArray) -> npt.NDArray:
    """Downsample the point cloud.

    Args:
        config (DictConfig): _description_
        point_cloud (npt.NDArray): _description_

    Raises:
        ValueError: Raised if the point cloud sampling method is not supported.

    Returns:
        npt.NDArray: Downsampled point cloud.
    """
    if config.point_cloud_sampling.method == "uniform":
        # If the number of points in the point cloud is less than the number of samples, sample same points.
        if point_cloud.shape[0] == 0:
            return point_cloud
        replace = True if point_cloud.shape[0] < config.point_cloud_sampling.num_samples else False
        random_points = np.random.choice(point_cloud.shape[0], config.point_cloud_sampling.num_samples, replace=replace)
        if config.point_cloud_sampling.use_rgb:
            return point_cloud[random_points]
        else:
            return point_cloud[random_points, :3]
    else:
        raise ValueError(f"Unsupported point cloud sampling method: {config.point_cloud_sampling.method}")


def depth_to_point_cloud_torch(
    intrinsics: torch.Tensor,
    depth: torch.Tensor,
    extrinsics: torch.Tensor,
    depth_scale: float = 1000.0,
    filter_points: bool = True,
    crop_area_min: Optional[list] = None,
    crop_area_max: Optional[list] = None,
    num_points: int = 2048,
    features: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    Converts a depth image to a point cloud.  If filter points is true, it will filter out invalid points and points
    outside of the crop area, if given.  num_points will be selected from the remaining points
    If features are given, they will be concatenated onto the corresponding points
    """
    height = depth.shape[-2]
    width = depth.shape[-1]

    v, u = torch.meshgrid(
        torch.arange(height, device=depth.device), torch.arange(width, device=depth.device), indexing="ij"
    )
    v = repeat(v, "h w -> b n h w", b=depth.shape[0], n=depth.shape[1])
    u = repeat(u, "h w -> b n h w", b=depth.shape[0], n=depth.shape[1])

    z = depth / depth_scale
    x = (
        (u - rearrange(intrinsics[..., 0, 2], "b n -> b n 1 1"))
        * z
        / rearrange(intrinsics[..., 0, 0], "b n -> b n 1 1")
    )
    y = (
        (v - rearrange(intrinsics[..., 1, 2], "b n -> b n 1 1"))
        * z
        / rearrange(intrinsics[..., 1, 1], "b n -> b n 1 1")
    )

    point_cloud = torch.stack([x, y, z], axis=-1)
    point_cloud = rearrange(point_cloud, "b n h w c -> b (n h w) c")

    if filter_points:
        valid_mask = point_cloud[:, :, 2] != 0

        if crop_area_min is not None:
            above_min = torch.all(point_cloud > torch.tensor(crop_area_min, device=point_cloud.device), dim=-1)
            valid_mask = torch.logical_and(above_min, valid_mask)

        if crop_area_max is not None:
            below_max = torch.all(point_cloud < torch.tensor(crop_area_max, device=point_cloud.device), dim=-1)
            valid_mask = torch.logical_and(below_max, valid_mask)

        indices = torch.multinomial(valid_mask.to(torch.float), num_points)
        rows = torch.arange(indices.shape[0]).unsqueeze(1).expand(-1, indices.shape[1])

        point_cloud = point_cloud[rows, indices]

        if features is not None:
            features = features[rows, indices]

    if features is None:
        return point_cloud

    features = rearrange(features, "b n c h w -> b (n h w) c")
    combined = torch.cat([point_cloud, features], dim=-1)

    return combined


def rgbd_to_point_cloud_multi(
    intrinsics: npt.NDArray,
    camera_ids: list[int],
    depth: npt.NDArray,
    color: npt.NDArray,
    extrinsics: npt.NDArray,
    crop_area: list[list[float]] | None = None,
    depth_scale: float = 1000.0,
    remove_invalid: bool = True,
) -> npt.NDArray:
    pcds = [
        rgbd_to_point_cloud(
            depth_scale=depth_scale,
            depth=depth[j],
            color=color[j],
            intrinsics=intrinsics[j],
            extrinsics=extrinsics[j],
            crop_area=crop_area,
            remove_invalid=remove_invalid,
        )
        for j in camera_ids
    ]
    pcd_merged = np.concatenate(pcds, axis=0)
    return pcd_merged


def rgbd_to_point_cloud(
    depth: npt.NDArray,
    color: npt.NDArray,
    intrinsics: npt.NDArray,
    extrinsics: npt.NDArray | None = None,
    depth_scale: float = 1000.0,
    remove_invalid: bool = True,
    crop_area: list[list[float]] | None = None,
) -> npt.NDArray:
    """Convert depth image to point cloud. The depth image is assumed to be in uint16 format and
    the color image is assumed to be in uint8 format.

    Args:
        depth (npt.NDArray): Depth image.
        color (npt.NDArray): Color image.
        intrinsics (npt.NDArray): Camera intrinsics.
        extrinsics (npt.NDArray, optional): Camera extrinsics. Defaults to None.
        depth_scale (float, optional): Depth scale. Defaults to 1000.0.
        remove_invalid (bool, optional): Remove invalid points. Defaults to True.
        crop_area (npt.NDArray, optional): Crop area. Defaults to None.

    Returns:
        npt.NDArray: Point cloud.
    """
    if color.dtype != np.uint8:
        raise ValueError("Color image must be in uint8 format, current dtype: {}".format(color.dtype))
    if intrinsics.shape != (3, 3):
        raise ValueError(f"Intrinsics must be of shape (3, 3).  Got: {intrinsics.shape}")
    if depth.ndim != 3:
        raise ValueError(f"Depth must have 3 dimensions.  Got: {depth.shape}")
    if extrinsics is not None and extrinsics.ndim != 3:
        raise ValueError(f"Extrinsics must have 3 dimensions.  Got: {extrinsics.shape}")

    depth = depth.astype(np.float32) / depth_scale
    depth = depth.squeeze(0)
    height, width = depth.shape
    v, u = np.mgrid[:height, :width]
    z = depth
    x = (u - intrinsics[0, 2]) * z / intrinsics[0, 0]
    y = (v - intrinsics[1, 2]) * z / intrinsics[1, 1]
    point_cloud = np.stack([x, y, z], axis=-1).reshape(-1, 3)
    color = color.reshape(-1, 3) / 255.0

    if remove_invalid:
        mask_nonzero = np.any(point_cloud != [0, 0, 0], axis=1)
        mask_is_number = np.all(np.isfinite(point_cloud), axis=1)
        mask = np.logical_and(mask_nonzero, mask_is_number)
        point_cloud = point_cloud[mask]
        color = color[mask]

    if extrinsics is not None:
        extrinsics = extrinsics.squeeze(0)
        N = point_cloud.shape[0]
        homogeneous_point_cloud = np.hstack([point_cloud, np.ones((N, 1))])  # Create homogeneous coordinates
        point_cloud_transformed = (extrinsics @ homogeneous_point_cloud.T).T
        point_cloud = point_cloud_transformed[:, :3]

    if crop_area is not None:
        crop_area_np = np.array(crop_area)
        if crop_area_np.shape != (2, 3):
            raise ValueError("Crop area must be of shape (2, 3)")
        mask = np.all(np.logical_and(crop_area_np[0] <= point_cloud, point_cloud <= crop_area_np[1]), axis=1)
        point_cloud = point_cloud[mask]
        color = color[mask]

    point_cloud = np.hstack([point_cloud, color]).astype(np.float32)
    return point_cloud


# TODO: Poetry has a problem installing pytorch3d, once we fix that, we will uncomment the following code.
# def farthest_point_sampling(point_cloud: npt.NDArray, num_samples: int = 1024) -> npt.NDArray:
#     rgbd = False
#     if point_cloud.shape[-1] == 6:
#         color = point_cloud[:, 3:]
#         point_cloud = point_cloud[:, :3]
#         rgbd = True

#     point_cloud = torch.from_numpy(point_cloud).unsqueeze(0)

#     point_cloud_sampled, indicies = sample_farthest_points(point_cloud, K=num_samples)
#     point_cloud_sampled = point_cloud_sampled.squeeze().numpy()
#     if rgbd:
#         point_cloud_sampled = np.hstack([point_cloud_sampled, color[indicies.squeeze().numpy()]])
#     return point_cloud_sampled
