#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import cv2
import numpy as np
import numpy.typing as npt
from PIL import Image

from visuomotor.utils.paths import get_visuomotor_path


def draw_keypoints_on_image(
    image: npt.NDArray, tracks: npt.NDArray, visibles: npt.NDArray, color: tuple[int, int, int] = (255, 0, 0)
) -> npt.NDArray:
    """Draw keypoints on image when visibilities are true.

    Args:
        image (npt.NDArray): Image.
        tracks (npt.NDArray): Array of (x,y) positions of the keypoints to be drawn.
        visibles (npt.NDArray): Visibilities.
        color (tuple[int, int, int]): Color used to draw the keypoints, defaults to Blue(255, 0, 0)

    Returns:
        npt.NDArray: Image with keypoints drawn.
    """
    tracks = np.round(tracks)
    for track, visible in zip(tracks, visibles, strict=True):
        if visible:
            cv2.circle(image, (int(track[0]), int(track[1])), max(image.shape[0], image.shape[1]) // 256, color, -1)
    return image


def image_list_to_video(
    images: list[npt.NDArray], video_name: str, video_width: int, video_height: int, frame_rate: int = 1
) -> None:
    """Genereate video from list of images.

    Args:
        images (list[npt.NDArray]): List of images.
        video_name (str): video name to be saved in vpl/videos folder.
        video_width int: width of the video to be generated, should match images shape
        video_height int: height of the video to be generated, should match images shape
        frame_rate int: expected frame rate for the output video
    """

    # Confirm that image dimensions are expected
    first_image = images[0]
    if first_image.shape[1] != video_width or first_image.shape[0] != video_height:
        raise Exception(
            f"Dimensions of the images do not match expected output video "
            f"({first_image.shape[1]},{first_image.shape[0]}) != ({video_width},{video_height})"
        )

    video_path = get_visuomotor_path() / "videos" / f"{video_name}.avi"
    fourcc = cv2.VideoWriter_fourcc(*"MJPG")
    video = cv2.VideoWriter(str(video_path), fourcc, frame_rate, (video_width, video_height), True)
    if not video.isOpened():
        raise Exception("Failed to open video writer")

    for i in range(len(images)):
        video.write(images[i])

    video.release()


def image_list_to_gif(images: list[npt.NDArray], video_name: str) -> None:
    """Generate gif from list of images.

    Args:
        images (list[npt.NDArray]): List of images.
        video_name (str): video name to be saved in visuomotor/videos folder.
    """
    videos_path = get_visuomotor_path() / "videos"
    video_path = videos_path / f"{video_name}.gif"
    videos_path.mkdir(exist_ok=True, parents=True)
    images = [Image.fromarray(image) for image in images]
    images[0].save(video_path, save_all=True, append_images=images[1:], duration=60, loop=0)
