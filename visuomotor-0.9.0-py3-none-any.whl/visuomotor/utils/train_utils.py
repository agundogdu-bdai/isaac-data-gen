#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
from omegaconf import DictConfig

TIMESTEP_OBS = [
    "state",
    "point_cloud",
    "depth",
    "eef_pose",
    "robot0_eef_pos",
    "robot0_eef_quat",
    "robot0_gripper_qpos",
    "robot0_eef_rot_axis_angle",
    "gripper_width",
]


def validate_config(cfg: DictConfig) -> None:
    if cfg.train.max_steps is not None and cfg.train.max_epochs is not None:
        raise ValueError("Both max_steps and max_epochs are set. Please specify only one.")


def is_timestep_obs(obs_name: str) -> bool:
    return obs_name.startswith("color") or obs_name in TIMESTEP_OBS
