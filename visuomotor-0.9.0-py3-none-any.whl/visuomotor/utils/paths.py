#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from __future__ import annotations

import os
from enum import Enum
from pathlib import Path
from typing import Union
from uuid import UUID

from hydra import compose, initialize_config_dir
from omegaconf import DictConfig, ListConfig, OmegaConf

DATASET_METADATA_FILENAME = "vpl_dataset_metadata.json"
"""Filename for dataset metadata file stored alongside dataset files."""


class DataSource(Enum):
    """Enum to represent different data source types."""

    DATA_PLATFORM = "data_platform"
    """Data platform source, identified by a valid UUID (session ID)."""
    GCS = "gcs"
    """Google Cloud Storage source, identified by a uri containing gs://."""
    NFS = "nfs"
    """Network File System source, identified by a path starting with the base NFS storage path."""
    POD = "pod"
    """Ray worker pod source, identified by a path starting with the base ray worker storage path."""
    PATH = "path"
    """File system path."""

    @classmethod
    def from_string(cls, ref: str) -> DataSource:
        """Identify the data source type from a string reference. Defaults to PATH type if no other type is matched."""

        def _is_uuid(ref: str) -> bool:
            try:
                UUID(ref)
                return True
            except ValueError:
                return False

        if _is_uuid(ref):
            return DataSource.DATA_PLATFORM
        elif ref.startswith("gs://"):
            return DataSource.GCS
        elif ref.startswith(str(get_nfs_storage_path())):
            return DataSource.NFS
        elif ref.startswith(str(get_pod_storage_path())):
            return DataSource.POD
        else:
            return DataSource.PATH

    @classmethod
    def _missing_(cls, value: object) -> None:
        raise ValueError(f"Error: DataSource {value} not recognized.")


def get_features_path() -> str:
    return "visuomotor/features"


def get_base_gcs_path() -> str:
    return "visuomotor/datasets"


def get_raw_env_path() -> str:
    return "visuomotor/raw"


def get_ray_worker_data_path(local_data_source: DataSource = DataSource.POD) -> Path:
    """Get the data path when using ray train.

    Args:
        local_data_source: Local data storage source of type `DataSource`. Defaults to `DataSource.POD`.

    Returns:
        Data path of ray worker that corresponds to the local `DataSource`.
    """
    override_path = os.environ.get("DATASETS_PATH")
    if override_path:
        return Path(override_path)
    if local_data_source == DataSource.NFS:
        return get_nfs_storage_path()
    elif local_data_source == DataSource.POD:
        return get_pod_storage_path()
    else:
        print("The data location is not defined correctly, will save in pod!")
        return get_pod_storage_path()


def get_pod_storage_path() -> Path:
    return Path("/storage/pod/visuomotor/datasets/")


def get_nfs_storage_path() -> Path:
    return Path("/storage/nfs/visuomotor/datasets/")


def get_visuomotor_path() -> Path:
    return Path(__file__).resolve().parent.parent


def get_configs_path() -> Path:
    return get_visuomotor_path() / "configs"


def get_datasets_path() -> Path:
    override_path = os.environ.get("DATASETS_PATH")
    if override_path:
        return Path(override_path)

    return get_visuomotor_path() / "datasets"


def get_checkpoints_path() -> Path:
    return get_visuomotor_path() / "checkpoints"


def get_test_output_path() -> Path:
    """We have regression tests that check running a policy on a dataset
    gives us the same results as it used to. We store those expected outputs
    here.
    """
    return get_visuomotor_path() / "test_outputs"


def get_dippy_data_path(path: Path) -> Path:
    """Get the full path to local data platform data downloaded by dippy."""
    return path / "data"  # Dippy read/write delegates add a `data` prefix to the output path.


def get_config(
    config_name: str | Path,
    config_folder: Path | str | None = None,
    overrides: dict | None = None,
) -> Union[DictConfig, ListConfig]:
    if config_folder is not None:
        config_path = get_configs_path() / config_folder
    else:
        config_path = get_configs_path()

    # Use context-managed Hydra initialization to avoid leaking global state
    with initialize_config_dir(
        config_dir=str(config_path),
        version_base=None,
    ):
        config = compose(config_name=config_name)

    # allow overrides for unittests
    if overrides:
        for key in overrides.keys():
            OmegaConf.update(config, key, overrides[key])
    return config
