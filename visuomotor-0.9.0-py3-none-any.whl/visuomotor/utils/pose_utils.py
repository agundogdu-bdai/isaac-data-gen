#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import numpy as np
import numpy.typing as npt
import scipy.spatial.transform as st
import torch


def normalize(vec: npt.NDArray | torch.Tensor, eps: float = 1e-12) -> npt.NDArray | torch.Tensor:
    if isinstance(vec, torch.Tensor):
        norm = torch.linalg.vector_norm(vec, axis=-1)
        norm = torch.maximum(norm, torch.tensor(eps, device=norm.device))
    else:
        norm = np.linalg.norm(vec, axis=-1)
        norm = np.maximum(norm, eps)
    out = (vec.T / norm).T
    return out


def rot6d_to_mat(d6: npt.NDArray | torch.Tensor) -> np.ndarray | torch.Tensor:
    a1, a2 = d6[..., :3], d6[..., 3:]
    b1 = normalize(a1)
    if isinstance(d6, torch.Tensor):
        b2 = a2 - torch.sum(b1 * a2, dim=-1, keepdim=True) * b1
        b2 = normalize(b2)
        b3 = torch.cross(b1, b2, axis=-1)
        out = torch.stack((b1, b2, b3), dim=-2)
    else:
        b2 = a2 - np.sum(b1 * a2, axis=-1, keepdims=True) * b1
        b2 = normalize(b2)
        b3 = np.cross(b1, b2, axis=-1)
        out = np.stack((b1, b2, b3), axis=-2)
    return out


def mat_to_rot6d(mat: npt.NDArray) -> npt.NDArray:
    batch_dim = mat.shape[:-2]
    out = mat[..., :2, :].copy().reshape(batch_dim + (6,))
    return out


def mat_to_pose10d(mat: npt.NDArray) -> npt.NDArray:
    pos = mat[..., :3, 3]
    rotmat = mat[..., :3, :3]
    d6 = mat_to_rot6d(rotmat)
    d10 = np.concatenate([pos, d6], axis=-1)
    return d10


def pose10d_to_mat(d10: npt.NDArray | torch.Tensor) -> npt.NDArray | torch.Tensor:
    """
    Converts a 10-dimensional pose array from diffusion policy to a homogeneous (4-by-4) matrix.

    This function assumes single-arm systems where the representation is an end-effector pose and gripper position.
    Specifically, the indices are:
        - 0-2 : End effector position (xyz)
        - 3-8 : End effector orientation, in "6D rotation" format
        - 9 : Gripper position (unused by this function)
    """
    pos = d10[..., :3]
    d6 = d10[..., 3:9]
    rotmat = rot6d_to_mat(d6)
    if isinstance(d10, torch.Tensor):
        out = torch.zeros(d10.shape[:-1] + (4, 4), dtype=d10.dtype, device=d10.device)
    else:
        out = np.zeros(d10.shape[:-1] + (4, 4), dtype=d10.dtype)
    out[..., :3, :3] = rotmat
    out[..., :3, 3] = pos
    out[..., 3, 3] = 1
    return out


# See related TODO at: test_pose_utils_rotation_forward_inverse_is_identity
# def mat_from_rpy(rpy: npt.NDArray) -> npt.NDArray:
#     r = R.from_euler("xyz", rpy, degrees=False)
#     return r.as_matrix()


# TODO: Code not currently tested, see PR#226 description,
# Validate rotation logic or migrate to RotationTransformer
# def mat_from_xyzrpy(xyzrpy: npt.NDArray) -> npt.NDArray:
#     x, y, z, rx, ry, rz = xyzrpy
#     r = R.from_euler("xyz", [rx, ry, rz], degrees=False)
#     t = np.eye(4)
#     t[:3, :3] = r.as_matrix()
#     t[:3, 3] = [x, y, z]
#     return t


# TODO: Code not currently tested, see PR#226 description,
# Validate rotation logic or migrate to RotationTransformer
# def mat_to_xyzrpy(mat: npt.NDArray) -> npt.NDArray:
#     r = R.from_matrix(mat[:3, :3])
#     xyzrpy = np.concatenate([mat[:3, 3], r.as_euler("xyz")])
#     return xyzrpy


def pos_rot_to_mat(pos: np.ndarray, rot: st.Rotation) -> np.ndarray:
    """convert poses represented by xyz and rotation to 4x4 rotation matrices.

    Args:
        pos (np.ndarray): xyz position. shape = ... x 3
        rot (st.Rotation): rotation

    Returns:
        np.ndarray: ... x 4 x 4
    """
    shape = pos.shape[:-1]
    mat = np.zeros((*shape, 4, 4), dtype=pos.dtype)
    mat[..., :3, 3] = pos
    mat[..., :3, :3] = rot.as_matrix()
    mat[..., 3, 3] = 1
    return mat


def _mat_to_pos_rot(mat: np.ndarray) -> tuple[np.ndarray, st.Rotation]:
    if np.any(mat[..., 3, 3] == 0):
        raise ValueError("Division by zero. Possibly a malformed matrix.")
    pos = (mat[..., :3, 3].T / mat[..., 3, 3].T).T
    rot = st.Rotation.from_matrix(mat[..., :3, :3])
    return pos, rot


def _pos_rot_to_pose(pos: np.ndarray, rot: st.Rotation) -> np.ndarray:
    shape = pos.shape[:-1]
    pose = np.zeros((*shape, 6), dtype=pos.dtype)
    pose[..., :3] = pos
    pose[..., 3:] = rot.as_rotvec()
    return pose


def _pose_to_pos_rot(pose: np.ndarray) -> tuple[np.ndarray, st.Rotation]:
    pos = pose[..., :3]
    rot = st.Rotation.from_rotvec(pose[..., 3:])
    return pos, rot


def pose_to_mat(pose: np.ndarray) -> np.ndarray:
    """convert pose (xyz and rotation vector) to matrix

    Args:
        pose (np.ndarray): ... x 6
            ... = batch dimensions
            last dimension = concat(xyz, rotation vector)

    Returns:
        np.ndarray: ... x 4 x 4
            ... = batch dimensions
            last 2 dims specify matrix that is meant
                to be right-multiplied by euclidean points
    """
    return pos_rot_to_mat(*_pose_to_pos_rot(pose))


def convert_pose_mat_rep(
    pose_mat: np.ndarray, base_pose_mat: np.ndarray, pose_rep: str = "abs", backward: bool = False
) -> np.ndarray:
    """calculate relative pose between poses in pose_mat and base_pose_mat

    Args:
        pose_mat (np.ndarray): pose matrices. shape = num_poses x 4 x 4
        base_pose_mat (np.ndarray): reference pose matrix. shape =  1 x 4 x 4
        pose_rep (str, optional): type of calculation. Options are
            abs: no relative calculation
            relative: base_pose_mat used as reference pose matrix for all pose
                matrices in pose mat. NOTE: this is probably the one you want!
            delta: concats --> [base_pose_mat, pose_mat]. Then, calculates relative
                pose transformation between adjacent matrices.
            Defaults to "abs".
        backward (bool, optional): Defaults to False.

    Raises:
        RuntimeError: illegal value for pose_rep.

    Returns:
        np.ndarray: transformed poses.
    """
    # from UMI: pose_repr_util.py
    if not backward:
        # training transform
        if pose_rep == "abs":
            return pose_mat
        elif pose_rep == "relative":
            out = np.linalg.inv(base_pose_mat) @ pose_mat
            return out
        elif pose_rep == "delta":
            all_pos = np.concatenate([base_pose_mat[None, :3, 3], pose_mat[..., :3, 3]], axis=0)
            out_pos = np.diff(all_pos, axis=0)

            all_rot_mat = np.concatenate([base_pose_mat[None, :3, :3], pose_mat[..., :3, :3]], axis=0)
            prev_rot = np.linalg.inv(all_rot_mat[:-1])
            curr_rot = all_rot_mat[1:]
            out_rot = np.matmul(curr_rot, prev_rot)

            out = np.copy(pose_mat)
            out[..., :3, :3] = out_rot
            out[..., :3, 3] = out_pos
            return out
        else:
            raise RuntimeError(f"Unsupported pose_rep: {pose_rep}")

    else:
        # eval transform
        if pose_rep == "abs":
            return pose_mat
        elif pose_rep == "relative":
            out = base_pose_mat @ pose_mat
            return out
        elif pose_rep == "delta":
            output_pos = np.cumsum(pose_mat[..., :3, 3], axis=0) + base_pose_mat[:3, 3]

            output_rot_mat = np.zeros_like(pose_mat[..., :3, :3])
            curr_rot = base_pose_mat[:3, :3]
            for i in range(len(pose_mat)):
                curr_rot = pose_mat[i, :3, :3] @ curr_rot
                output_rot_mat[i] = curr_rot

            out = np.copy(pose_mat)
            out[..., :3, :3] = output_rot_mat
            out[..., :3, 3] = output_pos
            return out
        else:
            raise RuntimeError(f"Unsupported pose_rep: {pose_rep}")
