#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
# From https://github.com/YanjieZe/3D-Diffusion-Policy/tree/master. Licensed under MIT.

from functools import partial
from typing import Callable, Dict, TypeVar

import torch


def dict_apply(x: Dict[str, torch.Tensor], func: Callable[[torch.Tensor], torch.Tensor]) -> Dict[str, torch.Tensor]:
    result = dict()
    for key, value in x.items():
        if isinstance(value, dict):
            result[key] = dict_apply(value, func)
        else:
            result[key] = func(value)
    return result


T = TypeVar("T")


def move_tensor_to_device_apply_identity_to_anything_else(x: T, device: torch.device | str) -> T:
    """If x is a tensor, returns the tensor moved to the device. Otherwise, just returns x."""
    if isinstance(x, torch.Tensor):
        return x.to(device)  # type: ignore # pylance can't tell this satisfies the TypeVar, but it does.
    else:
        return x


def dict_to_device(d: dict, device: torch.device | str) -> dict:
    """Return a new dict where all tensors have been moved to the target device. This works on nested dicts."""
    return dict_apply(d, partial(move_tensor_to_device_apply_identity_to_anything_else, device=device))
