#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
# From https://github.com/YanjieZe/3D-Diffusion-Policy/tree/master. Licensed under MIT.

from typing import Any, Dict, Optional, Protocol, Union

import numpy as np
import torch
import torch.nn as nn

from visuomotor.utils.dict_of_tensor_mixin import DictOfTensorMixin
from visuomotor.utils.pytorch_utils import dict_apply

INPUT = Union[Dict, torch.Tensor, np.ndarray]

AVAILABLE_MODES = ["limits", "gaussian"]


def can_fit_from_stats(mode: str, stats: dict[str, Any]) -> bool:
    """True iff d stores enough statistics to construct the normalizer with the given mode."""
    if mode == "limits":
        return {"min", "max"} <= set(stats.keys())
    elif mode == "gaussian":
        return {"std", "mean"} <= set(stats.keys())
    else:
        raise ValueError(f"Unknown mode '{mode}'")


class LinearNormalizer(DictOfTensorMixin):
    avaliable_modes = ["limits", "gaussian"]

    @torch.no_grad()
    def fit(
        self,
        data: Union[Dict[str, Union[torch.Tensor, np.ndarray, Dict[str, torch.Tensor]]], torch.Tensor, np.ndarray],
        last_n_dims: int = 1,
        dtype: torch.dtype = torch.float32,
        mode: str = "limits",
        output_max: float = 1.0,
        output_min: float = -1.0,
        range_eps: float = 1e-4,
        normalize_action_pos_only: bool = False,
        normalize_action_gripper_only: bool = False,
        gripper_idxs: Optional[list[int]] = None,
        data_path_basename: Optional[str] = None,
    ) -> None:

        if "color" in data:
            self.fit_color_normalizer(data=data)

        if "action" in data:
            if normalize_action_pos_only:
                self.fit_action_pos_only_normalizer(data=data, mode=mode)
            elif normalize_action_gripper_only:
                assert gripper_idxs is not None, "You have to give the gripper idxs to normalize"
                self.fit_action_gripper_only_normalizer(data=data, mode=mode, gripper_idxs=gripper_idxs)

        if "robot0_gripper_qpos" in data:
            self.fit_robot0_gripper_qpos_normalizer(data=data)

        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict) and can_fit_from_stats(mode, value):
                    # Precomputed statistics
                    self.params_dict[key] = _fit_from_stats(
                        value,
                        dtype=dtype,
                        mode=mode,
                        output_max=output_max,
                        output_min=output_min,
                        range_eps=range_eps,
                    )
                else:
                    # Raw data
                    self.params_dict[key] = _fit(
                        value,
                        last_n_dims=last_n_dims,
                        dtype=dtype,
                        mode=mode,
                        output_max=output_max,
                        output_min=output_min,
                        range_eps=range_eps,
                    )
        else:
            # Handle single field data or statistics
            if isinstance(data, dict) and can_fit_from_stats(mode, data):
                # Precomputed statistics
                self.params_dict["_default"] = _fit_from_stats(
                    data,
                    dtype=dtype,
                    mode=mode,
                    output_max=output_max,
                    output_min=output_min,
                    range_eps=range_eps,
                )
            else:
                # Raw data
                self.params_dict["_default"] = _fit(
                    data,
                    last_n_dims=last_n_dims,
                    dtype=dtype,
                    mode=mode,
                    output_max=output_max,
                    output_min=output_min,
                    range_eps=range_eps,
                )

    def fit_color_normalizer(self, data: Dict[str, torch.Tensor]) -> None:
        """Fits color observation normalizer.

        All input color channels should be in range [0,1]. All output color channels are normalized to range [-1.1].

        Args:
            data: Dictionary of dataset statistics with 'min', 'max', 'mean', 'std' for each dataset key.
        """
        assert "color" in data, "Failed to fit color normalizer, 'color' key not found in data."
        self.params_dict["color"] = nn.ParameterDict()
        self.params_dict["color"]["scale"] = nn.Parameter(2 * torch.ones([1]), requires_grad=False)
        self.params_dict["color"]["offset"] = nn.Parameter(-1 * torch.ones([1]), requires_grad=False)
        self.params_dict["color"]["input_stats"] = nn.ParameterDict(
            {
                "min": nn.Parameter(torch.zeros([1]), requires_grad=False),
                "max": nn.Parameter(torch.ones([1]), requires_grad=False),
                "mean": nn.Parameter(0.5 * torch.ones([1]), requires_grad=False),
                "std": nn.Parameter(np.sqrt(1 / 2) * torch.ones([1]), requires_grad=False),
            }
        )
        data.pop("color")

    def fit_robot0_gripper_qpos_normalizer(self, data: Dict[str, torch.Tensor]) -> None:

        assert (
            "robot0_gripper_qpos" in data
        ), "Failed to fit robot0_gripper_qpos normalizer, 'robot0_gripper_qpos' key not found in data."

        scale, offset = self.get_scale_offset(data["robot0_gripper_qpos"])

        self.params_dict["robot0_gripper_qpos"] = nn.ParameterDict()
        self.params_dict["robot0_gripper_qpos"]["scale"] = nn.Parameter(scale, requires_grad=False)
        self.params_dict["robot0_gripper_qpos"]["offset"] = nn.Parameter(offset, requires_grad=False)
        self.params_dict["robot0_gripper_qpos"]["input_stats"] = nn.ParameterDict(
            {k: nn.Parameter(v, requires_grad=False) for k, v in data["robot0_gripper_qpos"].items()}
        )
        data.pop("robot0_gripper_qpos")

    def fit_action_pos_only_normalizer(self, data: Dict[str, torch.Tensor], mode: str) -> None:
        """Fits action position only normalizer.

        This normalizes action position using input statistics, and applies an identity normalizer for
        action rotation and gripper.

        Args:
            data: Dictionary of dataset statistics with 'min', 'max', 'mean', 'std' for each dataset key.
            mode: LinearNormalizer normalization mode, 'limits' or 'gaussian'.
        """
        assert "action" in data, "Failed to fit action position normalizer, 'action' key not found in data."
        self.fit(data={"action": data["action"]}, dtype=torch.float32, mode=mode)
        scale = self.params_dict["action"]["scale"]
        offset = self.params_dict["action"]["offset"]
        input_stats = self.params_dict["action"]["input_stats"]
        action_dims = input_stats["min"].shape[-1]
        new_scale = nn.Parameter(torch.cat([scale[:3], torch.ones([action_dims - 3])]), requires_grad=False)
        new_offset = nn.Parameter(torch.cat([offset[:3], torch.zeros([action_dims - 3])]), requires_grad=False)
        new_input_stats = nn.ParameterDict(
            {
                "min": nn.Parameter(
                    torch.cat([input_stats["min"][:3], -1 * torch.ones([action_dims - 3])]), requires_grad=False
                ),
                "max": nn.Parameter(
                    torch.cat([input_stats["max"][:3], torch.ones([action_dims - 3])]), requires_grad=False
                ),
            }
        )
        if mode == "gaussian":
            new_input_stats["mean"] = nn.Parameter(
                torch.cat([input_stats["mean"][:3], torch.zeros([action_dims - 3])]), requires_grad=False
            )
            new_input_stats["std"] = nn.Parameter(
                torch.cat([input_stats["std"][:3], torch.ones([action_dims - 3])]), requires_grad=False
            )
        self.params_dict["action"]["scale"] = new_scale
        self.params_dict["action"]["offset"] = new_offset
        self.params_dict["action"]["input_stats"] = new_input_stats

        data.pop("action")

    def fit_action_gripper_only_normalizer(
        self,
        data: Dict[str, torch.Tensor],
        mode: str,
        gripper_idxs: list[int],
    ) -> None:
        """Fits action gripper-only normalizer.

        This normalizes ONLY the gripper components of the action using input statistics,
        and applies identity normalization for all other action components (positions and rotations).

        Args:
            data: Dictionary of dataset statistics with 'min', 'max', 'mean', 'std' for each dataset key.
            mode: LinearNormalizer normalization mode, 'limits' or 'gaussian'.
            gripper_idxs: List of action indices to normalize as grippers.
        """
        assert "action" in data, "Failed to fit action gripper normalizer, 'action' key not found in data."
        self.fit(data={"action": data["action"]}, dtype=torch.float32, mode=mode)

        scale = self.params_dict["action"]["scale"]
        offset = self.params_dict["action"]["offset"]
        input_stats = self.params_dict["action"]["input_stats"]
        action_dims = input_stats["min"].shape[-1]

        new_scale = torch.ones(action_dims, dtype=torch.float32)
        new_offset = torch.zeros(action_dims, dtype=torch.float32)
        new_min = -1.0 * torch.ones(action_dims, dtype=torch.float32)
        new_max = torch.ones(action_dims, dtype=torch.float32)

        if mode == "gaussian":
            new_mean = torch.zeros(action_dims, dtype=torch.float32)
            new_std = torch.ones(action_dims, dtype=torch.float32)

        with torch.no_grad():
            for gi in gripper_idxs:
                new_scale[gi] = scale[gi]
                new_offset[gi] = offset[gi]
                new_min[gi] = input_stats["min"][gi]
                new_max[gi] = input_stats["max"][gi]
                if mode == "gaussian":
                    new_mean[gi] = input_stats["mean"][gi]
                    new_std[gi] = input_stats["std"][gi]

        new_scale = nn.Parameter(new_scale, requires_grad=False)
        new_offset = nn.Parameter(new_offset, requires_grad=False)
        new_input_stats = nn.ParameterDict(
            {
                "min": nn.Parameter(new_min, requires_grad=False),
                "max": nn.Parameter(new_max, requires_grad=False),
            }
        )
        if mode == "gaussian":
            new_input_stats["mean"] = nn.Parameter(new_mean, requires_grad=False)
            new_input_stats["std"] = nn.Parameter(new_std, requires_grad=False)

        self.params_dict["action"]["scale"] = new_scale
        self.params_dict["action"]["offset"] = new_offset
        self.params_dict["action"]["input_stats"] = new_input_stats

        data.pop("action")

    def get_scale_offset(
        self, stat: dict, output_max: int = 1, output_min: int = -1, range_eps: float = 1e-7
    ) -> tuple[float, float]:
        """-1, 1 normalization ported over from equidiff: https://github.com/bdaiinstitute/bdai/blob/c592940cb5248d4ff4c76fa4a1ffa7fda1d5d595/projects/maple/src/equidiff/common/normalize_util.py#L105"""
        input_max = stat["max"]
        input_min = stat["min"]
        input_range = input_max - input_min
        ignore_dim = input_range < range_eps
        input_range[ignore_dim] = output_max - output_min
        scale = (output_max - output_min) / input_range
        offset = output_min - scale * input_min
        offset[ignore_dim] = (output_max + output_min) / 2 - input_min[ignore_dim]

        return scale, offset

    def __call__(self, x: Union[Dict, torch.Tensor, np.ndarray]) -> torch.Tensor:
        return self.normalize(x)

    def __getitem__(self, key: str) -> "SingleFieldLinearNormalizer":
        return SingleFieldLinearNormalizer(self.params_dict[key])

    def __setitem__(self, key: str, value: "SingleFieldLinearNormalizer") -> None:
        self.params_dict[key] = value.params_dict

    def _normalize_impl(self, x: INPUT, forward: bool = True) -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        if isinstance(x, dict):
            result = dict()
            for key, value in x.items():
                params = self.params_dict[key]
                result[key] = _normalize(value, params, forward=forward)
            return result
        else:
            if "_default" not in self.params_dict:
                raise RuntimeError("Not initialized")
            params = self.params_dict["_default"]
            return _normalize(x, params, forward=forward)

    def normalize(self, x: INPUT) -> INPUT:
        return self._normalize_impl(x, forward=True)

    def unnormalize(self, x: INPUT) -> INPUT:
        return self._normalize_impl(x, forward=False)

    def get_input_stats(self) -> Dict[str, torch.Tensor]:
        if len(self.params_dict) == 0:
            raise RuntimeError("Not initialized")
        if len(self.params_dict) == 1 and "_default" in self.params_dict:
            return self.params_dict["_default"]["input_stats"]

        result = dict()
        for key, value in self.params_dict.items():
            if key != "_default":
                result[key] = value["input_stats"]
        return result

    def get_output_stats(self, key: str = "_default") -> Dict[str, Any]:
        input_stats = self.get_input_stats()
        if "min" in input_stats:
            # No dict
            return dict_apply(input_stats, self.normalize)

        result = dict()
        for key, group in input_stats.items():
            this_dict = dict()
            for name, value in group.items():
                this_dict[name] = self.normalize({key: value})[key]
            result[key] = this_dict
        return result

    def __add__(self, other_obj: Union[int, float, "LinearNormalizer"]) -> "LinearNormalizer":
        state_dict = self.state_dict()
        if isinstance(other_obj, LinearNormalizer):
            other_state_dict = other_obj.state_dict()
            for key in state_dict:
                state_dict[key] += other_state_dict[key]
        elif isinstance(other_obj, (int, float)):
            for key in state_dict:
                state_dict[key] += other_obj
        else:
            raise NotImplementedError
        new = self.__class__()
        new.load_state_dict(state_dict)
        return new

    def __radd__(self, other_obj: Union[int, float, "LinearNormalizer"]) -> "LinearNormalizer":
        return self.__add__(other_obj)

    def __mul__(self, other_obj: Union[int, float]) -> "LinearNormalizer":
        state_dict = self.state_dict()
        if isinstance(other_obj, (int, float)):
            for key in state_dict:
                state_dict[key] *= other_obj
        else:
            raise NotImplementedError
        new = self.__class__()
        new.load_state_dict(state_dict)
        return new

    def __div__(self, other_obj: Union[int, float]) -> "LinearNormalizer":
        state_dict = self.state_dict()
        if isinstance(other_obj, (int, float)):
            for key in state_dict:
                state_dict[key] /= other_obj
        else:
            raise NotImplementedError
        new = self.__class__()
        new.load_state_dict(state_dict)
        return new

    def __truediv__(self, other_obj: Union[int, float]) -> "LinearNormalizer":
        return self.__div__(other_obj)

    def save(self, path: str) -> None:
        torch.save(self.state_dict(), path)

    @classmethod
    def load(cls, path: str) -> "LinearNormalizer":
        self = cls()
        self.load_state_dict(torch.load(path))
        return self


class EquidiffLinearNormalizer(LinearNormalizer):

    @torch.no_grad()
    def fit(
        self,
        data: Union[Dict[str, Union[torch.Tensor, np.ndarray, Dict[str, torch.Tensor]]], torch.Tensor, np.ndarray],
        last_n_dims: int = 1,
        dtype: torch.dtype = torch.float32,
        mode: str = "limits",
        output_max: float = 1.0,
        output_min: float = -1.0,
        range_eps: float = 1e-4,
        normalize_action_pos_only: bool = False,
        normalize_action_gripper_only: bool = False,
        gripper_idxs: Optional[list[int]] = None,
        data_path_basename: str = "",
    ) -> None:

        if "point_cloud" in data:
            self.fit_point_cloud_normalizer(data=data)

        if "robot0_eef_pos" in data:
            self.fit_robot0_eef_pos_normalizer(data=data, data_path_basename=data_path_basename)

        super().fit(
            data=data,
            dtype=torch.float32,
            mode=mode,
            normalize_action_pos_only=normalize_action_pos_only,
            normalize_action_gripper_only=normalize_action_gripper_only,
            gripper_idxs=gripper_idxs,
        )

    def fit_point_cloud_normalizer(self, data: Dict[str, torch.Tensor]) -> None:
        """Fits point_cloud observation normalizer."""
        assert "point_cloud" in data, "Failed to fit point_cloud normalizer, 'point_cloud' key not found in data."

        xyz_magnitude = max(-min(data["point_cloud"]["min"][:3]), max(data["point_cloud"]["max"][:3]))  # noqa: PLW3301
        data["point_cloud"]["min"][:3] = -xyz_magnitude
        data["point_cloud"]["max"][:3] = xyz_magnitude
        data["point_cloud"]["mean"][:3] = 0

        scale, offset = self.get_scale_offset(data["point_cloud"])
        self.params_dict["point_cloud"] = nn.ParameterDict()
        self.params_dict["point_cloud"]["scale"] = nn.Parameter(scale, requires_grad=False)
        self.params_dict["point_cloud"]["offset"] = nn.Parameter(offset, requires_grad=False)
        self.params_dict["point_cloud"]["input_stats"] = nn.ParameterDict(
            {k: nn.Parameter(v, requires_grad=False) for k, v in data["point_cloud"].items()}
        )
        data.pop("point_cloud")

    def fit_robot0_eef_pos_normalizer(self, data: Dict[str, torch.Tensor], data_path_basename: str) -> None:

        assert (
            "robot0_eef_pos" in data
        ), "Failed to fit robot0_eef_pos normalizer, 'robot0_eef_pos' key not found in data."

        if data_path_basename.startswith(("kitchen_", "hammer_cleanup_")):
            ws_x_center = -0.2
        else:
            ws_x_center = 0.0

        ws_y_center = 0.0
        ws_center = torch.Tensor([ws_x_center, ws_y_center])

        magnitude = torch.max(
            torch.concat((data["robot0_eef_pos"]["max"][:2] - ws_center, ws_center - data["robot0_eef_pos"]["min"][:2]))
        ).item()

        data["robot0_eef_pos"]["min"][:2] = ws_center - magnitude
        data["robot0_eef_pos"]["max"][:2] = ws_center + magnitude
        data["robot0_eef_pos"]["mean"][:2] = ws_center

        scale, offset = self.get_scale_offset(data["robot0_eef_pos"])

        self.params_dict["robot0_eef_pos"] = nn.ParameterDict()
        self.params_dict["robot0_eef_pos"]["scale"] = nn.Parameter(scale, requires_grad=False)
        self.params_dict["robot0_eef_pos"]["offset"] = nn.Parameter(offset, requires_grad=False)
        self.params_dict["robot0_eef_pos"]["input_stats"] = nn.ParameterDict(
            {k: nn.Parameter(v, requires_grad=False) for k, v in data["robot0_eef_pos"].items()}
        )
        data.pop("robot0_eef_pos")


class SingleFieldLinearNormalizer(DictOfTensorMixin):
    avaliable_modes = ["limits", "gaussian"]

    @torch.no_grad()
    def fit(
        self,
        data: Union[torch.Tensor, np.ndarray],
        last_n_dims: int = 1,
        dtype: torch.dtype = torch.float32,
        mode: str = "limits",
        output_max: float = 1.0,
        output_min: float = -1.0,
        range_eps: float = 1e-4,
    ) -> None:
        self.params_dict = _fit(
            data,
            last_n_dims=last_n_dims,
            dtype=dtype,
            mode=mode,
            output_max=output_max,
            output_min=output_min,
            range_eps=range_eps,
        )

    @classmethod
    def create_fit(
        cls, data: Union[torch.Tensor, np.ndarray], **kwargs: Dict[str, Any]
    ) -> "SingleFieldLinearNormalizer":
        obj = cls()
        obj.fit(data, **kwargs)
        return obj

    @classmethod
    def create_manual(
        cls,
        scale: Union[torch.Tensor, np.ndarray],
        offset: Union[torch.Tensor, np.ndarray],
        input_stats_dict: Dict[str, Union[torch.Tensor, np.ndarray]],
    ) -> "SingleFieldLinearNormalizer":
        def to_tensor(x: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
            if not isinstance(x, torch.Tensor):
                x = torch.from_numpy(x)
            x = x.flatten()
            return x

        for x in [offset, *list(input_stats_dict.values())]:
            assert x.shape == scale.shape
            assert x.dtype == scale.dtype

        params_dict = nn.ParameterDict(
            {
                "scale": to_tensor(scale),
                "offset": to_tensor(offset),
                "input_stats": nn.ParameterDict(dict_apply(input_stats_dict, to_tensor)),
            }
        )
        return cls(params_dict)

    @classmethod
    def create_identity(cls, dtype: torch.dtype = torch.float32) -> "SingleFieldLinearNormalizer":
        scale = torch.tensor([1], dtype=dtype)
        offset = torch.tensor([0], dtype=dtype)
        input_stats_dict = {
            "min": torch.tensor([-1], dtype=dtype),
            "max": torch.tensor([1], dtype=dtype),
            "mean": torch.tensor([0], dtype=dtype),
            "std": torch.tensor([1], dtype=dtype),
        }
        return cls.create_manual(scale, offset, input_stats_dict)

    def normalize(self, x: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
        return _normalize(x, self.params_dict, forward=True)

    def unnormalize(self, x: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
        return _normalize(x, self.params_dict, forward=False)

    def get_input_stats(self) -> Any:
        return self.params_dict["input_stats"]

    def get_output_stats(self) -> Dict[str, torch.Tensor]:
        return dict_apply(self.params_dict["input_stats"], self.normalize)

    def __call__(self, x: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
        return self.normalize(x)


def _fit(
    data: Union[torch.Tensor, np.ndarray],
    last_n_dims: int = 1,
    dtype: torch.dtype = torch.float32,
    mode: str = "limits",
    output_max: float = 1.0,
    output_min: float = -1.0,
    range_eps: float = 1e-4,
) -> nn.ParameterDict:
    assert mode in ["limits", "gaussian"]
    assert last_n_dims >= 0
    assert output_max > output_min

    if isinstance(data, np.ndarray):
        data = torch.from_numpy(data)
    if dtype is not None:
        data = data.type(dtype)

    dim = 1
    if last_n_dims > 0:
        dim = np.prod(data.shape[-last_n_dims:])
    data = data.reshape(-1, dim)

    input_min, _ = data.min(dim=0)
    input_max, _ = data.max(dim=0)
    input_mean = data.mean(dim=0)
    input_std = data.std(dim=0)

    if mode == "limits":
        input_range = input_max - input_min
        ignore_dim = input_range < range_eps
        input_range[ignore_dim] = output_max - output_min
        scale = (output_max - output_min) / input_range
        offset = output_min - scale * input_min
        offset[ignore_dim] = (output_max + output_min) / 2 - input_min[ignore_dim]
    elif mode == "gaussian":
        ignore_dim = input_std < range_eps
        scale = input_std.clone()
        scale[ignore_dim] = 1
        scale = 1 / scale
        offset = -input_mean * scale

    input_stats = nn.ParameterDict({"min": input_min, "max": input_max, "mean": input_mean, "std": input_std})

    for p in input_stats.parameters():
        p.requires_grad_(False)

    this_params = nn.ParameterDict(
        {
            "scale": scale,
            "offset": offset,
            "input_stats": input_stats,
        }
    )
    for p in this_params.parameters():
        p.requires_grad_(False)
    return this_params


def _normalize(x: Union[np.ndarray, torch.Tensor], params: Dict[str, Any], forward: bool = True) -> torch.Tensor:
    assert "scale" in params
    if isinstance(x, np.ndarray):
        x = torch.from_numpy(x)
    scale = params["scale"]
    offset = params["offset"]
    x = x.to(device=scale.device, dtype=scale.dtype)
    src_shape = x.shape
    x = x.reshape(-1, scale.shape[0])
    if forward:
        x = x * scale + offset
    else:
        x = (x - offset) / scale
    x = x.reshape(src_shape)
    return x


def _fit_from_stats(
    stats: Dict[str, torch.Tensor],
    dtype: torch.dtype = torch.float32,
    mode: str = "limits",
    output_max: float = 1.0,
    output_min: float = -1.0,
    range_eps: float = 1e-4,
) -> nn.ParameterDict:
    assert mode in ["limits", "gaussian"]
    assert output_max > output_min

    if mode == "gaussian":
        input_mean = stats["mean"].to(dtype=dtype)
        input_std = stats["std"].to(dtype=dtype)

        ignore_dim = input_std < range_eps
        scale = input_std.clone()
        scale[ignore_dim] = 1
        scale = 1 / scale
        offset = -input_mean * scale

        input_stats = nn.ParameterDict(
            {
                "mean": nn.Parameter(input_mean, requires_grad=False),
                "std": nn.Parameter(input_std, requires_grad=False),
            }
        )

    elif mode == "limits":
        input_min = stats["min"].to(dtype=dtype)
        input_max = stats["max"].to(dtype=dtype)

        input_range = input_max - input_min
        ignore_dim = input_range < range_eps
        input_range[ignore_dim] = output_max - output_min
        scale = (output_max - output_min) / input_range
        offset = output_min - scale * input_min
        offset[ignore_dim] = (output_max + output_min) / 2 - input_min[ignore_dim]

        input_stats = nn.ParameterDict(
            {
                "min": nn.Parameter(input_min, requires_grad=False),
                "max": nn.Parameter(input_max, requires_grad=False),
            }
        )
    else:
        raise NotImplementedError(f"Mode '{mode}' not supported. Please use one of: {AVAILABLE_MODES}")

    this_params = nn.ParameterDict(
        {
            "scale": nn.Parameter(scale, requires_grad=False),
            "offset": nn.Parameter(offset, requires_grad=False),
            "input_stats": input_stats,
        }
    )
    return this_params


class FieldNormalizer(Protocol):
    """interface for normalizing an individual data or output field"""

    def normalize(self, x: torch.Tensor) -> torch.Tensor:
        """normalize input

        Args:
            x (torch.Tensor): some tensor

        Returns:
            torch.Tensor: normalized tensor
        """
        ...

    def unnormalize(self, y: torch.Tensor) -> torch.Tensor:
        """unnormalize input

        Args:
            y (torch.Tensor): some tensor

        Returns:
            torch.Tensor: unnormalized tensor
        """
        ...


class NullNormalizer:
    """pass through implementation of FieldNormalizer interface"""

    def normalize(self, x: torch.Tensor) -> torch.Tensor:
        """pass through x

        Args:
            x (torch.Tensor): some tensor

        Returns:
            torch.Tensor: x
        """
        return x

    def unnormalize(self, y: torch.Tensor) -> torch.Tensor:
        """pass through y

        Args:
            y (torch.Tensor): some tensor

        Returns:
            torch.Tensor: y
        """
        return y


class AffineNormalizer(torch.nn.Module):
    """rescales input tensor via (x - offset) / scale. Implements FieldNormalizer interface."""

    def __init__(self, scale: torch.Tensor | np.ndarray, offset: torch.Tensor | np.ndarray):
        """init. Uses buffer to allow lightning to memory manage constant factor.

        Args:
            scale (torch.Tensor | np.ndarray):
            offset (torch.Tensor | np.ndarray):
                normalize: y = (x - offset) / scale
                unnormalize inverts: x = (y * scale) + offset
                NOTE: dtype and shape matching is the responsibility of the caller!
        """
        super().__init__()
        if isinstance(scale, np.ndarray):
            scale = torch.tensor(scale, dtype=torch.float32)
        if torch.any(torch.abs(scale) < 1e-8):
            raise RuntimeError("Scale too close to 0")
        if isinstance(offset, np.ndarray):
            offset = torch.tensor(offset, dtype=torch.float32)
        if scale.shape != offset.shape:
            raise RuntimeError("scale shape does not match offset shape")
        self.register_buffer("_scale", scale)
        self.register_buffer("_offset", offset)

    def normalize(self, x: torch.Tensor) -> torch.Tensor:
        """normalize x by dividing scale

        Args:
            x (torch.Tensor): input tensor

        Returns:
            torch.Tensor: normalized tensor
        """
        return (x - self._offset) / self._scale

    def unnormalize(self, y: torch.Tensor) -> torch.Tensor:
        """unnormalize x by multiplying by scale

        Args:
            y (torch.Tensor): input tensor

        Returns:
            torch.Tensor: unnormalized tensor
        """
        return (y * self._scale) + self._offset
