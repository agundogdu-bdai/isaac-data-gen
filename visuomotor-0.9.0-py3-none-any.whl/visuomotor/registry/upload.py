#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
from pathlib import Path

import wandb

from visuomotor.registry.download import REGISTRY


def upload_model(model_path: str, model_name: str, project_name: str = "vpl_pretrained") -> None:
    """
    Args:
      model_path: local path to model artifact
      model_name: model name in REGISTRY
      project_name: wandb requires uploading artifacts to a project first then linking
                    to the REGISTRY, by default this will go to a "vpl_pretrained" project

    """
    run = wandb.init(project=project_name)

    logged_artifact = run.log_artifact(Path(model_path), model_name, type="model")
    run.link_artifact(artifact=logged_artifact, target_path=f"{REGISTRY}/{model_name}")
    run.finish()


def main() -> None:
    parser = argparse.ArgumentParser(description="upload to VPL REGISTRY")
    parser.add_argument("--path", type=str, help="local path to model artifact")
    parser.add_argument(
        "--name",
        type=str,
        help="model name in REGISTRY",
    )
    parser.add_argument(
        "--project",
        type=str,
        default="vpl_pretrained",
        help="project name to upload artifact",
    )
    args = parser.parse_args()
    upload_model(model_path=args.path, model_name=args.name, project_name=args.project)


if __name__ == "__main__":
    main()
