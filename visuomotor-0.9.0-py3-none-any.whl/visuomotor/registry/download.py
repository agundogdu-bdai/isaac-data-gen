#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import os

import wandb

from visuomotor.utils.paths import get_checkpoints_path

REGISTRY = "bdaii-org/wandb-registry-VPL Pretrained Models"


def download_registry_checkpoint(model_name: str, tag: str = "latest") -> str:
    """
    Download model into checkpoint path.
    """
    artifact = wandb.Api().artifact(
        f"{REGISTRY}/{model_name}:{tag}",
        type="model",
    )
    artifact_dir = artifact.download(root=get_checkpoints_path())
    checkpoint_path = os.path.join(artifact_dir, model_name)
    return checkpoint_path


def main() -> None:
    parser = argparse.ArgumentParser(description="download from VPL REGISTRY")
    parser.add_argument("--name", type=str, help="model name in REGISTRY")
    parser.add_argument(
        "--tag",
        type=str,
        default="latest",
        help="model name in REGISTRY",
    )
    args = parser.parse_args()
    checkpoint_path = download_registry_checkpoint(model_name=args.name, tag=args.tag)

    print(f"Model {args.name} downloaded to {checkpoint_path}")


if __name__ == "__main__":
    main()
