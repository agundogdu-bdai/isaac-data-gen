#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from einops import rearrange
from torch import nn


class SharedRGBEncoderWrapper:
    """
    Preprocessing of images and postprocessing of features in the case of shared encoders.
    """

    def __init__(self, encoder: nn.Module) -> None:
        self.encoder = encoder

    def forward(self, batch: dict[str, torch.Tensor], encoder_key: str = "color") -> torch.Tensor:
        """
        Args:
            batch: Must have encoder_key in batch
            encoder_key: Key with rgb images to encode

        Returns:
            torch.Tensor: postprocessed features
        """
        if encoder_key not in batch:
            raise ValueError(f"Encoder key {encoder_key} not in batch for SharedRGBEncoderWrapper.")
        inputs = self.squeeze_cameras_with_batch(batch[encoder_key])
        encoding = self.encoder(inputs)
        n_batch, n_cams = batch[encoder_key].shape[0], batch[encoder_key].shape[1]
        features = self.unsqueeze_cameras_from_batch(encoding, n_batch=n_batch, n_cams=n_cams)
        return features

    def squeeze_cameras_with_batch(self, batch_color: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Args:
            batch: Expects batch_color is format (b, n, ...), where
                   b is batch size, n is number of cameras
                   Additional dimensions could include history, channel, height, width.

        Returns:
            rgb: (BxN, ...)
        """
        rgb = rearrange(batch_color, "b n ... -> (b n) ...")
        return rgb

    def unsqueeze_cameras_from_batch(self, encoding: torch.Tensor, n_batch: int, n_cams: int) -> torch.Tensor:
        """
        Expects output of forward pass to be (bxn, ...). Reshape to be (b, n, ...)
        """
        if n_cams > 1:
            encoding = rearrange(encoding, "(b n) ... -> b n ...", b=n_batch, n=n_cams)
        return encoding
