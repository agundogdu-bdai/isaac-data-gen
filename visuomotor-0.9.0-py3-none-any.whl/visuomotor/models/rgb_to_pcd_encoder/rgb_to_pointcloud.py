#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from einops import rearrange
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.protocols import Encoder
from visuomotor.perception.depth_utils import depth_to_point_cloud_torch


@register_model(name="rgb_to_pointcloud", model_type=ModelType.ENCODER_PCD, status="beta")
class RGBToPointcloudEncoder(torch.nn.Module):
    """
    Encodes the rgb image into pixel level features, then encodes
    the point cloud using those pixel level features for each point
    """

    def __init__(self, config: DictConfig, rgb_encoder: Encoder, pcd_encoder: Encoder) -> None:
        super().__init__()
        self.rgb_encoder = rgb_encoder

        self.point_cloud_encoder = pcd_encoder

        self.config = config
        self.build_model()

    def build_model(self) -> None:
        pass

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:

        rgb = batch["color"].to(torch.float32) / 255

        num_cameras = rgb.shape[1]
        rgb = rearrange(rgb, "b n h w c -> (b n) c h w")
        image_features = self.rgb_encoder(rgb)

        image_features = rearrange(image_features, "(b n) c h w -> b n c h w", n=num_cameras)

        point_cloud = depth_to_point_cloud_torch(
            intrinsics=batch["intrinsics"],
            depth=batch["depth"],
            extrinsics=batch["extrinsics"],
            crop_area_min=self.config.crop_area.min,
            crop_area_max=self.config.crop_area.max,
            num_points=self.config.num_samples,
            features=image_features,
            filter_points=True,
        )

        pcd_features = self.point_cloud_encoder(point_cloud)

        return pcd_features
