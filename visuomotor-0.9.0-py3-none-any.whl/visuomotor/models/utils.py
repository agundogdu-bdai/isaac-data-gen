#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

"""
models/utils.py
Utility functions and classes used for stable visuomotor models
"""

from typing import Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from omegaconf import DictConfig


def with_pos_embed(tensor: torch.Tensor, pos: torch.Tensor | None = None) -> torch.Tensor:
    return tensor if pos is None else tensor + pos


def to_torch(xs: np.array, device: str) -> Tuple[torch.Tensor, ...]:
    return tuple(torch.as_tensor(x, device=device) for x in xs)


def weight_init(m: nn.Module) -> None:
    if isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight.data)
        if hasattr(m.bias, "data"):
            m.bias.data.fill_(0.0)
    elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
        gain = nn.init.calculate_gain("relu")
        nn.init.orthogonal_(m.weight.data, gain)
        if hasattr(m.bias, "data"):
            m.bias.data.fill_(0.0)


def freeze(m: nn.Module) -> None:
    for param in m.parameters():
        param.requires_grad = False

    trainable_params = []
    for name, p in m.parameters():
        if p.requires_grad:
            trainable_params.append(name)

    print(f"Trainable parameters in the encoder: {trainable_params}")


def get_activation(activation: str | None) -> torch.nn.Module:
    """Get the activation function.

    Args:
        activation (str): The activation function.

    Raises:
        ValueError: If the activation function is not supported.

    Returns:
        torch.nn.Module: Torch activaiton function.
    """
    if activation is None:
        return torch.nn.Identity()
    elif activation == "relu":
        return torch.nn.ReLU()
    elif activation == "gelu":
        return torch.nn.GELU(approximate="tanh")
    elif activation == "tanh":
        return torch.nn.Tanh()
    elif activation == "sigmoid":
        return torch.nn.Sigmoid()
    else:
        raise ValueError(f"Activation {activation} not supported")


class SpatialSoftmax(nn.Module):
    """
    Spatial Softmax Layer.

    From robomimic implementation: https://github.com/ARISE-Initiative/robomimic.git
    """

    def __init__(
        self,
        input_shape: list,
        num_kp: int = 64,  # match robomimic paper
        temperature: float = 1.0,
        learnable_temperature: bool = False,
        output_variance: bool = False,
        noise_std: float = 0.0,
    ) -> None:
        """
        Args:
            input_shape: shape of the input feature (C, H, W)
            num_kp: number of keypoints (None for not using spatialsoftmax)
            temperature: temperature term for the softmax.
            learnable_temperature: whether to learn the temperature
            output_variance: treat attention as a distribution, and compute second-order statistics to return
            noise_std: add random spatial noise to the predicted keypoints
        """
        super(SpatialSoftmax, self).__init__()
        self._in_c, self._in_h, self._in_w = input_shape  # (C, H, W)

        self.nets = torch.nn.Conv2d(self._in_c, num_kp, kernel_size=1)
        self._num_kp = num_kp

        self.learnable_temperature = learnable_temperature
        self.output_variance = output_variance
        self.noise_std = noise_std

        if self.learnable_temperature:
            # temperature will be learned
            temperature = torch.nn.Parameter(torch.ones(1) * temperature, requires_grad=True)
            self.register_parameter("temperature", temperature)
        else:
            # temperature held constant after initialization
            temperature = torch.nn.Parameter(torch.ones(1) * temperature, requires_grad=False)
            self.register_buffer("temperature", temperature)

        pos_x, pos_y = np.meshgrid(np.linspace(-1.0, 1.0, self._in_w), np.linspace(-1.0, 1.0, self._in_h))
        pos_x = torch.from_numpy(pos_x.reshape(1, self._in_h * self._in_w)).float()
        pos_y = torch.from_numpy(pos_y.reshape(1, self._in_h * self._in_w)).float()
        self.register_buffer("pos_x", pos_x)
        self.register_buffer("pos_y", pos_y)

        self.kps: tuple | None = None

    def __repr__(self) -> str:
        """Pretty print network."""
        header = format(str(self.__class__.__name__))
        return header + "(num_kp={}, temperature={}, noise={})".format(
            self._num_kp, self.temperature.item(), self.noise_std
        )

    def output_shape(self, input_shape: list) -> list[int]:
        """
        Function to compute output shape from inputs to this module.

        Args:
            input_shape: shape of input. Does not include batch dimension.
                Some modules may not need this argument, if their output does not depend
                on the size of the input, or if they assume fixed size input.

        Returns:
            out_shape: list of integers corresponding to output shape
        """
        assert len(input_shape) == 3
        assert input_shape[0] == self._in_c
        return [self._num_kp, 2]

    def forward(self, feature: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through spatial softmax layer. For each keypoint, a 2D spatial
        probability distribution is created using a softmax, where the support is the
        pixel locations. This distribution is used to compute the expected value of
        the pixel location, which becomes a keypoint of dimension 2. K such keypoints
        are created.

        Returns:
            out: mean keypoints of shape [B, K, 2], and possibly
                keypoint variance of shape [B, K, 2, 2] corresponding to the covariance
                under the 2D spatial softmax distribution
        """
        assert feature.shape[1] == self._in_c
        assert feature.shape[2] == self._in_h
        assert feature.shape[3] == self._in_w
        feature = self.nets(feature)

        # [B, K, H, W] -> [B * K, H * W] where K is number of keypoints
        feature = feature.reshape(-1, self._in_h * self._in_w)
        # 2d softmax normalization
        attention = F.softmax(feature / self.temperature, dim=-1)
        # [1, H * W] x [B * K, H * W] -> [B * K, 1] for spatial coordinate mean in x and y dimensions
        expected_x = torch.sum(self.pos_x * attention, dim=1, keepdim=True)
        expected_y = torch.sum(self.pos_y * attention, dim=1, keepdim=True)
        # stack to [B * K, 2]
        expected_xy = torch.cat([expected_x, expected_y], 1)
        # reshape to [B, K, 2]
        feature_keypoints = expected_xy.view(-1, self._num_kp, 2)

        if self.training:
            noise = torch.randn_like(feature_keypoints) * self.noise_std
            feature_keypoints += noise

        if self.output_variance:
            # treat attention as a distribution, and compute second-order statistics to return
            expected_xx = torch.sum(self.pos_x * self.pos_x * attention, dim=1, keepdim=True)
            expected_yy = torch.sum(self.pos_y * self.pos_y * attention, dim=1, keepdim=True)
            expected_xy = torch.sum(self.pos_x * self.pos_y * attention, dim=1, keepdim=True)
            var_x = expected_xx - expected_x * expected_x
            var_y = expected_yy - expected_y * expected_y
            var_xy = expected_xy - expected_x * expected_y
            # stack to [B * K, 4] and then reshape to [B, K, 2, 2] where last 2 dims are covariance matrix
            feature_covar = torch.cat([var_x, var_xy, var_xy, var_y], 1).reshape(-1, self._num_kp, 2, 2)
            feature_keypoints = (feature_keypoints, feature_covar)

        if isinstance(feature_keypoints, tuple):
            self.kps = (feature_keypoints[0].detach(), feature_keypoints[1].detach())
        else:
            self.kps = feature_keypoints.detach()
        return feature_keypoints


def build_mlp(config: DictConfig) -> torch.nn.Module:
    """Build a multi-layer perceptron (MLP) from config.

    Args:
        config: A configuration containing:
            - input_dim: Input dimension
            - hidden_dim: List of hidden layer dimensions
            - output_dim: Output dimension
            - activation: Activation function to use
            - layer_norm: Whether to use layer normalization
            - final_activation: Optional final activation function

    Returns:
        A sequential MLP model
    """
    layers = []

    # Input layer
    dims = [config.input_dim] + config.hidden_dim + [config.output_dim]

    # Build network layers
    for i in range(len(dims) - 1):
        # Add linear layer
        layers.append(torch.nn.Linear(dims[i], dims[i + 1]))

        # For all but the final layer, add activation and optional layer norm
        if i < len(dims) - 2:
            if config.layer_norm:
                layers.append(torch.nn.LayerNorm(dims[i + 1]))
            layers.append(get_activation(config.activation))

    # Add final activation if specified
    if "final_activation" in config.keys() and config.final_activation is not None:
        layers.append(get_activation(config.final_activation))

    return torch.nn.Sequential(*layers)


class LearnablePosEncoding2D(nn.Module):
    """Learnable positional encoding for 2D inputs; inspired by DETR paper"""

    def __init__(
        self,
        hidden_dim: int,
        num_pos_feats: int = 64,
        scale: float = 1.0,
    ):
        assert hidden_dim % 2 == 0, "Hidden dimension must be even"
        super().__init__()
        self.num_pos_feats = num_pos_feats
        self.scale = scale
        self.row_embed = nn.Parameter(torch.rand(num_pos_feats, hidden_dim // 2))
        self.col_embed = nn.Parameter(torch.rand(num_pos_feats, hidden_dim // 2))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """ "
        Expects inputs to be (bsz, hidden_dim, H, W)
        Returns input with positional encoding in shape (L, bsz, hidden_dim)
        """
        assert x.dim() >= 3, "Input must be at least 3D"
        H, W = x.shape[-2:]
        col = self.col_embed[:W].unsqueeze(0).repeat(H, 1, 1)
        row = self.row_embed[:H].unsqueeze(1).repeat(1, W, 1)
        pos = torch.cat([col, row], dim=-1).flatten(0, 1).unsqueeze(1)
        if x.dim() == 5:
            num_imgs = x.shape[1]
            pos = pos.repeat(num_imgs, 1, 1)
            x = x.transpose(1, 2)
        x = x.flatten(2).permute(2, 0, 1)
        return self.scale * x + pos
