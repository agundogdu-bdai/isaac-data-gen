#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

"""
Protocols for modular, plug-and-play model components in visuomotor.

Each protocol defines the required interface for a specific component (encoder,
normalizer, action head). Using protocols ensures that we have a
shared contract across multiple implementations, without forcing everything to
inherit from a heavy base class.

As a best practice, we:
1. Use explicit docstrings for usage clarity.
2. Keep method signatures minimal but expressive.
3. Encourage composition: so we can easily replace or swap out a subcomponent
   like an encoder or fusion layer in a policy.
"""

import lightning as L
from beartype.typing import Any, Mapping, Optional, Protocol, Union, runtime_checkable
from diffusers.schedulers.scheduling_ddpm import DDPMScheduler
from numpy import typing as npt
from omegaconf import DictConfig, ListConfig
from torch import Tensor, nn

from visuomotor.models.heads.unet1d.conditional_unet1d import ConditionalUnet1D
from visuomotor.utils.normalizer import LinearNormalizer


@runtime_checkable
class Encoder(Protocol):
    """
    The required interface for implementing an encoder.
    """

    __version__: str
    name: str
    config: Union[DictConfig, ListConfig]

    def __init__(self, config: Union[DictConfig, ListConfig]):
        """
        Initialize the encoder with the given configuration.
        """

    def __call__(self, features: dict[str, Tensor]) -> Tensor: ...

    def forward(self, x: Tensor | dict[str, Tensor]) -> Tensor:
        """
        Encode the input data.
        """


@runtime_checkable
class ActionHead(Protocol):
    """
    The required interface for implementing an action head.
    """

    __version__: str
    name: str
    config: Union[DictConfig, ListConfig]
    noise_scheduler: DDPMScheduler
    unet: ConditionalUnet1D

    def __init__(self, config: Union[DictConfig, ListConfig]):
        """
        Initialize the action head with the given configuration.
        """

    def __call__(self, features: Tensor | dict[str, Tensor], *args: Any, **kwargs: Any) -> Tensor: ...

    def forward(self, x: Tensor | dict[str, Tensor]) -> Tensor:
        """
        Transform input embeddings into a hidden representation.
        """

    def _fuse_features(self, features: dict[str, Tensor]) -> Tensor:
        """
        Fuse the different latent vectors to feed into the action head.
        """

    def predict_action(self, x: Tensor | dict[str, Tensor], batched: bool = False, **kwargs: Any) -> Tensor:
        """
        Generate action predictions from the processed input tensor.
        """


@runtime_checkable
class Policy(Protocol, L.LightningModule):
    """The required interface for implementing a policy.

    We also expect all policies to subclass torch.nn.Module and PyTorchModelHubMixin.
    """

    __version__: str
    name: str
    config: Union[DictConfig, ListConfig]

    # encoder: Encoder
    encoders: Optional[nn.ModuleDict]
    head: Optional[ActionHead]
    normalizer: Optional[LinearNormalizer]

    def __init__(self, config: Union[DictConfig, ListConfig], **kwargs: Any):
        """
        Args:
            config: Policy configuration class instance or None, in which case the default instantiation of the
                 configuration class is used.
        """

    def __call__(self, features: dict[str, Tensor]) -> Tensor: ...

    def forward(self, batch: dict[str, Tensor]) -> Tensor | tuple[Tensor, Tensor]:
        """
        Run the batch through the model and returns:
        - The prediction, ie the output of that forward pass of the model
        - Optionally passes through another tensor
        """

    def predict_action(self, batch: Mapping[str, Tensor | str | npt.NDArray], batched: bool = False) -> npt.NDArray:
        """Generates an action prediction based on the input data."""
