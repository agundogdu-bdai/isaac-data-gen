# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any, Tuple

import einops
import torch


class EquiLinear(torch.nn.Module):
    def __init__(self, in_type: Any, out_type: Any, bias: bool = True) -> None:
        super().__init__()
        import escnn.nn as escnn_nn

        self.in_type = in_type
        self.out_type = out_type
        self.layer = escnn_nn.Linear(in_type, out_type, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        import escnn.nn as escnn_nn

        # x: B, D or B, N, D
        B = x.shape[0]
        D = x.shape[-1]
        middle_shape = None
        reshaped = False
        if len(x.shape) > 2:
            middle_shape = x.shape[1:-1]
            x = x.reshape(-1, D)
            reshaped = True
        x = escnn_nn.GeometricTensor(x, self.in_type)
        x = self.layer(x).tensor
        if reshaped:
            x = x.reshape(B, *middle_shape, -1)
        return x


class TransitionDown(torch.nn.Module):
    def __init__(self, in_type: Any, out_type: Any, stride: int = 1, nsample: int = 16) -> None:
        super().__init__()
        import escnn.nn as escnn_nn

        self.stride, self.nsample = stride, nsample
        self.group = in_type.gspace
        self.out_type = out_type

        # Create field type directly
        field_type = escnn_nn.FieldType(self.group, [self.group.irrep(1), self.group.trivial_repr])
        self.linear = torch.nn.Sequential(
            EquiLinear(
                field_type + in_type,
                out_type,
                bias=False,
            ),
            torch.nn.LayerNorm(out_type.size),
            torch.nn.ReLU(inplace=True),
        )

    def forward(self, x: Tuple[torch.Tensor, torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor]:
        import pytorch3d.ops as pytorch3d_ops

        xyz, feats = x
        if self.stride != 1:
            n_out = xyz.shape[1] // self.stride

            _, idx = pytorch3d_ops.sample_farthest_points(xyz, K=n_out)  # B, K
            # xyz: B, N, 3, idx: B, K
            sampled_xyz = xyz.gather(1, idx.unsqueeze(-1).expand(-1, -1, 3))

            _, knn_idx, _ = pytorch3d_ops.knn_points(sampled_xyz, xyz, K=self.nsample)
            knn_xyz = pytorch3d_ops.knn_gather(xyz, knn_idx)
            knn_xyz = knn_xyz - sampled_xyz.unsqueeze(2)
            feats = pytorch3d_ops.knn_gather(feats, knn_idx)
            x_out = torch.cat([knn_xyz, feats], dim=-1)
            x_out = self.linear(x_out)
            x_out = x_out.max(dim=2).values
            x_out = (sampled_xyz, x_out)
        else:
            x_out = torch.cat([xyz, feats], dim=-1)
            x_out = self.linear(x_out)
            x_out = (xyz, x_out)
        return x_out


class EquiPointTransformerLayer(torch.nn.Module):
    def __init__(self, in_type: Any, out_type: Any, share_planes: int = 8, nsample: int = 16) -> None:
        super().__init__()
        import escnn.nn as escnn_nn

        self.in_type = in_type
        self.out_type = out_type
        self.mid_type = out_type
        self.share_planes = share_planes

        # Create field type directly
        self.w_type = escnn_nn.FieldType(in_type.gspace, len(out_type) // share_planes * [in_type.gspace.regular_repr])
        self.group = in_type.gspace
        self.nsample = nsample

        self.linear_q = EquiLinear(in_type, self.mid_type)
        self.linear_k = EquiLinear(in_type, self.mid_type)
        self.linear_v = EquiLinear(in_type, self.out_type)
        self.linear_p = torch.nn.Sequential(
            EquiLinear(escnn_nn.FieldType(self.group, [self.group.irrep(1), self.group.trivial_repr]), self.out_type),
            torch.nn.LayerNorm(self.out_type.size),
            torch.nn.ReLU(inplace=True),
            EquiLinear(self.out_type, self.out_type),
        )
        self.linear_w = torch.nn.Sequential(
            torch.nn.LayerNorm(self.out_type.size),
            torch.nn.ReLU(inplace=True),
            EquiLinear(self.mid_type, self.w_type),
            torch.nn.LayerNorm(self.w_type.size),
            torch.nn.ReLU(inplace=True),
            EquiLinear(self.w_type, self.w_type),
        )
        self.softmax = torch.nn.Softmax(dim=2)

    def forward(self, x: Tuple[torch.Tensor, torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor]:
        import pytorch3d.ops as pytorch3d_ops

        xyz, feat = x
        x_q = self.linear_q(feat)
        x_k = self.linear_k(feat)
        x_v = self.linear_v(feat)
        _, idx, _ = pytorch3d_ops.knn_points(xyz, xyz, K=self.nsample)
        x_k = pytorch3d_ops.knn_gather(x_k, idx)
        x_v = pytorch3d_ops.knn_gather(x_v, idx)
        p = pytorch3d_ops.knn_gather(xyz, idx)
        p_r = p - xyz.unsqueeze(2)
        p_r = self.linear_p(p_r)
        r_qk = (
            x_k
            - x_q.unsqueeze(2)
            + einops.reduce(p_r, "b n ns (i j) -> b n ns j", reduction="sum", j=self.mid_type.size)
        )
        w = self.linear_w(r_qk)
        w = self.softmax(w)
        x = torch.einsum(
            "b n t s i, b n t i -> b n s i",
            einops.rearrange(x_v + p_r, "b n ns (s i) -> b n ns s i", s=self.share_planes),
            w,
        )
        x = einops.rearrange(x, "b n s i -> b n (s i)")
        return (xyz, x)
