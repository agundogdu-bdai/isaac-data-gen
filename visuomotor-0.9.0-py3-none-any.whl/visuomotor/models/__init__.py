#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import ast
import importlib
import os
import pkgutil
from importlib.util import find_spec


def module_has_register_decorator(module_path: str) -> bool:
    """
    Parse the module file using AST and check if any class
    has a decorator named 'register_model'.
    """
    with open(module_path, "r", encoding="utf-8") as f:
        source = f.read()
    try:
        tree = ast.parse(source, filename=module_path)
    except SyntaxError:
        print(f"Syntax error in {module_path}, skipping...")
        return False

    for node in ast.walk(tree):
        # Check only class definitions (or even functions if needed)
        if isinstance(node, ast.ClassDef):
            for decorator in node.decorator_list:
                # Handle both cases: decorator as a call (@register_model(...)) or just a name.
                if isinstance(decorator, ast.Call):
                    func = decorator.func
                    if isinstance(func, ast.Name) and func.id == "register_model":
                        return True
                    elif isinstance(func, ast.Attribute) and func.attr == "register_model":
                        return True
                elif isinstance(decorator, ast.Name):
                    if decorator.id == "register_model":
                        return True
                elif isinstance(decorator, ast.Attribute):
                    if decorator.attr == "register_model":
                        return True
    return False


def auto_import_registered_models(package_name: str) -> None:
    """
    Automatically imports submodules under the given package that contain
    the @register_model decorator. This triggers the registration logic in them.
    """
    package = importlib.import_module(package_name)
    if not hasattr(package, "__path__"):
        # Not a package, nothing to do
        return

    for finder, modname, ispkg in pkgutil.walk_packages(package.__path__, package.__name__ + "."):  # noqa: B007
        spec = find_spec(modname)
        if spec is None or spec.origin is None:
            continue
        if os.path.basename(spec.origin) == "__init__.py":
            continue
        if module_has_register_decorator(spec.origin):
            try:
                # Import the module so its @register_model decorator runs.
                importlib.import_module(modname)
            except ModuleNotFoundError as e:
                # Missing *optional* dependency; skip this model only.
                missing = e.name
                print(f"[visuomotor.models] Skipping '{modname}' - " f"optional dependency '{missing}' not found.")
            except Exception as e:
                # Any other import error: log and continue.
                print(f"[visuomotor.models] Skipping '{modname}' (import error: {e})")


auto_import_registered_models("visuomotor.models")
