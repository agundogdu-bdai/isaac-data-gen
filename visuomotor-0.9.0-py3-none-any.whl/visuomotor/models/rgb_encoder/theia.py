#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

# pip3 install transformers==4.37.0
import torch
from omegaconf import DictConfig
from transformers import AutoModel

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="theia", model_type=ModelType.ENCODER_RGB, status="beta")
class Theia(torch.nn.Module):
    """Theia is a visual backbone built by distilling multiple foundation models"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()

        self.config = config
        self.build_model()

    def build_model(self) -> None:
        # This currently relies on loading the model from a private huggingface repo.
        # Contact @kschmeckpeper or @jshang for access
        self.model = AutoModel.from_pretrained(
            self.config.name,
            trust_remote_code=True,
            feature_neck=self.config.feature_neck,
            forward_neck=self.config.feature_neck,
        )

        self.model.translator = None

        if self.config.freeze_encoder:
            self.model.freeze_encoder()

    def output_size(self) -> int:
        return 256

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        # Assumes input is between 0 and 1
        image = (image * 255).to(torch.uint8)
        output = self.model(image)
        return output
