"""Pretrained encoders from the timm library"""

#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
import typing

import timm
import torch
import torch.nn as nn
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model

logger = logging.getLogger(__name__)


class TIMMEncoder(nn.Module):
    """thin wrapper around pretrained timm models"""

    def __init__(
        self,
        timm_model_name: str = "vit_base_patch16_clip_224",
        frozen: bool = False,
        use_pretrained: bool = True,
        build_on_init: bool = True,
        expected_embed_dim: typing.Optional[int] = None,
    ):
        """
        Args:
            timm_model_name (str, optional): name of timm model.
                Defaults to "vit_base_patch16_clip_224".
            frozen (bool, optional): whether to freeze the weights of the timm model.
                Defaults to True.
            use_pretrained (bool, optional): whether to load pretrained weight for timm model.
                Defaults to False.
            build_on_init (bool, optional): whether the model should be build on init or
                delayed till build_model() call.
                Defaults to True.
            expected_embed_dim (typing.Optional[int]):
                if specified --> sets at init time and asserts at build time
                else --> sets at build time
        """
        super().__init__()
        logger.info(f"Instantiating TIMMEncoder wrapper class for {timm_model_name}")
        self._timm_model_name = timm_model_name
        self._use_pretrained = use_pretrained
        self._frozen = frozen
        self._expected_embed_dim = expected_embed_dim
        if expected_embed_dim is not None:
            self.output_size = torch.Size([expected_embed_dim])

        # NOTE: the following attributes are required by other modules
        # self.output_size = torch.Size([timm_config.])
        self.config = {"frozen": frozen}

        if build_on_init:
            self.build_model()

    def build_model(self) -> None:
        """build timm model"""
        # TODO(zcecere): timm has support for 1-3 channels --> do we need this?
        logger.info(f"Instantiating weights for {self._timm_model_name}")
        self.model = timm.create_model(
            model_name=self._timm_model_name, pretrained=self._use_pretrained, global_pool="", num_classes=0
        )

        if self._expected_embed_dim is not None:
            if self.model.embed_dim != self._expected_embed_dim:
                raise RuntimeError(
                    f"mismatch between timm model's embed dim {self.model.embed_dim} and expected "
                    "embed dim {self._expected_embed_dim}"
                )
        else:
            self.output_size = torch.Size([self.model.embed_dim])

        if self._frozen:
            for param in self.model.parameters():
                param.requires_grad = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """forward pass:
            timm_model(x) > take cls token > flatten HW

        Args:
            x (torch.Tensor): input
                batch_size num_channels x height x width

        Returns:
            torch.Tensor: image embedding
                batch_size x embed_dim
                where embed_dim comes from timm model
        """
        features = self.model(x)
        # Extract CLS token
        # TODO(ZTC): add extra unpacking options
        B = x.shape[0]
        return torch.reshape(features[:, 0], (B, -1))


@register_model(name="vit_base_patch16_clip_224", model_type=ModelType.ENCODER_RGB, status="beta")
class VitBasePatch16Clip224(TIMMEncoder):
    def __init__(self, config: DictConfig):
        super().__init__(
            timm_model_name="vit_base_patch16_clip_224",
            frozen=config.frozen,
            use_pretrained=config.pretrained,
            expected_embed_dim=768,
        )


@register_model(name="vit_large_patch14_clip_224.openai", model_type=ModelType.ENCODER_RGB, status="beta")
class VitLargePatch14Clip224OpenAI(TIMMEncoder):
    def __init__(self, config: DictConfig):
        super().__init__(
            timm_model_name="vit_large_patch14_clip_224.openai",
            frozen=config.frozen,
            use_pretrained=config.pretrained,
            expected_embed_dim=1024,
        )
