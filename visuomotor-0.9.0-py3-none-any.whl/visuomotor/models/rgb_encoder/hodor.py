#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from omegaconf import DictConfig
from torch import nn

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.sequence_modules.attention import AttentionLayer
from visuomotor.models.utils import weight_init


@register_model(name="hodor", model_type=ModelType.ENCODER_RGB, status="beta")
class Hodor(nn.Module):
    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        self.build_model()

    def build_model(self) -> None:

        bbox_layers = [nn.LayerNorm(4), nn.Linear(4, 16), nn.ReLU(inplace=True), nn.Linear(16, 16)]
        self.bbox_layer = nn.Sequential(*bbox_layers).float()

        self.attention = nn.Sequential(*[AttentionLayer(self.config.repr_dim + 16)]).float()

        repr_head_layers = [
            nn.LayerNorm(5 * (self.config.repr_dim + 16)),
            nn.Linear(5 * (self.config.repr_dim + 16), 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
        ]
        self.repr_head = nn.Sequential(*repr_head_layers).float()
        self.apply(weight_init)

    def forward(self, obs: torch.Tensor, bbox: torch.Tensor) -> torch.Tensor:
        obs_box = self.bbox_layer(bbox.type(torch.FloatTensor))
        obs = torch.cat((obs[:, :5, :], obs_box), dim=2).type(torch.FloatTensor)
        obs = self.attention(obs)
        obs = obs.permute(1, 0, 2)
        mu = self.repr_head(obs.reshape((obs.size(0), -1)))
        return mu
