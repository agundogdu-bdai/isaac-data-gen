#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import os

import hydra
import numpy as np
import omegaconf
import torch
import torch.nn as nn
import vc_models
from einops.layers.torch import Rearrange
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="vc_encoder", model_type=ModelType.ENCODER_RGB, status="beta")
class VCEncoder(torch.nn.Module):
    def __init__(self, config: DictConfig):
        super().__init__()
        self.config = config
        self.build_model()

    def build_model(self) -> None:
        model_name = self.config.model_name

        vc_models_abs_path = os.path.dirname(os.path.abspath(vc_models.__file__))

        cfg_path = os.path.join(vc_models_abs_path, "conf", "model", f"{model_name}.yaml")
        main_model_cfg = omegaconf.OmegaConf.load(cfg_path)
        backbone, feature_dim, transform, _ = hydra.utils.call(main_model_cfg)

        spatial_tokens = len(feature_dim) > 1

        if spatial_tokens:
            num_tokens_edge = feature_dim[-1]
            if "vc1" in self.config.model_name:
                reshape_layer = nn.Identity()
            else:
                reshape_layer = Rearrange("b (h w) c -> b c h w", h=num_tokens_edge, w=num_tokens_edge)
            feature_neck = nn.Sequential(
                reshape_layer,
                nn.Conv2d(
                    feature_dim[0], self.config.feature_neck_hidden_dim, kernel_size=4, stride=2, padding=1
                ),  # 14x14 -> 7x7
                nn.ReLU(),  # just to keep the same as super class
                nn.Conv2d(
                    self.config.feature_neck_hidden_dim, self.config.feature_neck_hidden_dim, kernel_size=3, stride=2
                ),  # 7x7 -> 3x3
                nn.ReLU(),
                nn.Conv2d(
                    self.config.feature_neck_hidden_dim, self.config.feature_neck_hidden_dim, kernel_size=3, stride=1
                ),  # 3x3 -> 1x1
                nn.ReLU(),
                nn.Flatten(),
            )
            feature_dim = self.config.feature_neck_hidden_dim
        else:
            feature_neck = nn.Identity()
            feature_dim = np.prod(feature_dim)

        if self.config.freeze_encoder:
            for _, p in backbone.named_parameters():
                p.requires_grad = False

        self.encoder = nn.Sequential(backbone, feature_neck)
        self.backbone = backbone
        self.feature_neck = feature_neck
        if (
            "vc1" in self.config.model_name
            or "mvp" in self.config.model_name
            or "e_radio" in self.config.model_name
            or "r3m" in self.config.model_name
        ):
            self.transform = transform
        else:
            self.transform = None

    def output_size(self) -> int:
        print("self.config.model_name", self.config.model_name)
        if self.config.model_name == "vc1_vitl":
            return 1024
        if self.config.model_name == "r3m":
            return 2048
        if self.config.model_name == "mvpl":
            return 1024
        return 256

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        # Assumes input is between 0 and 1
        x = (image * 255).to(torch.uint8)
        if self.transform is not None:
            x = self.transform(x.to(torch.float) / 255.0)
        if self.config.model_name == "e_radio":
            # This is a hack that is only for this specific image size
            assert x.shape[-1] == 298, x.shape
            x = x[:, :, :, 21 : 21 + 224]
        output = self.encoder(x)
        return output
