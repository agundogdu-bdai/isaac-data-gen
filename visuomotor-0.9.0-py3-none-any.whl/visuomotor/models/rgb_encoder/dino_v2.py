#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import shutil
import time

import torch
import torch.nn as nn
from filelock import FileLock
from omegaconf import DictConfig
from timm import layers

from visuomotor.models.model_registry import ModelType, register_model

DINOV2_FEATURE_DIM = {
    "dinov2_vits14": 384,
    "dinov2_vitb14": 768,
    "dinov2_vitl14": 1024,
    "dinov2_vitg14": 1536,
}


@register_model(name="dino_v2", model_type=ModelType.ENCODER_RGB, status="beta")
class DINOv2(torch.nn.Module):
    """Runs DINOv2 and upsamples either with featup or with interpolation"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config
        self.feature_dim = DINOV2_FEATURE_DIM[self.config.model_name]
        self.apply_attention_pooling = self.config.apply_attention_pooling
        if self.apply_attention_pooling:
            # AttentionPoolLatent can be used to reduce the dimensionality of DinoV2 outputs.
            # This layer computes a learned vector of queries, which attends to all the spatial tokens.
            # This allows to reduce the dimensionality of the embeddings from (B, seq_len, E) to (B, E).
            # For reference:
            # https://github.com/rwightman/timm/blob/main/timm/layers/attention_pool.py.
            self.attention_pool_latent = layers.AttentionPoolLatent(
                in_features=self.feature_dim,
                out_features=self.feature_dim,
                embed_dim=self.feature_dim,
                num_heads=8,
                feat_size=None,
                mlp_ratio=4.0,
                qkv_bias=True,
                qk_norm=False,
                latent_len=1,
                latent_dim=None,
                pos_embed="",
                pool_type="token",
                norm_layer=None,  # do layernorm ?
                drop=0.1,
            )
        else:
            self.attention_pool_latent = nn.Identity()
        self.build_model()
        self.input_size = (3, *config.image_size)
        self.output_size: torch.Size = self.compute_output_size(config.n_cams)

    def build_model(self) -> None:
        # Use file locking to prevent race conditions when multiple workers try to download the same model
        cache_dir = os.path.expanduser("~/.cache/torch/hub")
        lock_file = os.path.join(cache_dir, f"dinov2_{self.config.model_name}.lock")

        # Ensure cache directory exists
        os.makedirs(cache_dir, exist_ok=True)

        # Use file lock to ensure only one worker downloads the model at a time
        with FileLock(lock_file, timeout=300):  # 5 minute timeout
            try:
                # Clear any potential corrupted cache first
                repo_cache_dir = os.path.join(cache_dir, "facebookresearch_dinov2_main")
                if os.path.exists(repo_cache_dir):
                    try:
                        shutil.rmtree(repo_cache_dir)
                    except Exception as cache_cleanup_error:
                        print(f"Warning: Could not clean cache directory: {cache_cleanup_error}")

                self.model = torch.hub.load("facebookresearch/dinov2", f"{self.config.model_name}", trust_repo=True)

            except Exception:
                time.sleep(3)
                try:
                    self.model = torch.hub.load(
                        "facebookresearch/dinov2", f"{self.config.model_name}", trust_repo=True, verbose=True
                    )
                    print(f"Successfully loaded DINOv2 model on retry: {self.config.model_name}")
                except Exception as retry_error:
                    raise RuntimeError("Failed to load DINOv2 model") from retry_error

        if self.config.frozen:
            for param in self.model.parameters():
                param.requires_grad = False

        if self.config.project_features:
            self.project_features = torch.nn.Linear(self.feature_dim, self.config.projection_dim)

    @torch.no_grad()
    def compute_output_size(self, n_cams: int) -> torch.Size:
        x = torch.zeros(n_cams, *self.input_size)
        h = self.forward(x)
        output_size = h.squeeze().shape
        return output_size

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        """Encodes the image with DINOv2, then uses FeatUp to maintain the input resolution

        Args:
            image (torch.Tensor): (B, 3, H, W) batch of input images
                - Normalized to between 0 and 1

        Returns:
            torch.Tensor: DINOv2 features of the image at the original resolution.
        """
        # Processor scales images to 224x224, if patch size is 14, the resulting feature map is 16x16
        if self.config.frozen:
            with torch.no_grad():
                outputs = self.model.forward_features(image)
        else:
            outputs = self.model.forward_features(image)
        # if self.config.return_cls_token is True, we only return the CLS token, otherwise we
        # apply self.attention_pool_latent to the spatial tokens. Note that, if self.apply_attention_pooling is False,
        # self.attention_pool_latent is nn.Identity(), and all the spatial tokens will be returned.
        features = (
            outputs["x_norm_clstoken"]
            if self.config.return_cls_token
            else self.attention_pool_latent(outputs["x_norm_patchtokens"])
        )
        if self.config.project_features:
            features = self.project_features(features)
        return features
