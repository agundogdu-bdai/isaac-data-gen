#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import math

import torch
import torch.nn as nn
import torchvision.models as models
from hydra.utils import instantiate
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model

model_latent_size = {
    "resnet18": 512,
    "resnet34": 512,
    "resnet50": 2048,
}


@register_model(name="resnet", model_type=ModelType.ENCODER_RGB, status="stable")
class ResNet(nn.Module):
    """Load ResNet"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        self.root_dir = config.get("root_dir")
        self.embedding_name = config["embedding_name"]

        self.build_model()
        self.input_size = (3, *config.image_size)
        self.output_size = self.compute_output_size(config.n_cams)

    def build_model(self) -> None:
        self.model = get_supervised_resnet(self.config)

    @torch.no_grad()
    def compute_output_size(self, n_cams: int) -> torch.Size:
        x = torch.empty(n_cams, *self.input_size)
        h = self.model.forward(x)
        return h.squeeze().shape

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass of ResNet encoder.

        Args:
            x (torch.Tensor): (B, 3, H, W) rgb input, between 0 and 1

        Returns:
            torch.Tensor: encoding of rgb input.
        """
        h = self.model.forward(x)

        # If we are using resnet_dit, we need to squeeze the last two dimensions
        # to go from (B, D, 1, 1) to (B, D)
        if len(h.shape) == 4:
            h = h.squeeze(2, 3)
        return h


def group_norm(num_groups: int) -> nn.Module:
    """Helper function to create dynamically adjusted GroupNorm layers."""
    # num_groups = num_channels // num_groups_factor
    # return nn.GroupNorm(num_groups=num_groups, num_channels=num_channels)
    return lambda num_channels: nn.GroupNorm(num_groups, num_channels)


def get_supervised_resnet(config: DictConfig) -> nn.Module:
    """
    Get supervised ResNet based on the diffusion policy paper:
    https://arxiv.org/abs/2303.04137v4
    """

    # Handle layer norm configuration
    if config.norm_layer == "groupnorm":
        norm_layer = group_norm(config.num_groups)
    # elif config.norm_layer == "batchnorm" and config.weights:
    #     # When loading a pre-trained ResNet, use FrozenBatchNorm2d instead
    #     # of normal batch norm which can produce NaNs
    #     norm_layer = FrozenBatchNorm2d
    elif config.norm_layer == "batchnorm":  # and not config.weights:
        norm_layer = nn.BatchNorm2d  # Default batchnorm
    elif config.norm_layer == "identity":
        norm_layer = nn.Identity
    else:
        raise NotImplementedError(
            f"Norm layer {config.norm_layer} not implemented. Currently support ['groupnorm', 'batchnorm', 'identity']"
        )

    torchvision_resnet = getattr(models, config.embedding_name)
    model = torchvision_resnet(norm_layer=norm_layer)

    # If we want a trained model, replace the trained BatchNorm layers with GroupNorm
    if config.weights is not None:
        if config.embedding_name == "resnet18":
            w = models.ResNet18_Weights
        elif config.embedding_name == "resnet34":
            w = models.ResNet34_Weights
        elif config.embedding_name == "resnet50":
            w = models.ResNet50_Weights
        else:
            raise NotImplementedError(f"ResNet {config.embedding_name} not implemented.")
        w = w.verify(config.weights).get_state_dict(progress=True)
        # Remove running_mean and running_var from the batchnorm layers
        # Otherwise we can't load the weights
        if norm_layer is not nn.BatchNorm2d:
            w = {k: v for k, v in w.items() if "running_mean" not in k and "running_var" not in k}
        model.load_state_dict(w)

    # Remove average pooling and final layer from ResNet
    if config.get("global_pooling", False):
        layers = list(model.children())[:-1]
    else:
        layers = list(model.children())[:-2]

    # Check if the first of the new layers is a SpatialSoftmax and add input dimension
    if len(config.output_layers) > 0 and "SpatialSoftmax" in config.output_layers[0]._target_:
        # calculate output shape of Resnet layers
        resnet_latent_size = model_latent_size[config.embedding_name]
        input_shape = (3, config.image_size[0], config.image_size[1])
        out_h = int(math.ceil(input_shape[1] / 32.0))
        out_w = int(math.ceil(input_shape[2] / 32.0))
        resnet_output_shape = [resnet_latent_size, out_h, out_w]
        config.output_layers[0].input_shape = resnet_output_shape

    # Append any specific output layers we want
    for layer in config.output_layers:
        layers.append(instantiate(layer))

    model = nn.Sequential(*layers)

    if config.freeze:
        assert (
            config.freeze and config.weights is not None
        ), "You are trying to freeze an untrained model. Are you sure about this?"
        for param in model.parameters():
            param.requires_grad = False

    return model
