#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from omegaconf import DictConfig
from r3m import load_r3m


class R3M:
    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        self.encode_stackframes = config["encode_stackframes"]

        self.build_model()

    def build_model(self) -> None:
        super().__init__()
        self.model = load_r3m("resnet50")

    @torch.no_grad()
    def infer_dims(self) -> None:
        in_sz = 224
        dummy = torch.zeros(1, 3, in_sz, in_sz).to(next(self.model.parameters()).device)
        dummy_out = self.model(dummy)
        self.enc_hid_dim = dummy_out.shape[1]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.encode_stackframes:
            num_frame = x.shape[1] // 3
            feats = [self.model(x[:, i * 3 : (i + 1) * 3, ...]) for i in range(num_frame)]
            feats = torch.cat(feats, dim=-1)
            return feats
        else:
            img = x[:, -3:, ...]
            # img = self.resize(img)
            feat = self.model(img)
            return feat
