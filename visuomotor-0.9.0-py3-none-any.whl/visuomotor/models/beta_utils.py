#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

"""
models/beta_utils.py
Utility functions and classes used for beta visuomotor models

Functions/models requiring additional dependencies that the ones already
in visuomotor will be separated to keep the set of dependencies required
to install visuomotor small
"""

from typing import Callable

import torch


def get_optimizer(name: str) -> Callable[..., torch.optim.Optimizer]:
    """Get the optimizer.

    Args:
        name (str): The name of the optimizer.

    Raises:
        ValueError: If the optimizer is not supported.

    Returns:
        torch.optim.Optimizer: Torch optimizer.
    """
    if name == "adam":
        return torch.optim.Adam
    elif name == "adamw":
        return torch.optim.AdamW
    elif name == "sgd":
        return torch.optim.SGD
    elif name in ("adam8bit", "adamw8bit"):
        try:
            import bitsandbytes as bnb  # type: ignore[import-not-found]
        except Exception as exc:
            raise RuntimeError(
                f"Requested optimizer '{name}' requires bitsandbytes, "
                f"but it is unavailable or failed to initialize: {exc}"
            ) from exc
        return bnb.optim.Adam8bit if name == "adam8bit" else bnb.optim.AdamW8bit
    else:
        raise ValueError(f"Optimizer {name} not supported")
