"""
Protocols for modular, plug-and-play model components in visuomotor.

This module provides:
1. Model registration and instantiation
2. Automatic version compatibility checking when loading models
3. Support for loading models from checkpoints and wandb artifacts

Version Compatibility:
    The model registry automatically checks for version compatibility when loading models
    from checkpoints or wandb artifacts. If a version mismatch is detected, it will display
    a clear warning with instructions on how to resolve the issue.

Example usage:
    ```python
    from visuomotor.models.model_registry import REGISTRY

    # Load with automatic version checking
    policy = REGISTRY.build_policy_from_checkpoint(checkpoint)
    policy = REGISTRY.build_policy_from_artifact_name("project/run:tag")

    # Check version compatibility
    is_compatible, checkpoint_version, current_version = \\
        REGISTRY.check_checkpoint_version_compatibility("path/to/model.ckpt")
    ```
"""

#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
import os
import time
import warnings
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, Optional, Type, TypeVar, Union

import torch
import torch.nn as nn
import wandb
from omegaconf import DictConfig, OmegaConf

import visuomotor
from visuomotor.models.protocols import ActionHead, Encoder, Policy
from visuomotor.utils.paths import get_checkpoints_path

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler()],
)

T = TypeVar("T", bound=nn.Module)
TIMEOUT_SECONDS = 600


class ModelType(Enum):
    POLICY = "policy"
    ENCODER_RGB = "encoder_rgb"
    ENCODER_STATE = "encoder_state"
    ENCODER_PCD = "encoder_pcd"
    ENCODER_TASK = "encoder_task"
    HEAD = "head"


@dataclass
class ModelConfig:
    """
    Holds metadata about a model, including name, type, and status.
    Example:
        name="mlp", type="policy", status="stable"
    """

    # TODO: Add model versioning when the model strategy is finalized
    name: str  # e.g., "mlp", "diffpo", "resnet" etc.
    class_name: str
    type: str  # e.g., "policy", "encoder", etc.
    status: str = "beta"  # e.g., "stable", "beta", "deprecated"


class ModelVersionError(UserWarning):
    """Custom warning class for model version mismatches."""


def _extract_version_from_checkpoint(checkpoint: dict) -> str | None:
    """
    Extract version information from various locations in a checkpoint.

    Args:
        checkpoint: The full checkpoint dictionary

    Returns:
        Version string if found, None otherwise
    """
    # Check top-level checkpoint for version info
    if "__version__" in checkpoint:
        return checkpoint["__version__"]

    # Check in hyper_parameters if available
    if "hyper_parameters" in checkpoint:
        config = checkpoint["hyper_parameters"]

        # Look for __version__ attribute
        if hasattr(config, "__version__"):
            return config.__version__
        # Also check if it's stored as a regular dict key
        elif isinstance(config, dict) and "__version__" in config:
            return config["__version__"]

    return None


def _check_model_version_compatibility(checkpoint: dict, checkpoint_source: str = "checkpoint") -> None:
    """
    Check version compatibility between loaded checkpoint and current codebase.

    Args:
        checkpoint: The full checkpoint dictionary or config from the checkpoint
        checkpoint_source: Description of where the checkpoint came from (for error messages)

    Warns:
        ModelVersionError: If versions are incompatible
    """
    # Extract checkpoint version from various locations
    if isinstance(checkpoint, dict) and "hyper_parameters" in checkpoint:
        # Full checkpoint dictionary
        checkpoint_version = _extract_version_from_checkpoint(checkpoint)
    else:
        # Just the config part
        checkpoint_version = None
        config = checkpoint

        # Look for __version__ attribute
        if hasattr(config, "__version__"):
            checkpoint_version = config.__version__
        # Also check if it's stored as a regular dict key
        elif isinstance(config, dict) and "__version__" in config:
            checkpoint_version = config["__version__"]

    # Get current codebase version
    current_version = visuomotor.__version__

    # Only warn if major or minor version changed (ignore patch bumps)
    def sem_mismatch(cp_ver: str, curr_ver: str) -> bool:
        try:
            cp_major, cp_minor, *_ = cp_ver.split(".")
            cu_major, cu_minor, *_ = curr_ver.split(".")
            return (cp_major != cu_major) or (cp_minor != cu_minor)
        except Exception:
            # fallback to a simple full-string check if parsing fails
            return cp_ver != curr_ver

    # If we found a checkpoint version, compare it
    if checkpoint_version is not None:
        if sem_mismatch(checkpoint_version, current_version):
            version_warning = f"""
================================================================================
                         ⚠️  VERSION MISMATCH WARNING ⚠️
================================================================================

The model you're loading was trained with a different MAJOR/MINOR version of
visuomotor! This may indicate breaking changes in model architecture or behavior.

Details:
  • Checkpoint version: {checkpoint_version} (from {checkpoint_source})
  • Current version:    {current_version} (in your codebase)
  • Compatibility check: Major.Minor versions differ

Note: Patch version differences (e.g., 1.0.0 → 1.0.1) are considered
      compatible and will not trigger this warning.

This may cause:
  • Incompatible model architectures
  • Unexpected training/inference behavior
  • Runtime errors or degraded performance

Recommended actions:
  1. Use visuomotor version {checkpoint_version} for this model
  2. Or retrain the model with current version {current_version}
  3. Check the model's documentation for compatibility notes

To fix:
  pip install visuomotor=={checkpoint_version}

================================================================================
"""
            warnings.warn(version_warning, ModelVersionError, stacklevel=3)
            logger.warning(
                f"Major/minor version mismatch detected: checkpoint={checkpoint_version}, current={current_version}"
            )
    else:
        # If no version found in checkpoint, issue a different warning
        info_warning = f"""
================================================================================
                            📋 VERSION INFO MISSING
================================================================================

Could not determine the visuomotor version used to train this model.

Current info:
  • Current version: {current_version} (in your codebase)
  • Checkpoint from: {checkpoint_source}

If you experience issues:
  • Check when the model was trained
  • Verify compatibility with current codebase
  • Consider retraining with current version

================================================================================
"""
        logger.info(info_warning)


def model_template(model_class: Type[nn.Module], config: ModelConfig) -> Callable[..., nn.Module]:
    """
    Function-based template for creating model instances from a base configuration.
    Returns a callable that instantiates the model class by merging the base configuration
    with a provided Hydra config.
    """

    def create(**kwargs: Any) -> nn.Module:
        base_dict = {
            "name": config.name,
            "class_name": config.class_name,
            "type": config.type,
            "status": config.status,
        }
        if "config" in kwargs:
            hydra_cfg = kwargs.pop("config")
            logger.debug(f"Merging base config with Hydra config for model '{config.name}'")
            base_omegaconf = OmegaConf.create(base_dict)
            final_cfg = OmegaConf.merge(base_omegaconf, hydra_cfg)
        else:
            logger.warning(f"No Hydra config provided for model '{config.name}'. Using base config only.")
            final_cfg = OmegaConf.create(base_dict)

        if "name" in kwargs:
            # Remove 'name' from kwargs to prevent got an unexpected keyword argument 'name'
            # since 'name' is used for LeRobot models
            kwargs.pop("name")
        model_instance = model_class(final_cfg, **kwargs)
        logger.info(f"Created instance of model '{config.name}'")
        return model_instance

    return create


def _safe_get_nested(obj: Any, *attrs: str, default: Any = None) -> Any:
    """Safely get nested attributes from an object or dict."""
    try:
        for attr in attrs:
            obj = obj.get(attr) if isinstance(obj, dict) else getattr(obj, attr)
        return obj
    except (AttributeError, KeyError):
        return default


class ModelRegistry:
    """
    Central REGISTRY that manages models by the key: 'type/name'.
    Supports status tracking (e.g., stable, beta) and version compatibility checking.
    """

    def __init__(self) -> None:
        self._templates: Dict[str, Callable[..., nn.Module]] = {}
        self.type_to_config: dict = {
            ModelType.POLICY: "method_name",
            ModelType.ENCODER_RGB: "name",
            ModelType.ENCODER_STATE: "name",
            ModelType.ENCODER_PCD: "name",
            ModelType.ENCODER_TASK: "name",
            ModelType.HEAD: "name",
        }

    def register(self, model_class: Type[nn.Module], config: ModelConfig) -> None:
        """
        Register a model class (e.g., MLPBehaviorCloning, ResNetEncoder) with its config.
        The REGISTRY key is '<type>/<name>'.
        """
        key = f"{config.type}/{config.name}"
        if key in self._templates:
            raise ValueError(f"Model '{key}' is already registered.")
        self._templates[key] = model_template(model_class, config)
        logger.debug(f"Registered model: {key}")

    def get_template(self, model_type: str, name: str) -> Optional[Callable[..., nn.Module]]:
        """
        Retrieve the model template (creation callable) based on type and name.
        """
        key = f"{model_type}/{name}"
        template = self._templates.get(key)
        if template:
            logger.debug(f"Retrieved model template: {key}")
        else:
            logger.error(f"Model template not found: {key}")
        return template

    def create_model(
        self,
        model_type: ModelType,
        config: dict | DictConfig,
        ds_meta: Any = None,
        **kwargs: Any,
    ) -> Union[Policy, Encoder, ActionHead]:
        """
        Retrieve a registered model template by 'type/name', then create an instance,
        with a config dictionary and optional additional kwargs.
        If config.train.load_from_checkpoint.load is True, loads from wandb artifact instead.
        """
        if model_type == ModelType.POLICY and _safe_get_nested(
            config, "train", "load_from_checkpoint", "load", default=False
        ):
            project_run_id = _safe_get_nested(config, "train", "load_from_checkpoint", "project_run_id")
            tag = _safe_get_nested(config, "train", "load_from_checkpoint", "tag")
            if project_run_id and tag:
                # Ensure ds_meta is passed through to checkpoint loading
                if ds_meta is not None:
                    kwargs["ds_meta"] = ds_meta
                return self.build_policy_from_artifact_name(
                    name=f"{project_run_id}:{tag}",
                    **kwargs,
                )

        config_key = self.type_to_config.get(model_type)
        if not config_key:
            raise ValueError(f"No configuration key mapping found for ModelType '{model_type}'.")

        # Extract the model name from the provided config
        model_name = config.get(config_key)
        if not model_name:
            raise ValueError(
                f"Configuration key '{config_key}' not found in the provided config for ModelType '{model_type}'."
            )

        # Retrieve the creation callable
        template = self.get_template(model_type.value, model_name)
        if template is None:
            raise ValueError(
                f"No registered template found {model_type}/{model_name}. "
                f"Registered models: \n {self.list_models()}"
            )

        # Combine config with other kwargs and create the model instance
        # Only include ds_meta if it's not None (needed for LeRobot models)
        creation_kwargs = {"config": config, **kwargs}
        if ds_meta is not None:
            creation_kwargs["ds_meta"] = ds_meta

        model_instance = template(**creation_kwargs)
        return model_instance

    def list_models(self, model_type: Optional[ModelType] = None) -> dict[str, Callable[..., nn.Module]]:
        """
        List all registered models or models of a specific type.
        """
        if model_type:
            return {
                key: template for key, template in self._templates.items() if key.startswith(f"{model_type.value}/")
            }
        return self._templates

    def build_policy_from_checkpoint(
        self, checkpoint: dict, load_swa_weights: bool = False, suppress_version_warning: bool = False, **kwargs: Any
    ) -> Policy:
        """
        Load a policy from a torch checkpoint.

        Args:
            checkpoint: Policy checkpoint. Typically loaded via torch.load(checkpoint_path)
            load_swa_weights: If True, load the StochasticWeightAveraging weights.
            suppress_version_warning: If True, suppress version compatibility warnings.

        Returns:
            A Policy instance with the state_dict loaded from checkpoint.

        Raises:
            ValueError: If load_swa_weights is True but the checkpoint doesn't have SWA weights.
        """
        # Check version compatibility before creating policy
        if not suppress_version_warning:
            _check_model_version_compatibility(checkpoint, "checkpoint file")

        # Create policy using the hyperparameters stored in the checkpoint
        config = DictConfig(checkpoint["hyper_parameters"])

        # For lerobot models, restore metadata from checkpoint
        if config.get("method_name") == "lerobot" and "ds_meta" not in kwargs:
            # Try to load dataset metadata from checkpoint (check new naming first, then old for backward compatibility)
            dataset_metadata = checkpoint["hyper_parameters"].get("_lerobot_dataset_metadata") or checkpoint[
                "hyper_parameters"
            ].get("_lerobot_essential_info")
            if dataset_metadata:
                from visuomotor.models.policies.lerobot_model import LeRobotPolicy

                kwargs["ds_meta"] = LeRobotPolicy.create_metadata_from_dataset_info(dataset_metadata)
                print("✅ Restored dataset metadata from checkpoint")
            else:
                print(
                    "⚠️  No stored metadata found - this checkpoint was trained before metadata storage was implemented"
                )
                print("    Inference may fail due to missing metadata. Consider retraining with current version.")

        policy = self.create_model(ModelType.POLICY, config, **kwargs)
        if load_swa_weights:
            try:
                weights = checkpoint["callbacks"]["StochasticWeightAveraging"]["average_model_state"]
                policy.load_state_dict(weights)
            except KeyError as e:
                raise ValueError(
                    "Tried to load StochasticWeightAveraging weights from a checkpoint, but they were not present. "
                    "Please either use a checkpoint with SWA weights, or set load_swa_weights=False."
                ) from e
        else:
            policy.load_state_dict(checkpoint["state_dict"])
        return policy

    def build_policy_from_artifact_name(
        self,
        name: str,
        checkpoint_device: torch.device | str | None = None,
        device: torch.device | str | None = None,
        load_swa_weights: bool = False,
        precision: str | None = None,
        retries: int = 3,
        timeout_seconds: int = TIMEOUT_SECONDS,
        suppress_version_warning: bool = False,
        **kwargs: Any,
    ) -> Policy:
        """
        Load a policy from a wandb artifact name. The checkpoint will be downloaded
        to a folder based on that name.

        Args:
            name: Wandb artifact name. For example,
                  "bdaii/toy_pick_place_real_fausto_22102024_eef_abs-tkelestemur/diffpo-30fc9b1l-jl27us5v:v2".
            checkpoint_device: Device to load weights onto. If you are getting OOM, you can set
                               this to "cpu" to reduce memory, but it is slower.
            device: Device to put policy on.
            load_swa_weights: If True, load the SWA weights.
            precision: precision to convert the weights to
            retries: number of times to try downloading the model before failing
            suppress_version_warning: If True, suppress version compatibility warnings.

        Returns:
            A Policy instance with the loaded state_dict, moved to the specified device.
        """
        if device is None:
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if checkpoint_device is None:
            checkpoint_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        elif isinstance(device, str):
            device = torch.device(device)

        download_dir = get_checkpoints_path() / name
        checkpoint_path = download_dir / "model.ckpt"
        os.makedirs(download_dir, exist_ok=True)

        # Check if we're in any distributed context (Ray or Lightning/PyTorch DDP)
        local_rank = 0
        is_distributed = False

        # First check for Ray distributed training
        try:
            import ray.train

            ctx = ray.train.get_context()
            if ctx.get_world_size() > 1:
                is_distributed = True
                local_rank = ctx.get_local_rank()
                print(f"Detected Ray distributed training: local_rank={local_rank}")
        except Exception:
            pass

        # If not Ray, check for Lightning/PyTorch DDP
        if not is_distributed and torch.distributed.is_initialized():
            is_distributed = True
            # Use LOCAL_RANK environment variable for Lightning DDP
            local_rank = int(os.environ.get("LOCAL_RANK", 0))
            print(f"Detected Lightning DDP training: local_rank={local_rank}")

        # Only download on local rank 0 (first worker on each node)
        should_download = not is_distributed or local_rank == 0

        if not should_download:
            # Wait for local rank 0 to complete download on this node
            print(f"[Local rank {local_rank}] Waiting for local rank 0 to download checkpoint...")
            completion_marker = download_dir / ".download_complete"
            start_time = time.time()
            while not completion_marker.exists() and (time.time() - start_time) < timeout_seconds:
                time.sleep(5)
            if not completion_marker.exists():
                raise RuntimeError(f"Timeout waiting for checkpoint download on local rank {local_rank}")
        else:
            print(f"Downloading checkpoint to {checkpoint_path}")
            try:
                api = wandb.Api()
                for i in range(retries):
                    try:
                        api.artifact(name).download(root=str(download_dir))
                        print(f"Downloaded checkpoint on attempt {i}.")
                        break
                    except Exception as e:
                        print(f"Tried loading checkpoint from {name}, failed attempt {i}, error: {e}")
                        if i == retries - 1:
                            raise RuntimeError(
                                f"Failed to download checkpoint from {name} after {retries} attempts"
                            ) from e
                        print("Waiting 60 seconds before the next attempt...")
                        time.sleep(60)
            finally:
                # Signal completion on this node
                if is_distributed:
                    (download_dir / ".download_complete").touch()

        # Synchronize all workers if in distributed mode
        if is_distributed and torch.distributed.is_initialized():
            torch.distributed.barrier()

        try:
            checkpoint = torch.load(checkpoint_path, map_location=torch.device(checkpoint_device), weights_only=False)
        except Exception as e:
            raise RuntimeError(f"Failed to load checkpoint at {checkpoint_path}") from e

        # Add version check before creating policy
        if not suppress_version_warning:
            _check_model_version_compatibility(checkpoint, f"wandb artifact: {name}")

        # Use the original build_policy_from_checkpoint method
        policy = self.build_policy_from_checkpoint(
            checkpoint, load_swa_weights=load_swa_weights, suppress_version_warning=True, **kwargs
        )  # Already checked above
        if precision is not None:
            policy = policy.to(precision)
        policy.to(device)  # pyright: ignore[reportAttributeAccessIssue]
        return policy

    def check_checkpoint_version_compatibility(
        self, checkpoint_path: str, raise_on_mismatch: bool = False
    ) -> tuple[bool, str | None, str]:
        """
        Check version compatibility of a checkpoint file without loading the full model.

        Args:
            checkpoint_path: Path to the checkpoint file
            raise_on_mismatch: If True, raise an exception on version mismatch instead of just warning

        Returns:
            Tuple of (is_compatible, checkpoint_version, current_version)
        """
        try:
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        except Exception as e:
            logger.error(f"Failed to load checkpoint at {checkpoint_path}: {e}")
            raise RuntimeError(f"Failed to load checkpoint at {checkpoint_path}") from e

        checkpoint_version = _extract_version_from_checkpoint(checkpoint)
        current_version = visuomotor.__version__

        # Use the same semantic version logic as in _check_model_version_compatibility
        def sem_mismatch(cp_ver: str, curr_ver: str) -> bool:
            try:
                cp_major, cp_minor, *_ = cp_ver.split(".")
                cu_major, cu_minor, *_ = curr_ver.split(".")
                return (cp_major != cu_major) or (cp_minor != cu_minor)
            except Exception:
                # fallback to a simple full-string check if parsing fails
                return cp_ver != curr_ver

        # Determine compatibility using semantic versioning
        if checkpoint_version is not None:
            is_compatible = not sem_mismatch(checkpoint_version, current_version)
        else:
            is_compatible = True  # Unknown is considered compatible

        if not is_compatible:
            if raise_on_mismatch:
                raise ModelVersionError(f"Version mismatch: checkpoint={checkpoint_version}, current={current_version}")
            else:
                _check_model_version_compatibility(checkpoint, f"checkpoint: {checkpoint_path}")

        return is_compatible, checkpoint_version, current_version


def register_model(name: str, model_type: ModelType, status: str = "stable") -> Any:
    """
    Decorator to register a model class with the REGISTRY.
    """

    def decorator(cls: Type[nn.Module]) -> Type[nn.Module]:
        if not issubclass(cls, nn.Module):
            raise TypeError("Registered model must be a subclass of torch.nn.Module")
        config = ModelConfig(name=name, class_name=cls.__name__, type=model_type.value, status=status)
        REGISTRY.register(cls, config)
        return cls

    return decorator


def get_base_config(template: Callable[..., Any]) -> ModelConfig:
    """
    Extracts the ModelConfig from the closure of the model creation callable.
    """
    if not hasattr(template, "__closure__") or template.__closure__ is None:
        raise ValueError("Template does not have a closure.")
    for cell in template.__closure__:
        if isinstance(cell.cell_contents, ModelConfig):
            return cell.cell_contents
    raise ValueError("ModelConfig not found in template's closure.")


# Create a global REGISTRY instance to be imported and used across the codebase
REGISTRY = ModelRegistry()
