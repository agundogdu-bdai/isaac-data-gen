#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from omegaconf import DictConfig
from transformers import CLIPProcessor, CLIPTextModel

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="clip_language_encoder", model_type=ModelType.ENCODER_TASK, status="beta")
class ClipLanguageEncoder(torch.nn.Module):
    """Encodes language with clip"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        self.build_model()
        self.output_size = torch.Size([self.config.output_dim])

    def build_model(self) -> None:
        self.model = CLIPTextModel.from_pretrained(self.config.model_path)
        print("model", self.model.__dict__.keys())
        self.processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:

        task_tokens = self.processor(text=batch["task_description"], return_tensors="pt", padding=True)
        task_tokens.to(batch["task_index"].device)

        outputs = self.model(**task_tokens)

        return outputs.pooler_output
