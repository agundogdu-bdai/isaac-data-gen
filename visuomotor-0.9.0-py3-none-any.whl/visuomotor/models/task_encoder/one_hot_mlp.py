#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
import torch.nn.functional as F
from omegaconf import DictConfig
from omegaconf.omegaconf import open_dict

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.utils import build_mlp


@register_model(name="one_hot_mlp", model_type=ModelType.ENCODER_TASK, status="stable")
class TaskIndexOneHotMLP(torch.nn.Module):
    """One hot and MPL encoding for task index"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        self.build_model()
        self.output_size = torch.Size([self.config.output_dim])

    def build_model(self) -> None:
        self.num_datasets = self.config.num_datasets

        with open_dict(self.config):
            self.config["input_dim"] = self.config.num_datasets

        self.encoder = build_mlp(self.config)

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        indices = batch["task_index"].long()
        indices = indices.reshape(indices.shape[0])
        max_index = torch.max(indices).item()
        assert (
            self.num_datasets > max_index
        ), f"self.num_datasets {self.num_datasets} should be greater than the maximum dataset index {max_index}"
        min_index = torch.min(indices).item()
        assert min_index >= 0, f"Task indices must be >= 0.  The min index is {min_index}."

        one_hot = F.one_hot(indices, num_classes=self.num_datasets)

        one_hot = one_hot.to(torch.float32)

        encoding = self.encoder(one_hot)

        return encoding
