#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from torch import nn


class DefaultEncoderWrapper:
    def __init__(self, encoder: nn.Module) -> None:
        self.encoder = encoder

    def forward(self, batch: dict[str, torch.Tensor], encoder_key: str) -> torch.Tensor:
        """
        Args:
            batch: entire batch as a dict
            encoder_key: key of data to encode from batch

        Returns:
            torch.Tensor: postprocessed features
        """
        inputs = self.preprocess(batch, encoder_key=encoder_key)
        features = self.encoder(inputs)
        return features

    def preprocess(self, batch: dict[str, torch.Tensor], encoder_key: str) -> torch.Tensor | dict[str, torch.Tensor]:
        """
        If batch has encoder key in it, returns specific tensor, otherwise returns whole batch
        """
        if encoder_key in batch:
            inputs = batch[encoder_key]
        else:
            inputs = batch
        return inputs
