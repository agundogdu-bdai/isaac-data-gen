#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

"""
This file contains the DiT (Diffusion Transformer) model implementation.

The DiT model is a transformer-based model that uses a diffusion process to predict a sequence of actions.
It is based on the DiT model proposed in the paper "Diffusion Transformer" by Sudeep Dasari et al.
https://github.com/sudeepdasari/dit-policy
"""

import copy

import numpy as np
import torch
import torch.nn as nn

from visuomotor.models.utils import get_activation, with_pos_embed


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000) -> None:
        super().__init__()
        # Compute the positional encodings once in log space
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32) * -(torch.log(torch.tensor(10000.0)) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)  # Shape: [max_len, 1, d_model]
        # self.register_buffer("pe", pe)
        self.pe = nn.Parameter(pe, requires_grad=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor of shape (seq_len, batch_size, d_model)

        Returns:
            Tensor of shape (seq_len, batch_size, d_model) with positional encodings added
        """
        pe = self.pe[: x.shape[0]]
        pe = pe.repeat((1, x.shape[1], 1))
        return pe


class TimeNetwork(nn.Module):
    def __init__(self, time_dim: int, out_dim: int, learnable_w: bool = False) -> None:
        assert time_dim % 2 == 0, "time_dim must be even!"
        half_dim = int(time_dim // 2)
        super().__init__()

        w = np.log(10000) / (half_dim - 1)
        w = torch.exp(torch.arange(half_dim) * -w).float()
        self.register_parameter("w", nn.Parameter(w, requires_grad=learnable_w))

        self.out_net = nn.Sequential(nn.Linear(time_dim, out_dim), nn.SiLU(), nn.Linear(out_dim, out_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert len(x.shape) == 1, "assumes 1d input timestep array"
        x = x[:, None] * self.w[None]
        x = torch.cat((torch.cos(x), torch.sin(x)), dim=1)
        return self.out_net(x)


class SelfAttnEncoder(nn.Module):
    def __init__(
        self, d_model: int, nhead: int = 8, dim_feedforward: int = 2048, dropout: float = 0.1, activation: str = "gelu"
    ) -> None:
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.activation = get_activation(activation)

    def forward(self, src: torch.Tensor, pos: torch.Tensor) -> torch.Tensor:
        q = k = with_pos_embed(src, pos)
        src2, _ = self.self_attn(q, k, value=src, need_weights=False)
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.linear2(self.dropout2(self.activation(self.linear1(src))))
        src = src + self.dropout3(src2)
        src = self.norm2(src)
        return src

    def reset_parameters(self) -> None:
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)


class ShiftScaleMod(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.act = nn.SiLU()
        self.scale = nn.Linear(dim, dim)
        self.shift = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        c = self.act(c)
        return x * self.scale(c).unsqueeze(0) + self.shift(c).unsqueeze(0)

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.scale.weight)
        nn.init.xavier_uniform_(self.shift.weight)
        nn.init.zeros_(self.scale.bias)
        nn.init.zeros_(self.shift.bias)


class ZeroScaleMod(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.act = nn.SiLU()
        self.scale = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        c = self.act(c)
        return x * self.scale(c).unsqueeze(0)

    def reset_parameters(self) -> None:
        nn.init.zeros_(self.scale.weight)
        nn.init.zeros_(self.scale.bias)


class DiTDecoder(nn.Module):
    def __init__(
        self, d_model: int, nhead: int = 8, dim_feedforward: int = 2048, dropout: float = 0.1, activation: str = "gelu"
    ) -> None:

        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.activation = get_activation(activation)

        # Create modulation layers
        self.attn_mod1 = ShiftScaleMod(d_model)
        self.attn_mod2 = ZeroScaleMod(d_model)
        self.mlp_mod1 = ShiftScaleMod(d_model)
        self.mlp_mod2 = ZeroScaleMod(d_model)

    def forward(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # Process the conditioning vector
        # Average over seq_len dimension (E, B, H) -> (B, H)
        cond = torch.mean(cond, dim=0)
        cond = cond + t  # [B, hidden_dim]

        x2 = self.attn_mod1(self.norm1(x), cond)
        x2, _ = self.self_attn(x2, x2, x2, need_weights=False)
        x = self.attn_mod2(self.dropout1(x2), cond) + x

        x2 = self.mlp_mod1(self.norm2(x), cond)
        x2 = self.linear2(self.dropout2(self.activation(self.linear1(x2))))
        x2 = self.mlp_mod2(self.dropout3(x2), cond)
        return x + x2

    def reset_parameters(self) -> None:
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
        for s in (self.attn_mod1, self.attn_mod2, self.mlp_mod1, self.mlp_mod2):
            if hasattr(s, "reset_parameters"):
                s.reset_parameters()
            else:
                raise NotImplementedError("Modulation layer must have a reset_parameters method.")


class FinalLayer(nn.Module):
    def __init__(self, hidden_size: int, out_size: int) -> None:
        super().__init__()
        self.norm_final = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.linear = nn.Linear(hidden_size, out_size, bias=True)
        self.adaLN_modulation = nn.Sequential(nn.SiLU(), nn.Linear(hidden_size, 2 * hidden_size, bias=True))

    def forward(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # Process the conditioning vector
        cond = torch.mean(cond, axis=0)  # Average over seq_len dimension
        cond = cond + t  # [B, hidden_dim]

        shift, scale = self.adaLN_modulation(cond).chunk(2, dim=1)
        x = x * scale.unsqueeze(0) + shift.unsqueeze(0)
        x = self.linear(x)
        return x.transpose(0, 1)

    def reset_parameters(self) -> None:
        for p in self.parameters():
            nn.init.zeros_(p)


class TransformerEncoder(nn.Module):
    def __init__(self, base_module: nn.Module, num_layers: int) -> None:
        super().__init__()
        self.layers = nn.ModuleList([copy.deepcopy(base_module) for _ in range(num_layers)])

        for layer in self.layers:
            if hasattr(layer, "reset_parameters"):
                layer.reset_parameters()
            else:
                raise NotImplementedError("Encoder layer must have a reset_parameters method.")

    def forward(self, src: torch.Tensor, pos: torch.Tensor) -> list[torch.Tensor]:
        x = src
        outputs = []
        for _, layer in enumerate(self.layers):
            x = layer(x, pos)
            outputs.append(x)
        return outputs


class TransformerDecoder(nn.Module):
    def __init__(self, base_module: nn.Module, num_layers: int) -> None:
        super().__init__()
        self.layers = nn.ModuleList([copy.deepcopy(base_module) for _ in range(num_layers)])

        for layer in self.layers:
            if hasattr(layer, "reset_parameters"):
                layer.reset_parameters()
            else:
                raise NotImplementedError("Decoder layer must have a reset_parameters method.")

    def forward(self, x: torch.Tensor, t: torch.Tensor, all_conds: list[torch.Tensor]) -> torch.Tensor:
        """Forward pass through the decoder.

        Args:
            x (torch.Tensor): Input tensor of shape (action_horizon, batch_size, d_model)
            t (torch.Tensor): Time tensor of shape (batch_size, d_model)
            all_conds (list[torch.Tensor]): Conditioning tensors of shape (num_layers, seq_len, batch_size, d_model)

        Returns:
            torch.Tensor: Output tensor of shape (seq_len, batch_size, d_model)
        """
        assert len(all_conds) == len(self.layers), "Number of conditions must match number of layers"
        for layer, cond in zip(self.layers, all_conds, strict=False):
            x = layer(x, t, cond)
        return x


class DiTModel(nn.Module):
    def __init__(
        self,
        action_dim: int,
        action_seq_len: int,
        time_dim: int = 256,
        hidden_dim: int = 512,
        num_blocks: int = 6,
        dropout: float = 0.1,
        dim_feedforward: int = 2048,
        nhead: int = 8,
        activation: str = "gelu",
    ) -> None:
        super().__init__()

        self.action_dim = action_dim
        self.action_seq_len = action_seq_len

        # Positional encoding blocks
        self.enc_pos = PositionalEncoding(hidden_dim)
        self.register_parameter(
            "dec_pos",
            nn.Parameter(torch.empty(action_seq_len, 1, hidden_dim), requires_grad=True),
        )
        nn.init.xavier_uniform_(self.dec_pos.data)

        # Input encoder MLPs
        self.time_net = TimeNetwork(time_dim, hidden_dim)
        self.action_proj = nn.Sequential(
            nn.Linear(action_dim, action_dim),
            nn.GELU(approximate="tanh"),
            nn.Linear(action_dim, hidden_dim),
        )

        # Encoder blocks
        encoder_module = SelfAttnEncoder(
            hidden_dim,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation=activation,
        )
        self.encoder = TransformerEncoder(encoder_module, num_blocks)

        # Decoder blocks
        decoder_module = DiTDecoder(
            hidden_dim,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation=activation,
        )
        self.decoder = TransformerDecoder(decoder_module, num_blocks)

        # Final output layer
        self.eps_out = FinalLayer(hidden_dim, action_dim)

        print("Number of DiT parameters: {:e}".format(sum(p.numel() for p in self.parameters())))

    def forward(self, noise_actions: torch.Tensor, time: torch.Tensor, tokens: torch.Tensor) -> torch.Tensor:
        # noise_actions: [B, action_seq_len, action_dim], time: [B], tokens: [B, E, H]

        # Encoder
        enc_cache = self.forward_enc(tokens)  # List of encoder outputs

        # Decoder
        output = self.forward_dec(noise_actions, time, enc_cache)  # [B, action_seq_len, action_dim]

        return output

    def forward_enc(self, tokens: torch.Tensor) -> list:
        # tokens: [B, E, H]
        tokens = tokens.transpose(0, 1)  # [E, B, H]
        pos = self.enc_pos(tokens)

        # Process through encoder
        enc_cache = self.encoder(tokens, pos)

        return enc_cache

    def forward_dec(self, noise_actions: torch.Tensor, time: torch.Tensor, enc_cache: list) -> torch.Tensor:
        # noise_actions: [B, action_seq_len, action_dim], time: [B] tokens: [E, B, H]
        time_enc = self.time_net(time)  # time_enc: [B, hidden_dim]
        # Project actions
        ac_tokens = self.action_proj(noise_actions)  # ac_tokens [B, action_seq_len, hidden_dim]
        ac_tokens = ac_tokens.transpose(0, 1)  # [action_seq_len, B, hidden_dim]

        dec_in = ac_tokens + self.dec_pos  # [action_seq_len, B, hidden_dim]

        # Apply decoder
        dec_out = self.decoder(dec_in, time_enc, enc_cache)  # [action_seq_len, B, hidden_dim]

        # Apply final output layer
        output = self.eps_out(dec_out, time_enc, enc_cache[-1])  # [B, action_seq_len, action_dim]
        return output
