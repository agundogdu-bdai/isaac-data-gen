#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
# Porting over of `EquiDiffusionUNetFrameAverage` from Maple equidiff originally at
# https://github.com/bdaiinstitute/bdai/blob/76e0dea88307e9a300edb3e589dbd4dc5a41d3ed/projects/maple/src/equidiff/models/diffusion/equi_conditional_unet1d.py#L228


from typing import Any, List, Union

import numpy as np
import torch
from einops import rearrange, repeat

from visuomotor.models.heads.unet1d.conditional_unet1d import ConditionalUnet1D


class EquiDiffusionUNetFrameAverage(torch.nn.Module):

    def __init__(
        self,
        input_dim: int,
        local_cond_dim: int | None,
        global_cond_dim: int,
        diffusion_step_embed_dim: int,
        down_dims: List[int],
        kernel_size: int,
        n_groups: int,
        condition_type: str,
        N: int,
        use_down_condition: bool = True,
        use_mid_condition: bool = True,
        use_up_condition: bool = True,
    ) -> None:

        super().__init__()
        import escnn.group as escnn_group
        import escnn.gspaces as escnn_gspaces

        self.N = N
        self.group = escnn_gspaces.no_base_space(escnn_group.CyclicGroup(self.N))
        self.order = self.N
        self.unet = ConditionalUnet1D(
            input_dim=input_dim,
            local_cond_dim=local_cond_dim,
            global_cond_dim=global_cond_dim * N,
            diffusion_step_embed_dim=diffusion_step_embed_dim,
            down_dims=down_dims,
            kernel_size=kernel_size,
            n_groups=n_groups,
            condition_type=condition_type,
            use_down_condition=use_down_condition,
            use_mid_condition=use_mid_condition,
            use_up_condition=use_up_condition,
        )

        self.trans = torch.zeros([self.N, 2, 2])
        self.trans_inv = torch.zeros([self.N, 2, 2])
        for i in range(self.N):
            self.trans[i] = torch.tensor(
                [
                    [np.cos(2 * i * np.pi / self.N), -np.sin(2 * i * np.pi / self.N)],
                    [np.sin(2 * i * np.pi / self.N), np.cos(2 * i * np.pi / self.N)],
                ]
            )
            self.trans_inv[i] = torch.tensor(
                [
                    [np.cos(-2 * i * np.pi / self.N), -np.sin(-2 * i * np.pi / self.N)],
                    [np.sin(-2 * i * np.pi / self.N), np.cos(-2 * i * np.pi / self.N)],
                ]
            )

    def getOutFieldType(self) -> Any:
        import escnn.nn as escnn_nn

        return escnn_nn.FieldType(
            self.group,
            4 * [self.group.irrep(1)] + 2 * [self.group.trivial_repr],  # 8  # 2
        )

    def getOutput(self, conv_out: torch.Tensor) -> torch.Tensor:
        xy = conv_out[:, 0:2]
        cos1 = conv_out[:, 2:3]
        sin1 = conv_out[:, 3:4]
        cos2 = conv_out[:, 4:5]
        sin2 = conv_out[:, 5:6]
        cos3 = conv_out[:, 6:7]
        sin3 = conv_out[:, 7:8]
        z = conv_out[:, 8:9]
        g = conv_out[:, 9:10]

        action = torch.cat((xy, z, cos1, cos2, cos3, sin1, sin2, sin3, g), dim=1)
        return action

    def getActionGeometricTensor(self, act: torch.Tensor) -> Any:
        import escnn.nn as escnn_nn

        batch_size = act.shape[0]
        xy = act[:, 0:2]
        z = act[:, 2:3]
        rot = act[:, 3:9]
        g = act[:, 9:]

        cat = torch.cat(
            (
                xy.reshape(batch_size, 2),
                rot[:, 0].reshape(batch_size, 1),
                rot[:, 3].reshape(batch_size, 1),
                rot[:, 1].reshape(batch_size, 1),
                rot[:, 4].reshape(batch_size, 1),
                rot[:, 2].reshape(batch_size, 1),
                rot[:, 5].reshape(batch_size, 1),
                z.reshape(batch_size, 1),
                g.reshape(batch_size, 1),
            ),
            dim=1,
        )
        return escnn_nn.GeometricTensor(cat, self.getOutFieldType())

    def forward(
        self,
        sample: torch.Tensor,
        timestep: Union[torch.Tensor, float, int],
        local_cond: torch.Tensor | None = None,
        global_cond: torch.Tensor | None = None,
        **kwargs: Any,
    ) -> torch.Tensor:
        """
        Args:
            sample: (B,T,input_dim)
            timestep: (B,) or int, diffusion step
            local_cond: (B,T,local_cond_dim)
            global_cond: (B,global_cond_dim)

        Returns:
            output: (B, T, input_dim)
        """
        B, T = sample.shape[:2]
        expanded = repeat(sample, "b t d -> (b t) f d", f=self.order)
        trans_sample = expanded.clone()
        trans_inv = self.trans_inv.to(expanded.device).unsqueeze(0)
        trans_sample[:, :, 0:2] = (trans_inv @ expanded[:, :, 0:2].unsqueeze(-1)).squeeze(-1)
        trans_sample[:, :, [3, 6]] = (trans_inv @ expanded[:, :, [3, 6]].unsqueeze(-1)).squeeze(-1)
        trans_sample[:, :, [4, 7]] = (trans_inv @ expanded[:, :, [4, 7]].unsqueeze(-1)).squeeze(-1)
        trans_sample[:, :, [5, 8]] = (trans_inv @ expanded[:, :, [5, 8]].unsqueeze(-1)).squeeze(-1)
        trans_sample = rearrange(trans_sample, "(b t) f d -> (b f) t d", t=T)

        if type(timestep) == torch.Tensor and len(timestep.shape) == 1:
            timestep = repeat(timestep, "b -> (b f)", f=self.order)
        if local_cond is not None:
            local_cond = rearrange(local_cond, "b t (c f) -> (b f) t c", f=self.order)
        if global_cond is not None:
            global_cond = rearrange(global_cond, "b (c f) -> b c f", f=self.order)
            expanded = global_cond.unsqueeze(1).expand(-1, self.order, -1, -1)
            indices = (torch.arange(self.order)[:, None] - torch.arange(self.order)) % self.order
            indices = indices.to(expanded.device)
            indices = indices.unsqueeze(0).unsqueeze(2)  # Shape: [1, 1, F, 1, F]
            indices = indices.expand(B, -1, expanded.shape[-2], -1)
            gathered = torch.gather(expanded, 3, indices)
            global_cond = rearrange(gathered, "b f1 c f2 -> (b f1) (c f2)")
        out = self.unet(trans_sample, timestep, local_cond, global_cond, **kwargs)

        out = rearrange(out, "(b f) t d -> (b t) f d", f=self.order)
        trans = self.trans.to(out.device).unsqueeze(0)
        out[:, :, 0:2] = (trans @ out[:, :, 0:2].unsqueeze(-1)).squeeze(-1)
        out[:, :, [3, 6]] = (trans @ out[:, :, [3, 6]].unsqueeze(-1)).squeeze(-1)
        out[:, :, [4, 7]] = (trans @ out[:, :, [4, 7]].unsqueeze(-1)).squeeze(-1)
        out[:, :, [5, 8]] = (trans @ out[:, :, [5, 8]].unsqueeze(-1)).squeeze(-1)
        out = rearrange(out, "(b t) f d -> b f t d", t=T)
        return out.mean(1)
