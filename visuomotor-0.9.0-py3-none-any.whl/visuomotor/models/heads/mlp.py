#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any

import torch
import torch.nn.functional as F
from omegaconf import DictConfig
from omegaconf.omegaconf import open_dict

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.utils import build_mlp


class MLPBaseActionHead(torch.nn.Module):
    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config
        self.build_model()

    def build_model(self) -> None:
        with open_dict(self.config):
            self.config["output_dim"] = self.config.action_dim * self.config.horizon
        self.net = build_mlp(self.config)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Flatten fusion: flattens all input embeddings and concatenates them.
        This replaces the separate flatten fusion layer.

        Args:
            features: Dictionary mapping encoder names to their output tensors

        Returns:
            Concatenated and flattened feature tensor
        """
        # Assume that everything is batch-first
        latents = [value.flatten(1) for value in features.values()]

        # concatenate all embeddings
        latent = torch.cat(latents, dim=1)

        return latent

    def forward(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        # Handle backward compatibility: if input is a tensor (from fusion), use it directly
        if isinstance(features, torch.Tensor):
            x = features
        else:
            # New path: fuse features directly
            x = self._fuse_features(features)

        output = self.net(x)
        output = output.reshape(-1, self.config.horizon, self.config.action_dim)
        return output

    def predict_action(self, features: dict[str, torch.Tensor], batched: bool = False, **kwargs: Any) -> torch.Tensor:
        raise NotImplementedError()


@register_model(name="mlp_continuous", model_type=ModelType.HEAD, status="stable")
class MLPContinuousActionHead(MLPBaseActionHead):
    def predict_action(self, features: dict[str, torch.Tensor], batched: bool = False, **kwargs: Any) -> torch.Tensor:
        return self.forward(features)


@register_model(name="mlp_discrete", model_type=ModelType.HEAD, status="beta")
class MLPDiscreteActionHead(MLPBaseActionHead):
    def predict_action(self, features: dict[str, torch.Tensor], batched: bool = False, **kwargs: Any) -> torch.Tensor:
        logits = self.forward(features)
        logits = F.softmax(logits, dim=-1)
        return torch.argmax(logits, dim=-1)
