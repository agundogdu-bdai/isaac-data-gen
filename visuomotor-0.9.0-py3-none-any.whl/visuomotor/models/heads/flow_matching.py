#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import typing

import torch
import torch.nn as nn
from omegaconf import DictConfig, OmegaConf

from visuomotor.models.heads.dit import DiTModel
from visuomotor.models.heads.unet1d.conditional_unet1d import ConditionalUnet1D
from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="flow_matching", model_type=ModelType.HEAD, status="beta")
class FlowMatchingActionHead(nn.Module):
    """
    1D flow_matching policy action head.

    This head is compatible with both U-Net and Transformer denoisers. The denoiser_type
    parameter in the config determines which model to use.

    IMPORTANT NOTE: this implementation is based on https://github.com/facebookresearch/flow_matching.
    """

    def __init__(self, config: DictConfig) -> None:
        """
        Args:
            config: Configuration object (OmegaConf). Expected keys:
                - denoiser_type: Type of denoiser to use ('unet' or 'transformer')
                - num_inference_steps (int): number of steps for DDIM inference
                - horizon (int): how many future actions to generate
                - input_dim (int): dimension of the global conditioning input
                - action_dim (int): dimension of the action space
                - batch_size (int): (if use_cuda_graph) the fixed batch size for capture
                - unet1d or dit_model (dict): config for the chosen denoiser
        """
        super().__init__()
        self.config = config
        self.seed = getattr(config, "seed", 42)
        self.denoiser_type = getattr(config, "denoiser_type", "unet")
        # Build the basic modules (denoiser + Scheduler).
        self.compile_model = getattr(config, "compile_model", False)
        self._build_model()

    def _build_model(self) -> None:
        """Builds the main denoiser and noise scheduler."""
        if self.denoiser_type == "unet":
            self.denoiser = ConditionalUnet1D(
                input_dim=self.config.action_dim,
                local_cond_dim=None,
                global_cond_dim=self.config.input_dim,
                **self.config.unet1d,
            )
        elif self.denoiser_type == "transformer":
            self.denoiser = DiTModel(
                action_dim=self.config.action_dim, action_seq_len=self.config.horizon, **self.config.dit_model
            )
        else:
            raise ValueError(f"Unknown denoiser type: {self.denoiser_type}")

        if self.compile_model:
            self.denoiser = torch.compile(self.denoiser)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Flatten fusion: flattens all input embeddings and concatenates them.
        This replaces the separate flatten fusion layer.

        Args:
            features: Dictionary mapping encoder names to their output tensors
            n_obs_history: Dictionary mapping encoder names to their history length

        Returns:
            Concatenated and flattened feature tensor
        """

        # Assume that everything is batch-first
        latents = [value.flatten(1) for value in features.values()]

        # concatenate all embeddings
        latent = torch.cat(latents, dim=1)

        return latent

    def _run_denoiser(
        self, noisy_trajectory: torch.Tensor, timestep: torch.Tensor, global_cond: torch.Tensor
    ) -> torch.Tensor:
        """
        Run the denoiser model with the appropriate interface based on denoiser type.

        Args:
            noisy_trajectory: The noisy trajectory to denoise, shape [B, horizon, action_dim]
            timestep: The diffusion timestep, scalar tensor or shape [B] for transformer
            global_cond: Global conditioning, shape [B, input_dim]

        Returns:
            Model output, shape [B, horizon, action_dim]
        """
        if self.denoiser_type == "unet":
            return self.denoiser(sample=noisy_trajectory, timestep=timestep, local_cond=None, global_cond=global_cond)
        elif self.denoiser_type == "transformer":
            # For transformer, expand timestep to batch dimension if needed
            if len(timestep.shape) == 0:
                t_batch = timestep.expand(noisy_trajectory.shape[0]).to(noisy_trajectory.device)
            else:
                t_batch = timestep
            return self.denoiser(noise_actions=noisy_trajectory, time=t_batch, tokens=global_cond)
        else:
            raise ValueError(f"Unknown denoiser type: {self.denoiser_type}")

    def __getstate__(self) -> dict:
        state = self.__dict__.copy()
        return state

    def forward(
        self,
        h: typing.Union[torch.Tensor, dict[str, torch.Tensor]],
        action: torch.Tensor,
        rank: int,
        rng_offset: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Performs the diffusion forward pass, including:
          1. Sampling noise and timesteps (using an ephemeral generator)
          2. Adding noise to the action via the noise scheduler
          3. Running the noisy trajectory through the denoiser

        Args:
            h: Global conditioning tensor (e.g. encoded observations), shape [B, input_dim] or dict of encoder features
            action: Ground-truth action tensor, shape [B, horizon, action_dim]
            rank: Integer rank (used to compute an offset for the random seed)
            rng_offset: An offset for the random generator (increments per forward pass)

        Returns:
            pred: The denoiser prediction, shape [B, horizon, action_dim]
            noise: The noise tensor that was sampled and added to the action, shape [B, horizon, action_dim]
        """
        # Handle fusion: if h is a dict of features, fuse them
        if isinstance(h, dict):
            h = self._fuse_features(h)
        action_shape = action.shape
        action_device = action.device

        # 1) Set up the random generator.
        base_seed = self.seed  # expects train.seed in the config
        rank_offset = rank * 100_000  # large offset per rank to avoid collisions
        local_seed = base_seed + rank_offset + rng_offset
        gen = torch.Generator(device=action_device)
        gen.manual_seed(local_seed)

        # 2) Sample noise and timesteps.
        noise = torch.randn(action_shape, device=action_device, generator=gen)
        t = torch.rand((action_shape[0],), device=action_device, generator=gen)

        # 3) Sample from the interpolating CondOT probability path
        interp_t = t[:, None, None]
        path_sample = interp_t * action + (1 - interp_t) * noise

        # 4) Get the training target
        target = action - noise

        # 4) Compute the denoiser prediction.
        pred = self._run_denoiser(path_sample, timestep=t, global_cond=h)
        return pred, target

    def predict_action(
        self, x: typing.Union[torch.Tensor, dict[str, torch.Tensor]], batched: bool = False, **kwargs: typing.Any
    ) -> torch.Tensor:
        """
        Predicts a sequence of actions via DDIM sampling.
        Optimized to run encoder only once for transformer models.

        Args:
            x: Global conditioning tensor (encoded observations), shape [B, input_dim] or dict of encoder features
            n_obs_history: Dictionary mapping encoder names to their history length (for fusion)

        Returns:
            trajectory: Predicted action sequence, shape [B, horizon, action_dim]
        """
        # Handle fusion: if x is a dict of features, fuse them
        if isinstance(x, dict):
            x = self._fuse_features(x)

        batch_size = x.shape[0]
        horizon = self.config.horizon
        action_dim = self.config.action_dim

        # Generate initial trajectory noise
        noise = torch.randn((batch_size, horizon, action_dim), device=x.device, dtype=x.dtype)
        T = torch.linspace(0, 1, self.config.num_inference_steps)
        T = T.to(device=x.device)
        dt = 1.0 / (self.config.num_inference_steps - 1)
        x_t = noise
        if self.denoiser_type == "transformer":
            # For transformer models, compute encoder output once
            enc_cache = self.denoiser.forward_enc(x)
            for time in T[:-1]:
                expanded_time = time.expand(batch_size)
                velocity_field = self.denoiser.forward_dec(noise_actions=x_t, time=expanded_time, enc_cache=enc_cache)
                x_t += dt * velocity_field
        else:
            for time in T[:-1]:
                velocity_field = self._run_denoiser(noisy_trajectory=x_t, timestep=time, global_cond=x)
                x_t += dt * velocity_field
        return x_t


@register_model(name="flow_matching_transformer", model_type=ModelType.HEAD, status="beta")
class FlowMatchingDiTActionHead(FlowMatchingActionHead):
    """DiT action head.

    Uses the DiT (Diffusion Transformer) model to predict a sequence of actions.

    Based on https://github.com/facebookresearch/DiT and https://github.com/SudeepDasari/dit-policy.
    """

    def __init__(self, config: DictConfig) -> None:
        # Set denoiser_type to transformer before init
        config_dict = dict(config)
        config_dict["denoiser_type"] = "transformer"
        updated_config = OmegaConf.create(config_dict)

        super().__init__(updated_config)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        DropoutDiT fusion: applies dropout to concatenated features and reshapes for DiT compatibility.
        This replaces the separate dropout_dit fusion layer.

        Args:
            features: Dictionary mapping encoder names to their output tensors

        Returns:
            Reshaped feature tensor [batch_size, sequence_length, hidden_dim] for DiT
        """
        # First apply dropout fusion logic
        latents = [value.flatten(1) for value in features.values()]
        num_latents = len(latents)
        features_combined = torch.cat(latents, dim=1)

        # Apply dropout
        if self.training:
            features_combined = torch.nn.functional.dropout(
                features_combined, p=self.config.token_dropout, training=self.training
            )

        batch_size = features_combined.shape[0]

        # Reshape to [batch_size, sequence_length, hidden_dim]
        features_combined = features_combined.reshape(batch_size, num_latents, self.config.dit_model.hidden_dim)

        return features_combined
