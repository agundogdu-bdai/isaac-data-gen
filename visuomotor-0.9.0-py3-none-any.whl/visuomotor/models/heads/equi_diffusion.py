#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.


import torch
from diffusers.schedulers import DDIMScheduler
from omegaconf import DictConfig

from visuomotor.models.heads.diffusion import DiffusionActionHead
from visuomotor.models.heads.unet1d.equi_conditional_unet1d import EquiDiffusionUNetFrameAverage
from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="equi_diffusion", model_type=ModelType.HEAD, status="beta")
class EquiDiffusionActionHead(DiffusionActionHead):

    def __init__(self, config: DictConfig) -> None:
        # Initialize the equivariant fusion components before calling super().__init__()
        # Following VPL nomenclature here for keys
        self.encoders_equivariant_representation = {
            "color_0": lambda size, group: size * [group.trivial_repr],
            "state": lambda size, group: 3 * [group.irrep(1)] + 2 * [group.trivial_repr],
            "point_cloud": lambda size, group: size * [group.regular_repr],
        }
        super().__init__(config)

    def _build_model(self) -> None:
        """Instantiates equivariant diffusion action head and a noise scheduler."""
        # Build the equivariant fusion layer first
        self._build_equivariant_fusion()

        # The global_cond_dim should be the output size of the fusion layer
        # For equivariant fusion, this is enc_n_hidden
        global_cond_dim = self.config.enc_n_hidden
        action_dim = self.config.action_dim

        # Override denoiser_type to ensure it's always "unet"
        self.denoiser_type = "unet"

        self.denoiser = EquiDiffusionUNetFrameAverage(
            input_dim=action_dim, local_cond_dim=None, global_cond_dim=global_cond_dim, **self.config.unet1d
        )

        if self.compile_model:
            self.denoiser = torch.compile(self.denoiser)

        self.noise_scheduler = DDIMScheduler(**self.config.noise_scheduler)

    def _build_equivariant_fusion(self) -> None:
        """Build the equivariant fusion layer."""
        import escnn.nn as escnn_nn

        enc_n_hidden = self.config.enc_n_hidden
        equivariant_group, equivariant_representations = self._get_equivariant_params()

        in_type = escnn_nn.FieldType(equivariant_group, equivariant_representations)
        out_type = escnn_nn.FieldType(equivariant_group, enc_n_hidden * [equivariant_group.regular_repr])
        self.fusion_net = escnn_nn.Linear(in_type, out_type)

    def _get_equivariant_params(self) -> tuple:
        """Get equivariant group and representations for the fusion layer."""
        import escnn.group as escnn_group
        import escnn.gspaces as escnn_gspaces

        equivariant_group = escnn_gspaces.no_base_space(escnn_group.CyclicGroup(self.config.N))
        equivariant_representations = []
        encoder_output_sizes = self.config.encoder_output_sizes
        for encoder_name, output_size in encoder_output_sizes.items():
            representations = self.encoders_equivariant_representation[encoder_name](output_size, equivariant_group)
            print(
                f"Encoder {encoder_name} has output size of: {output_size} and equivariant "
                f"representation of size {sum([repr.size for repr in representations])}"
            )
            equivariant_representations += representations

        return equivariant_group, equivariant_representations

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Equivariant fusion: uses equivariant linear layer to fuse encoder features.
        This replaces the flatten fusion with equivariant fusion.

        Args:
            features: Dictionary mapping encoder names to their output tensors

        Returns:
            Fused feature tensor using equivariant operations
        """
        import escnn.nn as escnn_nn

        latents = [value.flatten(1) for value in features.values()]
        features_combined = torch.cat(latents, dim=1)
        features_combined = escnn_nn.GeometricTensor(features_combined, self.fusion_net.in_type)
        return self.fusion_net(features_combined).tensor
