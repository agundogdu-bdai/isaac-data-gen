#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import typing

import torch
import torch.nn as nn
from diffusers.schedulers import DDIMScheduler
from einops import rearrange
from omegaconf import DictConfig, OmegaConf

from visuomotor.models.heads.dit import DiTModel
from visuomotor.models.heads.unet1d.conditional_unet1d import ConditionalUnet1D
from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="diffusion", model_type=ModelType.HEAD, status="stable")
class DiffusionActionHead(nn.Module):
    """
    1D diffusion policy action head with optional CUDA Graph support.

    If `config.use_cuda_graph` is True, the model captures a single forward
    pass of the denoiser into a CUDA Graph, reusing it for each timestep in the
    diffusion sampling loop. This enhances inference speed once input shapes
    are fixed.

    This head is compatible with both U-Net and Transformer denoisers. The denoiser_type
    parameter in the config determines which model to use.
    """

    def __init__(self, config: DictConfig) -> None:
        """
        Args:
            config: Configuration object (OmegaConf). Expected keys:
                - denoiser_type: Type of denoiser to use ('unet' or 'transformer')
                - use_cuda_graph (bool): whether to enable CUDA Graph capturing
                - num_inference_steps (int): number of steps for DDIM inference
                - horizon (int): how many future actions to generate
                - input_dim (int): dimension of the global conditioning input
                - action_dim (int): dimension of the action space
                - batch_size (int): (if use_cuda_graph) the fixed batch size for capture
                - unet1d or dit_model (dict): config for the chosen denoiser
                - noise_scheduler (dict): config for `DDIMScheduler`
        """
        super().__init__()
        self.config = config
        self.seed = getattr(config, "seed", 42)
        self.denoiser_type = getattr(config, "denoiser_type", "unet")
        # Build the basic modules (denoiser + Scheduler).
        self.compile_model = getattr(config, "compile_model", False)
        self._build_model()

        # Optionally prepare CUDA Graph (including warm-up).
        self.use_cuda_graph = getattr(config, "use_cuda_graph", False)
        if self.use_cuda_graph and self.denoiser_type == "unet":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            if self.device == torch.device("cpu"):
                raise ValueError("Cannot use CUDA Graph on CPU.")
            self.denoiser.to(self.device)
            self.batch_size = self.config.batch_size
            self._build_cuda_graph()
        elif self.use_cuda_graph and self.denoiser_type == "transformer":
            print("CUDA Graph is not supported for transformer models. Disabling.")
            self.use_cuda_graph = False

    def _build_model(self) -> None:
        """Builds the main denoiser and noise scheduler."""
        if self.denoiser_type == "unet":
            self.denoiser = ConditionalUnet1D(
                input_dim=self.config.action_dim,
                local_cond_dim=None,
                global_cond_dim=self.config.input_dim,
                **self.config.unet1d,
            )
        elif self.denoiser_type == "transformer":
            self.denoiser = DiTModel(
                action_dim=self.config.action_dim, action_seq_len=self.config.horizon, **self.config.dit_model
            )
        else:
            raise ValueError(f"Unknown denoiser type: {self.denoiser_type}")

        if self.compile_model:
            self.denoiser = torch.compile(self.denoiser)

        # Scheduler
        self.noise_scheduler = DDIMScheduler(**self.config.noise_scheduler)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Flatten fusion: flattens all input embeddings and concatenates them.

        Args:
            features: Dictionary mapping encoder names to their output tensors
            n_obs_history: Dictionary mapping encoder names to their history length

        Returns:
            Concatenated and flattened feature tensor
        """
        # Assume that everything is batch-first
        latents = [value.flatten(1) for value in features.values()]

        # concatenate all embeddings
        latent = torch.cat(latents, dim=1)

        return latent

    def _build_cuda_graph(self) -> None:
        """
        Captures a single forward pass of the model into a CUDA Graph.
        This graph can be replayed for each timestep in `predict_action`.

        NOTE: This approach requires:
            1) A fixed batch size, horizon, and action_dim.
            2) The same shapes on every forward pass.
        """
        horizon = self.config.horizon
        action_dim = self.config.action_dim
        global_cond_dim = self.config.input_dim

        # Allocate static buffers using the current batch size
        self.static_noisy_action = torch.empty(
            (self.batch_size, horizon, action_dim), device=self.device, dtype=torch.float32
        )
        self.static_timestep = torch.empty((), device=self.device, dtype=torch.int32)
        self.static_global_cond = torch.empty(
            (self.batch_size, global_cond_dim), device=self.device, dtype=torch.float32
        )
        # Allocate static buffer for the model output
        self.static_model_output = torch.empty_like(self.static_noisy_action)

        # Warm-up passes to ensure all lazy kernels are initialized
        warmup_iterations = 1
        for _ in range(warmup_iterations):
            _ = self._run_denoiser(
                noisy_trajectory=self.static_noisy_action,
                timestep=self.static_timestep,
                global_cond=self.static_global_cond,
            )
        torch.cuda.synchronize()

        # Now capture the forward pass in a CUDA Graph
        self.cuda_graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.cuda_graph):
            out = self._run_denoiser(
                noisy_trajectory=self.static_noisy_action,
                timestep=self.static_timestep,
                global_cond=self.static_global_cond,
            )
            # Copy the forward pass output into the static buffer
            self.static_model_output.copy_(out)

    def _run_denoiser(
        self, noisy_trajectory: torch.Tensor, timestep: torch.Tensor, global_cond: torch.Tensor
    ) -> torch.Tensor:
        """
        Run the denoiser model with the appropriate interface based on denoiser type.

        Args:
            noisy_trajectory: The noisy trajectory to denoise, shape [B, horizon, action_dim]
            timestep: The diffusion timestep, scalar tensor or shape [B] for transformer
            global_cond: Global conditioning, shape [B, input_dim]

        Returns:
            Model output, shape [B, horizon, action_dim]
        """
        if self.denoiser_type == "unet":
            return self.denoiser(sample=noisy_trajectory, timestep=timestep, local_cond=None, global_cond=global_cond)
        elif self.denoiser_type == "transformer":
            # For transformer, expand timestep to batch dimension if needed
            if len(timestep.shape) == 0:
                t_batch = timestep.expand(noisy_trajectory.shape[0]).to(noisy_trajectory.device)
            else:
                t_batch = timestep
            return self.denoiser(noise_actions=noisy_trajectory, time=t_batch, tokens=global_cond)
        else:
            raise ValueError(f"Unknown denoiser type: {self.denoiser_type}")

    def __getstate__(self) -> dict:
        state = self.__dict__.copy()
        if hasattr(state, "cuda_graph"):
            state["cuda_graph"] = None  # Exclude the cuda_graph from serialization
        return state

    def initialize_cuda_graph(self) -> None:
        """
        Initializes (or reinitializes) the CUDA graph using the current stored batch size.
        This method should be called after deserializing a model checkpoint or whenever the CUDA graph
        is lost, as CUDA graphs cannot be serialized.

        It moves the denoiser to the proper device and rebuilds the CUDA graph.
        """
        if self.use_cuda_graph:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            if self.device == torch.device("cpu"):
                raise ValueError("Cannot use CUDA Graph on CPU.")
            self.denoiser.to(self.device)
            self._build_cuda_graph()

    def forward(
        self,
        h: typing.Union[torch.Tensor, dict[str, torch.Tensor]],
        action: torch.Tensor,
        rank: int,
        rng_offset: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Performs the diffusion forward pass, including:
          1. Sampling noise and timesteps (using an ephemeral generator)
          2. Adding noise to the action via the noise scheduler
          3. Running the noisy trajectory through the denoiser

        Args:
            h: Global conditioning tensor (e.g. encoded observations), shape [B, input_dim] or dict of encoder features
            action: Ground-truth action tensor, shape [B, horizon, action_dim]
            rank: Integer rank (used to compute an offset for the random seed)
            rng_offset: An offset for the random generator (increments per forward pass)

        Returns:
            pred: The denoiser prediction, shape [B, horizon, action_dim]
            noise: The noise tensor that was sampled and added to the action, shape [B, horizon, action_dim]
        """
        # Handle fusion: if h is a dict of features, fuse them
        if isinstance(h, dict):
            h = self._fuse_features(h)
        action_shape = action.shape
        action_device = action.device

        # 1) Set up the random generator.
        base_seed = self.seed  # expects train.seed in the config
        rank_offset = rank * 100_000  # large offset per rank to avoid collisions
        local_seed = base_seed + rank_offset + rng_offset
        gen = torch.Generator(device=action_device)
        gen.manual_seed(local_seed)

        # 2) Sample noise and timesteps.
        noise = torch.randn(action_shape, device=action_device, generator=gen)
        timesteps = torch.randint(
            0,
            self.noise_scheduler.config["num_train_timesteps"],
            (action_shape[0],),
            device=action_device,
            generator=gen,
        ).long()

        # 3) Add noise to the action.
        noisy_trajectory = self.noise_scheduler.add_noise(action, noise, timesteps)

        # 4) Compute the denoiser prediction.
        pred = self._run_denoiser(noisy_trajectory=noisy_trajectory, timestep=timesteps, global_cond=h)
        return pred, noise

    def predict_action(
        self, x: typing.Union[torch.Tensor, dict[str, torch.Tensor]], batched: bool = False, **kwargs: typing.Any
    ) -> torch.Tensor:
        """
        Predicts a sequence of actions via DDIM sampling.
        Optimized to run encoder only once for transformer models.

        Args:
            x: Global conditioning tensor (encoded observations), shape [B, input_dim] or dict of encoder features
            n_obs_history: Dictionary mapping encoder names to their history length (for fusion)

        Returns:
            trajectory: Predicted action sequence, shape [B, horizon, action_dim]
        """
        # Handle fusion: if x is a dict of features, fuse them
        if isinstance(x, dict):
            x = self._fuse_features(x)
        self.noise_scheduler.set_timesteps(self.config.num_inference_steps)

        batch_size = x.shape[0]
        horizon = self.config.horizon
        action_dim = self.config.action_dim

        # Generate initial trajectory noise
        trajectory = torch.randn((batch_size, horizon, action_dim), device=x.device, dtype=x.dtype)

        if self.denoiser_type == "transformer":
            # For transformer models, compute encoder output once
            enc_cache = self.denoiser.forward_enc(x)
            # Then only use the decoder in the diffusion loop
            for t in self.noise_scheduler.timesteps:
                # For transformer, expand timestep to batch dimension
                tstep = t.to(device=x.device, dtype=torch.long).expand(batch_size)

                # Only run the decoder part
                model_output = self.denoiser.forward_dec(trajectory, tstep, enc_cache)
                trajectory = self.noise_scheduler.step(model_output, t, trajectory).prev_sample

            return trajectory
        elif not self.use_cuda_graph:
            # Original path for non-transformer models without CUDA graph
            for t in self.noise_scheduler.timesteps:
                model_output = self._run_denoiser(noisy_trajectory=trajectory, timestep=t, global_cond=x)
                trajectory = self.noise_scheduler.step(model_output, t, trajectory).prev_sample

            return trajectory
        else:
            # CUDA Graph path
            if batch_size != self.batch_size:
                print(f"Rebuilding CUDA graph with new batch size: {batch_size} (old: {self.batch_size}).")
                self.batch_size = batch_size
                self._build_cuda_graph()

            self.static_global_cond.copy_(x)
            for t in self.noise_scheduler.timesteps:
                self.static_timestep.copy_(torch.tensor(t, device=self.device, dtype=torch.long))
                self.static_noisy_action.copy_(trajectory)

                # Replay the CUDA graph
                self.cuda_graph.replay()

                # Use the captured output to get the next step
                trajectory = self.noise_scheduler.step(self.static_model_output, t, trajectory).prev_sample

            return trajectory.detach()


@register_model(name="diffusion_transformer", model_type=ModelType.HEAD, status="beta")
class DiTActionHead(DiffusionActionHead):
    """DiT action head.

    Uses the DiT (Diffusion Transformer) model to predict a sequence of actions.

    Based on https://github.com/facebookresearch/DiT and https://github.com/SudeepDasari/dit-policy.
    """

    def __init__(self, config: DictConfig) -> None:
        # Set denoiser_type to transformer before init
        config_dict = dict(config)
        config_dict["denoiser_type"] = "transformer"
        updated_config = OmegaConf.create(config_dict)

        super().__init__(updated_config)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Applies dropout to concatenated features and reshapes them to (batch, sequence, latent_size).

        Args:
            features: Dictionary mapping encoder names to their output tensors

        Returns:
            Reshaped feature tensor [batch_size, sequence_length, hidden_dim] for DiT
        """
        # Make sure all the feature dimensions are the same
        features_dims = [value.shape[-1] for value in features.values()]
        if len(set(features_dims)) > 1:
            raise ValueError(f"Feature dimensions are not the same: {features_dims}")

        latents = []
        for key in features:
            # We concatenate the features along the sequence dimension, so we need to unsqueeze the 2D features
            # If the feature is already 3D, we don't need to unsqueeze it (e.g. DINOv2 features)
            if features[key].ndim == 2:
                features[key] = features[key].unsqueeze(1)
            # If the shared_encoder is True, the color features are 4D (B, N, K, D)
            # We stack the features along the camera dimension
            elif features[key].ndim == 4:
                features[key] = rearrange(features[key], "b n k d -> b (n k) d")
            latents.append(features[key])

        features_combined = torch.cat(latents, dim=1)
        num_latents = features_combined.shape[1]
        batch_size = features_combined.shape[0]
        token_dim = features_combined.shape[2]

        # Apply dropout
        features_dropout = torch.nn.functional.dropout(
            features_combined, p=self.config.token_dropout, training=self.training
        )
        # Reshape to [batch_size, sequence_length, hidden_dim]
        features_dropout = features_dropout.reshape(batch_size, num_latents, token_dim)
        return features_dropout
