#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import math
from itertools import chain
from typing import Any

import einops
import torch
from omegaconf import DictConfig
from torch import nn

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.utils import get_activation, with_pos_embed


@register_model(name="act", model_type=ModelType.HEAD, status="beta")
class ActionChunkingTransformerHead(nn.Module):
    """Action Chunking Transformer"""

    def __init__(self, config: DictConfig):
        super().__init__()
        self.config = config

        self.encoder = ACTEncoder(config)
        self.decoder = ACTDecoder(config)
        # TODO (tarik): The color projection is currently in action head.
        # Since head doesn't have access to encoder config, we need to hardcode the color projection input dim.
        self.color_projection = nn.Conv2d(512, config.dim_model, kernel_size=1)

        # Transformer encoder positional embeddings.
        # We concatenate all the states so we only have one state embedding.
        self.state_pos_embed = nn.Embedding(1, config.dim_model)
        self.color_pos_embed = ACTSinusoidalPositionEmbedding2d(config.dim_model // 2)

        # Learnable positional embedding for the transformer's decoder.
        self.decoder_pos_embed = nn.Embedding(config.horizon, config.dim_model)

        # Final action regression head on the output of the transformer's decoder.
        self.final_layer = nn.Linear(config.dim_model, self.config.action_dim)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        """Xavier-uniform initialization of the transformer parameters as in the original code."""
        for p in chain(self.encoder.parameters(), self.decoder.parameters()):
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def _fuse_features(self, features: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        """Fuse the features to input encoder."""
        encoder_tokens = []
        encoder_pos_embed = []
        # Add state token and pose embedding if available.
        if "state" in features:
            encoder_pos_embed.append(self.state_pos_embed.weight.unsqueeze(1))  # (1, 1, C)
            encoder_tokens.append(features["state"].unsqueeze(0))  # (1, B, C)

        for k, v in features.items():
            # ACT uses the output of the last conv layer of the ResNet so the color
            # features are in the shape of (B, C, H, W)
            if k.startswith("color"):
                color_features = self.color_projection(v)  # (B, C, H, W)
                color_pos_embed = self.color_pos_embed(v).to(dtype=v.dtype)  # (1, C, H, W)

                # Rearrange features to (sequence, batch, dim).
                color_features = einops.rearrange(color_features, "b c h w -> (h w) b c")
                color_pos_embed = einops.rearrange(color_pos_embed, "b c h w -> (h w) b c")

                encoder_tokens.append(color_features)
                encoder_pos_embed.append(color_pos_embed)

        encoder_tokens = torch.cat(encoder_tokens, dim=0)  # (S, B, C)
        encoder_pos_embed = torch.cat(encoder_pos_embed, dim=0)  # (S, 1, C)

        return encoder_tokens, encoder_pos_embed

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        """A forward pass through the Action Chunking Transformer.
        Args:
            batch: dictionary of observation features.
            - color: (B, C, H, W) batch of color images.
            - state: (B, C)
        Returns:
            (B, chunk_size, action_dim) batch of action sequences
            Tuple containing the latent PDF's parameters (mean, log(σ²)) both as (B, L) tensors where L is the
            latent dimension.
        """

        encoder_tokens, encoder_pos_embed = self._fuse_features(batch)
        encoder_out = self.encoder(encoder_tokens, pos_embed=encoder_pos_embed)
        # TODO (tarik): Why do we need to input zeros to the decoder as input?
        # Can't we just input the decoder position encodings?
        decoder_in = torch.zeros(
            (self.config.horizon, encoder_tokens.shape[1], self.config.dim_model),
            dtype=encoder_pos_embed.dtype,
            device=encoder_pos_embed.device,
        )
        decoder_out = self.decoder(
            decoder_in,
            encoder_out,
            encoder_pos_embed=encoder_pos_embed,
            decoder_pos_embed=self.decoder_pos_embed.weight.unsqueeze(1),
        )

        # Move back to (B, S, C).
        decoder_out = decoder_out.transpose(0, 1)

        actions = self.final_layer(decoder_out)

        return actions

    def predict_action(self, batch: dict[str, torch.Tensor], batched: bool = False, **kwargs: Any) -> torch.Tensor:
        """Predict action sequence using the ACT model."""
        return self.forward(batch)


class ACTEncoder(nn.Module):
    """Convenience module for running multiple encoder layers, maybe followed by normalization."""

    def __init__(self, config: DictConfig):
        super().__init__()
        self.layers = nn.ModuleList([ACTEncoderLayer(config) for _ in range(config.num_encoder_layers)])
        self.norm = nn.LayerNorm(config.dim_model) if config.norm_first else nn.Identity()

    def forward(self, x: torch.Tensor, pos_embed: torch.Tensor | None = None) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x, pos_embed=pos_embed)
        x = self.norm(x)
        return x


class ACTEncoderLayer(nn.Module):
    def __init__(self, config: DictConfig):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(
            embed_dim=config.dim_model,
            num_heads=config.num_heads,
            dropout=config.dropout,
            batch_first=False,
        )

        # Feed forward layers.
        self.linear1 = nn.Linear(config.dim_model, config.dim_feedforward)
        self.dropout = nn.Dropout(config.dropout)
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model)

        self.norm1 = nn.LayerNorm(config.dim_model)
        self.norm2 = nn.LayerNorm(config.dim_model)
        self.dropout1 = nn.Dropout(config.dropout)
        self.dropout2 = nn.Dropout(config.dropout)

        self.activation = get_activation(config.feedforward_activation)
        self.norm_first = config.norm_first

    def forward(self, x: torch.Tensor, pos_embed: torch.Tensor | None = None) -> torch.Tensor:
        skip = x
        if self.norm_first:
            x = self.norm1(x)
        q = k = x if pos_embed is None else x + pos_embed
        # TODO (tarik): Doesn't skip change here?
        x, _ = self.self_attn(q, k, value=x, need_weights=False)
        x = skip + self.dropout1(x)
        if self.norm_first:
            skip = x
            x = self.norm2(x)
        else:
            x = self.norm1(x)
            skip = x
        x = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = skip + self.dropout2(x)
        if not self.norm_first:
            x = self.norm2(x)
        return x


class ACTDecoder(nn.Module):
    def __init__(self, config: DictConfig):
        """Convenience module for running multiple decoder layers followed by normalization."""
        super().__init__()
        self.layers = nn.ModuleList([ACTDecoderLayer(config) for _ in range(config.num_decoder_layers)])
        self.norm = nn.LayerNorm(config.dim_model)

    def forward(
        self,
        x: torch.Tensor,
        encoder_out: torch.Tensor,
        decoder_pos_embed: torch.Tensor | None = None,
        encoder_pos_embed: torch.Tensor | None = None,
    ) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x, encoder_out, decoder_pos_embed=decoder_pos_embed, encoder_pos_embed=encoder_pos_embed)
        if self.norm is not None:
            x = self.norm(x)
        return x


class ACTDecoderLayer(nn.Module):
    def __init__(self, config: DictConfig):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(
            embed_dim=config.dim_model,
            num_heads=config.num_heads,
            dropout=config.dropout,
            batch_first=False,
        )
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=config.dim_model,
            num_heads=config.num_heads,
            dropout=config.dropout,
            batch_first=False,
        )

        # Feed forward layers.
        self.linear1 = nn.Linear(config.dim_model, config.dim_feedforward)
        self.dropout = nn.Dropout(config.dropout)
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model)

        self.norm1 = nn.LayerNorm(config.dim_model)
        self.norm2 = nn.LayerNorm(config.dim_model)
        self.norm3 = nn.LayerNorm(config.dim_model)
        self.dropout1 = nn.Dropout(config.dropout)
        self.dropout2 = nn.Dropout(config.dropout)
        self.dropout3 = nn.Dropout(config.dropout)

        self.activation = get_activation(config.feedforward_activation)
        self.norm_first = config.norm_first

    def forward(
        self,
        x: torch.Tensor,
        encoder_out: torch.Tensor,
        decoder_pos_embed: torch.Tensor | None = None,
        encoder_pos_embed: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x: (Decoder Sequence, Batch, Channel) tensor of input tokens.
            encoder_out: (Encoder Sequence, B, C) output features from the last layer of the encoder we are
                cross-attending with.
            decoder_pos_embed: (ES, 1, C) positional embedding for keys (from the encoder).
            encoder_pos_embed: (DS, 1, C) Positional_embedding for the queries (from the decoder).
        Returns:
            (DS, B, C) tensor of decoder output features.
        """
        skip = x
        if self.norm_first:
            x = self.norm1(x)
        q = k = with_pos_embed(x, decoder_pos_embed)
        x, _ = self.self_attn(q, k, value=x, need_weights=False)  # select just the output, not the attention weights
        x = skip + self.dropout1(x)
        if self.norm_first:
            skip = x
            x = self.norm2(x)
        else:
            x = self.norm1(x)
            skip = x
        x, _ = self.multihead_attn(
            query=with_pos_embed(x, decoder_pos_embed),
            key=with_pos_embed(encoder_out, encoder_pos_embed),
            value=encoder_out,
            need_weights=False,
        )
        x = skip + self.dropout2(x)
        if self.norm_first:
            skip = x
            x = self.norm3(x)
        else:
            x = self.norm2(x)
            skip = x
        x = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = skip + self.dropout3(x)
        if not self.norm_first:
            x = self.norm3(x)
        return x


class ACTSinusoidalPositionEmbedding2d(nn.Module):
    """2D sinusoidal positional embeddings similar to what's presented in Attention Is All You Need.

    The variation is that the position indices are normalized in [0, 2π] (not quite: the lower bound is 1/H
    for the vertical direction, and 1/W for the horizontal direction.
    """

    def __init__(self, dimension: int):
        """
        Args:
            dimension: The desired dimension of the embeddings.
        """
        super().__init__()
        self.dimension = dimension
        self._two_pi = 2 * math.pi
        self._eps = 1e-6
        # Inverse "common ratio" for the geometric progression in sinusoid frequencies.
        self._temperature = 10000

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: A (B, C, H, W) batch of 2D feature map to generate the embeddings for.
        Returns:
            A (1, C, H, W) batch of corresponding sinusoidal positional embeddings.
        """
        not_mask = torch.ones_like(x[0, :1])  # (1, H, W)
        # Note: These are like range(1, H+1) and range(1, W+1) respectively, but in most implementations
        # they would be range(0, H) and range(0, W). Keeping it at as is to match the original code.
        y_range = not_mask.cumsum(1, dtype=torch.float32)
        x_range = not_mask.cumsum(2, dtype=torch.float32)

        # "Normalize" the position index such that it ranges in [0, 2π].
        # Note: Adding epsilon on the denominator should not be needed as all values of y_embed and x_range
        # are non-zero by construction. This is an artifact of the original code.
        y_range = y_range / (y_range[:, -1:, :] + self._eps) * self._two_pi
        x_range = x_range / (x_range[:, :, -1:] + self._eps) * self._two_pi

        inverse_frequency = self._temperature ** (
            2 * (torch.arange(self.dimension, dtype=torch.float32, device=x.device) // 2) / self.dimension
        )

        x_range = x_range.unsqueeze(-1) / inverse_frequency  # (1, H, W, 1)
        y_range = y_range.unsqueeze(-1) / inverse_frequency  # (1, H, W, 1)

        # Note: this stack then flatten operation results in interleaved sine and cosine terms.
        # pos_embed_x and pos_embed_y are (1, H, W, C // 2).
        pos_embed_x = torch.stack((x_range[..., 0::2].sin(), x_range[..., 1::2].cos()), dim=-1).flatten(3)
        pos_embed_y = torch.stack((y_range[..., 0::2].sin(), y_range[..., 1::2].cos()), dim=-1).flatten(3)
        pos_embed = torch.cat((pos_embed_y, pos_embed_x), dim=3).permute(0, 3, 1, 2)  # (1, C, H, W)

        return pos_embed
