#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from easydict import EasyDict as edict
from omegaconf import DictConfig, OmegaConf
from openpoints.models import build_model_from_cfg


class PointNext(torch.nn.Module):
    """Load Pointnext model from openpoints"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config

        if not torch.cuda.is_available():
            raise ValueError("Openpoints implementation of PointNext expects GPU.")

        self.build_model()

    def build_model(self) -> None:
        encoder_args = edict(OmegaConf.to_container(self.config))
        self.model = build_model_from_cfg(encoder_args).cuda()

    def forward(self, xyz: torch.Tensor, features: torch.Tensor = None) -> torch.Tensor:
        """Forward pass of Pointnext encoder.

        Args:
            xyz (torch.Tensor): (B, N, 3) xyz coordinates of the pointcloud.
                                N is number of points.
            features (torch.Tensor): (B, C, N) Features of the pointcloud. Defaults to None.
                                     C is dimension of features.

        Returns:
            torch.Tensor: encoding of point cloud as vector of features.
        """
        h = self.model.forward_cls_feat(xyz, features)
        return h
