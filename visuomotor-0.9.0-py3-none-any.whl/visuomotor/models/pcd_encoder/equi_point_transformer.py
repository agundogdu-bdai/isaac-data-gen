#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
# Porting over of `EquiPointTransformerEncoder` from Maple equidiff originally at
# https://github.com/bdaiinstitute/bdai/blob/76e0dea88307e9a300edb3e589dbd4dc5a41d3ed/projects/maple/src/equidiff/models/encoders/point_cloud.py#L42


from typing import Any, List

import torch

from visuomotor.models.equi_layers import EquiLinear, EquiPointTransformerLayer, TransitionDown
from visuomotor.models.model_registry import ModelType, register_model


class Bottleneck(torch.nn.Module):
    """Bottleneck helper class for equivariant point transformer encoder."""

    def __init__(self, in_type: Any, share_planes: int = 8, nsample: int = 16) -> None:
        super().__init__()
        self.linear1 = EquiLinear(in_type, in_type, bias=False)
        self.layernorm1 = torch.nn.LayerNorm(in_type.size)
        self.transformer = EquiPointTransformerLayer(in_type, in_type, share_planes, nsample)
        self.layernorm2 = torch.nn.LayerNorm(in_type.size)
        self.linear3 = EquiLinear(in_type, in_type, bias=False)
        self.layernorm3 = torch.nn.LayerNorm(in_type.size)
        self.relu = torch.nn.ReLU(inplace=True)

    def forward(self, x: tuple[torch.Tensor, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        xyz, feats = x
        identity = feats
        feats = self.relu(self.layernorm1(self.linear1(feats)))
        feats = self.relu(self.layernorm2(self.transformer((xyz, feats))[1]))
        feats = self.layernorm3(self.linear3(feats))
        feats += identity
        feats = self.relu(feats)
        return (xyz, feats)


@register_model(name="equi_point_transformer", model_type=ModelType.ENCODER_PCD, status="beta")
class EquiPointTransformerEncoder(torch.nn.Module):
    """Equivariant point transformer encoder."""

    def __init__(self, config: dict) -> None:
        super().__init__()
        self.config = config
        self.build_model()

    def build_model(self) -> None:
        import escnn.group as escnn_group
        import escnn.gspaces as escnn_gspaces
        import escnn.nn as escnn_nn

        self.channels = self.config["channels"]
        self.nsample = self.config["nsample"]
        self.stride = self.config["stride"]
        self.share_planes = self.config["share_planes"]
        self.feat_channels_dim = self.config["feat_channels_dim"]
        self.n_out = self.config["n_out"]
        self.pc_xyz_dims = self.config["PC_XYZ_DIMS"]
        self.total_pc_dim = self.pc_xyz_dims + self.feat_channels_dim

        # Create cyclic group directly
        self.group = escnn_gspaces.no_base_space(escnn_group.CyclicGroup(self.config["N"]))
        self.in_type = escnn_nn.FieldType(self.group, self.feat_channels_dim * [self.group.trivial_repr])
        self.out_type = escnn_nn.FieldType(self.group, self.n_out * [self.group.regular_repr])

        layers = []
        for i in range(len(self.stride)):
            if i == 0:
                in_type = self.in_type
            else:
                in_type = escnn_nn.FieldType(self.group, self.channels[i - 1] * [self.group.regular_repr])
            out_type = escnn_nn.FieldType(self.group, self.channels[i] * [self.group.regular_repr])
            layers.append(TransitionDown(in_type, out_type, stride=self.stride[i], nsample=self.nsample[i]))
            layers.append(Bottleneck(out_type, share_planes=self.share_planes, nsample=self.nsample[i]))
        self.pointnet = torch.nn.Sequential(*layers)

        import escnn.nn as escnn_nn

        self.out_layer = torch.nn.Sequential(
            EquiLinear(escnn_nn.FieldType(self.group, self.channels[-1] * [self.group.regular_repr]), self.out_type),
            torch.nn.LayerNorm(self.out_type.size),
        )

    def get_equivariant_representation(self, group: Any) -> List[Any]:
        """
        Gets the equivariant representation to put together an equivariant policy.

        Args
            group : The abstract group space from which to extract information.
        """
        assert group == self.group
        return self.n_out * [group.regular_repr]

    @property
    def output_size(self) -> torch.Size:
        """Gets the output size of the encoder for concatenation."""
        return torch.Size([self.n_out])

    def forward(self, pc: torch.Tensor) -> torch.Tensor:
        assert pc.dim() == 3

        xyz = pc[:, :, : self.pc_xyz_dims]
        feats = pc[:, :, self.pc_xyz_dims : self.total_pc_dim]
        pc = (xyz, feats)
        pc = self.pointnet(pc)
        pc = pc[1].mean(dim=1)
        pc = self.out_layer(pc)

        return pc
