#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.


import torch
import torch.nn as nn
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="vanilla_pointnet", model_type=ModelType.ENCODER_PCD, status="stable")
class VanillaPointNet(torch.nn.Module):
    """A simple pointnet encoder based on https://arxiv.org/abs/2403.03954"""

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config
        self.build_model()
        self.output_size = torch.Size([self.config.output_dim])

    def build_model(self) -> None:
        input_dim = self.config.input_dim
        use_layer_norm = self.config.use_layernorm
        hidden_features = self.config.hidden_dim

        layers = [
            nn.Linear(input_dim, hidden_features[0]),
            nn.LayerNorm(hidden_features[0]) if use_layer_norm else nn.Identity(),
            nn.ReLU(),
        ]

        for i in range(len(hidden_features) - 1):
            feature_layers = [
                nn.Linear(hidden_features[i], hidden_features[i + 1]),
                nn.LayerNorm(hidden_features[i + 1]) if use_layer_norm else nn.Identity(),
                nn.ReLU(),
            ]
            layers.extend(feature_layers)

        self.pointnet = nn.Sequential(*layers)

        if self.config.final_layernorm:
            self.projection = nn.Sequential(
                nn.Linear(hidden_features[-1], self.config.output_dim),
                nn.LayerNorm(self.config.output_dim),
            )
        else:
            self.projection = nn.Linear(hidden_features[-1], self.config.output_dim)

    def forward(self, xyz: torch.Tensor) -> torch.Tensor:
        h = self.pointnet(xyz)
        h = torch.max(h, 1)[0]
        h = self.projection(h)
        return h
