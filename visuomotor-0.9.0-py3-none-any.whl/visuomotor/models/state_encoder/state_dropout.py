#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Dict

import torch
from omegaconf import DictConfig
from torch import nn

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="state_dropout", model_type=ModelType.ENCODER_STATE, status="beta")
class StateDropout(nn.Module):
    """
    Simplest fusion model which flattens all input embeddings and concatenates them.
    """

    def __init__(self, config: DictConfig):
        super().__init__()
        self.config = config
        self.state_embeding = nn.Sequential(
            nn.Dropout(p=config.dropout), nn.Linear(config.input_dim, config.output_dim)
        )
        self.output_size = torch.Size([self.config.output_dim])

    def forward(self, x: Dict[str, torch.Tensor]) -> torch.Tensor:
        return self.state_embeding(x)

    def compute_output_size(self, modules: Dict[str, nn.Module]) -> torch.Size:
        """
        Returns the output shape of the module
        """
        return self.config.output_dim
