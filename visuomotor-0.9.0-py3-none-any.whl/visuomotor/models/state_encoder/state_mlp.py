#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.


import torch
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.utils import build_mlp


@register_model(name="state_mlp", model_type=ModelType.ENCODER_STATE, status="beta")
class StateMLP(torch.nn.Module):
    # TODO: Fix config that gets fusion.latent_dim as output_dim
    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config
        self.input_size = config.input_dim
        self.output_size = torch.Size([self.config.output_dim])
        self.build_model()

    def build_model(self) -> None:
        self.state_mlp = build_mlp(self.config)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.state_mlp(x)
