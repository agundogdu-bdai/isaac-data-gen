#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from omegaconf import DictConfig
from torch import nn

from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="flatten", model_type=ModelType.ENCODER_STATE, status="stable")
class FlattenEncoder(nn.Module):
    """
    Placeholder encoder which just flattens the input tensor
    """

    def __init__(self, config: DictConfig):
        super().__init__()
        self.config = config
        self.input_size = torch.Size([self.config.input_dim])
        self.output_size = torch.Size([self.config.input_dim])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Flattens tensor buts keeps batch dimension
        """

        # Assume that everything is batch-first
        return x.flatten(1)
