# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
from omegaconf import DictConfig

from visuomotor.data.rotation_transformer import RotationTransformer
from visuomotor.models.model_registry import ModelType, register_model


@register_model(name="equivariant_state_encoder", model_type=ModelType.ENCODER_STATE, status="beta")
class EquiEndEffectorStateEncoder(torch.nn.Module):
    """Equivariant encoder for robot end effector state."""

    def __init__(
        self,
        config: DictConfig,
    ) -> None:
        """
        Initializes the encoder.

        Args
            eef_gripper_pos_obs_name : Observation name for gripper finger positions.
            eef_rot_obs_name : Observation name for end effector rotation (as a quaternion).
        """
        super().__init__()

        self.config = config
        self.eef_gripper_pos_obs_name = self.config.eef_gripper_pos_obs_name
        self.eef_rot_obs_name = self.config.eef_rot_obs_name
        self.quat_to_6d = RotationTransformer(from_rep="quaternion", to_rep="rotation_6d")

    @property
    def output_size(self) -> int:
        """
        Gets the output size of the encoder for concatenation.

        This consists of:
            - 2 for gripper finger position
            - 6 for the 6D rotation representation of the end effector
        """
        return torch.Size([8])

    def forward(self, obs: dict[str, torch.Tensor]) -> torch.Tensor:
        ee_gripper_pos = torch.Tensor(obs[self.eef_gripper_pos_obs_name])
        ee_quat = torch.Tensor(obs[self.eef_rot_obs_name])

        assert ee_gripper_pos.shape[-1] == 2, (
            "Shape of `ee_gripper_pos` observation should be 2 to run this conversion"
            f" and you have {ee_gripper_pos.shape[-1]}"
        )
        assert ee_quat.shape[-1] == 4, (
            "Shape of `ee_quat` observation should be 4 to run this conversion" f" and you have {ee_quat.shape[-1]}"
        )

        ee_rot = self.quat_to_6d.forward(ee_quat[:, [3, 0, 1, 2]])

        # Rotation and gripper position only.
        feature_components = [
            ee_rot[..., 0:1],
            ee_rot[..., 3:4],
            ee_rot[..., 1:2],
            ee_rot[..., 4:5],
            ee_rot[..., 2:3],
            ee_rot[..., 5:6],
            ee_gripper_pos[..., 0:1],
            ee_gripper_pos[..., 1:2],
        ]

        return torch.cat(feature_components, dim=-1)
