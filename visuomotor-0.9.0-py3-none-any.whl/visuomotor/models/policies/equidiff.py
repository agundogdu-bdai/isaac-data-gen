#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
from copy import deepcopy
from typing import Union

import numpy as np
import torch
from numpy import typing as npt
from omegaconf import DictConfig

from visuomotor.data.datasets import (
    subtract_eef_pos_from_actions,
    subtract_eef_pos_from_pointcloud_obs,
)
from visuomotor.data.space_rot_randomizer import SpaceRotRandomizer
from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.policies.bc import DiffusionBehaviorCloning

logger = logging.getLogger(__name__)


@register_model(name="equi_diffpo", model_type=ModelType.POLICY, status="beta")
class EquiDiffusionBehaviorCloning(DiffusionBehaviorCloning):

    def __init__(self, config: DictConfig) -> None:
        super().__init__(config)
        self.init_space_rot_randomizer()

    def calculate_state_dim(self) -> int:
        # Because we use equivariant state encoder our state dim is 8
        return 8

    def init_space_rot_randomizer(self) -> None:
        if self.config.data.get("space_rotation_randomization"):
            self.space_rot_randomizer = SpaceRotRandomizer(key_to_n_obs_history=self.key_to_n_obs_history)

    def prepare_inputs(self, batch: dict[str, Union[np.ndarray, torch.Tensor, str]]) -> dict[str, torch.Tensor]:
        """
        Prepares the input batch for encoding (reshaping, normalizing, transformations).

        - Reshapes observations to match encoder input requirements.
        - Concatenates state tensors to form a unified state representation.
        - Splits color observations into separate camera keys when using non-shared RGB encoders.
        - Applies normalization and space rotation randomization if configured.

        Args:
            batch (dict[str, torch.Tensor]):
                The input batch containing various types of observations.

        Returns:
            dict[str, torch.Tensor]:
                The processed batch, ready for encoding by the model's encoders.
        """
        data_cfg = self.config.data
        norm_keys = set(data_cfg.norm_keys) if getattr(data_cfg, "norm_keys", None) else set()

        # Reshape and (optionally) normalize
        normalized_batch = {}
        for key, value in batch.items():
            if isinstance(value, np.ndarray):
                value = torch.from_numpy(value)
            elif isinstance(value, str):
                value = torch.tensor([value])  # Temporary fix for language encoder

            reshaped = self.reshape_for_encoding(value, key)
            if self.normalizer and key in norm_keys:
                reshaped = self.normalizer[key].normalize(reshaped)
            normalized_batch[key] = reshaped

        if self.training and self.config.data.get("space_rotation_randomization"):
            normalized_batch = self.space_rot_randomizer(normalized_batch)

        if self.config.state_encoder.get("name") == "equivariant_state_encoder":
            # For equivariant_state_encoder, keep states as separate keys.
            pass
        else:
            state_tensors = []
            for k in self.obs_state.keys():
                if k in normalized_batch:
                    tensor = normalized_batch.pop(k)
                    # If tensor is 3D and the second dimension is 1, squeeze it to remove the extra dimension.
                    if tensor.dim() == 3 and tensor.size(1) == 1:
                        tensor = tensor.squeeze(1)
                    logger.debug(f"Processed state key '{k}' shape: {tensor.shape}")
                    state_tensors.append(tensor)
            if state_tensors:
                concatenated_state = torch.cat(state_tensors, dim=-1)
                logger.debug(f"Concatenated state shape: {concatenated_state.shape}")
                normalized_batch["state"] = concatenated_state

        # If a non-shared rgb_encoder is used, split the "color" observation into separate camera keys.
        rgb_cfg = getattr(self.config, "rgb_encoder", None)
        if rgb_cfg and not rgb_cfg.shared_encoder and "color" in normalized_batch:
            color_tensor = normalized_batch.pop("color")
            for cam in range(self.n_cameras):
                normalized_batch[f"color_{cam}"] = color_tensor[:, cam]

        return normalized_batch

    @torch.no_grad()
    def predict_action(self, batch: dict[str, npt.NDArray | torch.Tensor], batched: bool = False) -> npt.NDArray:

        if "color" in batch:
            batch["color"] = self.reshape_color_input(batch["color"], batched)
        batch = self.cast_inputs_to_appropriate_type(batch, batched)

        if self.config.data.get("subtract_eef_pos_from_actions"):
            _, eef_pos_obs_name = self.config.data.subtract_eef_pos_from_actions
            raw_eef_pos = deepcopy(batch[eef_pos_obs_name])

        if self.config.data.get("subtract_eef_pos_from_pointcloud_obs"):
            pc_obs_name, eef_pos_obs_name = self.config.data.subtract_eef_pos_from_pointcloud_obs
            pc_obs = batch[pc_obs_name]
            if isinstance(pc_obs, (np.ndarray, torch.Tensor)):
                pc_obs[..., :3] = subtract_eef_pos_from_pointcloud_obs(batch, pc_obs_name, eef_pos_obs_name)
                batch[pc_obs_name] = pc_obs
            else:
                raise ValueError(f"Unsupported type for {pc_obs_name} in batch: {type(pc_obs)}")

        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        action = self.head.predict_action(features).squeeze()
        if self.normalizer is not None:
            action = self.normalizer["action"].unnormalize(action)

        if self.config.data.get("subtract_eef_pos_from_actions"):
            action_name, eef_pos_obs_name = self.config.data.subtract_eef_pos_from_actions
            _batch = {action_name: action, eef_pos_obs_name: raw_eef_pos}
            action[..., :3] = subtract_eef_pos_from_actions(
                data=_batch, action_name=action_name, eef_pos_obs_name=eef_pos_obs_name, forward=False
            )

        action = action.cpu().numpy()
        return action
