#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import warnings

import einops
import numpy as np
import ray.train
import torch
from lightning import LightningModule
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import Dataset

from visuomotor.data import is_lerobot_available

# Conditional imports for LeRobot functionality
if is_lerobot_available():
    from lerobot.configs.train import TrainPipelineConfig
    from lerobot.configs.types import FeatureType, PolicyFeature
    from lerobot.datasets.transforms import ImageTransformConfig, ImageTransformsConfig


def build_dynamic_input_features(train_dataset: Dataset, config: DictConfig) -> dict[str, PolicyFeature]:
    """Build input features by strictly inspecting the actual dataset."""
    input_features = {}

    # Get sample for dimension detection
    first_sample = train_dataset[0]

    # Extract visual features for each camera
    visual_keys = config.data.obs_keys.visual
    camera_ids = config.data.camera_ids

    for visual_key in visual_keys:
        for cam_idx in camera_ids:
            feature_key = f"{visual_key}_{cam_idx}"

            if feature_key in first_sample:
                img_tensor = first_sample[feature_key]

                # Directly extract dimensions from the tensor
                if isinstance(img_tensor, torch.Tensor):
                    # For PyTorch tensors
                    if img_tensor.dim() >= 3:
                        # Extract last 3 dimensions - handles any nesting level
                        dims = img_tensor.shape[-3:]

                        # Determine if channel-first or channel-last
                        if dims[-1] == 3:  # Channel-last format (H,W,C)
                            channels = dims[-1]
                            height, width = dims[-3], dims[-2]
                        else:  # Channel-first format (C,H,W)
                            channels = dims[0]
                            height, width = dims[1], dims[2]
                elif isinstance(img_tensor, np.ndarray):
                    # For NumPy arrays
                    if img_tensor.ndim >= 3:
                        # Extract last 3 dimensions
                        dims = img_tensor.shape[-3:]

                        # Determine if channel-first or channel-last
                        if dims[-1] == 3:  # Channel-last format (H,W,C)
                            channels = dims[-1]
                            height, width = dims[-3], dims[-2]
                        else:  # Channel-first format (C,H,W)
                            channels = dims[0]
                            height, width = dims[1], dims[2]

                # Create visual feature with detected dimensions
                input_features[feature_key] = PolicyFeature(type=FeatureType.VISUAL, shape=(channels, height, width))

    # Add state features based on actual data - ENSURE CONSISTENCY WITH STATISTICS
    if "observation.state" in first_sample:
        state_shape = first_sample["observation.state"].shape

        # For non-HF datasets, calculate expected total state dimension from config
        if hasattr(config.data, "obs_keys") and "state" in config.data.obs_keys:
            state_config = config.data.obs_keys.state
            if isinstance(state_config, dict):
                expected_total_dim = sum(
                    state_info["shape"][0] if isinstance(state_info["shape"], list) else state_info["shape"]
                    for state_info in state_config.values()
                )

                # ALWAYS use the expected dimension from config to ensure consistency
                # The first sample might be incomplete due to dataset processing order
                input_features["observation.state"] = PolicyFeature(type=FeatureType.STATE, shape=(expected_total_dim,))
            else:
                input_features["observation.state"] = PolicyFeature(type=FeatureType.STATE, shape=(state_shape[-1],))
        else:
            input_features["observation.state"] = PolicyFeature(type=FeatureType.STATE, shape=(state_shape[-1],))
    elif any(k.startswith("states") for k in first_sample.keys()):
        state_key = next(k for k in first_sample.keys() if k.startswith("states"))
        state_shape = first_sample[state_key].shape
        last_dim = state_shape[-1] if len(state_shape) > 1 else state_shape[0]
        input_features["observation.state"] = PolicyFeature(type=FeatureType.STATE, shape=(last_dim,))

    # ADDITIONAL CHECK: If we have individual state components, compute expected dimensions
    state_component_keys = [k for k in first_sample.keys() if k.startswith("observation.state.")]
    if state_component_keys and "observation.state" not in input_features:
        # Calculate total dimension from individual components
        total_state_dim = 0
        for key in sorted(state_component_keys):
            if not key.endswith("_is_pad"):  # Skip padding indicators
                component_shape = first_sample[key].shape
                # For 1D tensors, the shape[0] is the dimension count
                # For multi-dimensional tensors, use the last dimension
                if len(component_shape) == 1:
                    component_dim = component_shape[0]
                else:
                    component_dim = component_shape[-1]
                total_state_dim += component_dim

        input_features["observation.state"] = PolicyFeature(type=FeatureType.STATE, shape=(total_state_dim,))

    return input_features


def build_train_pipeline_config(config: DictConfig) -> TrainPipelineConfig:
    # Use correct import paths for LeRobot v0.3.2
    from lerobot.configs.train import DatasetConfig, TrainPipelineConfig
    from lerobot.policies.factory import make_policy_config

    # Create dataset config with image transforms from config
    def create_image_transforms_from_config(config: DictConfig) -> ImageTransformsConfig:
        """Convert config image_randomization to LeRobot ImageTransformsConfig format.
        Supports explicit override at data.image_transforms.enable.
        """
        # Explicit override path: data.image_transforms.enable=false disables all transforms
        override_block = getattr(config.data, "image_transforms", None)
        if override_block is not None and hasattr(override_block, "enable"):
            if not bool(override_block.enable):
                return ImageTransformsConfig(enable=False, tfs={})

        image_randomization = config.data.get("image_randomization", {})
        color_jitter = image_randomization.get("color_jitter", {})

        tfs = {}

        # Handle case where color_jitter is None (transforms disabled)
        if color_jitter is None:
            color_jitter = {}

        # Convert albumentations ColorJitter format to LeRobot format
        # Albumentations: brightness=0.3 means [1-0.3, 1+0.3] = [0.7, 1.3]
        if "brightness" in color_jitter:
            brightness_val = color_jitter["brightness"]
            brightness_range = (1.0 - brightness_val, 1.0 + brightness_val)
            tfs["brightness"] = ImageTransformConfig(
                weight=1.0, type="ColorJitter", kwargs={"brightness": brightness_range}
            )

        if "contrast" in color_jitter:
            contrast_val = color_jitter["contrast"]
            contrast_range = (1.0 - contrast_val, 1.0 + contrast_val)
            tfs["contrast"] = ImageTransformConfig(weight=1.0, type="ColorJitter", kwargs={"contrast": contrast_range})

        if "saturation" in color_jitter:
            saturation_val = color_jitter["saturation"]
            saturation_range = (1.0 - saturation_val, 1.0 + saturation_val)
            tfs["saturation"] = ImageTransformConfig(
                weight=1.0, type="ColorJitter", kwargs={"saturation": saturation_range}
            )

        if "hue" in color_jitter:
            hue_val = color_jitter["hue"]
            hue_range = (-hue_val, hue_val)
            tfs["hue"] = ImageTransformConfig(weight=1.0, type="ColorJitter", kwargs={"hue": hue_range})

        # Only enable transforms if we have color_jitter configured
        enable_transforms = len(tfs) > 0

        return ImageTransformsConfig(enable=enable_transforms, tfs=tfs)

    image_transforms = create_image_transforms_from_config(config)

    dataset_config = DatasetConfig(
        repo_id=config.data.repo_id,
        root=getattr(config.data, "root", None),  # Set to a specific path if needed
        revision=None,  # Or set to a specific revision
        episodes=[i for i in range(int(config.data.max_episodes))],  # Set if you want specific episodes
        video_backend=getattr(config.data, "video_backend", "torchcodec"),
        use_imagenet_stats=bool(getattr(config.data, "use_imagenet_stats", False)),
        image_transforms=image_transforms,
    )

    # Get the policy type from config
    policy_type = config.policy.type

    # Create policy config using lerobot's factory
    policy_config = make_policy_config(policy_type)

    # Set policy config values from your YAML config
    # Common parameters for all policies
    if hasattr(config.data, "n_obs_history_visual"):
        policy_config.n_obs_steps = config.data.n_obs_history_visual

    # Set policy-specific parameters from the YAML config (prefer top-level 'policy')
    if hasattr(config, "policy"):
        try:
            policy_section = OmegaConf.to_container(config.policy, resolve=True)
        except Exception:
            policy_section = dict(config.policy)
        if isinstance(policy_section, dict):
            for key, value in policy_section.items():
                if hasattr(policy_config, key) and key not in ("normalization", "type"):
                    setattr(policy_config, key, value)

    # Alternative approach: set from lerobot section
    if hasattr(config, "lerobot"):
        for key, value in config.lerobot.items():
            if hasattr(policy_config, key):
                setattr(policy_config, key, value)

    # Final safety: mirror from data.horizon if still defaulting
    if hasattr(config, "data") and hasattr(config.data, "horizon"):
        try:
            horizon_val = int(config.data.horizon)
            if getattr(policy_config, "chunk_size", 50) == 50:
                policy_config.chunk_size = horizon_val
            if getattr(policy_config, "n_action_steps", 50) == 50:
                policy_config.n_action_steps = horizon_val
        except Exception as exc:
            warnings.warn(
                f"Failed to apply horizon-derived timing (chunk_size/n_action_steps) from config.data.horizon: {exc}",
                UserWarning,
                stacklevel=2,
            )

    # Set normalization mapping if present in config
    if hasattr(config.policy, "normalization"):
        from lerobot.configs.types import NormalizationMode

        norm_config = config.policy.normalization
        norm_mapping = {}

        if hasattr(norm_config, "visual"):
            norm_mapping["VISUAL"] = getattr(NormalizationMode, norm_config.visual)
        if hasattr(norm_config, "state"):
            norm_mapping["STATE"] = getattr(NormalizationMode, norm_config.state)
        if hasattr(norm_config, "action"):
            norm_mapping["ACTION"] = getattr(NormalizationMode, norm_config.action)

        if norm_mapping and hasattr(policy_config, "normalization_mapping"):
            policy_config.normalization_mapping = norm_mapping

    # Apply model overrides for testing (e.g., smaller models for CPU)
    if hasattr(config, "model_overrides"):
        for key, value in config.model_overrides.items():
            if hasattr(policy_config, key):
                setattr(policy_config, key, value)
                print(f"Applied model override: {key} = {value}")

    # Return the combined config
    return TrainPipelineConfig(
        dataset=dataset_config,
        env=None,
        policy=policy_config,
        batch_size=config.train.batch_size,
        seed=config.train.seed,
        num_workers=config.train.num_workers,
    )


def combine_state_from_batch(
    batch: dict[str, torch.Tensor],
    state_names: list[str],
) -> torch.Tensor:
    ray.logger.info(f"state keys {batch.keys()} and state names: {state_names}")
    # breakpoint()
    states = []
    for key in state_names:
        state = batch[key]
        if state.dim() == 4:
            state = einops.rearrange(state, "... h w -> ... (h w)")
        if state.dim() == 1:
            state = state.unsqueeze(1)
        states.append(state)
    state = torch.cat(states, dim=-1)
    # If the resulting state tensor has a singleton time dimension, remove it.
    if state.dim() == 3 and state.shape[1] == 1:
        state = state.squeeze(1)
    return state


def process_and_log_losses(
    model: LightningModule,
    result: dict[str, torch.Tensor] | tuple[torch.Tensor, dict[str, torch.Tensor]] | torch.Tensor,
) -> torch.Tensor:
    """Process and log losses from LeRobot model outputs."""
    # Extract loss and metrics
    if isinstance(result, tuple) and len(result) == 2:
        loss, loss_dict = result
    else:
        loss = result
        loss_dict = None

    # Extract the actual loss tensor if needed
    if isinstance(loss, dict) and "loss" in loss:
        final_loss = loss["loss"]
        # Use the loss dict if we didn't get a loss_dict
        if loss_dict is None:
            loss_dict = loss
    else:
        final_loss = loss

    # Only log metrics when the model is in training mode to prevent step corruption during evaluation
    if model.training:
        # Log the loss
        if isinstance(final_loss, torch.Tensor):
            model.log("loss", final_loss)
        elif final_loss is None:
            # Handle the case where loss is None (could happen in some models)
            final_loss = torch.tensor(0.0, device=model.device)
            model.log("loss", final_loss)

        # Log loss components if available
        if loss_dict is not None:
            for k, v in loss_dict.items():
                if isinstance(v, torch.Tensor):
                    model.log(k, torch.mean(v))
                elif isinstance(v, (int, float)):
                    model.log(k, v)

        print(f"loss update policy: {final_loss}")
    else:
        # During evaluation, ensure we have a valid loss tensor but don't log it
        if final_loss is None:
            final_loss = torch.tensor(0.0, device=model.device)

    return final_loss
