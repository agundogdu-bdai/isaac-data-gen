#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any, Optional

import torch
import torch.nn.functional as F
from lightning.pytorch.utilities.types import STEP_OUTPUT
from omegaconf import DictConfig

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.policies.bc import BehaviorCloning


@register_model(name="flowpo", model_type=ModelType.POLICY, status="beta")
class FlowMatchingBehaviorCloning(BehaviorCloning):
    """Flow matching policy training module."""

    def __init__(self, config: DictConfig) -> None:
        super().__init__(config)
        self.rng_offset = 0  # increments each time we sample noise
        self.rank = 0  # will be set properly in setup() if distributed

    def setup(self, stage: Optional[str] = None) -> None:
        if self.trainer is not None and hasattr(self.trainer, "global_rank"):
            self.rank = self.trainer.global_rank
        else:
            self.rank = 0

    def on_load_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        # Restore offset, etc.
        self.rng_offset = checkpoint.get("rng_offset", 0)

    def on_save_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        # Store the rng_offset so we can resume the noise sequence after checkpoint
        checkpoint["rng_offset"] = self.rng_offset

    def forward(self, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        action = batch["action"]
        pred, noise = self.head(
            features,
            action=action,
            rank=self.rank,
            rng_offset=self.rng_offset,
        )
        self.rng_offset += 1  # update for next forward pass
        return pred, noise

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred, noise = self.forward(batch)
        loss = self.compute_loss(pred, noise)
        self.log("train_loss", loss)
        return loss

    def validation_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred, noise = self.forward(batch)
        loss = self.compute_loss(pred, noise)
        self.log("valid_loss", loss)
        return loss

    def compute_loss(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert y_hat.shape == y.shape, f"y_hat.shape: {y_hat.shape}, y.shape: {y.shape}"
        return F.mse_loss(y_hat, y)
