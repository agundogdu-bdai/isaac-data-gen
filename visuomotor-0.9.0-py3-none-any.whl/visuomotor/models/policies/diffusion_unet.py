#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
import math
from typing import Any, Optional, Union

import einops
import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.schedulers import DDIMScheduler
from einops.layers.torch import Rearrange
from omegaconf import DictConfig, ListConfig

from visuomotor.models.model_registry import REGISTRY, ModelType, register_model
from visuomotor.models.policies.base import BasePolicy

logger = logging.getLogger(__name__)


@register_model(name="diffusion_policy", model_type=ModelType.POLICY, status="beta")
class DiffusionPolicy(BasePolicy):
    def __init__(self, config: DictConfig | ListConfig) -> None:
        super().__init__(config)

        self.encoders = torch.nn.ModuleDict()
        if "color" in self.config.data.obs_keys.visual:
            num_encoders = 1 if self.config.rgb_encoder.shared_encoder else len(self.config.data.camera_ids)
            for cam in range(num_encoders):
                self.encoders[f"color_{cam}"] = REGISTRY.create_model(
                    name=self.config.rgb_encoder.name,
                    config=self.config.rgb_encoder,
                    model_type=ModelType.ENCODER_RGB,
                )

        # After building encoders, compute input_dim which is needed for the unet action head.
        self.config.input_dim = 0
        if "color" in self.config.data.obs_keys.visual:
            self.config.input_dim += (
                self.config.rgb_encoder.output_dim
                * len(self.config.data.camera_ids)
                * self.config.data.n_obs_history_visual
            )
        if self.config.data.obs_keys.state is not None:
            self.config.input_dim += self.calculate_state_input_dim()
        self.model = UNetDiffusionModel(self.config)

        self.rank = 0
        self.rng_offset = 0  # increments each time we sample noise

    def setup(self, stage: Optional[str] = None) -> None:
        # The rank and rng_offset are only used for diffusion-based policies
        if self.trainer is not None and hasattr(self.trainer, "global_rank"):
            self.rank = self.trainer.global_rank
        else:
            self.rank = 0

    def encode(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Encodes observations using registered encoders and concatenates them into a
        single global feature tensor of shape [B, input_dim].
        """
        features: list[torch.Tensor] = []

        # Visual encoders (RGB)
        if "color_0" in self.encoders:
            n_cams = len(self.config.data.camera_ids)
            if self.config.rgb_encoder.shared_encoder:
                assert batch["color"].dim() == 6, "Color tensor must be 6 dimensional, [B, T, N, C, H, W]"
                # Combine batch, time, and camera dimensions so we can do a single forward pass
                input_images = einops.rearrange(batch["color"], "b t n c h w -> (b t n) c h w")
                encoded = self.encoders["color_0"](input_images)
                # UNet diffpo expects RGB encoder output to be two dimensional [B*T*N, D]
                assert encoded.dim() == 2, "The output dimension of the RGB encoder should be 2"
                # Unpack time and camera dimensions and pack them back together with feature dimension
                input_encoded = einops.rearrange(
                    encoded,
                    "(b t n) d -> b (t n d)",
                    b=batch["color"].shape[0],
                    t=batch["color"].shape[1],
                    n=batch["color"].shape[2],
                )
                features.append(input_encoded)
            else:
                for cam in range(n_cams):
                    input_images = einops.rearrange(batch["color"][:, :, cam], "b t c h w -> (b t) c h w")
                    encoded = self.encoders[f"color_{cam}"](input_images)
                    assert encoded.dim() == 2, "The output dimension of the RGB encoder should be 2"
                    input_encoded = einops.rearrange(
                        encoded, "(b t) d -> b (t d)", b=batch["color"].shape[0], t=batch["color"].shape[1]
                    )
                    features.append(input_encoded)

        # Diffusion policy does not use state encoders so we concatenate state tensors directly
        if self.config.data.obs_keys.state is not None:
            state_tensors = []
            for k in self.config.data.obs_keys.state.keys():
                # Combine time and state dimensions
                assert batch[k].dim() == 3, "State tensor must be 3 dimensional, [B, T, D]"
                input_state = einops.rearrange(batch[k], "b t d -> b (t d)")
                state_tensors.append(input_state)
            # Concatenate state along last dimension
            state_cat = torch.cat(state_tensors, dim=-1)
            features.append(state_cat)

        assert len(features) > 0, "No features were encoded. Check visual/state obs keys in the config."

        # Concatenate all features into [B, input_dim]
        return torch.cat(features, dim=1)

    def forward(self, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Training-time forward pass returning (prediction, noise).
        Expects 'action' in the batch with shape [B, horizon, action_dim].
        """
        normalized = self.normalize_inputs(batch)
        features = self.encode(normalized)
        pred, noise = self.model(
            features=features, action=normalized["action"], rank=self.rank, rng_offset=self.rng_offset
        )
        self.rng_offset += 1  # update for next forward pass
        return pred, noise

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> torch.Tensor:
        pred, noise = self.forward(batch)

        if self.config.noise_scheduler.prediction_type == "epsilon":
            target = noise
        elif self.config.noise_scheduler.prediction_type == "sample":
            target = batch["action"]
        else:
            raise ValueError(f"Invalid prediction type {self.config.noise_scheduler.prediction_type}")

        loss = F.mse_loss(pred, target)
        self.log("train_loss", loss)
        return loss


class UNetDiffusionModel(nn.Module):
    """
    1D diffusion policy action head with optional CUDA Graph support.

    If `config.use_cuda_graph` is True, the model captures a single forward
    pass of the denoiser into a CUDA Graph, reusing it for each timestep in the
    diffusion sampling loop. This enhances inference speed once input shapes
    are fixed.
    """

    def __init__(self, config: DictConfig) -> None:
        """
        Args:
            config: Configuration object (OmegaConf). Expected keys:
                - use_cuda_graph (bool): whether to enable CUDA Graph capturing
                - num_inference_steps (int): number of steps for DDIM inference
                - horizon (int): how many future actions to generate
                - input_dim (int): dimension of the global conditioning input
                - action_dim (int): dimension of the action space
                - batch_size (int): (if use_cuda_graph) the fixed batch size for capture
                - unet1d (dict): config for the chosen denoiser
                - noise_scheduler (dict): config for `DDIMScheduler`
        """
        super().__init__()
        self.config = config
        self.seed = getattr(config, "seed", 42)
        # Build the basic modules (denoiser + Scheduler).
        self.compile_model = getattr(config, "compile_model", False)

        # Build the main denoiser and noise scheduler first
        self.unet = ConditionalUnet1D(
            input_dim=self.config.action_dim,
            local_cond_dim=None,
            global_cond_dim=self.config.input_dim,
            **self.config.unet1d,
        )

        if self.compile_model:
            self.unet = torch.compile(self.unet)

        # Scheduler
        self.noise_scheduler = DDIMScheduler(**self.config.noise_scheduler)

        # Optionally prepare CUDA Graph (including warm-up).
        self.use_cuda_graph = getattr(config, "use_cuda_graph", False)
        if self.use_cuda_graph:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            if self.device == torch.device("cpu"):
                raise ValueError("Cannot use CUDA Graph on CPU.")
            self.unet.to(self.device)
            self.batch_size = self.config.batch_size
            self._build_cuda_graph()

    def _build_cuda_graph(self) -> None:
        """
        Captures a single forward pass of the model into a CUDA Graph.
        This graph can be replayed for each timestep in `predict_action`.

        NOTE: This approach requires:
            1) A fixed batch size, horizon, and action_dim.
            2) The same shapes on every forward pass.
        """
        horizon = self.config.data.horizon
        action_dim = self.config.action_dim
        global_cond_dim = self.config.input_dim

        # Allocate static buffers using the current batch size
        self.static_noisy_action = torch.empty(
            (self.batch_size, horizon, action_dim), device=self.device, dtype=torch.float32
        )
        self.static_timestep = torch.empty((), device=self.device, dtype=torch.long)
        self.static_global_cond = torch.empty(
            (self.batch_size, global_cond_dim), device=self.device, dtype=torch.float32
        )
        # Allocate static buffer for the model output
        self.static_model_output = torch.empty_like(self.static_noisy_action)

        # Warm-up passes to ensure all lazy kernels are initialized
        warmup_iterations = 1
        for _ in range(warmup_iterations):
            _ = self.unet(
                sample=self.static_noisy_action, timestep=self.static_timestep, global_cond=self.static_global_cond
            )
        torch.cuda.synchronize()

        # Now capture the forward pass in a CUDA Graph
        self.cuda_graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.cuda_graph):
            out = self.unet(
                sample=self.static_noisy_action, timestep=self.static_timestep, global_cond=self.static_global_cond
            )
            # Copy the forward pass output into the static buffer
            self.static_model_output.copy_(out)

    def __getstate__(self) -> dict:
        state = self.__dict__.copy()
        if hasattr(state, "cuda_graph"):
            state.pop("cuda_graph", None)  # Exclude the cuda_graph from serialization
        return state

    def initialize_cuda_graph(self) -> None:
        """
        Initializes (or reinitializes) the CUDA graph using the current stored batch size.
        This method should be called after deserializing a model checkpoint or whenever the CUDA graph
        is lost, as CUDA graphs cannot be serialized.

        It moves the denoiser to the proper device and rebuilds the CUDA graph.
        """
        if self.use_cuda_graph:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            if self.device == torch.device("cpu"):
                raise ValueError("Cannot use CUDA Graph on CPU.")
            self.unet.to(self.device)
            self._build_cuda_graph()

    def forward(
        self,
        features: torch.Tensor,
        action: torch.Tensor,
        rank: int,
        rng_offset: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Performs the diffusion forward pass, including:
          1. Sampling noise and timesteps (using an ephemeral generator)
          2. Adding noise to the action via the noise scheduler
          3. Running the noisy trajectory through the denoiser

        Args:
            features: Global conditioning tensor (e.g. encoded observations), shape [B, input_dim]
            action: Ground-truth action tensor, shape [B, horizon, action_dim]
            rank: Integer rank (used to compute an offset for the random seed)
            rng_offset: An offset for the random generator (increments per forward pass)

        Returns:
            pred: The denoiser prediction, shape [B, horizon, action_dim]
            noise: The noise tensor that was sampled and added to the action, shape [B, horizon, action_dim]
        """
        action_shape = action.shape
        action_device = action.device

        # 1) Set up the random generator.
        base_seed = self.seed  # expects train.seed in the config
        rank_offset = rank * 100_000  # large offset per rank to avoid collisions
        local_seed = base_seed + rank_offset + rng_offset
        gen = torch.Generator(device=action_device)
        gen.manual_seed(local_seed)

        # 2) Sample noise and timesteps.
        noise = torch.randn(action_shape, device=action_device, generator=gen)
        timesteps = torch.randint(
            0,
            int(self.noise_scheduler.config.num_train_timesteps),
            (action_shape[0],),
            device=action_device,
            generator=gen,
        ).long()

        # 3) Add noise to the action.
        noisy_trajectory = self.noise_scheduler.add_noise(action, noise, timesteps)

        # 4) Compute the denoiser prediction.
        pred = self.unet(sample=noisy_trajectory, timestep=timesteps, global_cond=features)
        return pred, noise

    def generate_action(self, features: torch.Tensor) -> torch.Tensor:
        """
        Predicts a sequence of actions via DDIM sampling.
        Optimized to run encoder only once for transformer models.

        Args:
            x: Global conditioning tensor (encoded observations), shape [B, input_dim] or dict of encoder features
            n_obs_history: Dictionary mapping encoder names to their history length (for fusion)

        Returns:
            trajectory: Predicted action sequence, shape [B, horizon, action_dim]
        """
        self.noise_scheduler.set_timesteps(self.config.num_inference_steps)

        batch_size = features.shape[0]
        horizon = self.config.horizon
        action_dim = self.config.action_dim

        # Generate initial trajectory noise
        trajectory = torch.randn((batch_size, horizon, action_dim), device=features.device, dtype=features.dtype)

        if not self.use_cuda_graph:
            # Original path for non-transformer models without CUDA graph
            for t in self.noise_scheduler.timesteps:
                model_output = self.unet(sample=trajectory, timestep=t, global_cond=features)
                trajectory = self.noise_scheduler.step(model_output, t, trajectory).prev_sample

            return trajectory
        else:
            # CUDA Graph path
            if batch_size != self.batch_size:
                logger.info(f"Rebuilding CUDA graph with new batch size: {batch_size} (old: {self.batch_size}).")
                self.batch_size = batch_size
                self._build_cuda_graph()

            self.static_global_cond.copy_(features)
            for t in self.noise_scheduler.timesteps:
                self.static_timestep.copy_(torch.tensor(t, device=self.device, dtype=torch.long))
                self.static_noisy_action.copy_(trajectory)

                # Replay the CUDA graph
                self.cuda_graph.replay()

                # Use the captured output to get the next step
                trajectory = self.noise_scheduler.step(self.static_model_output, t, trajectory).prev_sample

            return trajectory.detach()


class Downsample1d(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.conv = nn.Conv1d(dim, dim, 3, 2, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)


class Upsample1d(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.conv = nn.ConvTranspose1d(dim, dim, 4, 2, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)


class Conv1dBlock(nn.Module):
    def __init__(self, inp_channels: int, out_channels: int, kernel_size: int, n_groups: int = 8) -> None:
        super().__init__()

        self.block = nn.Sequential(
            nn.Conv1d(inp_channels, out_channels, kernel_size, padding=kernel_size // 2),
            # Rearrange('batch channels horizon -> batch channels 1 horizon'),
            nn.GroupNorm(n_groups, out_channels),
            # Rearrange('batch channels 1 horizon -> batch channels horizon'),
            nn.Mish(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class SinusoidalPosEmb(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.dim = dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        device = x.device
        half_dim = self.dim // 2
        emb = math.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=device) * -emb)
        emb = x[:, None] * emb[None, :]  # type: ignore
        emb = torch.cat((emb.sin(), emb.cos()), dim=-1)  # type: ignore
        return emb


class CrossAttention(nn.Module):
    def __init__(self, in_dim: int, cond_dim: int, out_dim: int) -> None:
        super().__init__()
        self.query_proj = nn.Linear(in_dim, out_dim)
        self.key_proj = nn.Linear(cond_dim, out_dim)
        self.value_proj = nn.Linear(cond_dim, out_dim)

    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # x: [batch_size, t_act, in_dim]
        # cond: [batch_size, t_obs, cond_dim]

        # Project x and cond to query, key, and value
        query = self.query_proj(x)  # [batch_size, horizon, out_dim]
        key = self.key_proj(cond)  # [batch_size, horizon, out_dim]
        value = self.value_proj(cond)  # [batch_size, horizon, out_dim]

        # Compute attention
        attn_weights = torch.matmul(query, key.transpose(-2, -1))  # [batch_size, horizon, horizon]
        attn_weights = F.softmax(attn_weights, dim=-1)

        # Apply attention
        attn_output = torch.matmul(attn_weights, value)  # [batch_size, horizon, out_dim]

        return attn_output


class ConditionalResidualBlock1D(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        cond_dim: int,
        kernel_size: int = 3,
        n_groups: int = 8,
        condition_type: str = "film",
    ) -> None:
        super().__init__()

        self.blocks = nn.ModuleList(
            [
                Conv1dBlock(in_channels, out_channels, kernel_size, n_groups=n_groups),
                Conv1dBlock(out_channels, out_channels, kernel_size, n_groups=n_groups),
            ]
        )

        self.condition_type = condition_type

        cond_channels = out_channels
        if condition_type == "film":  # FiLM modulation https://arxiv.org/abs/1709.07871
            # predicts per-channel scale and bias
            cond_channels = out_channels * 2
            self.cond_encoder = nn.Sequential(
                nn.Mish(),
                nn.Linear(cond_dim, cond_channels),
                Rearrange("batch t -> batch t 1"),
            )
        elif condition_type == "add":
            self.cond_encoder = nn.Sequential(
                nn.Mish(),
                nn.Linear(cond_dim, out_channels),
                Rearrange("batch t -> batch t 1"),
            )
        elif condition_type == "cross_attention_add":
            self.cond_encoder = CrossAttention(in_channels, cond_dim, out_channels)
        elif condition_type == "cross_attention_film":
            cond_channels = out_channels * 2
            self.cond_encoder = CrossAttention(in_channels, cond_dim, cond_channels)
        elif condition_type == "mlp_film":
            cond_channels = out_channels * 2
            self.cond_encoder = nn.Sequential(
                nn.Mish(),
                nn.Linear(cond_dim, cond_dim),
                nn.Mish(),
                nn.Linear(cond_dim, cond_channels),
                Rearrange("batch t -> batch t 1"),
            )
        else:
            raise NotImplementedError(f"condition_type {condition_type} not implemented")

        self.out_channels = out_channels
        # make sure dimensions compatible
        self.residual_conv = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()

    def forward(self, x: torch.Tensor, cond: torch.Tensor | None = None) -> torch.Tensor:
        """
        x : [ batch_size x in_channels x horizon ]
        cond : [ batch_size x cond_dim]

        returns:
        out : [ batch_size x out_channels x horizon ]
        """
        out = self.blocks[0](x)
        if cond is not None:
            if self.condition_type == "film":
                embed = self.cond_encoder(cond)
                embed = embed.reshape(embed.shape[0], 2, self.out_channels, 1)
                scale = embed[:, 0, ...]
                bias = embed[:, 1, ...]
                out = scale * out + bias
            elif self.condition_type == "add":
                embed = self.cond_encoder(cond)
                out = out + embed
            elif self.condition_type == "cross_attention_add":
                embed = self.cond_encoder(x.permute(0, 2, 1), cond)
                embed = embed.permute(0, 2, 1)  # [batch_size, out_channels, horizon]
                out = out + embed
            elif self.condition_type == "cross_attention_film":
                embed = self.cond_encoder(x.permute(0, 2, 1), cond)
                embed = embed.permute(0, 2, 1)
                embed = embed.reshape(embed.shape[0], 2, self.out_channels, -1)
                scale = embed[:, 0, ...]
                bias = embed[:, 1, ...]
                out = scale * out + bias
            elif self.condition_type == "mlp_film":
                embed = self.cond_encoder(cond)
                embed = embed.reshape(embed.shape[0], 2, self.out_channels, -1)
                scale = embed[:, 0, ...]
                bias = embed[:, 1, ...]
                out = scale * out + bias
            else:
                raise NotImplementedError(f"condition_type {self.condition_type} not implemented")
        out = self.blocks[1](out)
        out = out + self.residual_conv(x)
        return out


class ConditionalUnet1D(nn.Module):
    def __init__(
        self,
        input_dim: int,
        local_cond_dim: int | None = None,
        global_cond_dim: int | None = None,
        diffusion_step_embed_dim: int = 256,
        down_dims: tuple[int, ...] = (256, 512, 1024),
        kernel_size: int = 3,
        n_groups: int = 8,
        condition_type: str = "film",
        use_down_condition: bool = True,
        use_mid_condition: bool = True,
        use_up_condition: bool = True,
    ) -> None:
        super().__init__()
        self.condition_type = condition_type

        self.use_down_condition = use_down_condition
        self.use_mid_condition = use_mid_condition
        self.use_up_condition = use_up_condition

        all_dims = [input_dim] + list(down_dims)
        start_dim = down_dims[0]

        dsed = diffusion_step_embed_dim
        diffusion_step_encoder = nn.Sequential(
            SinusoidalPosEmb(dsed),
            nn.Linear(dsed, dsed * 4),
            nn.Mish(),
            nn.Linear(dsed * 4, dsed),
        )
        cond_dim = dsed
        if global_cond_dim is not None:
            cond_dim += global_cond_dim

        in_out = list(zip(all_dims[:-1], all_dims[1:]))  # noqa

        local_cond_encoder = None
        if local_cond_dim is not None:
            _, dim_out = in_out[0]
            dim_in = local_cond_dim
            local_cond_encoder = nn.ModuleList(
                [
                    # down encoder
                    ConditionalResidualBlock1D(
                        dim_in,
                        dim_out,
                        cond_dim=cond_dim,
                        kernel_size=kernel_size,
                        n_groups=n_groups,
                        condition_type=condition_type,
                    ),
                    # up encoder
                    ConditionalResidualBlock1D(
                        dim_in,
                        dim_out,
                        cond_dim=cond_dim,
                        kernel_size=kernel_size,
                        n_groups=n_groups,
                        condition_type=condition_type,
                    ),
                ]
            )

        mid_dim = all_dims[-1]
        self.mid_modules = nn.ModuleList(
            [
                ConditionalResidualBlock1D(
                    mid_dim,
                    mid_dim,
                    cond_dim=cond_dim,
                    kernel_size=kernel_size,
                    n_groups=n_groups,
                    condition_type=condition_type,
                ),
                ConditionalResidualBlock1D(
                    mid_dim,
                    mid_dim,
                    cond_dim=cond_dim,
                    kernel_size=kernel_size,
                    n_groups=n_groups,
                    condition_type=condition_type,
                ),
            ]
        )

        down_modules = nn.ModuleList([])
        for ind, (dim_in, dim_out) in enumerate(in_out):
            is_last = ind >= (len(in_out) - 1)
            down_modules.append(
                nn.ModuleList(
                    [
                        ConditionalResidualBlock1D(
                            dim_in,
                            dim_out,
                            cond_dim=cond_dim,
                            kernel_size=kernel_size,
                            n_groups=n_groups,
                            condition_type=condition_type,
                        ),
                        ConditionalResidualBlock1D(
                            dim_out,
                            dim_out,
                            cond_dim=cond_dim,
                            kernel_size=kernel_size,
                            n_groups=n_groups,
                            condition_type=condition_type,
                        ),
                        Downsample1d(dim_out) if not is_last else nn.Identity(),
                    ]
                )
            )

        up_modules = nn.ModuleList([])
        for ind, (dim_in, dim_out) in enumerate(reversed(in_out[1:])):
            is_last = ind >= (len(in_out) - 1)
            up_modules.append(
                nn.ModuleList(
                    [
                        ConditionalResidualBlock1D(
                            dim_out * 2,
                            dim_in,
                            cond_dim=cond_dim,
                            kernel_size=kernel_size,
                            n_groups=n_groups,
                            condition_type=condition_type,
                        ),
                        ConditionalResidualBlock1D(
                            dim_in,
                            dim_in,
                            cond_dim=cond_dim,
                            kernel_size=kernel_size,
                            n_groups=n_groups,
                            condition_type=condition_type,
                        ),
                        Upsample1d(dim_in) if not is_last else nn.Identity(),
                    ]
                )
            )

        final_conv = nn.Sequential(
            Conv1dBlock(start_dim, start_dim, kernel_size=kernel_size),
            nn.Conv1d(start_dim, input_dim, 1),
        )

        self.diffusion_step_encoder = diffusion_step_encoder
        self.local_cond_encoder = local_cond_encoder
        self.up_modules = up_modules
        self.down_modules = down_modules
        self.final_conv = final_conv

    def forward(
        self,
        sample: torch.Tensor,
        timestep: Union[torch.Tensor, float, int],
        local_cond: torch.Tensor | None = None,
        global_cond: torch.Tensor | None = None,
        **kwargs: Any,
    ) -> torch.Tensor:
        """
        sample: (B,T,input_dim)
        timestep: (B,) or int, diffusion step
        local_cond: (B,T,local_cond_dim)
        global_cond: (B,global_cond_dim)
        output: (B,T,input_dim)
        """
        sample = einops.rearrange(sample, "b h t -> b t h")

        # 1. time
        timesteps = timestep
        if not torch.is_tensor(timesteps):
            # TODO: this requires sync between CPU and GPU. So try to pass timesteps as tensors if you can
            timesteps = torch.tensor([timesteps], dtype=torch.long, device=sample.device)
        elif torch.is_tensor(timesteps) and len(timesteps.shape) == 0:  # type: ignore
            timesteps = timesteps[None].to(sample.device)  # type: ignore
        # broadcast to batch dimension in a way that's compatible with ONNX/Core ML
        timesteps = timesteps.expand(sample.shape[0])  # type: ignore

        timestep_embed = self.diffusion_step_encoder(timesteps)
        if global_cond is not None:
            if self.condition_type == "cross_attention":
                timestep_embed = timestep_embed.unsqueeze(1).expand(-1, global_cond.shape[1], -1)
            # global_feature = torch.cat([timestep_embed, global_cond], axis=-1)
            timestep_embed = timestep_embed.to(global_cond.device)
            global_feature = torch.cat([timestep_embed, global_cond], axis=-1)

        # encode local features
        h_local = list()
        if local_cond is not None:
            local_cond = einops.rearrange(local_cond, "b h t -> b t h")
            resnet, resnet2 = self.local_cond_encoder  # type: ignore
            x = resnet(local_cond, global_feature)
            h_local.append(x)
            x = resnet2(local_cond, global_feature)
            h_local.append(x)

        x = sample
        h = []
        for idx, (resnet, resnet2, downsample) in enumerate(self.down_modules):
            if self.use_down_condition:
                x = resnet(x, global_feature)
                if idx == 0 and len(h_local) > 0:
                    x = x + h_local[0]
                x = resnet2(x, global_feature)
            else:
                x = resnet(x)
                if idx == 0 and len(h_local) > 0:
                    x = x + h_local[0]
                x = resnet2(x)
            h.append(x)
            x = downsample(x)

        for mid_module in self.mid_modules:
            if self.use_mid_condition:
                x = mid_module(x, global_feature)
            else:
                x = mid_module(x)

        for idx, (resnet, resnet2, upsample) in enumerate(self.up_modules):
            x = torch.cat((x, h.pop()), dim=1)
            if self.use_up_condition:
                x = resnet(x, global_feature)
                if idx == len(self.up_modules) and len(h_local) > 0:
                    x = x + h_local[1]
                x = resnet2(x, global_feature)
            else:
                x = resnet(x)
                if idx == len(self.up_modules) and len(h_local) > 0:
                    x = x + h_local[1]
                x = resnet2(x)
            x = upsample(x)

        x = self.final_conv(x)

        x = einops.rearrange(x, "b t h -> b h t")

        return x
