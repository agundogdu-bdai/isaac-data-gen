#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import copy
import logging
from typing import Optional

import einops
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.schedulers import DDIMScheduler
from omegaconf import DictConfig, ListConfig

from visuomotor.models.model_registry import REGISTRY, ModelType, register_model
from visuomotor.models.policies.base import BasePolicy
from visuomotor.models.utils import get_activation, with_pos_embed

logger = logging.getLogger(__name__)


@register_model(name="diffusion_transformer", model_type=ModelType.POLICY, status="beta")
class DiffusionTransformerPolicy(BasePolicy):
    def __init__(self, config: DictConfig | ListConfig) -> None:
        super().__init__(config)

        if self.config.data.n_obs_history_visual > 1 or self.config.data.n_obs_history_state > 1:
            raise ValueError("DiffusionTransformerPolicy does not support temporal history.")

        self.encoders = torch.nn.ModuleDict()
        if "color" in self.config.data.obs_keys.visual:
            num_encoders = 1 if self.config.rgb_encoder.shared_encoder else len(self.config.data.camera_ids)
            for cam in range(num_encoders):
                self.encoders[f"color_{cam}"] = REGISTRY.create_model(
                    name=self.config.rgb_encoder.name,
                    config=self.config.rgb_encoder,
                    model_type=ModelType.ENCODER_RGB,
                )

        if self.config.data.obs_keys.state is not None:
            self.config.state_encoder.input_dim = self.calculate_state_input_dim()
            self.encoders["state"] = REGISTRY.create_model(
                name=self.config.state_encoder.name,
                config=self.config.state_encoder,
                model_type=ModelType.ENCODER_STATE,
            )

        self.dit = DiTModel(self.config)

        self.rank = 0
        self.rng_offset = 0  # increments each time we sample noise

    def setup(self, stage: Optional[str] = None) -> None:
        # The rank and rng_offset are only used for diffusion-based policies
        if self.trainer is not None and hasattr(self.trainer, "global_rank"):
            self.rank = self.trainer.global_rank
        else:
            self.rank = 0

    def encode(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        features: list[torch.Tensor] = []

        # Visual encoders (RGB)
        if "color_0" in self.encoders:
            n_cams = len(self.config.data.camera_ids)
            if self.config.rgb_encoder.shared_encoder:
                assert batch["color"].dim() == 6, "Color tensor must be 6 dimensional, [B, T, N, C, H, W]"
                # Combine batch, time, and camera dimensions so we can do a single forward pass
                input_images = einops.rearrange(batch["color"], "b t n c h w -> (b t n) c h w")
                encoded = self.encoders["color_0"](input_images)
                input_encoded = einops.rearrange(
                    encoded,
                    "(b t n) d -> (b t) n d",
                    b=batch["color"].shape[0],
                    t=batch["color"].shape[1],
                    n=batch["color"].shape[2],
                )
                features.extend([input_encoded[:, i, :] for i in range(input_encoded.shape[1])])
            else:
                for cam in range(n_cams):
                    # TODO (tarik): Handle timesteps here
                    input_images = einops.rearrange(batch["color"][:, :, cam], "b t c h w -> (b t) c h w")
                    encoded = self.encoders[f"color_{cam}"](input_images)
                    input_encoded = einops.rearrange(
                        encoded, "(b t) d -> b (t d)", b=batch["color"].shape[0], t=batch["color"].shape[1]
                    )
                    features.append(input_encoded)

        # State encoder
        if "state" in self.encoders:
            state_tensors = []
            for k in self.config.data.obs_keys.state.keys():
                # TODO (tarik): Handle timesteps here
                assert batch[k].dim() == 3, "State tensor must be 3 dimensional, [B, T, D]"
                input_state = einops.rearrange(batch[k], "b t d -> b (t d)")
                state_tensors.append(input_state)
            # Concatenate state along last dimension
            state_cat = torch.cat(state_tensors, dim=-1)
            encoded = self.encoders["state"](state_cat)
            features.append(encoded)

        assert len(features) > 0, "No features were encoded. Check visual/state obs keys in the config."

        # Concatenate all features into [B, E, D]
        features_combined = torch.stack(features, dim=1)
        # TODO (tarik): Original DiT-Block Policy apply a dropout before feeding the tokens into the
        # transformer. Do we actually need to do it here?
        return features_combined

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        normalized = self.normalize_inputs(batch)
        features = self.encode(normalized)
        actions = self.dit(features=features, action=normalized["action"], rank=self.rank, rng_offset=self.rng_offset)
        return actions

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> torch.Tensor:
        pred, noise = self.forward(batch)

        if self.config.noise_scheduler.prediction_type == "epsilon":
            target = noise
        elif self.config.noise_scheduler.prediction_type == "sample":
            target = batch["action"]
        else:
            raise ValueError(f"Invalid prediction type {self.config.noise_scheduler.prediction_type}")

        loss = F.mse_loss(pred, target)
        self.log("train_loss", loss)
        return loss


class DiTModel(nn.Module):
    """DiT action head.

    Uses the DiT (Diffusion Transformer) model to predict a sequence of actions.

    Based on https://github.com/facebookresearch/DiT and https://github.com/SudeepDasari/dit-policy.
    """

    def __init__(self, config: DictConfig) -> None:
        super().__init__()
        self.config = config
        self.seed = getattr(config, "seed", 42)
        # Build the basic modules (denoiser + Scheduler).
        self.compile_model = getattr(config, "compile_model", False)
        self.model = DiffusionTransformer(self.config)

        if self.compile_model:
            self.model = torch.compile(self.model)

        # Scheduler
        self.noise_scheduler = DDIMScheduler(**self.config.noise_scheduler)

    def forward(
        self,
        features: torch.Tensor,
        action: torch.Tensor,
        rank: int,
        rng_offset: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Performs the diffusion forward pass, including:
          1. Sampling noise and timesteps (using an ephemeral generator)
          2. Adding noise to the action via the noise scheduler
          3. Running the noisy trajectory through the denoiser

        Args:
            h: Global conditioning tensor (e.g. encoded observations), shape [B, input_dim] or dict of encoder features
            action: Ground-truth action tensor, shape [B, horizon, action_dim]
            rank: Integer rank (used to compute an offset for the random seed)
            rng_offset: An offset for the random generator (increments per forward pass)

        Returns:
            pred: The denoiser prediction, shape [B, horizon, action_dim]
            noise: The noise tensor that was sampled and added to the action, shape [B, horizon, action_dim]
        """

        action_shape = action.shape
        action_device = action.device

        # 1) Set up the random generator.
        base_seed = self.seed  # expects train.seed in the config
        rank_offset = rank * 100_000  # large offset per rank to avoid collisions
        local_seed = base_seed + rank_offset + rng_offset
        gen = torch.Generator(device=action_device)
        gen.manual_seed(local_seed)

        # 2) Sample noise and timesteps.
        noise = torch.randn(action_shape, device=action_device, generator=gen)
        timesteps = torch.randint(
            0,
            int(self.noise_scheduler.config.num_train_timesteps),
            (action_shape[0],),
            device=action_device,
            generator=gen,
        ).long()

        # 3) Add noise to the action.
        noisy_trajectory = self.noise_scheduler.add_noise(action, noise, timesteps)

        # 4) Compute the denoiser prediction.
        pred = self.model(noise_actions=noisy_trajectory, time=timesteps, tokens=features)
        return pred, noise

    def generate_action(self, features: torch.Tensor) -> torch.Tensor:
        """
        Predicts a sequence of actions via DDIM sampling.
        Optimized to run encoder only once for transformer models.

        Args:
            x: Global conditioning tensor (encoded observations), shape [B, input_dim] or dict of encoder features
            n_obs_history: Dictionary mapping encoder names to their history length (for fusion)

        Returns:
            trajectory: Predicted action sequence, shape [B, horizon, action_dim]
        """

        self.noise_scheduler.set_timesteps(self.config.num_inference_steps)

        batch_size = features.shape[0]
        horizon = self.config.data.horizon
        action_dim = self.config.action_dim

        # Generate initial trajectory noise
        trajectory = torch.randn((batch_size, horizon, action_dim), device=features.device, dtype=features.dtype)

        # For transformer models, compute encoder output once
        enc_cache = self.model.forward_enc(features)
        # Then only use the decoder in the diffusion loop
        for t in self.noise_scheduler.timesteps:
            # For transformer, expand timestep to batch dimension
            tstep = t.to(device=features.device, dtype=torch.long).expand(batch_size)

            # Only run the decoder part
            model_output = self.model.forward_dec(trajectory, tstep, enc_cache)
            trajectory = self.noise_scheduler.step(model_output, t, trajectory).prev_sample

        return trajectory


class DiffusionTransformer(nn.Module):
    def __init__(self, config: DictConfig) -> None:
        super().__init__()

        self.action_dim = config.action_dim
        self.action_seq_len = config.data.horizon

        # Positional encoding blocks
        self.enc_pos = PositionalEncoding(config.dit_model.hidden_dim)
        self.register_parameter(
            "dec_pos",
            nn.Parameter(torch.empty(self.action_seq_len, 1, config.dit_model.hidden_dim), requires_grad=True),
        )
        nn.init.xavier_uniform_(self.dec_pos.data)

        # Input encoder MLPs
        self.time_net = TimeNetwork(config.dit_model.time_dim, config.dit_model.hidden_dim)
        self.action_proj = nn.Sequential(
            nn.Linear(config.action_dim, config.action_dim),
            nn.GELU(approximate="tanh"),
            nn.Linear(config.action_dim, config.dit_model.hidden_dim),
        )

        # Encoder blocks
        encoder_module = SelfAttnEncoder(
            config.dit_model.hidden_dim,
            nhead=config.dit_model.nhead,
            dim_feedforward=config.dit_model.dim_feedforward,
            dropout=config.dit_model.dropout,
            activation=config.dit_model.activation,
        )
        self.encoder = TransformerEncoder(encoder_module, config.dit_model.num_blocks)

        # Decoder blocks
        decoder_module = DiTDecoder(
            config.dit_model.hidden_dim,
            nhead=config.dit_model.nhead,
            dim_feedforward=config.dit_model.dim_feedforward,
            dropout=config.dit_model.dropout,
            activation=config.dit_model.activation,
        )
        self.decoder = TransformerDecoder(decoder_module, config.dit_model.num_blocks)

        # Final output layer
        self.eps_out = FinalLayer(config.dit_model.hidden_dim, config.action_dim)

        logger.info("Number of DiT parameters: %e", sum(p.numel() for p in self.parameters()))

    def forward(self, noise_actions: torch.Tensor, time: torch.Tensor, tokens: torch.Tensor) -> torch.Tensor:
        # noise_actions: [B, action_seq_len, action_dim], time: [B], tokens: [B, E, H]

        # Encoder
        enc_cache = self.forward_enc(tokens)  # List of encoder outputs

        # Decoder
        output = self.forward_dec(noise_actions, time, enc_cache)  # [B, action_seq_len, action_dim]

        return output

    def forward_enc(self, tokens: torch.Tensor) -> list:
        # tokens: [B, E, H]
        tokens = tokens.transpose(0, 1)  # [E, B, H]
        pos = self.enc_pos(tokens)

        # Process through encoder
        enc_cache = self.encoder(tokens, pos)

        return enc_cache

    def forward_dec(self, noise_actions: torch.Tensor, time: torch.Tensor, enc_cache: list) -> torch.Tensor:
        # noise_actions: [B, action_seq_len, action_dim], time: [B] tokens: [E, B, H]
        time_enc = self.time_net(time)  # time_enc: [B, hidden_dim]
        # Project actions
        ac_tokens = self.action_proj(noise_actions)  # ac_tokens [B, action_seq_len, hidden_dim]
        ac_tokens = ac_tokens.transpose(0, 1)  # [action_seq_len, B, hidden_dim]

        dec_in = ac_tokens + self.dec_pos  # [action_seq_len, B, hidden_dim]

        # Apply decoder
        dec_out = self.decoder(dec_in, time_enc, enc_cache)  # [action_seq_len, B, hidden_dim]

        # Apply final output layer
        output = self.eps_out(dec_out, time_enc, enc_cache[-1])  # [B, action_seq_len, action_dim]
        return output


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000) -> None:
        super().__init__()
        # Compute the positional encodings once in log space
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32) * -(torch.log(torch.tensor(10000.0)) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)  # Shape: [max_len, 1, d_model]
        # self.register_buffer("pe", pe)
        self.pe = nn.Parameter(pe, requires_grad=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor of shape (seq_len, batch_size, d_model)

        Returns:
            Tensor of shape (seq_len, batch_size, d_model) with positional encodings added
        """
        pe = self.pe[: x.shape[0]]
        pe = pe.repeat((1, x.shape[1], 1))
        return pe


class TimeNetwork(nn.Module):
    def __init__(self, time_dim: int, out_dim: int, learnable_w: bool = False) -> None:
        assert time_dim % 2 == 0, "time_dim must be even!"
        half_dim = int(time_dim // 2)
        super().__init__()

        w = np.log(10000) / (half_dim - 1)
        w = torch.exp(torch.arange(half_dim) * -w).float()
        self.register_parameter("w", nn.Parameter(w, requires_grad=learnable_w))

        self.out_net = nn.Sequential(nn.Linear(time_dim, out_dim), nn.SiLU(), nn.Linear(out_dim, out_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert len(x.shape) == 1, "assumes 1d input timestep array"
        x = x[:, None] * self.w[None]
        x = torch.cat((torch.cos(x), torch.sin(x)), dim=1)
        return self.out_net(x)


class SelfAttnEncoder(nn.Module):
    def __init__(
        self, d_model: int, nhead: int = 8, dim_feedforward: int = 2048, dropout: float = 0.1, activation: str = "gelu"
    ) -> None:
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.activation = get_activation(activation)

    def forward(self, src: torch.Tensor, pos: torch.Tensor) -> torch.Tensor:
        q = k = with_pos_embed(src, pos)
        src2, _ = self.self_attn(q, k, value=src, need_weights=False)
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.linear2(self.dropout2(self.activation(self.linear1(src))))
        src = src + self.dropout3(src2)
        src = self.norm2(src)
        return src

    def reset_parameters(self) -> None:
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)


class ShiftScaleMod(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.act = nn.SiLU()
        self.scale = nn.Linear(dim, dim)
        self.shift = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        c = self.act(c)
        return x * self.scale(c).unsqueeze(0) + self.shift(c).unsqueeze(0)

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.scale.weight)
        nn.init.xavier_uniform_(self.shift.weight)
        nn.init.zeros_(self.scale.bias)
        nn.init.zeros_(self.shift.bias)


class ZeroScaleMod(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.act = nn.SiLU()
        self.scale = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        c = self.act(c)
        return x * self.scale(c).unsqueeze(0)

    def reset_parameters(self) -> None:
        nn.init.zeros_(self.scale.weight)
        nn.init.zeros_(self.scale.bias)


class DiTDecoder(nn.Module):
    def __init__(
        self, d_model: int, nhead: int = 8, dim_feedforward: int = 2048, dropout: float = 0.1, activation: str = "gelu"
    ) -> None:

        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.activation = get_activation(activation)

        # Create modulation layers
        self.attn_mod1 = ShiftScaleMod(d_model)
        self.attn_mod2 = ZeroScaleMod(d_model)
        self.mlp_mod1 = ShiftScaleMod(d_model)
        self.mlp_mod2 = ZeroScaleMod(d_model)

    def forward(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # Process the conditioning vector
        # Average over seq_len dimension (E, B, H) -> (B, H)
        cond = torch.mean(cond, dim=0)
        cond = cond + t  # [B, hidden_dim]

        x2 = self.attn_mod1(self.norm1(x), cond)
        x2, _ = self.self_attn(x2, x2, x2, need_weights=False)
        x = self.attn_mod2(self.dropout1(x2), cond) + x

        x2 = self.mlp_mod1(self.norm2(x), cond)
        x2 = self.linear2(self.dropout2(self.activation(self.linear1(x2))))
        x2 = self.mlp_mod2(self.dropout3(x2), cond)
        return x + x2

    def reset_parameters(self) -> None:
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
        for s in (self.attn_mod1, self.attn_mod2, self.mlp_mod1, self.mlp_mod2):
            if hasattr(s, "reset_parameters"):
                s.reset_parameters()
            else:
                raise NotImplementedError("Modulation layer must have a reset_parameters method.")


class FinalLayer(nn.Module):
    def __init__(self, hidden_size: int, out_size: int) -> None:
        super().__init__()
        self.norm_final = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.linear = nn.Linear(hidden_size, out_size, bias=True)
        self.adaLN_modulation = nn.Sequential(nn.SiLU(), nn.Linear(hidden_size, 2 * hidden_size, bias=True))

    def forward(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # Process the conditioning vector
        cond = torch.mean(cond, axis=0)  # Average over seq_len dimension
        cond = cond + t  # [B, hidden_dim]

        shift, scale = self.adaLN_modulation(cond).chunk(2, dim=1)
        x = x * scale.unsqueeze(0) + shift.unsqueeze(0)
        x = self.linear(x)
        return x.transpose(0, 1)

    def reset_parameters(self) -> None:
        for p in self.parameters():
            nn.init.zeros_(p)


class TransformerEncoder(nn.Module):
    def __init__(self, base_module: nn.Module, num_layers: int) -> None:
        super().__init__()
        self.layers = nn.ModuleList([copy.deepcopy(base_module) for _ in range(num_layers)])

        for layer in self.layers:
            if hasattr(layer, "reset_parameters"):
                layer.reset_parameters()
            else:
                raise NotImplementedError("Encoder layer must have a reset_parameters method.")

    def forward(self, src: torch.Tensor, pos: torch.Tensor) -> list[torch.Tensor]:
        x = src
        outputs = []
        for _, layer in enumerate(self.layers):
            x = layer(x, pos)
            outputs.append(x)
        return outputs


class TransformerDecoder(nn.Module):
    def __init__(self, base_module: nn.Module, num_layers: int) -> None:
        super().__init__()
        self.layers = nn.ModuleList([copy.deepcopy(base_module) for _ in range(num_layers)])

        for layer in self.layers:
            if hasattr(layer, "reset_parameters"):
                layer.reset_parameters()
            else:
                raise NotImplementedError("Decoder layer must have a reset_parameters method.")

    def forward(self, x: torch.Tensor, t: torch.Tensor, all_conds: list[torch.Tensor]) -> torch.Tensor:
        """Forward pass through the decoder.

        Args:
            x (torch.Tensor): Input tensor of shape (action_horizon, batch_size, d_model)
            t (torch.Tensor): Time tensor of shape (batch_size, d_model)
            all_conds (list[torch.Tensor]): Conditioning tensors of shape (num_layers, seq_len, batch_size, d_model)

        Returns:
            torch.Tensor: Output tensor of shape (seq_len, batch_size, d_model)
        """
        assert len(all_conds) == len(self.layers), "Number of conditions must match number of layers"
        for layer, cond in zip(self.layers, all_conds, strict=False):
            x = layer(x, t, cond)
        return x
