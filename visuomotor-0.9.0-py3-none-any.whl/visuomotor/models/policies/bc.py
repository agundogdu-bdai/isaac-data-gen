#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
from datetime import datetime
from functools import partial
from typing import Any, Callable, Optional, Union

import numpy as np
import torch
import torch.nn.functional as F
from einops import rearrange
from hydra.utils import instantiate
from lightning import LightningModule
from lightning.pytorch.utilities import grad_norm
from lightning.pytorch.utilities.types import STEP_OUTPUT, OptimizerLRScheduler
from numpy import typing as npt
from omegaconf import DictConfig, ListConfig, OmegaConf
from omegaconf.omegaconf import open_dict
from torch.optim import Optimizer

import visuomotor
from visuomotor.data.datasets import (
    get_color_transforms,
)
from visuomotor.data.utils import create_key_to_history_mapping
from visuomotor.models import lr_schedules
from visuomotor.models.beta_utils import get_optimizer
from visuomotor.models.default_encoder_wrapper import DefaultEncoderWrapper
from visuomotor.models.model_registry import REGISTRY, ModelType, register_model
from visuomotor.models.protocols import ActionHead, Encoder
from visuomotor.utils.normalizer import LinearNormalizer
from visuomotor.utils.train_utils import is_timestep_obs

logger = logging.getLogger(__name__)


class BehaviorCloning(LightningModule):
    """
    Behavior cloning module acts as a base class for all stable models.
    """

    __version__ = visuomotor.__version__
    name = "BehaviorCloning"

    def __init__(self, config: DictConfig | ListConfig) -> None:

        super().__init__()

        self.config = config
        self.init_normalizer()
        self.init_obs_keys()
        self.init_encoders()
        self.init_action_head()
        self.save_config()

    def init_normalizer(self) -> None:

        if self.config.data.normalize:
            self.normalizer: Optional[LinearNormalizer] = LinearNormalizer()
        else:
            self.normalizer = None

    def init_obs_keys(self) -> None:

        self.obs_visual = self.config.data.obs_keys.get("visual", list())
        self.obs_state = self.config.data.obs_keys.get("state", dict())
        self.n_cameras = len(self.config.data.camera_ids)
        self.n_obs_history_visual = self.config.data.get("n_obs_history_visual")
        self.n_obs_history_state = self.config.data.get("n_obs_history_state")
        self.key_to_n_obs_history = create_key_to_history_mapping(
            obs_visual=self.obs_visual,
            obs_state=self.obs_state.keys(),
            n_obs_history_visual=self.n_obs_history_visual,
            n_obs_history_state=self.n_obs_history_state,
        )

    def init_encoders(self) -> None:

        # Dictionary of encoders and corresponding wrapper for each observation type
        self.encoders = torch.nn.ModuleDict()
        self.encoders_n_obs_history: dict[str, int] = dict()
        self.encoder_wrapper: dict[str, Any] = dict()

        # Build the appropriate encoders based on the observations keys.
        if "color" in self.obs_visual:
            self.predict_action_color_transforms = get_color_transforms(self.config.data, True)
            resize = self.config.data.get("image_randomization", {}).get("resize")
            crop_size = self.config.data.get("image_randomization", {}).get("crop_size")
            if resize:
                self.config.rgb_encoder.image_size = resize
            if crop_size:
                self.config.rgb_encoder.image_size = crop_size
            if resize is None and crop_size is None and self.config.rgb_encoder.image_size is None:
                raise ValueError(
                    "If you're not using resizing or cropping,\
                          you must specify the image size under the rgb_encoder config."
                )

            if self.config.rgb_encoder.shared_encoder:
                self.config.rgb_encoder.n_cams = self.n_cameras
                encoder_key = "color"
                # Initialize encoder using the REGISTRY
                self.encoders[encoder_key] = REGISTRY.create_model(
                    name=self.config.rgb_encoder.name,  # e.g., "resnet"
                    config=self.config.rgb_encoder,  # Pass entire encoder config
                    model_type=ModelType.ENCODER_RGB,
                )
                assert self.config.rgb_encoder.shared_encoder
                self.encoder_wrapper[encoder_key] = self.instantiate_encoder_wrapper(
                    encoder_config=self.config.rgb_encoder,
                    encoder=self.encoders[encoder_key],
                )
                self.encoders_n_obs_history[encoder_key] = self.n_obs_history_visual

            else:
                self.config.rgb_encoder.n_cams = 1
                for cam in range(len(self.config.data.camera_ids)):
                    encoder_key = f"color_{cam}"
                    # Initialize encoder using the REGISTRY
                    self.encoders[encoder_key] = REGISTRY.create_model(
                        name=self.config.rgb_encoder.name,  # e.g., "resnet"
                        config=self.config.rgb_encoder,  # Pass entire encoder config
                        model_type=ModelType.ENCODER_RGB,
                    )
                    # No special processing needed if not shared encoder
                    self.encoder_wrapper[encoder_key] = self.instantiate_encoder_wrapper(
                        encoder_config=self.config.rgb_encoder,
                        encoder=self.encoders[encoder_key],
                        use_default=True,
                    )
                    self.encoders_n_obs_history[encoder_key] = self.n_obs_history_visual

        if "point_cloud" in self.obs_visual:
            # Initialize PCD encoder using the REGISTRY
            self.encoders["point_cloud"] = REGISTRY.create_model(
                name=self.config.pcd_encoder.name,
                config=self.config.pcd_encoder,
                model_type=ModelType.ENCODER_PCD,
            )
            self.encoder_wrapper["point_cloud"] = self.instantiate_encoder_wrapper(
                encoder_config=self.config.pcd_encoder,
                encoder=self.encoders["point_cloud"],
            )
            self.encoders_n_obs_history["point_cloud"] = self.n_obs_history_visual

        # Resolve the config and update config
        resolved_dict = OmegaConf.to_container(self.config, resolve=True)
        self.config = OmegaConf.create(resolved_dict)

        state_dim = self.calculate_state_dim()
        self.config.state_encoder.input_dim = state_dim
        # Initialize state encoder using the REGISTRY
        self.encoders["state"] = REGISTRY.create_model(
            name=self.config.state_encoder.name,
            config=self.config.state_encoder,
            model_type=ModelType.ENCODER_STATE,
        )
        self.encoders_n_obs_history["state"] = self.n_obs_history_state
        self.encoder_wrapper["state"] = self.instantiate_encoder_wrapper(
            encoder_config=self.config.state_encoder,
            encoder=self.encoders["state"],
        )

        task_encoder_cfg = self.config.task_encoder if "task_encoder" in self.config else None
        if task_encoder_cfg is not None:
            self.encoders["task"] = REGISTRY.create_model(
                name=task_encoder_cfg.name, config=task_encoder_cfg, model_type=ModelType.ENCODER_TASK
            )
            self.encoders_n_obs_history["task"] = 1
            self.encoder_wrapper["task"] = self.instantiate_encoder_wrapper(
                encoder_config=self.config.task_encoder,
                encoder=self.encoders["task"],
            )

        # Calculate total input dimension for backward compatibility
        # This is used to set input_dim for action heads that might need it
        head_input_dim = 0
        for encoder_name, encoder in self.encoders.items():
            size = encoder.output_size.numel()
            n_obs_history_this_key = self.encoders_n_obs_history.get(encoder_name, 1)
            head_input_dim += size * n_obs_history_this_key
        self.config.action_head.input_dim = head_input_dim

    def init_action_head(self) -> None:

        # Infer the input dimension of the action head based on the concatenated latent size.
        head_config = self.config.action_head.copy()
        with open_dict(head_config):
            head_config.horizon = self.config.data.horizon
        self.head: ActionHead = REGISTRY.create_model(
            name=self.config.action_head.name,
            config=head_config,
            model_type=ModelType.HEAD,
        )

    def save_config(self) -> None:
        timestamp = datetime.now().strftime("%Y.%m.%d.%H.%M.%S")
        self.config.storage_path = f"gs://bdai-common-storage/visuomotor/ray/test_vpl_diffpo/{timestamp}"
        config_with_version = OmegaConf.to_container(self.config)
        config_with_version["__version__"] = visuomotor.__version__
        self.save_hyperparameters(config_with_version)
        logger.info(f"Using policy: {self.config.method_name}")
        logger.info(f"Using action head: {self.config.action_head.name}")
        logger.info(f"Saving model with visuomotor version: {visuomotor.__version__}")

    def on_train_batch_start(self, batch: Any, batch_idx: int) -> None:
        """On train batch start Lightning callback"""
        for i, param_group in enumerate(self.trainer.optimizers[0].param_groups):
            self.log(f"opt_{i+1}_lr", param_group["lr"])

    def on_before_optimizer_step(self, optimizer: torch.optim.Optimizer) -> None:
        if not self.config.action_head.get("use_cuda_graph", False):
            norm = grad_norm(self, norm_type=2)["grad_2.0_norm_total"]
            self.log("grad_norm", norm)

    def configure_optimizers(self) -> tuple[list[Optimizer], list[OptimizerLRScheduler]]:
        # TODO: type signature is wrong
        optimizer_config = self.config.train.optimizer
        optimizer_cls: Callable[..., Optimizer] = get_optimizer(optimizer_config.name)
        optimizer_params = getattr(optimizer_config, "params", {})
        optimizer_params = {k: v for k, v in optimizer_params.items() if v is not None}

        pcd_param_set = set()
        pcd_param_group: Optional[dict] = None
        if "pcd_lr" in optimizer_config.learning_rate:
            logging.info("overwriting pcd encoder learning rates")
            pcd_param_set = set(self.encoders["point_cloud"].parameters())
            pcd_param_group = {
                "params": list(pcd_param_set),
                "lr": optimizer_config.learning_rate.pcd_lr,
                "weight_decay": optimizer_config.learning_rate.pcd_weight_decay,
                "betas": optimizer_config.learning_rate.pcd_betas,
            }

        color_param_set = set()
        color_param_group: Optional[dict] = None
        if "color_lr" in optimizer_config.learning_rate:
            logging.info("overwriting color encoder learning rates")
            for encoder_name, encoder in self.encoders.items():
                if encoder_name.startswith("color"):
                    color_param_set.update(set(encoder.parameters()))
            color_param_group = {"params": list(color_param_set), "lr": optimizer_config.learning_rate.color_lr}

        other_param_group = {
            "params": [p for p in self.parameters() if p not in {*pcd_param_set, *color_param_set}],
            "lr": optimizer_config.learning_rate.lr,
        }

        parameters = [group for group in [color_param_group, pcd_param_group, other_param_group] if group is not None]

        optimizer = optimizer_cls(
            parameters,
            lr=optimizer_config.learning_rate.lr,
            **optimizer_params,
        )

        # Use cosine decay with linear warmup.
        # TODO(ZTC): add support for other warmup strategies
        lr_fn = partial(
            lr_schedules.cosine_decay_linear_warmup_simple_scheduler,
            warmup_steps=optimizer_config.learning_rate.warmup_iters,
            steps_per_cycle=self.config.train.max_steps,
        )

        scheduler = {
            "scheduler": torch.optim.lr_scheduler.LambdaLR(
                optimizer,
                lr_fn,
            ),
            "interval": "step",
            "frequency": 1,
        }

        return [optimizer], [scheduler]

    def reshape_for_encoding(self, obs: torch.Tensor, obs_name: str) -> torch.Tensor:
        if obs_name in self.obs_state.keys():
            if obs.dim() == 4:
                obs = rearrange(obs, "... h w -> ... (h w)")
            if obs.dim() == 1:
                obs = obs.unsqueeze(1)
        # Timesteps are merged with batches for the encoding step
        if is_timestep_obs(obs_name):
            obs = rearrange(obs, "b t ... -> (b t) ...")

        return obs

    def extract_n_obs_history(self, key: str, encoded: torch.Tensor) -> torch.Tensor:
        """The timesteps were previously merged with batches to be sent to encoders
        independently. We extract those out before feeding them to the fusion step
        Dimension names:
        b batch
        t time (observaiton history)
        c embedding dimension
        i camera id
        """
        if is_timestep_obs(key):
            n_obs_history = self.encoders_n_obs_history[key]
            encoded = rearrange(encoded, "(b t) c ... -> b (t c) ...", t=n_obs_history)

        return encoded

    def calculate_state_dim(self) -> int:
        return sum([sum(v["shape"]) for v in self.obs_state.values()])

    def instantiate_encoder_wrapper(
        self, encoder_config: DictConfig, encoder: Encoder, use_default: bool = False
    ) -> Any:
        """
        If encoder wrapper is specified and use_default is False, instantiates specified wrapper.
        Otherwise, uses default wrapper that gets the specific key from batch if there's a match
        or returns entire batch as is, and no postprocessing.
        """
        encoder_wrapper_class = encoder_config.get("encoder_wrapper")
        if encoder_wrapper_class is not None and not use_default:
            encoder_wrapper = instantiate(encoder_wrapper_class, encoder=encoder)
        else:
            encoder_wrapper = DefaultEncoderWrapper(encoder=encoder)
        return encoder_wrapper

    def encode(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        """Encodes observations into a dict of feature tensors"""

        # TODO: This is currently broken, commenting it until we fix it.
        # if self.rgb_to_pcd_encoder is not None:
        #     rgb_to_pcd_features = self.rgb_to_pcd_encoder(batch)
        #     features.append(rgb_to_pcd_features)

        features = {}
        for key in self.encoders.keys():
            encoded = self.encoder_wrapper[key].forward(batch=batch, encoder_key=key)
            features[key] = self.extract_n_obs_history(key, encoded)

        return features

    def prepare_inputs(self, batch: dict[str, Union[np.ndarray, torch.Tensor, str]]) -> dict[str, torch.Tensor]:
        """
        Prepares the input batch for encoding (reshaping, normalizing, transformations).

        - Reshapes observations to match encoder input requirements.
        - Concatenates state tensors to form a unified state representation.
        - Splits color observations into separate camera keys when using non-shared RGB encoders.
        - Applies normalization

        Args:
            batch (dict[str, torch.Tensor]):
                The input batch containing various types of observations.

        Returns:
            dict[str, torch.Tensor]:
                The processed batch, ready for encoding by the model's encoders.
        """
        data_cfg = self.config.data
        norm_keys = set(data_cfg.norm_keys) if getattr(data_cfg, "norm_keys", None) else set()

        # Reshape and (optionally) normalize
        normalized_batch = {}
        for key, value in batch.items():
            if isinstance(value, np.ndarray):
                value = torch.from_numpy(value)
            elif isinstance(value, str):
                value = torch.tensor([value])  # Temporary fix for language encoder

            reshaped = self.reshape_for_encoding(value, key)
            if self.normalizer and key in norm_keys:
                reshaped = self.normalizer[key].normalize(reshaped)
            normalized_batch[key] = reshaped

        state_tensors = []
        for k in self.obs_state.keys():
            if k in normalized_batch:
                tensor = normalized_batch.pop(k)
                # If tensor is 3D and the second dimension is 1, squeeze it to remove the extra dimension.
                if tensor.dim() == 3 and tensor.size(1) == 1:
                    tensor = tensor.squeeze(1)
                logger.debug(f"Processed state key '{k}' shape: {tensor.shape}")
                state_tensors.append(tensor)
        if state_tensors:
            concatenated_state = torch.cat(state_tensors, dim=-1)
            logger.debug(f"Concatenated state shape: {concatenated_state.shape}")
            normalized_batch["state"] = concatenated_state

        # If a non-shared rgb_encoder is used, split the "color" observation into separate camera keys.
        rgb_cfg = getattr(self.config, "rgb_encoder", None)
        if rgb_cfg and not rgb_cfg.shared_encoder and "color" in normalized_batch:
            color_tensor = normalized_batch.pop("color")
            for cam in range(self.n_cameras):
                normalized_batch[f"color_{cam}"] = color_tensor[:, cam]

        return normalized_batch

    def cast_inputs_to_appropriate_type(
        self, batch: dict[str, torch.Tensor], batched: bool = False
    ) -> dict[str, torch.Tensor]:
        """Observations need to be parsed into specific formats, mainly Torch.Tensor. Also batched if required"""

        for key, value in batch.items():
            if isinstance(value, np.ndarray):
                batch[key] = torch.from_numpy(value).float().to(self.device)
            elif isinstance(value, list):
                # This is because we are currently doing string tokenization inside of the language encoder
                if isinstance(value[0], str):
                    batch[key] = value
                else:
                    batch[key] = torch.from_numpy(np.array(value)).float().to(self.device)
            elif isinstance(value, torch.Tensor):
                batch[key] = value.to(self.device)
            elif isinstance(value, str):
                # This is because we are currently doing string tokenization inside of the language encoder
                batch[key] = [value]
            else:
                raise TypeError(f"{value} is neither `np.ndarray` nor `torch.Tensor` but {type(value)}")

            if not batched:
                if isinstance(batch[key], torch.Tensor):
                    batch[key] = batch[key].unsqueeze(0)
                else:
                    batch[key] = [batch[key]]
        return batch

    def reshape_color_input(self, color: torch.Tensor, batched: bool = False) -> torch.Tensor:
        """The following transformations are applied to the color observation:
        - Selecting the correct camera(s) to use from the environment / dataset
        - Run tranformations on those images like resize, cropping...
        - Scale from [0, 255] to [0, 1]
        - Rearrange axes
        """

        # Select cameras
        if self.config.get("simulation") and self.config.simulation.get("predict_action_camera_ids"):
            # If simulation produces different cameras we need to make sure we pick the right
            # ones to predict_action on
            camera_ids = self.config.simulation.get("predict_action_camera_ids")
        else:
            camera_ids = self.config.data.get("camera_ids")
        # Unbatched shape is (t, X, H, W, C). Batched shape is
        #  (b, t, X, H, W, C ) where C=channels=3 and X = camera id,
        # and t is timestep.
        if batched:
            color = color[:, :, camera_ids]
        else:
            color = color[:, camera_ids]

        # TODO: (tarik) Move this to a separate function so that it always same with the dataset.
        if self.predict_action_color_transforms:
            # albumentations doesn't work on torch tensors
            if isinstance(color, torch.Tensor):
                color = color.cpu().numpy()

            # NOTE: albumentations doesn't work on batches. It is still faster than torchvision for training,
            # but if this is too slow for inference on large batches, we could change to torchvision here.
            # Keeping it the same package now for convenience.
            # TODO: test performance for inference
            if batched:
                transformed = [
                    [
                        [
                            self.predict_action_color_transforms(image=image)["image"].astype(np.float32)
                            for image in timestep
                        ]
                        for timestep in color_sequence
                    ]
                    for color_sequence in color
                ]
            else:
                transformed = [
                    [
                        self.predict_action_color_transforms(image=image)["image"].astype(np.float32)
                        for image in timestep
                    ]
                    for timestep in color
                ]
            color = np.array(transformed)

        color = color / 255.0
        color = rearrange(color, "... h w c -> ... c h w")

        return color

    @torch.no_grad()
    def predict_action(self, batch: dict[str, npt.NDArray | torch.Tensor], batched: bool = False) -> npt.NDArray:

        if "color" in batch:
            batch["color"] = self.reshape_color_input(batch["color"], batched)
        batch = self.cast_inputs_to_appropriate_type(batch, batched)
        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        action = self.head.predict_action(features).squeeze()
        if self.normalizer is not None:
            action = self.normalizer["action"].unnormalize(action)

        action = action.cpu().numpy()
        return action

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        raise NotImplementedError("Subclasses must implement this method.")

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        raise NotImplementedError("Subclasses must implement this method.")

    def compute_loss(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError("Subclasses must implement this method.")


@register_model(name="mlp", model_type=ModelType.POLICY, status="stable")
class MLPBehaviorCloning(BehaviorCloning):

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        pred = self.head(features)
        return pred

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred = self.forward(batch)
        target = batch["action"]
        loss = self.compute_loss(pred, target)
        self.log("train_loss", loss)
        return loss

    def validation_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred = self.forward(batch)
        target = batch["action"]
        loss = self.compute_loss(pred, target)
        self.log("valid_loss", loss)
        return loss

    def compute_loss(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert y_hat.shape == y.shape, f"y_hat.shape: {y_hat.shape}, y.shape: {y.shape}"
        return F.mse_loss(y_hat, y)


@register_model(name="diffpo", model_type=ModelType.POLICY, status="stable")
class DiffusionBehaviorCloning(BehaviorCloning):
    """3D diffusion policy training module."""

    def __init__(self, config: DictConfig) -> None:
        super().__init__(config)
        self.rng_offset = 0  # increments each time we sample noise
        self.rank = 0  # will be set properly in setup() if distributed

    def setup(self, stage: Optional[str] = None) -> None:
        if self.trainer is not None and hasattr(self.trainer, "global_rank"):
            self.rank = self.trainer.global_rank
        else:
            self.rank = 0

    def on_load_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        # Restore offset, etc.
        self.rng_offset = checkpoint.get("rng_offset", 0)
        # Reinitialize the cuda graph for the head if needed
        if self.head.use_cuda_graph:
            self.head.initialize_cuda_graph()

    def on_save_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        # Store the rng_offset so we can resume the noise sequence after checkpoint
        checkpoint["rng_offset"] = self.rng_offset

    def forward(self, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:

        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        pred, noise = self.head(
            features,
            action=batch["action"],
            rank=self.rank,
            rng_offset=self.rng_offset,
        )
        self.rng_offset += 1  # update for next forward pass
        return pred, noise

    def get_target(self, batch: dict[str, torch.Tensor], noise: torch.Tensor) -> torch.Tensor:

        if self.head.config.noise_scheduler.prediction_type == "epsilon":
            return noise
        elif self.head.config.noise_scheduler.prediction_type == "sample":
            return batch["action"]
        else:
            raise ValueError(f"Invalid prediction type {self.head.config.noise_scheduler.prediction_type}")

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred, noise = self.forward(batch)
        target = self.get_target(batch, noise)
        loss = self.compute_loss(pred, target)
        self.log("train_loss", loss)
        return loss

    def validation_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred, noise = self.forward(batch)
        target = self.get_target(batch, noise)
        loss = self.compute_loss(pred, target)
        self.log("valid_loss", loss)
        return loss

    def compute_loss(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert y_hat.shape == y.shape, f"y_hat.shape: {y_hat.shape}, y.shape: {y.shape}"
        return F.mse_loss(y_hat, y)
