#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import copy
from typing import Any, Optional, Union

import numpy as np
import ray.train
import torch
import torch.quantization
from beartype.typing import Mapping
from lerobot.configs.policies import PreTrainedConfig
from lerobot.configs.types import NormalizationMode
from lightning import LightningModule
from lightning.pytorch.utilities.types import OptimizerLRScheduler
from numpy import typing as npt
from omegaconf import DictConfig, ListConfig, OmegaConf
from torch import Tensor, nn

from visuomotor import __version__
from visuomotor.data import is_lerobot_available
from visuomotor.data.lerobot_preprocessing import process_color_observations
from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.policies.lerobot_utils import process_and_log_losses
from visuomotor.models.protocols import ActionHead, Policy
from visuomotor.utils.normalizer import LinearNormalizer

if is_lerobot_available():
    from lerobot.optim.factory import make_optimizer_and_scheduler
    from lerobot.policies.factory import make_policy, make_policy_config


def make_filtered_policy_config(policy_type: str, **kwargs: Any) -> PreTrainedConfig:
    """Create policy config with only parameters that exist in the config class"""
    try:
        # Create a temporary config with no params to inspect its attributes
        temp_config = make_policy_config(policy_type)

        # Get available attributes from the config instance
        valid_params = set(vars(temp_config).keys())

        # Filter kwargs to only include parameters that exist in the config
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params and v is not None}

        # Create final config with filtered parameters
        return make_policy_config(policy_type, **filtered_kwargs)

    except (ValueError, KeyError, AttributeError, TypeError) as e:
        # Fallback to original behavior if inspection fails
        print(f"Warning: Failed to filter policy config parameters ({type(e).__name__}: {e}). Using all kwargs.")
        return make_policy_config(policy_type, **kwargs)


def _flatten_top_level(dc: Union[DictConfig, dict] | None) -> dict[str, Any]:
    """Extract top-level simple fields from a DictConfig or dict.

    Returns a mapping of key -> value for scalars/lists/tuples/None. Nested dicts are ignored.
    """
    out: dict[str, Any] = {}
    if dc is None:
        return out
    try:
        container = OmegaConf.to_container(dc, resolve=True) if isinstance(dc, (DictConfig, ListConfig)) else dc
    except Exception:
        container = dict(dc)
    if not isinstance(container, dict):
        return out
    for k, v in container.items():
        if k in {"normalization"}:
            continue
        if isinstance(v, (int, float, bool, str, list, tuple)) or v is None:
            out[k] = v
    return out


def _collect_policy_overrides(cfg: DictConfig) -> dict[str, Any]:
    """Collect generic overrides for LeRobot policy configuration from VPL config.

    Policy-agnostic: unknown keys are later dropped by make_filtered_policy_config.
    """
    overrides: dict[str, Any] = {}
    # 1) user-specified policy fields
    overrides.update(_flatten_top_level(getattr(cfg, "policy", None)))
    # 2) optional 'lerobot' block (e.g., n_action_steps, chunk_size)
    overrides.update(_flatten_top_level(getattr(cfg, "lerobot", None)))
    # 3) dataset-driven knobs
    data_block = getattr(cfg, "data", None)
    if data_block is not None:
        horizon = getattr(data_block, "horizon", None)
        if horizon is not None:
            overrides.setdefault("horizon", horizon)
        n_vis = getattr(data_block, "n_obs_history_visual", None)
        n_state = getattr(data_block, "n_obs_history_state", None)
        if n_vis is not None and n_vis == n_state:
            overrides.setdefault("n_obs_steps", n_vis)
    # Remove non-policy keys we know don't belong
    for drop in ("type", "normalization"):
        overrides.pop(drop, None)
    return overrides


@register_model(name="lerobot", model_type=ModelType.POLICY, status="beta")
class LeRobotPolicy(LightningModule):
    """Wrapper for lerobot policies."""

    # Required attributes for Policy protocol
    __version__: str = __version__
    name: str = "lerobot"

    def __init__(self, config: Union[DictConfig, ListConfig], **kwargs: Any) -> None:
        # Extract ds_meta and env_config from kwargs
        self.ds_meta = kwargs.pop("ds_meta", None)
        self.env_config = kwargs.pop("env_config", None)

        # Pass the remaining kwargs to parent
        super().__init__(**kwargs)

        self.config = config
        self.policy = self.build_policy()

        # Add required Protocol attributes which are handled by LeRobot
        self.encoders: Optional[nn.ModuleDict] = None
        self.head: Optional[ActionHead] = None
        self.normalizer: Optional[LinearNormalizer] = None

        self._detect_expected_image_keys()
        self._detect_expected_state_keys()

        # Save hyperparameters with dataset metadata for checkpoint loading
        self._save_hyperparameters_with_metadata(config)

    def _detect_expected_image_keys(self) -> None:
        """Detect and store the expected image keys once during initialization."""
        # Check if the policy has image_features configuration
        if hasattr(self.policy.config, "image_features") and self.policy.config.image_features:
            self.expected_image_keys = list(self.policy.config.image_features)
        # Fallback: check dataset metadata for image features
        elif hasattr(self.ds_meta, "features"):
            self.expected_image_keys = [key for key in self.ds_meta.features.keys() if "image" in key or "color" in key]
            print(f"DEBUG: Using dataset metadata image keys: {self.expected_image_keys}")
        else:
            camera_ids = getattr(self.config.data, "camera_ids", [0])
            if getattr(self.config.data, "is_hf_dataset", False):
                self.expected_image_keys = [f"observation.image.color_cam{i}" for i in camera_ids]
            else:
                self.expected_image_keys = [f"color_{i}" for i in camera_ids]

        print(f"Detected expected image keys: {self.expected_image_keys}")

    def _detect_expected_state_keys(self) -> None:
        """Detect and store the expected state keys once during initialization."""
        # TODO(ahmet): Consider failing fast when unified `observation.state` is missing
        # and gate the per-component auto-unify behind an explicit config knob
        # (e.g., `lerobot.allow_state_auto_unify`). If enabled, enforce deterministic
        # concatenation order and validate per-component shapes to avoid silent mismatches.
        # Check if dataset metadata has state features
        if hasattr(self.ds_meta, "features"):
            self.expected_state_keys = [
                key for key in self.ds_meta.features.keys() if key.startswith("observation.state")
            ]
            if not self.expected_state_keys:
                # Look for individual state components that would be combined
                state_components = [
                    key
                    for key in self.ds_meta.features.keys()
                    if not ("image" in key or "color" in key or key.startswith("action") or key == "task")
                ]
                self.expected_state_keys = state_components
        # Fallback: check config for state keys
        elif (
            hasattr(self.config, "data")
            and hasattr(self.config.data, "obs_keys")
            and hasattr(self.config.data.obs_keys, "state")
        ):
            self.expected_state_keys = list(self.config.data.obs_keys.state.keys())
        else:
            # Default fallback
            self.expected_state_keys = []

        print(f"Detected expected state keys: {self.expected_state_keys}")

    def build_policy(self) -> Policy:
        """Build a LeRobot policy using the factory."""
        policy_type = self.config.policy.type
        policy_path = getattr(self.config.policy, "pretrain_path", None)
        print(f"policy_path: {policy_path}")

        # Collect overrides generically from VPL config. Unknown keys are dropped safely.
        overrides = _collect_policy_overrides(self.config)
        policy_config = make_filtered_policy_config(policy_type, **overrides)

        # Set normalization settings
        normalization_settings = getattr(self.config.policy, "normalization", {})
        visual_norm = getattr(normalization_settings, "visual", "IDENTITY")
        state_norm = getattr(normalization_settings, "state", "IDENTITY")
        action_norm = getattr(normalization_settings, "action", "MIN_MAX")

        policy_config.normalization_mapping = {
            "VISUAL": getattr(NormalizationMode, visual_norm),
            "STATE": getattr(NormalizationMode, state_norm),
            "ACTION": getattr(NormalizationMode, action_norm),
        }

        # Set device based on training configuration
        if self.config.train.get("use_gpu", True) and torch.cuda.is_available():
            policy_config.device = "cuda:" + str(ray.train.get_context().get_local_rank())
        else:
            policy_config.device = "cpu"

        # If using HF dataset and we have individual state components, modify the dataset metadata
        # BEFORE creating the policy so the model is built with correct dimensions
        modified_ds_meta = self.ds_meta
        if getattr(self.config.data, "is_hf_dataset", False) and hasattr(self.ds_meta, "features"):
            state_keys = [key for key in self.ds_meta.features.keys() if key.startswith("observation.state.")]

            if len(state_keys) > 1:
                # Calculate total state dimension
                total_state_dim = sum(
                    (
                        self.ds_meta.features[key]["shape"][-1]
                        if isinstance(self.ds_meta.features[key]["shape"], (list, tuple))
                        else self.ds_meta.features[key]["shape"]
                    )
                    for key in state_keys
                )

                modified_ds_meta = copy.deepcopy(self.ds_meta)

                # Remove individual state features
                for key in state_keys:
                    if key in modified_ds_meta.features:
                        del modified_ds_meta.features[key]

                # Add unified state feature
                modified_ds_meta.features["observation.state"] = {
                    "dtype": "float32",
                    "shape": (total_state_dim,),
                    "names": [],
                }

                print(f"Modified dataset metadata to expect unified observation.state with shape ({total_state_dim},)")

        policy_config.pretrained_path = policy_path
        # Show only the applied overrides (post-filter) and persist for checkpointing
        try:
            _applied = {k: getattr(policy_config, k) for k in overrides.keys() if hasattr(policy_config, k)}
        except Exception:
            _applied = {k: None for k in overrides.keys()}
        self._applied_policy_overrides = _applied
        self._policy_config_repr = str(policy_config)
        print(f"policy_overrides_applied: {_applied}")

        # Workaround for DTensor DeviceMesh issue under DDP/Ray when SmolVLA enables device_map="auto" internally.
        # We drop the device_map kwarg from HF model loading to avoid sharding within a worker.
        # TODO(ahmet): Remove this once we have a better solution for DDP/Ray.
        if policy_type == "smolvla":
            try:
                from transformers import AutoModelForImageTextToText

                _orig_from_pretrained = AutoModelForImageTextToText.from_pretrained

                def _from_pretrained_drop_device_map(*args: Any, **kwargs: Any) -> Any:
                    kwargs.pop("device_map", None)
                    return _orig_from_pretrained(*args, **kwargs)

                AutoModelForImageTextToText.from_pretrained = _from_pretrained_drop_device_map  # type: ignore[assignment]
                print("Patched AutoModelForImageTextToText.from_pretrained to drop device_map for SmolVLA")
            except Exception as e:
                print(f"Warning: failed to patch AutoModelForImageTextToText.from_pretrained: {e}")

        # Create the policy with the (possibly modified) dataset metadata
        policy = make_policy(cfg=policy_config, ds_meta=modified_ds_meta, env_cfg=self.env_config)

        return policy

    def on_train_batch_start(self, batch: Any, batch_idx: int) -> None:
        """On train batch start Lightning callback"""
        self.log("opt_1_lr", self.trainer.optimizers[0].param_groups[0]["lr"])

    def _resolve_optimizer_hparams(self) -> tuple[float, tuple[float, float], float, float]:
        """Resolve optimizer hyperparameters from VPL config, optionally mirroring policy.*.
        Returns: (base_lr, (beta1,beta2), eps, weight_decay)
        """
        prefer_policy = bool(getattr(self.config.train, "prefer_policy_hparams", False))
        opt_cfg = self.config.train.optimizer
        try:
            opt_params = OmegaConf.to_container(opt_cfg.params, resolve=True)
        except Exception:
            opt_params = dict(opt_cfg.params)
        base_lr = float(opt_cfg.learning_rate.lr)
        beta1, beta2 = opt_params.get("betas", [0.9, 0.95]) or [0.9, 0.95]
        eps = float(opt_params.get("eps", 1e-8))
        weight_decay = float(opt_params.get("weight_decay", 0.0))

        if prefer_policy and hasattr(self, "policy") and hasattr(self.policy, "config"):
            pc = self.policy.config
            base_lr = float(getattr(pc, "optimizer_lr", base_lr))
            betas = getattr(pc, "optimizer_betas", (beta1, beta2))
            if isinstance(betas, (list, tuple)) and len(betas) == 2:
                beta1, beta2 = float(betas[0]), float(betas[1])
            eps = float(getattr(pc, "optimizer_eps", eps))
            weight_decay = float(getattr(pc, "optimizer_weight_decay", weight_decay))

        return base_lr, (beta1, beta2), eps, weight_decay

    def _resolve_scheduler_hparams(self) -> tuple[int, int, float, int]:
        """Resolve scheduler hyperparameters (warmup, decay, eta_min, max_steps).
        VPL-first; optionally mirror policy.* when enabled.
        Returns: (warmup_steps, decay_steps, eta_min, max_steps)
        """
        prefer_policy = bool(getattr(self.config.train, "prefer_policy_hparams", False))
        max_steps = int(self.config.train.max_steps)

        warmup_steps = int(getattr(self.config.train.optimizer.learning_rate, "warmup_iters", 0) or 0)
        # Top-level optional scheduler config
        scheduler_cfg = getattr(self.config, "scheduler", {})
        try:
            scheduler_cfg = (
                OmegaConf.to_container(scheduler_cfg, resolve=True)
                if isinstance(scheduler_cfg, (DictConfig, ListConfig))
                else scheduler_cfg
            )
        except Exception:
            scheduler_cfg = dict(scheduler_cfg) if hasattr(scheduler_cfg, "items") else {}
        decay_steps = int(scheduler_cfg.get("num_decay_steps", max_steps))
        eta_min = float(scheduler_cfg.get("decay_lr", 0.0))

        if prefer_policy and hasattr(self, "policy") and hasattr(self.policy, "config"):
            pc = self.policy.config
            warmup_steps = int(getattr(pc, "scheduler_warmup_steps", warmup_steps))
            decay_steps = int(getattr(pc, "scheduler_decay_steps", decay_steps))
            eta_min = float(getattr(pc, "scheduler_decay_lr", eta_min))

        return warmup_steps, decay_steps, eta_min, max_steps

    def configure_optimizers(self) -> tuple[list[torch.optim.Optimizer], list[OptimizerLRScheduler]]:
        """Always use LeRobot factory with policy presets for exact parity."""
        from lerobot.configs.train import TrainPipelineConfig

        max_steps = int(self.config.train.max_steps)
        # Fill optimizer/scheduler from policy presets explicitly (no dual path)
        opt_preset = self.policy.config.get_optimizer_preset()
        sch_preset = self.policy.config.get_scheduler_preset()
        # Persist minimal copies for checkpoint diffing
        try:
            self._optimizer_preset = {
                "lr": getattr(opt_preset, "lr", None),
                "betas": getattr(opt_preset, "betas", None),
                "eps": getattr(opt_preset, "eps", None),
                "weight_decay": getattr(opt_preset, "weight_decay", None),
                "grad_clip_norm": getattr(opt_preset, "grad_clip_norm", None),
            }
            self._scheduler_preset = {
                "num_warmup_steps": getattr(sch_preset, "num_warmup_steps", None),
                "num_decay_steps": getattr(sch_preset, "num_decay_steps", None),
                "decay_lr": getattr(sch_preset, "decay_lr", None),
            }
        except Exception:
            self._optimizer_preset = {}
            self._scheduler_preset = {}
        train_cfg = TrainPipelineConfig(
            dataset=None,
            policy=self.policy.config,
            steps=max_steps,
            use_policy_training_preset=True,
            optimizer=opt_preset,
            scheduler=sch_preset,
        )
        optimizer, scheduler = make_optimizer_and_scheduler(train_cfg, self.policy)  # type: ignore[arg-type]

        return [optimizer], [{"scheduler": scheduler, "interval": "step"}]

    def on_fit_start(self) -> None:
        """Push effective overrides and presets to W&B config if available."""
        logger = getattr(self, "logger", None)
        exp = getattr(logger, "experiment", None)
        cfg = getattr(exp, "config", None)
        if cfg is not None and hasattr(cfg, "update"):
            payload = {
                "lerobot/policy_overrides": getattr(self, "_applied_policy_overrides", {}),
                "lerobot/optimizer_preset": getattr(self, "_optimizer_preset", {}),
                "lerobot/scheduler_preset": getattr(self, "_scheduler_preset", {}),
                "lerobot/policy_config_repr": getattr(self, "_policy_config_repr", ""),
            }
            try:
                cfg.update(payload, allow_val_change=True)
            except TypeError:
                cfg.update(payload)

    def forward(self, batch: dict[str, Tensor]) -> tuple[Tensor, Tensor] | Tensor:
        return self.policy.forward(batch)

    def train(self, mode: bool = True) -> "LeRobotPolicy":
        """Set the module in training mode and delegate to the underlying policy."""
        super().train(mode)
        if hasattr(self.policy, "train"):
            self.policy.train(mode)
        return self

    def eval(self) -> "LeRobotPolicy":
        """Set the module in evaluation mode and delegate to the underlying policy."""
        super().eval()
        if hasattr(self.policy, "eval"):
            self.policy.eval()
        return self

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> torch.Tensor:
        result = self.forward(batch)
        return process_and_log_losses(self, result)

    @torch.no_grad()
    def predict_action(self, batch: Mapping[str, Tensor | str | npt.NDArray], batched: bool = False) -> npt.NDArray:
        """Predict actions from observations using the underlying LeRobot policy."""
        was_training = self.training
        self.eval()

        try:
            # Convert to tensors and move to device
            processed_batch = {}
            for key, value in batch.items():
                if isinstance(value, np.ndarray):
                    processed_batch[key] = torch.tensor(value, device=self.device)
                elif isinstance(value, torch.Tensor):
                    processed_batch[key] = value.to(self.device, non_blocking=True)
                else:
                    processed_batch[key] = value

            # LeRobot policies expect specific batch sizes that match normalization statistics

            # Process color observations if needed
            if "color" in processed_batch:
                color_tensor = processed_batch["color"]
                processed_cameras = process_color_observations(color_tensor, self.expected_image_keys)
                processed_batch.update(processed_cameras)
                processed_batch.pop("color")

            # Process state observations if needed for inference
            if "observation.state" not in processed_batch and self.expected_state_keys:
                from visuomotor.data.lerobot_preprocessing import process_state_observations_unified

                processed_batch = process_state_observations_unified(
                    processed_batch,
                    set(self.expected_state_keys),
                    output_key="observation.state",
                    remove_individual_keys=False,
                )

            # Add task if missing
            if "task" not in processed_batch:
                task_desc = getattr(getattr(self.config, "env", None), "task_description", "Do the task")
                num_envs = 1
                for value in processed_batch.values():
                    if isinstance(value, torch.Tensor) and value.dim() > 0:
                        num_envs = value.shape[0]
                        break
                processed_batch["task"] = [task_desc] * num_envs

            # Remove action if present
            observation_batch = {k: v for k, v in processed_batch.items() if k != "action"}

            return self.select_action(observation_batch).cpu().numpy()

        finally:
            self.train(was_training)

    @torch.no_grad()
    def select_action(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        """Delegate to LeRobot policy."""
        was_training = self.training
        self.eval()
        try:
            try:
                policy_device = next(self.policy.parameters()).device  # type: ignore[call-arg]
            except Exception:
                policy_device = torch.device(getattr(self.policy.config, "device", "cpu"))
            for k, v in list(batch.items()):
                if isinstance(v, torch.Tensor) and v.device != policy_device:
                    batch[k] = v.to(policy_device, non_blocking=policy_device.type == "cuda")

            return self.policy.select_action(batch)
        finally:
            self.train(was_training)

    def reset(self) -> None:
        """Reset the underlying LeRobot policy state."""
        if hasattr(self.policy, "reset"):
            self.policy.reset()
        else:
            raise ValueError("Policy does not have a reset method")

    def on_save_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        """Embed effective LeRobot settings into the checkpoint for diffing later."""
        checkpoint["lerobot_policy_overrides"] = getattr(self, "_applied_policy_overrides", {})
        checkpoint["lerobot_policy_config_repr"] = getattr(self, "_policy_config_repr", "")
        checkpoint["lerobot_optimizer_preset"] = getattr(self, "_optimizer_preset", {})
        checkpoint["lerobot_scheduler_preset"] = getattr(self, "_scheduler_preset", {})

    def _save_hyperparameters_with_metadata(self, config: DictConfig) -> None:
        """Save hyperparameters with dataset metadata for checkpoint loading."""
        # Start with the full config to preserve all training configuration
        from omegaconf import OmegaConf

        hyperparams = OmegaConf.to_container(config, resolve=False)

        # Always include version information for compatibility checking
        hyperparams["__version__"] = self.__version__

        if self.ds_meta is not None:
            # Store dataset metadata needed to reconstruct input/output specifications
            dataset_metadata = {
                "data_path": str(getattr(self.ds_meta, "data_path", "unknown")),
                "input_shapes": {},
                "output_shapes": {},
            }

            # Extract input shapes
            if hasattr(self.ds_meta, "input_features"):
                for key, feature in self.ds_meta.input_features.items():
                    if hasattr(feature, "shape"):
                        dataset_metadata["input_shapes"][key] = list(feature.shape)  # type: ignore

            # Extract output shapes
            if hasattr(self.ds_meta, "output_features"):
                for key, feature in self.ds_meta.output_features.items():
                    if hasattr(feature, "shape"):
                        dataset_metadata["output_shapes"][key] = list(feature.shape)  # type: ignore

            hyperparams["_lerobot_dataset_metadata"] = dataset_metadata
            print("💾 Stored dataset metadata in checkpoint")

        # Save everything in one call - this preserves the full config + metadata
        self.save_hyperparameters(hyperparams)

    @staticmethod
    def create_metadata_from_dataset_info(dataset_metadata: dict) -> Any:
        """Create metadata from dataset shape information stored in checkpoint."""
        from lerobot.configs.types import FeatureType, PolicyFeature

        from visuomotor.data.datasets_lerobot import CustomDatasetMetadata

        input_features = {}
        output_features = {}

        # Reconstruct input features from stored shapes
        for key, shape in dataset_metadata.get("input_shapes", {}).items():
            if "color" in key or "image" in key:
                # Visual feature
                input_features[key] = PolicyFeature(type=FeatureType.VISUAL, shape=tuple(shape))
            else:
                # State feature
                input_features[key] = PolicyFeature(type=FeatureType.STATE, shape=tuple(shape))

        # Reconstruct output features from stored shapes
        for key, shape in dataset_metadata.get("output_shapes", {}).items():
            output_features[key] = PolicyFeature(type=FeatureType.ACTION, shape=tuple(shape))

        return CustomDatasetMetadata(
            data_path=dataset_metadata.get("data_path", "checkpoint_inference"),
            input_features=input_features,
            output_features=output_features,
            stats=None,
        )
