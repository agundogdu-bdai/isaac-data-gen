#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import logging
from datetime import datetime
from functools import partial
from typing import Callable, Optional

import torch
from lightning import LightningModule
from lightning.pytorch.utilities import grad_norm
from lightning.pytorch.utilities.types import OptimizerLRScheduler
from omegaconf import DictConfig, ListConfig, OmegaConf
from torch.optim import Optimizer

import visuomotor
from visuomotor.models import lr_schedules
from visuomotor.models.beta_utils import get_optimizer
from visuomotor.utils.normalizer import LinearNormalizer

logger = logging.getLogger(__name__)


class BasePolicy(LightningModule):
    """
    Base class for all policies. Subclasses must implement the following methods:
    - encode
    - forward
    - training_step
    - predict_action

    This class provides the necessary infrastructure for a policy to be trained and evaluated.
    """

    def __init__(self, config: DictConfig | ListConfig) -> None:
        super().__init__()

        self.config = config
        self.normalizer = LinearNormalizer()
        # This is for backward compatibility. ResNet requires n_cams to be set for bc.py
        if "color" in self.config.data.obs_keys.visual:
            if self.config.rgb_encoder.shared_encoder:
                self.config.rgb_encoder.n_cams = len(self.config.data.camera_ids)
            else:
                self.config.rgb_encoder.n_cams = 1

        # Set the image size based on the image randomization config
        resize = self.config.data.get("image_randomization", {}).get("resize")
        crop_size = self.config.data.get("image_randomization", {}).get("crop_size")
        if resize is None and crop_size is None and self.config.rgb_encoder.image_size is None:
            raise ValueError(
                "If you're not using resizing or cropping,\
                            you must specify the image size under the rgb_encoder config."
            )
        if resize:
            self.config.rgb_encoder.image_size = resize
        if crop_size:
            self.config.rgb_encoder.image_size = crop_size

        timestamp = datetime.now().strftime("%Y.%m.%d.%H.%M.%S")
        self.config.storage_path = f"gs://bdai-common-storage/visuomotor/ray/test_vpl_diffpo/{timestamp}"
        config_with_version = OmegaConf.to_container(self.config)
        config_with_version["__version__"] = visuomotor.__version__
        try:
            action_head_name = self.config.action_head.name  # type: ignore[attr-defined]
        except Exception:
            action_head_name = "integrated"
        logger.info(f"Using action head: {action_head_name}")
        logger.info(f"Using policy: {self.config.method_name}")
        logger.info(f"Saving model with visuomotor version: {visuomotor.__version__}")
        self.save_hyperparameters(config_with_version)

    def calculate_state_input_dim(self) -> int:
        state_dim = sum([sum(v["shape"]) for v in self.config.data.obs_keys.state.values()])
        return state_dim * self.config.data.n_obs_history_state

    def on_train_batch_start(self, batch: dict[str, torch.Tensor], batch_idx: int) -> None:
        for i, param_group in enumerate(self.trainer.optimizers[0].param_groups):
            self.log(f"opt_{i+1}_lr", param_group["lr"])

    def on_before_optimizer_step(self, optimizer: torch.optim.Optimizer) -> None:
        norm = grad_norm(self, norm_type=2)["grad_2.0_norm_total"]
        self.log("grad_norm", norm)

    def configure_optimizers(self) -> tuple[list[Optimizer], list[OptimizerLRScheduler]]:
        optimizer_config = self.config.train.optimizer
        optimizer_cls: Callable[..., Optimizer] = get_optimizer(optimizer_config.name)
        optimizer_params = getattr(optimizer_config, "params", {})
        optimizer_params = {k: v for k, v in optimizer_params.items() if v is not None}

        pcd_param_set = set()
        pcd_param_group: Optional[dict] = None
        if "pcd_lr" in optimizer_config.learning_rate:
            logging.info("overwriting pcd encoder learning rates")
            pcd_param_set = set(self.encoders["point_cloud"].parameters())
            pcd_param_group = {
                "params": list(pcd_param_set),
                "lr": optimizer_config.learning_rate.pcd_lr,
                "weight_decay": optimizer_config.learning_rate.pcd_weight_decay,
                "betas": optimizer_config.learning_rate.pcd_betas,
            }

        color_param_set = set()
        color_param_group: Optional[dict] = None
        if "color_lr" in optimizer_config.learning_rate:
            logging.info("overwriting color encoder learning rates")
            for encoder_name, encoder in self.encoders.items():
                if encoder_name.startswith("color"):
                    color_param_set.update(set(encoder.parameters()))
            color_param_group = {"params": list(color_param_set), "lr": optimizer_config.learning_rate.color_lr}

        other_param_group = {
            "params": [p for p in self.parameters() if p not in {*pcd_param_set, *color_param_set}],
            "lr": optimizer_config.learning_rate.lr,
        }

        parameters = [group for group in [color_param_group, pcd_param_group, other_param_group] if group is not None]

        optimizer = optimizer_cls(
            parameters,
            lr=optimizer_config.learning_rate.lr,
            **optimizer_params,
        )

        # Use cosine decay with linear warmup.
        # TODO(ZTC): add support for other warmup strategies
        lr_fn = partial(
            lr_schedules.cosine_decay_linear_warmup_simple_scheduler,
            warmup_steps=optimizer_config.learning_rate.warmup_iters,
            steps_per_cycle=self.config.train.max_steps,
        )

        scheduler = {
            "scheduler": torch.optim.lr_scheduler.LambdaLR(
                optimizer,
                lr_fn,
            ),
            "interval": "step",
            "frequency": 1,
        }

        return [optimizer], [scheduler]

    def normalize_inputs(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        if not self.config.data.normalize:
            return batch
        for key in self.config.data.norm_keys:
            batch[key] = self.normalizer[key](batch[key])
        return batch
