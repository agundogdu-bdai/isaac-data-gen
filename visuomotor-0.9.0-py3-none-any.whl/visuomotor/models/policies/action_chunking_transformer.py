#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import torch
import torch.nn.functional as F
from lightning.pytorch.utilities.types import STEP_OUTPUT
from omegaconf import DictConfig, ListConfig

from visuomotor.models.model_registry import ModelType, register_model
from visuomotor.models.policies.bc import BehaviorCloning


@register_model(name="act", model_type=ModelType.POLICY, status="beta")
class ActionChunkingTransformer(BehaviorCloning):
    def __init__(self, config: DictConfig | ListConfig) -> None:

        super().__init__(config)

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        batch = self.prepare_inputs(batch)
        features = self.encode(batch)
        pred = self.head(features)
        return pred

    def training_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred = self.forward(batch)
        target = batch["action"]
        loss = self.compute_loss(pred, target)
        self.log("train_loss", loss)
        return loss

    def validation_step(self, batch: dict[str, torch.Tensor], batch_idx: int) -> STEP_OUTPUT:
        pred = self.forward(batch)
        target = batch["action"]
        loss = self.compute_loss(pred, target)
        self.log("valid_loss", loss)
        return loss

    def compute_loss(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert y_hat.shape == y.shape, f"y_hat.shape: {y_hat.shape}, y.shape: {y.shape}"
        return F.l1_loss(y_hat, y)
