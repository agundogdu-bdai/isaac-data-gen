#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
"""Code for handling Stochastic Weighted Average."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from omegaconf import DictConfig


def prepare_swa_config(d: dict | DictConfig) -> dict:
    """Convert the stochastic weighted average config we get from omegaconf into the **kwargs we'll
    pass to lightning's StochasticWeightAveraging.
    """
    keys_to_replace = ["avg_fn", "ema_decay_rate"]
    d_prepared = {k: v for k, v in d.items() if k not in keys_to_replace}
    # Setup the function that decides how to weight the average across epochs.
    avg_fn_str = d["avg_fn"]
    match avg_fn_str:
        case "swa":
            from torch.optim.swa_utils import get_swa_avg_fn  # pyright: ignore[reportAttributeAccessIssue]

            avg_fn = get_swa_avg_fn()
        case "ema":
            from torch.optim.swa_utils import get_ema_avg_fn  # pyright: ignore[reportAttributeAccessIssue]

            avg_fn = get_ema_avg_fn(decay=d["ema_decay_rate"])
        case _:
            raise ValueError(f"Supported avg_fn are 'ema' and 'swa'. The selected value '{avg_fn_str}' is invalid.")
    d_prepared["avg_fn"] = avg_fn
    return d_prepared
