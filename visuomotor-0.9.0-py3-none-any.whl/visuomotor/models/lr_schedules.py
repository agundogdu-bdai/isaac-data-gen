# Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
# From https://github.com/google-research/scenic.
# Licensed under Apache-2.0.

import numpy as np


def cosine_decay_scheduler(
    step: int, steps_per_cycle: int, t_mul: float = 1.0, m_mul: float = 1.0, alpha: float = 0.0
) -> float:
    """Gives a scaling factor based on scheduling with a cosine decay.

    Args:
        step: int; Current step.
        steps_per_cycle: int; Number of steps to reset the decay cycle.
        t_mul: int; Used to derive the number of iterations in the i-th period.
        m_mul: float; Used to derive the initial learning rate of the i-th period.
        alpha: float; The minimum value as a fraction of the initial value.

    Returns:
        Scaling factor applied to the learning rate on the given step.
    """
    if steps_per_cycle <= 0:
        raise ValueError(f"steps_per_cycle must be > 0. Got {steps_per_cycle}.")
    progress = step / float(steps_per_cycle)
    if t_mul == 1.0:
        i_restart = np.floor(progress)
        progress -= i_restart
    else:
        i_restart = np.floor(np.log(1.0 - progress * (1.0 - t_mul)) / np.log(t_mul))
        sum_r = (1.0 - t_mul**i_restart) / (1.0 - t_mul)
        progress = (progress - sum_r) / t_mul**i_restart
    m_fac = m_mul**i_restart
    cosine_decay = np.maximum(0.0, 0.5 * m_fac * (1.0 + np.cos(np.pi * (progress % 1.0))))
    return (1 - alpha) * cosine_decay + alpha


def linear_warmup_scheduler(step: int, warmup_steps: int, alpha: float = 0.0) -> float:
    """Gives a scaling factor based on scheduling with a Linear Warmup.

    Args:
        step: int; Current step.
        warmup_steps: int; How many steps to warm up for in the warmup schedule.
        alpha: float: The minimum value as a fraction of the initial value.

    Returns:
        Scaling factor applied to the learning rate on the given step.
    """
    if warmup_steps > 0:
        return np.minimum(1.0, alpha + step * (1.0 - alpha) / warmup_steps)
    else:
        return 1.0


def cosine_decay_linear_warmup_simple_scheduler(step: int, warmup_steps: int, steps_per_cycle: int) -> float:
    """Combines linear warmup and cosine annealing."""
    if step < warmup_steps:
        return linear_warmup_scheduler(step, warmup_steps)
    else:
        return cosine_decay_scheduler(step, steps_per_cycle)
