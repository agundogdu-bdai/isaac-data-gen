#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import time

import ray
import ray.util.scheduling_strategies
import wandb
from lightning import LightningModule
from omegaconf import DictConfig

from visuomotor.ray_train.simulation.constants import MIMICGEN_BENCHMARK_TASKS, MIMICGEN_TASK_STEPS
from visuomotor.ray_train.simulation.mimicgen_actor import DexMimicgenActor, MimicgenActor
from visuomotor.ray_train.simulation.simulation_manager import SimulationManager

SIM_ACTORS = {
    "mimicgen": MimicgenActor,
    "dexmimicgen": DexMimicgenActor,
}

MAX_EXTRA_SIM_TIME = 86400  # if sims run after training for more than a day, stop it


class SimulationValidation:
    def __init__(self, config: DictConfig, max_groups_per_manager: int = 10) -> None:
        self.config = config
        self.fps = self.config.get("video_fps", 60)

        self.sim_actors = []
        for index, env in enumerate(self.config["envs"]):
            if env["type"] == "mimicgen":
                task_name, task_number = env["name"].rsplit("_", 1)
                assert task_name in MIMICGEN_BENCHMARK_TASKS and task_number in MIMICGEN_BENCHMARK_TASKS[task_name], (
                    f"The task in your config: {task_name}_{task_number} is not part of the available "
                    f"mimicgen tasks: {MIMICGEN_BENCHMARK_TASKS}"
                )
                num_steps = env.get("num_steps", MIMICGEN_TASK_STEPS[task_name])
            else:
                num_steps = env.get("num_steps")
            self.sim_actors.append((env["name"], index, SIM_ACTORS[env["type"]], num_steps))

        self.sim_managers: list = []
        self.groups_per_manager: list[int] = []
        self.finished_groups_per_manager: list[int] = []
        if config.get("use_checkpoints", False):
            # if using checkpoints, they get downloaded onto the sim actor nodes
            # instead of passing through sim manager
            self.sim_manager_gpus = 0
        else:
            self.sim_manager_gpus = 1
        self.add_sim_manager()
        self.max_groups_per_manager = max_groups_per_manager

    def start_sim(
        self, epoch: int, config: DictConfig, pl_module: LightningModule | None = None, artifact_name: str | None = None
    ) -> None:
        for sim_actor in self.sim_actors:
            sim_manager = self.get_sim_manager()
            ray.get(
                sim_manager.start_simulations.remote(  # type: ignore
                    actors=[sim_actor],
                    artifact_name=artifact_name,
                    current_epoch=epoch,
                    config=config,
                    pl_module=pl_module,
                )
            )
        self.check_and_log_finished()

    def add_sim_manager(self) -> None:
        """Add a SimulationManager to list of sim_managers"""
        sim_manager_ind = len(self.sim_managers)
        self.sim_managers.append(
            SimulationManager.options(name=f"sim_manager_{sim_manager_ind}", num_gpus=self.sim_manager_gpus).remote(  # type: ignore
                self.config
            )
        )
        self.groups_per_manager.append(0)
        self.finished_groups_per_manager.append(0)

    def get_sim_manager(self) -> SimulationManager:
        """
        To avoid loading too many models in a single manager which can cause OOM, we can launch
        one simulation manager for every self.max_groups_per_manager.

        This method returns the manager to run the next group on.
        """
        candidate_manager_indexes = [
            ind
            for ind, val in enumerate(self.groups_per_manager)
            if val < self.max_groups_per_manager and self.sim_managers[ind] is not None
        ]
        if len(candidate_manager_indexes) > 0:
            sim_manager_ind = candidate_manager_indexes[0]
            # TODO: (elin) move this out of here, so we can get a sim manager without incrementing
            self.groups_per_manager[sim_manager_ind] += 1
            return self.sim_managers[sim_manager_ind]
        else:
            self.add_sim_manager()
            return self.get_sim_manager()

    def check_and_log_finished(self, timeout: float = 1.0) -> None:
        wandb.define_metric("validation_epoch")
        for env in self.config["envs"]:
            wandb.define_metric(f"{env['name']}_success_rate", step_metric="validation_epoch")
            wandb.define_metric(f"{env['name']}_num_episodes", step_metric="validation_epoch")
            wandb.define_metric(f"{env['name']}_avg_rewards", step_metric="validation_epoch")
            # This metric is the one that corresponds to "mean_score" from bdai equidiff / diffpo original repo
            wandb.define_metric(f"{env['name']}_mean_of_episode_max_reward", step_metric="validation_epoch")

        """Checks to see if any sim runs have completed and logs results."""
        for sim_manager_ind, sim_manager in enumerate(self.sim_managers):

            if sim_manager is None:
                continue

            finished = ray.get(sim_manager.get_finished.remote(timeout=timeout))
            for result in finished:
                epoch = result["epoch"]
                self.finished_groups_per_manager[sim_manager_ind] += 1
                if self.config.save_videos:
                    wandb.log(
                        {
                            f"{result['env_name']}_sim_epoch_{result['epoch']}": wandb.Video(
                                result["frames_np"], fps=self.fps
                            ),
                            "validation_epoch": epoch,
                        }
                    )
                wandb.log({f"{result['env_name']}_success_rate": result["success_rate"], "validation_epoch": epoch})
                wandb.log(
                    {f"{result['env_name']}_num_episodes": result["total_num_episodes"], "validation_epoch": epoch}
                )
                wandb.log({f"{result['env_name']}_avg_rewards": result["avg_rewards"], "validation_epoch": epoch})
                wandb.log(
                    {
                        f"{result['env_name']}_mean_of_episode_max_reward": result["mean_of_episode_max_reward"],
                        "validation_epoch": epoch,
                    }
                )

            if self.finished_groups_per_manager[sim_manager_ind] == self.groups_per_manager[sim_manager_ind]:
                self.sim_managers[sim_manager_ind] = None

    def run_until_end(self) -> None:
        """Wait for remaining simulations to complete and log."""
        start = time.time()
        while any(sm is not None for sm in self.sim_managers) and (time.time() - start < MAX_EXTRA_SIM_TIME):
            self.check_and_log_finished()
