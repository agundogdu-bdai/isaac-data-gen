# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
# Ported over from fork of robomimic: https://github.com/ARISE-Initiative/robomimic/compare/master...pointW:robomimic:pc
# The purpose of that fork was to implement point cloud generation from camera depths

from typing import Any

import numpy as np
import open3d as o3d
import robomimic.utils.obs_utils as ObsUtils
from robomimic.envs.env_robosuite import EnvRobosuite
from robosuite.utils.camera_utils import get_camera_extrinsic_matrix, get_camera_intrinsic_matrix, get_real_depth_map


def depth2fgpcd(depth: np.array, mask: np.array, cam_params: np.array) -> np.array:
    # depth: (h, w)
    # fgpcd: (n, 3)
    # mask: (h, w)
    h, w = depth.shape
    mask = np.logical_and(mask, depth > 0)
    fgpcd = np.zeros((mask.sum(), 3))
    fx, fy, cx, cy = cam_params
    pos_x, pos_y = np.meshgrid(np.arange(w), np.arange(h))
    pos_x = pos_x[mask]
    pos_y = pos_y[mask]
    fgpcd[:, 0] = (pos_x - cx) * depth[mask] / fx
    fgpcd[:, 1] = (pos_y - cy) * depth[mask] / fy
    fgpcd[:, 2] = depth[mask]
    return fgpcd


def np2o3d(pcd: np.array, color: np.array = None) -> Any:
    # pcd: (n, 3)
    # color: (n, 3)
    pcd_o3d = o3d.geometry.PointCloud()
    pcd_o3d.points = o3d.utility.Vector3dVector(pcd)
    if color is not None and color.shape[0] > 0:
        assert pcd.shape[0] == color.shape[0]
        assert color.max() <= 1
        assert color.min() >= 0
        pcd_o3d.colors = o3d.utility.Vector3dVector(color)
    return pcd_o3d


class PointCloudRobomimicEnv(EnvRobosuite):

    def __init__(
        self,
        env_name: str,
        render: bool = False,
        render_offscreen: bool = False,
        use_image_obs: bool = False,
        use_depth_obs: bool = False,
        postprocess_visual_obs: bool = True,
        **kwargs: dict,
    ) -> None:
        super().__init__(
            env_name=env_name,
            render=render,
            render_offscreen=render_offscreen,
            use_image_obs=use_image_obs,
            use_depth_obs=use_depth_obs,
            postprocess_visual_obs=postprocess_visual_obs,
            **kwargs,
        )

        voxel_center = np.array([0, 0, 0.7])
        pc_center = np.array([0, 0, 0.7])
        if hasattr(self.env, "table_offset"):
            voxel_center[:2] = self.env.table_offset[:2]
            pc_center = np.array(self.env.table_offset)
            pc_center[2] = pc_center[2] + 0.02
        self.ws_size = 0.6
        if env_name.startswith("Kitchen_"):
            self.ws_size = 0.7
            pc_center = self.env.table_offset
        elif env_name.startswith("PickPlace_"):
            pc_center = np.array([0, 0, 0.83])
            self.ws_size = 1.1

        self.voxel_workspace = np.array(
            [
                [voxel_center[0] - self.ws_size / 2, voxel_center[0] + self.ws_size / 2],
                [voxel_center[1] - self.ws_size / 2, voxel_center[1] + self.ws_size / 2],
                [voxel_center[2], voxel_center[2] + self.ws_size],
            ]
        )
        self.pc_workspace = np.array(
            [
                [pc_center[0] - self.ws_size / 2, pc_center[0] + self.ws_size / 2],
                [pc_center[1] - self.ws_size / 2, pc_center[1] + self.ws_size / 2],
                [pc_center[2], pc_center[2] + self.ws_size],
            ]
        )

    def get_observation(self, raw_obs: Any = None) -> dict:
        """
        Get current environment observation dictionary.
        Args:
            raw_obs (dict): current raw observation dictionary from robosuite to wrap and provide
                as a dictionary. If not provided, will be queried from robosuite.
        """

        if raw_obs is None:
            if self._is_v1:
                raw_obs = self.env._get_observations(force_update=True)  # noqa SLF001
            else:
                raw_obs = self.env._get_observation()  # noqa SLF001

        obs = {}
        for k in raw_obs:
            if k in ObsUtils.OBS_KEYS_TO_MODALITIES:
                if ObsUtils.key_is_obs_modality(key=k, obs_modality="rgb"):
                    obs[k] = raw_obs[k][::-1]
                    if self.postprocess_visual_obs:
                        obs[k] = ObsUtils.process_obs(obs=obs[k], obs_key=k)
                if ObsUtils.key_is_obs_modality(key=k, obs_modality="depth"):
                    depth_map = raw_obs[k][::-1]
                    depth_map = np.clip(depth_map, 0, 1)
                    obs[k] = get_real_depth_map(self.env.sim, depth_map)
                    if self.postprocess_visual_obs:
                        obs[k] = ObsUtils.process_obs(obs=obs[k], obs_key=k)

        obs["object"] = np.array(raw_obs["object-state"])

        obs = self.generate_point_cloud_from_depth(raw_obs, obs)

        if self._is_v1:
            for robot in self.env.robots:
                # add all robot-arm-specific observations. Note the (k not in obs) check
                # ensures that we don't accidentally add robot wrist images a second time
                pf = robot.robot_model.naming_prefix
                for k in raw_obs:
                    if k.startswith(pf) and (k not in obs) and (not k.endswith("proprio-state")):
                        obs[k] = np.array(raw_obs[k])
        else:
            # minimal proprioception for older versions of robosuite
            obs["proprio"] = np.array(raw_obs["robot-state"])
            obs["eef_pos"] = np.array(raw_obs["eef_pos"])
            obs["eef_quat"] = np.array(raw_obs["eef_quat"])
            obs["gripper_qpos"] = np.array(raw_obs["gripper_qpos"])
        return obs

    def generate_point_cloud_from_depth(self, raw_obs: dict, obs: dict) -> dict:

        if self.env.use_camera_obs:
            workspace = self.voxel_workspace

            voxel_bound = workspace.T
            voxel_size = 64

            all_pcds = o3d.geometry.PointCloud()
            for cam_idx, camera_name in enumerate(self.env.camera_names):
                cam_height = self.env.camera_heights[cam_idx]
                cam_width = self.env.camera_widths[cam_idx]
                ext_mat = get_camera_extrinsic_matrix(self.env.sim, camera_name)
                int_mat = get_camera_intrinsic_matrix(self.env.sim, camera_name, cam_height, cam_width)
                depth = raw_obs[f"{camera_name}_depth"][::-1]
                depth = np.clip(depth, 0, 1)
                depth = get_real_depth_map(self.env.sim, depth)
                depth = depth[:, :, 0]
                color = raw_obs[f"{camera_name}_image"][::-1]

                cam_param = [int_mat[0, 0], int_mat[1, 1], int_mat[0, 2], int_mat[1, 2]]
                mask = np.ones_like(depth, dtype=bool)
                pcd = depth2fgpcd(depth, mask, cam_param)

                pose = ext_mat

                trans_pcd = pose @ np.concatenate([pcd.T, np.ones((1, pcd.shape[0]))], axis=0)
                trans_pcd = trans_pcd[:3, :].T

                mask = (
                    (trans_pcd[:, 0] > workspace[0, 0])
                    * (trans_pcd[:, 0] < workspace[0, 1])
                    * (trans_pcd[:, 1] > workspace[1, 0])
                    * (trans_pcd[:, 1] < workspace[1, 1])
                    * (trans_pcd[:, 2] > workspace[2, 0])
                    * (trans_pcd[:, 2] < workspace[2, 1])
                )

                pcd_o3d = np2o3d(trans_pcd[mask], color.reshape(-1, 3)[mask].astype(np.float64) / 255)

                all_pcds += pcd_o3d

            voxel_grid = o3d.geometry.VoxelGrid.create_from_point_cloud_within_bounds(
                all_pcds,
                voxel_size=self.ws_size / voxel_size + 1e-4,
                min_bound=voxel_bound[0],
                max_bound=voxel_bound[1],
            )
            voxels = voxel_grid.get_voxels()  # returns list of voxels
            if len(voxels) == 0:
                np_voxels = np.zeros([4, voxel_size, voxel_size, voxel_size], dtype=np.uint8)
            else:
                indices = np.stack(list(vx.grid_index for vx in voxels))
                colors = np.stack(list(vx.color for vx in voxels))

                mask = (indices > 0) * (indices < voxel_size)
                indices = indices[mask.all(axis=1)]
                colors = colors[mask.all(axis=1)]

                np_voxels = np.zeros([4, voxel_size, voxel_size, voxel_size], dtype=np.uint8)
                np_voxels[0, indices[:, 0], indices[:, 1], indices[:, 2]] = 1
                np_voxels[1:, indices[:, 0], indices[:, 1], indices[:, 2]] = colors.T * 255

            obs["voxel"] = np_voxels

            bounding_box = o3d.geometry.AxisAlignedBoundingBox(self.pc_workspace.T[0], self.pc_workspace.T[1])
            cropped_pcd = all_pcds.crop(bounding_box)
            if len(cropped_pcd.points) == 0:
                # create fake points
                cropped_pcd.points = o3d.utility.Vector3dVector(np.array([[0.0, 0.0, 0.0]]))
                cropped_pcd.colors = o3d.utility.Vector3dVector(np.array([[0.0, 0.0, 0.0]]))
            if len(cropped_pcd.points) < 1024:
                # random upsample to 1024
                num_pad = 1024 - len(cropped_pcd.points)
                indices = np.random.choice(len(cropped_pcd.points), num_pad)
                padded_xyz = np.asarray(cropped_pcd.points)[indices]
                padded_color = np.asarray(cropped_pcd.colors)[indices]
                xyz = np.concatenate([np.asarray(cropped_pcd.points), padded_xyz], 0)
                color = np.concatenate([np.asarray(cropped_pcd.colors), padded_color], 0)
                cropped_pcd = o3d.geometry.PointCloud()
                cropped_pcd.points = o3d.utility.Vector3dVector(xyz)
                cropped_pcd.colors = o3d.utility.Vector3dVector(color)
            sampled_pcds = cropped_pcd.farthest_point_down_sample(1024)
            xyz = np.asarray(sampled_pcds.points)
            color = np.asarray(sampled_pcds.colors)

            obs["point_cloud"] = np.concatenate([xyz, color], 1)

        return obs
