#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

import numpy as np
from omegaconf import DictConfig
from scipy.spatial.transform import Rotation

# from pytorch3d.ops import sample_farthest_points
from torch.utils.data import Dataset

from visuomotor.data.data_readers import EpisodeReader, SamplePayload


class AbsoluteDataset(Dataset):
    """

    Loads training samples for 10dof gripper and single camera.
    Applies the following temporal structure:
        > __getitem__(idx): idx is the index of the last camera frame
        > camera timepoints: [..., idx - rgb_step_size * 2, idx - rgb_step_size * 1, idx]
        > action timepoints: [idx, idx + action_step_size, idx + 2 * action_step_size, ...]
        > eef timepoints: [..., idx - 2 * eef_step_size, idx - eef_step_size, idx]
        > gripper timepoints:
            [..., idx - 2 * eef_step_size, idx - eef_step_size, idx]

    Padding:
        > no padding applied on input side --> only legal windows considered
        > padding applied on action side --> outputs mask
    """

    def __init__(
        self,
        config: DictConfig,
        reader: EpisodeReader[dict[str, SamplePayload]],
    ):
        """

        Args:
            config (DictConfig): config to initialize the dataset. It needs
                action_horizon (int): target action_horizon
                action_step_size (int): target action step size
                    action window: range(idx, idx + action_horizon * action_step_size, action_step_size)
                rgb_horizon (int): camera horizon
                rgb_step_size (int): camera step size
                    rgb window: range(idx, idx - rgb_horizon * rgb_step_size, rgb_step_size)
                eef_horizon (int): end effector horizon
                eef_step_size (int): end effector step size
                action_name (str, optional): action field name in raw dataset.
                    Expected shape of underlying data: T x 7 = [xyz, rot_vec, gripper_width].
                rgb_name (str, optional): rgb field name in raw dataset. This field is expected to be uint8 images.
                    Expected shape of underlying data: T x H x W x 3.
                gripper_name (str, optional): gripper field name in raw dataset.
                    Expected shape of underlying data: T x 1.
            reader (EpisodeReader): read underlying data
        """
        self.config = config
        self._rgb_name = self.config.rgb_name
        self._action_name = self.config.action_name
        self._eef_horizon = self.config.eef_horizon
        self._eef_step_size = self.config.eef_step_size
        self._gripper_name = self.config.gripper_name
        self._rgb_horizon = self.config.rgb_horizon
        self._rgb_step_size = self.config.rgb_step_size
        self._action_horizon = self.config.action_horizon
        self._action_step_size = self.config.action_step_size
        self._return_mask = self.config.return_mask
        self._reader = reader

        # relative windows
        input_pose_rel_window = np.arange(0, -1 * self._eef_horizon * self._eef_step_size, -1 * self._eef_step_size)[
            ::-1
        ]
        self._relative_windows = {
            self._rgb_name: np.arange(0, -1 * self._rgb_horizon * self._rgb_step_size, -1 * self._rgb_step_size)[::-1],
            self._action_name: np.hstack(
                (
                    input_pose_rel_window,
                    np.arange(0, self._action_horizon * self._action_step_size, self._action_step_size),
                )
            ),
        }

        # episode lengths
        self._prefix_len = max(
            (self._rgb_horizon - 1) * self._rgb_step_size, (self._eef_horizon - 1) * self._eef_step_size
        )
        self._episode_lengths = [
            self._reader.get_episode_length(episode_idx) - self._prefix_len
            for episode_idx in range(self._reader.get_number_of_episodes())
        ]
        self._cumulative_episode_lengths = np.cumsum(self._episode_lengths)
        self._dset_length = sum(self._episode_lengths)

    def __len__(self) -> int:
        return self._dset_length

    def __getitem__(self, idx: int) -> dict[str, np.ndarray]:
        """get data at requested index

        Args:
            idx (int): target index. This index specified the last camera frame in the window

        Returns:
            dict[str, np.ndarray]: mapping from data fieldnames to processed arrays
                mapping from field name to shapes within a sample (pre-batching):
                    action: action_horizon x 10
                    action_mask: action_horizon x 10
                    color: rgb_horizon x 1 (num_camera) x 3 (num_channel) x target_image_shape
                    robot0_eef_pose: eef_horizon x 3
        """
        # map idx to last_camera_idx:
        episode_idx = np.where(self._cumulative_episode_lengths > idx)[0][0]
        if episode_idx == 0:
            idx_within_episode = idx
        else:
            idx_within_episode = idx - self._cumulative_episode_lengths[episode_idx - 1]
        idx_within_episode += self._prefix_len
        episode_length = self._reader.get_episode_length(episode_idx)

        # make absolute windows:
        absolute_windows = {}
        for field_name, relative_window in self._relative_windows.items():
            v = relative_window + idx_within_episode
            rmask = v < episode_length
            absolute_windows[field_name] = v[rmask]

        data_sample = self._reader.load_sample(episode_idx, absolute_windows)

        # rgb:
        rgb = data_sample[self._rgb_name].sample.transpose((0, 3, 1, 2))
        rgb = rgb.astype(np.float32) / 255.0

        # pose:
        combined = data_sample[self._action_name].sample
        xyz = combined[:, :3]
        rot = Rotation.from_rotvec(combined[:, 3:6]).as_matrix()[:, :2, :3].reshape(-1, 6)
        eef_pose = np.hstack((xyz[: self._eef_horizon], rot[: self._eef_horizon], combined[: self._eef_horizon, -1:]))
        action_pose = np.hstack(
            (xyz[self._eef_horizon :], rot[self._eef_horizon :], combined[self._eef_horizon :, -1:])
        )

        # pad action
        action_pad_length = self._action_horizon - action_pose.shape[0]
        action_pose = np.vstack((action_pose, np.zeros((action_pad_length, 10))))
        action_mask = np.ones((self._action_horizon, 10))
        action_mask[action_mask.shape[0] - action_pad_length :] = 0.0

        raw_dset = {
            "action": action_pose,
            "action_mask": action_mask,
            "color": rgb[:, None],  # adds a dimension for number of cameras
            "robot0_eef_pose": eef_pose,
        }

        dset = {k: v.astype(np.float32) for k, v in raw_dset.items()}

        return dset
