#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
from __future__ import annotations

import os
from typing import TYPE_CHECKING

from google.cloud import storage

from visuomotor.utils.paths import get_datasets_path

if TYPE_CHECKING:
    import omegaconf

GCS_PROJECT_ID = "engineering-380817"
GCS_BUCKET_NAME = "bdai-common-storage"
_BUCKET: storage.Bucket | None = None
"""Bucket. We leave this as a global to avoid re-initializing it for each download request.
We initialize it on use, rather than on import, in case this gets imported before gcloud
has authenticated.
"""


def get_bucket() -> storage.Bucket:
    global _BUCKET
    if _BUCKET is None:
        _BUCKET = storage.Client(project=GCS_PROJECT_ID).bucket(GCS_BUCKET_NAME)
    return _BUCKET


def download_dataset_sample(dataset_path: str, n_episodes: int, overwrite: bool = True) -> None:
    """Downloads the first n_episodes of a dataset from GCS.

    Args:
        dataset_path: Path to dataset. Locally, this is relative to get_datasets_path(). In GCS, this
            is relative to bdai-common-storage/visuomotor/datasets
        n_episodes: Number of episodes to download.
        overwrite: If True, always download the files. If False, skip downloaded files.
    """
    bucket = get_bucket()
    print(f"Downloading {n_episodes} from {dataset_path}")
    dataset_prefix = f"visuomotor/datasets/{dataset_path}"
    dataset_path_local = get_datasets_path() / dataset_path
    os.makedirs(dataset_path_local, exist_ok=True)

    metadata_name = "metadata.json"
    metadata_download_path = dataset_path_local / metadata_name
    if overwrite or (not metadata_download_path.exists()):
        print("Downloading metadata")
        bucket.blob(f"{dataset_prefix}/{metadata_name}").download_to_filename(dataset_path_local / metadata_name)
    else:
        print("Metadata is already downloaded")

    for i_episode in range(n_episodes):
        episode_path_relative_to_dataset = f"episode_{i_episode}/episode_{i_episode}.h5"
        os.makedirs((dataset_path_local / episode_path_relative_to_dataset).parent, exist_ok=True)
        episode_download_path = dataset_path_local / episode_path_relative_to_dataset
        if overwrite or (not episode_download_path.exists()):
            print(f"Downloading episode {i_episode}")
            bucket.blob(f"{dataset_prefix}/{episode_path_relative_to_dataset}").download_to_filename(
                episode_download_path
            )
        else:
            print(f"Episode {i_episode} is already downloaded.")


def get_data_path(config: omegaconf.DictConfig) -> list[str] | omegaconf.listconfig.ListConfig | str:
    # If there's a 'data' section with a 'data_path', use it.
    if "data" in config and config.data is not None and "data_path" in config.data:
        return config.data.data_path
    # Otherwise, fall back to a top-level 'data_path' if it exists.
    elif "data_path" in config:
        return config.data_path
    else:
        raise AttributeError("Configuration must have either 'data.data_path' or 'data_path' key.")


def download_dataset_sample_from_config(config: omegaconf.DictConfig, n_episodes: int, overwrite: bool = True) -> None:
    """Download the first n_episodes from the first data_path in a config.

    Args:
        config: The toplevel training config.
        n_episodes: Number of episodes to download.
        overwrite: If True, always download the files. If False, skip downloaded files.
    """
    import omegaconf

    data_path = get_data_path(config)
    if isinstance(data_path, (list, omegaconf.listconfig.ListConfig)):
        data_path = data_path[0]
    assert isinstance(data_path, str), str(type(data_path))
    download_dataset_sample(data_path, n_episodes, overwrite)
