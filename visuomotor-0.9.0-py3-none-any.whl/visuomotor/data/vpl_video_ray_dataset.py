#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import glob
import os
import random
import time
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

import av
import h5py
import numpy as np
import numpy.typing as npt
import ray
import torch
from einops import rearrange
from omegaconf import DictConfig, OmegaConf
from packaging import version

from visuomotor.data.datasets import NORMALIZERS, compute_final_statistics
from visuomotor.data.rotation_transformer import RotationTransformer
from visuomotor.data.transforms import (
    get_color_transforms,
)
from visuomotor.data.utils import create_key_to_history_mapping, get_task_metadata
from visuomotor.utils.normalizer import LinearNormalizer
from visuomotor.utils.paths import DataSource, get_ray_worker_data_path

RAY_VERSION_REQUIRED = "2.47.1"


def ray_version_check() -> None:
    """Check if the current Ray version meets the required version."""
    ray_version_current = ray.__version__
    if version.parse(ray_version_current) < version.parse(RAY_VERSION_REQUIRED):
        raise RuntimeError(
            f"Ray version {ray_version_current} is too low. "
            f"Please upgrade to at least {RAY_VERSION_REQUIRED}."
            f"Please refer this PR Overview to use Ray dataset: https://github.com/bdaiinstitute/visuomotor/pull/382"
        )


def decode(sample: Dict[str, Any], config: DictConfig, ray_worker: bool = True, base_seed: int = 42) -> List[dict]:
    """
    Convert the sample to a list of frames

    This function needs to be run as a flat_map since it accepts a single sample (HDF5 file)
    and returns a list of rows.

    Args:
        sample (Dict[str, Any]): Dictionary containing the HDF5 file path and bytes (keys: "path", "bytes").
        config (DictConfig): Configuration object specifying dataset parameters, observation/action keys, history, etc.
        ray_worker (bool, optional): Whether the function is running on a Ray worker node. Defaults to True.

    Returns:
        List[dict]: List of dictionaries, each representing a single timestep with processed actions, observations,
                    and metadata, suitable for downstream training or evaluation.
    """

    def mp4_to_frames(video_path: str) -> Iterator[av.VideoFrame]:
        """read video into a list of frames."""
        frames = av.open(video_path).decode(video=0)
        return frames

    def stack_cam_frames(frames: Tuple[av.VideoFrame]) -> np.ndarray:
        return np.stack([frame.to_ndarray(format="rgb24") for frame in frames], axis=0)

    obs_visual = config.obs_keys.get("visual", list())
    obs_state = config.obs_keys.get("state", dict())
    obs_keys = [*obs_visual, *obs_state.keys()]

    horizon = config.horizon
    assert horizon >= 1, f"Action horizon ({horizon}) must be at least 1."

    pad_action = config.pad_action
    if pad_action is not None and pad_action not in ("constant", "edge"):
        raise ValueError(
            "Valid modes for padding the action are 'constant' (pad with zeros) and "
            "'edge' (pad with the last action)."
        )
    last_n_steps_to_remove = horizon - 1 if pad_action is None else None
    local_data_source = DataSource(config.local_data_source_str)
    metadata = get_task_metadata(
        config.data_path,
        local_data_source=local_data_source,
        ray_worker=ray_worker,
        max_episodes=config.max_episodes,
        last_n_steps_to_remove=last_n_steps_to_remove,
    )

    n_obs_history_visual = config.get("n_obs_history_visual")
    n_obs_history_state = config.get("n_obs_history_state")
    key_to_n_obs_history = create_key_to_history_mapping(
        obs_visual=obs_visual,
        obs_state=obs_state.keys(),
        n_obs_history_visual=n_obs_history_visual,
        n_obs_history_state=n_obs_history_state,
    )

    episode_timestep_total = metadata["episode_timestep_total"]
    h5_file = sample["path"]

    episode_idx = Path(h5_file).stem
    with h5py.File.in_memory(sample["bytes"]) as hdf:
        rows = []
        separate_cam_frames = []
        for camera_id in config.camera_ids:
            video_path = Path(h5_file).parent / "videos" / f"camera_{camera_id}" / f"{Path(h5_file).stem}.mp4"
            separate_cam_frames.append(mp4_to_frames(str(video_path)))

        # Combine frames from all cameras into a single list of frames
        combined_cam_frames = map(stack_cam_frames, zip(*separate_cam_frames, strict=False))

        history_buffer = None
        for timestep_idx, frame in enumerate(combined_cam_frames):
            if timestep_idx < episode_timestep_total[episode_idx]:
                frame_dict = {}
                # load action
                action = hdf["action"][timestep_idx : timestep_idx + horizon].astype(np.float32)

                if (diff_horizon := horizon - len(action)) != 0:
                    if pad_action is None:
                        raise ValueError(
                            f"Invalid action shape: {action.shape} which is less than the\
                                required horizon: {config.horizon}"
                        )
                    action = np.pad(action, ((0, diff_horizon), (0, 0)), pad_action)
                frame_dict["action"] = action
                # Handle observation history
                for key in obs_keys:
                    n_obs_history = key_to_n_obs_history[key]

                    if n_obs_history > 1 and not history_buffer:
                        from collections import deque

                        history_buffer = deque(maxlen=n_obs_history)

                    if "color" not in key:
                        raw_obs = hdf[key][max(0, timestep_idx - n_obs_history + 1) : timestep_idx + 1]
                    else:
                        if n_obs_history == 1:
                            raw_obs = frame[np.newaxis, ...]
                        else:
                            history_buffer.append(frame)  # type: ignore[attr-defined]
                            raw_obs = np.stack(history_buffer)
                    # If the episode is just starting, we need to pad before the very first timestep
                    # by repeating it
                    if (diff_obs := n_obs_history - len(raw_obs)) > 0:
                        padding = [(diff_obs, 0)] + [(0, 0)] * (raw_obs.ndim - 1)
                        raw_obs = np.pad(raw_obs, padding, "edge")
                    frame_dict[key] = raw_obs

                frame_dict["data_count"] = len(metadata["episode_timestep_idx"])
                rows.append(frame_dict)
            else:
                break
        # implement manual local shuffle
        # add episode number in seed so that we can reproduce but keep difference on each episodes
        # TODO: make each epoch seed different, need to have a ray actor to record epoch number
        episode_num = int(episode_idx.split("_")[-1])
        random.seed(base_seed + episode_num)
        random.shuffle(rows)
        return rows


def preprocess_color_batch(color_batch: np.ndarray, config: DictConfig) -> np.ndarray:
    """Preprocess frames read from video

    Args:
        color_batch (np.ndarray): frame batch
        config (DictConfig): data config

    Returns:
        np.ndarray: frames with color transforms, shape=(Batch, History, Camera, Channel, H, W)
    """
    obs_visual = config.obs_keys.get("visual", list())
    obs_state = config.obs_keys.get("state", dict())
    obs_keys = [*obs_visual, *obs_state.keys()]
    if "color" in obs_keys:
        color_transforms = get_color_transforms(config, inference=False)

    if color_transforms:
        batch_size, num_history, num_cameras, W, H, C = color_batch.shape
        # Flatten to process all frames
        images = color_batch.reshape(-1, W, H, C)
        transformed_frames = np.stack([color_transforms(image=img)["image"] for img in images])
        NH, NW, _ = transformed_frames.shape[-3:]
        color_obs = transformed_frames.reshape(batch_size, num_history, num_cameras, NH, NW, C)
    else:
        color_obs = color_batch

    # normalization
    # (put normalization in trainig could save memory but makes other users confused,
    # and Ray streaming dataset should be fine to handle the float32 data)
    color_obs = color_obs.astype(np.float32) / 255.0
    # Rearrange to (Batch, History, Cameras, Channel, H, W)
    color_obs = rearrange(color_obs, "b t n h w c -> b t n c h w")
    return color_obs


def preprocess_action_batch(action_batch: np.ndarray, config: DictConfig) -> np.ndarray:
    """preprocess action

    Args:
        action_batch (np.ndarray): action batch
        config (DictConfig): data config

    Returns:
        np.ndarray: preprocessed action, shape = [horizon, N], like (32,17).
    """
    batch_size, action_len, action_dim = action_batch.shape

    if config.get("action_convert_7d_to_10d"):
        rotation_transformer = RotationTransformer(from_rep="axis_angle", to_rep="rotation_6d")

    else:
        rotation_transformer = None

    def mat_to_rot6d(mat: npt.NDArray) -> npt.NDArray:
        batch_dim = mat.shape[:-2]
        out = mat[..., :2, :].copy().reshape(batch_dim + (6,))
        return out

    def mat_to_pose10d(mat: npt.NDArray) -> npt.NDArray:
        pos = mat[..., :3, 3]
        rotmat = mat[..., :3, :3]
        d6 = mat_to_rot6d(rotmat)
        d10 = np.concatenate([pos, d6], axis=-1)
        return d10

    if config.get("disable_action_conversion", False):
        processed_action_batch = action_batch

    elif action_dim == 17:
        # 16D pose (full transformation matrix) + 1D gripper
        processed_action_batch = np.concatenate(
            [mat_to_pose10d(action_batch[:, :, :16].reshape(batch_size, action_len, 4, 4)), action_batch[:, :, 16:17]],
            axis=-1,
        )

    elif action_dim == 7 and config.action_convert_7d_to_10d:
        # 6D pose (xyz_rpy) + 1D gripper → convert to 10D
        # TODO: need to verify
        pos = action_batch[:, :, :3]
        rot = action_batch[:, :, 3:6]
        gripper = action_batch[:, :, 6:]

        if rotation_transformer is None:
            rotation_transformer = RotationTransformer(from_rep="axis_angle", to_rep="rotation_6d")
        # Reshape for batch processing
        original_shape = rot.shape
        rot_flat = rot.reshape(-1, rot.shape[-1])
        rot_transformed = rotation_transformer.forward(rot_flat)
        rot = rot_transformed.reshape(original_shape[0], original_shape[1], -1)

        processed_action_batch = np.concatenate([pos, rot, gripper], axis=-1).astype(np.float32)

        out_dim = processed_action_batch.shape[-1]
        assert out_dim == 10, f"Expected action shape to be 10d after rotation transformer, got {out_dim}"

    elif action_dim == 33:
        # 16D pose for end-effector + 16D pose for torso + 1D gripper
        eef_matrices = action_batch[:, :, :16].reshape(batch_size, -1, 4, 4)
        torso_matrices = action_batch[:, :, 16:32].reshape(batch_size, -1, 4, 4)
        gripper = action_batch[:, :, 32:33]

        processed_action_batch = np.concatenate(
            [
                mat_to_pose10d(eef_matrices),
                mat_to_pose10d(torso_matrices),
                gripper,
            ],
            axis=-1,
        )

    else:
        processed_action_batch = action_batch

    return processed_action_batch


def preprocess_data(batch: Dict[str, np.ndarray], config: DictConfig) -> Dict[str, np.ndarray]:
    """Preprocess data including action, and observation color

    Args:
        batch (Dict[str, np.ndarray]): data batch
        config (DictConfig): data config

    Returns:
        Dict[str, np.ndarray]: preprocessed batch with action and color
    """
    new_batch = {}
    new_batch["action"] = preprocess_action_batch(batch["action"], config)
    new_batch["color"] = preprocess_color_batch(batch["color"], config)
    for k in batch:
        if k not in ("action", "color"):
            new_batch[k] = batch[k]
    return new_batch


def _aggregate_function_get_statistics(
    a: Optional[Dict[str, Any]], row: Dict[str, Any], norm_keys: List[str]
) -> Dict[str, Any]:
    """Aggregation function to accumulate statistics, such as sum, count, and min/max values for normalization.

    Args:
        a (Optional[Dict[str, Any]]): The accumulator dictionary containing running statistics
        row (Dict[str, Any]): Single data sample from the Ray dataset
        norm_keys (List[str]): normalizer keys

    Returns:
        Dict[str, Any]: aggregator
    """

    # Initialize accumulator if None
    if a is None:
        a = {
            "data_stats": {key: {"sum": None, "sum_sq": None, "count": 0} for key in norm_keys},
            "min_vals": {key: None for key in norm_keys},
            "max_vals": {key: None for key in norm_keys},
        }
    for key in norm_keys:
        if key not in row:
            continue
        data = row[key]
        if len(data.shape) > 2:
            data = data.reshape(-1, data.shape[-1])

        # Update count
        a["data_stats"][key]["count"] += data.shape[0]

        # Update sum and sum_sq
        if a["data_stats"][key]["sum"] is None:
            a["data_stats"][key]["sum"] = data.sum(axis=0)
            a["data_stats"][key]["sum_sq"] = (data**2).sum(axis=0)
        else:
            a["data_stats"][key]["sum"] += data.sum(axis=0)
            a["data_stats"][key]["sum_sq"] += (data**2).sum(axis=0)

        # Update min/max
        batch_min = data.min(axis=0)
        batch_max = data.max(axis=0)

        if a["min_vals"][key] is None:
            a["min_vals"][key] = batch_min
            a["max_vals"][key] = batch_max
        else:
            a["min_vals"][key] = np.minimum(a["min_vals"][key], batch_min)
            a["max_vals"][key] = np.maximum(a["max_vals"][key], batch_max)

    return a


def _merge_function(a1: Optional[Dict[str, Any]], a2: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Merge the accumulator from different workers"""
    if a1 is None:
        return a2
    if a2 is None:
        return a1

    merged: Dict[str, Any] = {"data_stats": {}, "min_vals": {}, "max_vals": {}}

    for key in a1["data_stats"].keys():
        merged["data_stats"][key] = {
            "sum": a1["data_stats"][key]["sum"] + a2["data_stats"][key]["sum"],
            "sum_sq": a1["data_stats"][key]["sum_sq"] + a2["data_stats"][key]["sum_sq"],
            "count": a1["data_stats"][key]["count"] + a2["data_stats"][key]["count"],
        }
        merged["min_vals"][key] = np.minimum(a1["min_vals"][key], a2["min_vals"][key])
        merged["max_vals"][key] = np.maximum(a1["max_vals"][key], a2["max_vals"][key])

    return merged


def convert_to_tensors(
    data_stats: Dict[str, Any], min_vals: Dict[str, Any], max_vals: Dict[str, Any]
) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    """Convert numpy arrays/lists to torch tensors for compatibility"""
    converted_data_stats = {}
    converted_min_vals = {}
    converted_max_vals = {}

    for key in data_stats:
        converted_data_stats[key] = {
            "sum": (
                torch.from_numpy(np.array(data_stats[key]["sum"]))
                if not isinstance(data_stats[key]["sum"], torch.Tensor)
                else data_stats[key]["sum"]
            ),
            "sum_sq": (
                torch.from_numpy(np.array(data_stats[key]["sum_sq"]))
                if not isinstance(data_stats[key]["sum_sq"], torch.Tensor)
                else data_stats[key]["sum_sq"]
            ),
            "count": data_stats[key]["count"],
        }

        converted_min_vals[key] = (
            torch.from_numpy(np.array(min_vals[key])) if not isinstance(min_vals[key], torch.Tensor) else min_vals[key]
        )
        converted_max_vals[key] = (
            torch.from_numpy(np.array(max_vals[key])) if not isinstance(max_vals[key], torch.Tensor) else max_vals[key]
        )

    return converted_data_stats, converted_min_vals, converted_max_vals


def compute_and_save_normalizer(dataset: ray.data.Dataset, config: DictConfig) -> str:
    """Compute normalizer using raydataset GroupedData stats

    Args:
        dataset (ray.data.Dataset): ray dataset
        data_statistics (dict): data statistics that calculated from aggregation
        config (DictConfig): data config

    Returns:
        str: normalizer saved path
    """
    ray_version_check()
    # below function are only in newer version Ray
    from ray.data.aggregate import AggregateFn

    norm_start_time = time.perf_counter()
    aggregation = AggregateFn(
        init=lambda column: None,
        # Apply this to each row to produce a partial aggregate result
        accumulate_row=lambda a, row: _aggregate_function_get_statistics(a, row, config.norm_keys),
        merge=lambda a1, a2: _merge_function(a1, a2),
        name="normalizer",
    )
    data_statistics = dataset.aggregate(aggregation)

    if config.norm_keys is not None:
        keys_str = "_".join(config.norm_keys)
    else:
        keys_str = "all_keys"

    local_data_source = DataSource(config.local_data_source_str)
    normalizer_path = get_ray_worker_data_path(local_data_source) / config.data_path[0] / f"normalizer_{keys_str}.pt"

    # NOTE: Ray data use aggregate function to get statistics of union data, so we calculate forcefully
    data_final = {}  # Dict[str, Dict[str, torch.Tensor]]
    # Get statistics using functions in raydatatset
    data_stats, min_vals, max_vals = convert_to_tensors(
        data_statistics["normalizer"]["data_stats"],
        data_statistics["normalizer"]["min_vals"],
        data_statistics["normalizer"]["max_vals"],
    )

    data_final = compute_final_statistics(data_stats, min_vals, max_vals)

    for key in data_final:
        for stat_key in data_final[key]:
            if not isinstance(data_final[key][stat_key], torch.Tensor):
                data_final[key][stat_key] = torch.tensor(data_final[key][stat_key])

    normalizer_cls = NORMALIZERS[config.normalizer_name] if config.get("normalizer_name") else LinearNormalizer
    normalizer = normalizer_cls()
    normalizer.fit(
        data=data_final,
        dtype=torch.float32,
        mode=config.norm_mode,
        normalize_action_pos_only=config.get("normalize_action_pos_only", False),
        normalize_action_gripper_only=config.get("normalize_action_gripper_only", False),
    )
    # save for future use
    normalizer.save(str(normalizer_path))
    print(f"it takes {time.perf_counter()-norm_start_time} to get normalizer")
    return str(normalizer_path)


# add decorator to let the function run on worker node if head node does not have access like our current situation
@ray.remote(resources={"train": 0.001})
def create_dataset(config: DictConfig, train_seed: int = 42) -> Tuple[ray.data.Dataset, Optional[str], int]:
    """Main function to create ray dataset

    Args:
        config (DictConfig): data config
        train_seed (int): seed we used for shuffle

    Returns:
        Tuple[ray.data.Dataset, Optional[str]]: Ray dataset used for training, and normalizer_path
    """
    ray_version_check()
    # function only exists in newer version Ray
    from ray.data import FileShuffleConfig

    shuffle = FileShuffleConfig(seed=train_seed)
    if config.get("preserve_order", False):
        # NOTE: seed can not promise a deterministic row order since tasks are executed in parallel
        # and their completion order might vary, so we need to set preserve_order
        ray.data.DataContext.get_current().execution_options.preserve_order = True
    datasets_list = []
    total_count = 0
    for task_index, path in enumerate(list(config.data_path)):
        data_config = OmegaConf.create(config)
        data_config.data_path = path
        data_config.task_index = task_index
        local_data_source = DataSource(data_config.local_data_source_str)
        data_local_path = str(get_ray_worker_data_path(local_data_source) / path)
        data_local_file_ls = glob.glob(os.path.join(data_local_path, "*/*.h5"))
        print(f"{data_local_path=}, and total file number = {len(data_local_file_ls)}")

        ray_ds = ray.data.read_binary_files(data_local_file_ls, include_paths=True, shuffle=shuffle)
        decoded_ds = ray_ds.flat_map(decode, fn_kwargs={"config": data_config, "base_seed": train_seed})
        preprocessed_ds = decoded_ds.map_batches(preprocess_data, fn_args=[data_config])

        # this takes time, can escape if we have a customized Datasource
        data_count = preprocessed_ds.take(1)[0]["data_count"]
        total_count += data_count
        datasets_list.append(preprocessed_ds)
    concatenated_dataset: ray.data.Dataset = (
        datasets_list[0].union(*datasets_list[1:]) if len(datasets_list) > 1 else datasets_list[0]
    )

    print("Full dataset length", total_count)

    normalizer_path = None
    if config.normalize:
        normalizer_path = compute_and_save_normalizer(concatenated_dataset, config)

    return concatenated_dataset, normalizer_path, total_count
