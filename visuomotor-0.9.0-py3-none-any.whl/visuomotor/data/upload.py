#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import os
from typing import Dict

from visuomotor.utils import paths


def parse_dataset_name(dataset_name: str) -> Dict:
    """Parsing metadata from dataset naming convention: <task_name>_<real/sim>_<robot_id>_mmddyyyy"""

    parsed_name = dataset_name.split("_")

    if len(parsed_name) != 4:
        raise ValueError("Dataset name should be in format <task_name>_<real/sim>_<robot_id>_mmddyyyy")

    metadata = {
        "project": "vpl",
        "task_name": parsed_name[0],
        "collection_method": parsed_name[1],
        "robot_id": None if parsed_name[2] == "None" else parsed_name[2],
        "collected_date": parsed_name[3],
    }
    return metadata


def upload_processed_dataset(args: argparse.Namespace) -> None:
    """bdai upload the processed dataset.

    One version will be in `gs://project-dmm-main-storage`, the other will be in the data platform.
    NOTE: If you use a `gcs_data_path` that exists bdai upload will throw an error.

    TODO: Data team is planning on moving the upload function out of bdai_cli, which we can use here
    when that is complete. For now, using gsutil to upload.
    """
    config = paths.get_config(args.config).data
    processed_data_path = paths.get_datasets_path() / config.data_path

    if args.gcs_data_path is None:
        gcs_data_path = os.path.join("gs://bdai-common-storage/visuomotor/preprocessed/", args.data_path)
    else:
        gcs_data_path = args.gcs_data_path

    # NOTE: not used for now, but will be used when we use common `upload` function in the future
    # metadata = parse_dataset_name(config.data_path)

    # # bdai upload requires extra json in a file, writing to tmp file
    # extra_json_file = tempfile.NamedTemporaryFile(mode="w+")
    # json.dump(metadata, extra_json_file)
    # extra_json_file.flush()

    copy_command = f"gsutil -m cp -r {processed_data_path} {gcs_data_path}"
    os.system(copy_command)


def main() -> None:
    parser = argparse.ArgumentParser(description="bdai upload datasets")
    parser.add_argument("--config", type=str, default="train", help="config file to use")
    parser.add_argument(
        "--gcs-data-path",
        type=str,
        default=None,
        help="Path to the GCS location to upload. If not specified, will automatically upload to gs://project-dmm-main-storage/visuomotor/preprocessed",
    )
    upload_processed_dataset(parser.parse_args())


if __name__ == "__main__":
    main()
