#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse

import h5py

from visuomotor.data.utils import get_task_metadata, load_intrinsics
from visuomotor.perception.depth_utils import rgbd_to_point_cloud_multi
from visuomotor.ray_train.ray_tqdm_utils import tqdm_ray_newline
from visuomotor.utils import paths
from visuomotor.utils.paths import DataSource


def main(args: argparse.Namespace) -> None:
    config = paths.get_config(args.config, config_folder="data")
    data_path = config.data_path[0]
    metadata = get_task_metadata(data_path, DataSource(config.local_data_source_str))
    num_episodes = metadata["num_episodes"]
    print(f"pre-processing {num_episodes} episodes of data")

    if (
        "crop_area" in config
        and config.crop_area is not None
        and len(config.crop_area.min) == 3
        and len(config.crop_area.max) == 3
    ):
        crop_area = [
            config.crop_area.min,
            config.crop_area.max,
        ]
    else:
        crop_area = None

    depth_scale = 1000  # default for point clouds in mm
    if "depth_scale" in config:
        depth_scale = config.depth_scale

    intrinsics = load_intrinsics(data_path)
    for episode in tqdm_ray_newline(range(num_episodes), desc="episodes"):
        num_timesteps = metadata["num_timesteps"][episode]
        episode_path = paths.get_datasets_path() / data_path / f"episode_{episode}" / f"episode_{episode}.h5"
        with h5py.File(episode_path, "r+") as episode_data:
            episode_data.create_group("point_cloud5")

            for timestep in range(num_timesteps):
                point_cloud = rgbd_to_point_cloud_multi(
                    depth_scale=depth_scale,
                    intrinsics=intrinsics,
                    color=episode_data["color"][timestep],
                    depth=episode_data["depth"][timestep],
                    extrinsics=episode_data["extrinsics"][timestep],
                    crop_area=crop_area,
                    camera_ids=config.camera_ids,
                )
                episode_data["point_cloud"][f"{timestep}"] = point_cloud


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract point cloud data")
    parser.add_argument("--config", type=str, default="ambulance_3d", help="config file to use")
    cli_args = parser.parse_args()
    main(cli_args)
