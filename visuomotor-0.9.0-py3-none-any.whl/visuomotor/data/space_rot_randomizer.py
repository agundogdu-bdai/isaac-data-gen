# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
# Largely inspired from https://github.com/bdaiinstitute/equidiffv2

import functools
import logging
from typing import Any, Callable, Optional

import numpy as np
import torch
import torch.nn as nn
from einops import rearrange

ANGLE_TRESHOLD = 1 / 64


def unmerge_timesteps_and_merge_back(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapper(cls: nn.Module, batch: dict[str, torch.Tensor], *args: Any, **kwargs: Any) -> dict[str, torch.Tensor]:

        timestep_keys = [cls.pc_obs_name, cls.eef_pos_obs_name, cls.eef_quat_obs_name]
        for key in timestep_keys:
            batch[key] = rearrange(batch[key], "(b t) ... -> b t ...", t=cls.key_to_n_obs_history[key])

        batch = func(cls, batch, *args, **kwargs)

        for key in timestep_keys:
            batch[key] = rearrange(batch[key], "b t ... -> (b t) ...", t=cls.key_to_n_obs_history[key])

        return batch

    return wrapper


class SpaceRotRandomizer(nn.Module):
    """
    During training, runs a data augmentation that randomly rotates the following items:
    - point_cloud
    - eef_pos
    - eef_quat
    - action
    (Images are not rotated)
    If the rotated observations are still within normalized bounds they are successfully returned
    otherwise we try again `n_rotations` times. If the `n_rotations` are unsuccessful we return
    the input observations unchanged
    """

    def __init__(
        self,
        pc_obs_name: str = "point_cloud",
        eef_pos_obs_name: str = "robot0_eef_pos",
        eef_quat_obs_name: str = "robot0_eef_quat",
        action_name: str = "action",
        n_rotations: int = 1000,
        key_to_n_obs_history: Optional[dict[str, int]] = None,
    ) -> None:
        """
        Args:
            pc_obs_name: The name of the point cloud observation.
            eef_pos_obs_name: The name of the end effector position observation.
            eef_quat_obs_name: The name of the end effector quaternion orientation observation.
            action_name: The name of the action.
            n_rotations: The number of rotation tries to run
            key_to_n_obs_history: The number of timesteps used per observation key
        """
        super().__init__()
        self.pc_obs_name = pc_obs_name
        self.eef_pos_obs_name = eef_pos_obs_name
        self.eef_quat_obs_name = eef_quat_obs_name
        self.action_name = action_name
        self.n_rotations = n_rotations
        from visuomotor.data.rotation_transformer import RotationTransformer

        self.tf = RotationTransformer("quaternion", "matrix")
        if key_to_n_obs_history is None:
            key_to_n_obs_history = {
                self.eef_pos_obs_name: 1,
                self.eef_quat_obs_name: 1,
                self.pc_obs_name: 1,
            }
        self.key_to_n_obs_history = key_to_n_obs_history

    @unmerge_timesteps_and_merge_back
    def forward(
        self,
        batch: dict[str, torch.Tensor],
    ) -> dict[str, torch.Tensor]:
        """
        Randomly rotates the inputs if in training mode.
        Keeps inputs unchanged if in evaluation mode.

        This expects observations to be normalized within [-1, 1]
        Expected shape for each observation is:
        - pc_obs_name: [B, T, H, C]
        - eef_pos_obs_name: [B, T, C]
        - eef_quat_obs_name: [B, T, C]
        - action_name: [B, H, C]
        """

        # TODO: Change this currently random try of n rotation which doesn't fail if
        # they fall outside of normalized treshold
        # TODO: Update logic to parallelize the matrices generation and usage.
        # TODO: Remove nn.Module if unecessary

        for obs_name in [self.action_name, self.pc_obs_name, self.eef_pos_obs_name, self.eef_quat_obs_name]:
            assert -1 <= batch[obs_name].all() <= 1

        if not self.training:
            return batch

        pc = batch[self.pc_obs_name]
        pos = batch[self.eef_pos_obs_name]
        action = batch[self.action_name]
        # x, y, z, w -> w, x, y, z
        quat = batch[self.eef_quat_obs_name][:, :, [3, 0, 1, 2]]
        eef_pose_matrix = self.tf.forward(quat)
        batch_size = pc.shape[0]
        T = pc.shape[1]
        device = pc.device

        assert pc.dim() == 4
        assert pos.dim() == 3
        assert quat.dim() == 3
        assert action.dim() == 3

        success_mask = torch.zeros(batch_size, dtype=torch.bool, device=device)
        final_rotated_pos = torch.zeros(pos.shape, device=device)
        final_rotated_quat = torch.zeros(quat.shape, device=device)
        final_rotated_action = torch.zeros(action.shape, device=device)
        final_rotation_matrix = torch.zeros((batch_size, 3, 3), device=device)

        for rotation_attempt_i in range(self.n_rotations):

            indices_to_try = (~success_mask).nonzero(as_tuple=True)[0]
            if len(indices_to_try) == 0:
                print(f"Took {rotation_attempt_i}/{self.n_rotations} iterations to successfully rotate")
                break

            action_subset = action[indices_to_try]
            pos_subset = pos[indices_to_try]
            eef_pose_matrix_subset = eef_pose_matrix[indices_to_try]

            rotated_pos, rotated_quat, rotated_action, rotation_matrix = self.rotate_space(
                action=action_subset,
                pos=pos_subset,
                eef_pose_matrix=eef_pose_matrix_subset,
                device=device,
            )
            valid_angles = self.get_valid_angles(rotated_pos, rotated_action)
            successful_indices = indices_to_try[valid_angles]

            success_mask[successful_indices] = True
            final_rotated_pos[successful_indices] = rotated_pos[valid_angles]
            final_rotated_quat[successful_indices] = rotated_quat[valid_angles]
            final_rotated_action[successful_indices] = rotated_action[valid_angles]
            final_rotation_matrix[successful_indices] = rotation_matrix[valid_angles]

        rotated_pos = final_rotated_pos
        rotated_quat = final_rotated_quat
        rotated_action = final_rotated_action
        rotation_matrix = final_rotation_matrix

        is_successful_rotation = (
            rotated_pos.min() >= -1
            and rotated_pos.max() <= 1
            and rotated_action[:, :, :2].min() >= -1
            and rotated_action[:, :, :2].max() <= 1
        )
        if not is_successful_rotation:
            logging.warning("The SpaceRotRandomizer failed so returned the observations unrotated.")
            return batch

        pc = rearrange(pc, "b t n d -> b (t n) d")
        if pc.shape[2] == 3:
            rotated_pc = self.apply_rotation_to_matrix(rotation_matrix, pc)
        else:
            xyz = pc[:, :, :3]
            rgb = pc[:, :, 3:]
            rotated_xyz = self.apply_rotation_to_matrix(rotation_matrix, xyz)
            rotated_pc = torch.cat([rotated_xyz, rgb], dim=2)
        rotated_pc = rearrange(rotated_pc, "b (t n) d -> b t n d", t=T)

        batch[self.pc_obs_name] = rotated_pc
        batch[self.eef_pos_obs_name] = rotated_pos
        batch[self.eef_quat_obs_name] = rotated_quat[:, :, [1, 2, 3, 0]]
        batch[self.action_name] = rotated_action

        return batch

    def rotate_space(
        self,
        action: torch.Tensor,
        pos: torch.Tensor,
        eef_pose_matrix: torch.Tensor,
        device: str,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:

        from visuomotor.data.rotation_transformer import RotationTransformer

        # Make sure self.tf is initialized if not already
        if not hasattr(self, "tf"):
            self.tf = RotationTransformer("quaternion", "matrix")

        n_rotation = action.shape[0]
        rotation_matrix = self.create_rotation_matrix(n_rotation=n_rotation, device=device)
        rotated_action = self.rotate_action(action, rotation_matrix)

        rotated_pos = self.apply_rotation_to_matrix(rotation_matrix, pos)
        rotated_rot = rotation_matrix.unsqueeze(1) @ eef_pose_matrix
        rotated_quat = self.tf.inverse(rotated_rot)

        return rotated_pos, rotated_quat, rotated_action, rotation_matrix

    def get_valid_angles(self, rotated_pos: torch.Tensor, rotated_action: torch.Tensor) -> torch.Tensor:
        """If any position in either `pos` or `action` is out of [-1, 1] bound, we call the entire
        datapoint as failed and will retry another rotation"""

        rotated_action_xy = rotated_action[:, :, :2]

        invalid_pos = ((rotated_pos < -1) | (rotated_pos > 1)).any(dim=(1, 2))
        invalid_actions = ((rotated_action_xy < -1) | (rotated_action_xy > 1)).any(dim=(1, 2))
        invalid_angles = invalid_pos | invalid_actions

        valid_angles = ~invalid_angles

        return valid_angles

    def create_rotation_matrix(self, n_rotation: int, device: str) -> torch.Tensor:

        angles = torch.rand(n_rotation) * 2 * np.pi - np.pi
        rotation_matrix = torch.zeros((n_rotation, 3, 3), device=device)
        rotation_matrix[:, 2, 2] = 1

        angles[torch.rand(n_rotation) < ANGLE_TRESHOLD] = 0
        cos_angles = torch.cos(angles)
        sin_angles = torch.sin(angles)
        rotation_matrix[:, 0, 0] = cos_angles
        rotation_matrix[:, 0, 1] = -sin_angles
        rotation_matrix[:, 1, 0] = sin_angles
        rotation_matrix[:, 1, 1] = cos_angles

        return rotation_matrix

    def rotate_action(self, action: torch.Tensor, rotation_matrix: torch.Tensor) -> torch.Tensor:

        assert action.shape[2] == 10, (
            f"The dimension of action should be 10 if you "
            f"want to use the SpaceRotRandomizer and you have {action.shape[2]}"
        )

        rotated_action = action.clone()
        rotated_action[:, :, 0:3] = self.apply_rotation_to_matrix(rotation_matrix, action[:, :, 0:3])
        rotated_action[:, :, [3, 6]] = self.apply_rotation_to_matrix(rotation_matrix[:, :2, :2], action[:, :, [3, 6]])
        rotated_action[:, :, [4, 7]] = self.apply_rotation_to_matrix(rotation_matrix[:, :2, :2], action[:, :, [4, 7]])
        rotated_action[:, :, [5, 8]] = self.apply_rotation_to_matrix(rotation_matrix[:, :2, :2], action[:, :, [5, 8]])

        return rotated_action

    def apply_rotation_to_matrix(self, rotation: torch.Tensor, matrix: torch.Tensor) -> torch.Tensor:
        return (rotation @ matrix.permute(0, 2, 1)).permute(0, 2, 1)
