#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import io
import json
import os
from typing import Iterable, Optional

import h5py
import numpy as np
import numpy.typing as npt
from PIL import Image

from visuomotor.utils.paths import DATASET_METADATA_FILENAME, DataSource, get_datasets_path, get_ray_worker_data_path

DATA_KEYS = ["color", "depth", "extrinsics", "gripper_width", "eef_pose"]


def load_intrinsics(task: str) -> dict[str, npt.NDArray]:
    intrinsics_path = os.path.join(get_datasets_path(), task, "intrinsics.h5")
    with open(intrinsics_path, "rb") as f:
        intrinsics_file = h5py.File(f, "r")
        intrinsics = intrinsics_file["intrinsics"][:]
    return intrinsics


def get_episode_h5_path(task: str, episode: int) -> str:
    return os.path.join(get_datasets_path(), task, f"episode_{episode}", f"episode_{episode}.h5")


def h5_to_dict(
    h5_path: str,
    data_keys: list = DATA_KEYS,
) -> dict[str, npt.NDArray]:
    data = {}
    with open(h5_path, "rb") as f:
        data_file = h5py.File(f, "r")
        for key in data_keys:
            if key not in data_file.keys():
                raise KeyError(f"Key {key} not found in {h5_path}")
            else:
                # Check if the item is a dataset or a group
                if isinstance(data_file[key], h5py.Dataset):
                    data[key] = data_file[key][:]
                else:
                    # For groups, create a nested dictionary
                    group_data = {}
                    for subkey in data_file[key].keys():
                        if isinstance(data_file[key][subkey], h5py.Dataset):
                            group_data[subkey] = data_file[key][subkey][:]
                    data[key] = group_data

    return data


def get_task_metadata(
    task: str,
    local_data_source: DataSource,
    ray_worker: bool = False,
    max_episodes: int = -1,
    last_n_steps_to_remove: Optional[int] = None,
) -> dict:
    if ray_worker:
        task_path = os.path.join(get_ray_worker_data_path(local_data_source), task)
    else:
        task_path = os.path.join(get_datasets_path(), task)

    # check if metadata exists
    metadata_path = os.path.join(task_path, "metadata.json")
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"Metadata file not found here: {metadata_path}")

    with open(metadata_path) as f:
        metadata_dict = json.load(f)

    available_episodes = len(metadata_dict["num_timesteps"])
    # If max_episodes is -1 (use all) or larger than available, cap to available
    if max_episodes == -1 or max_episodes > available_episodes:
        num_episodes = available_episodes
    else:
        num_episodes = max_episodes
    num_timesteps = np.array(metadata_dict["num_timesteps"][:num_episodes])

    if last_n_steps_to_remove is not None:
        num_timesteps -= last_n_steps_to_remove

    episode_timestep_idx = []
    episode_timestep_total = {}
    for i in range(num_episodes):
        episode_timestep_total[f"episode_{i}"] = num_timesteps[i]
        for j in range(num_timesteps[i]):
            episode_timestep_idx.append((i, j))

    metadata = {
        "num_episodes": num_episodes,
        "episode_timestep_idx": episode_timestep_idx,
        "num_timesteps": num_timesteps.tolist(),  # Expose per-episode lengths so datasets can build padding masks.
        "episode_timestep_total": episode_timestep_total,
    }

    if "task_description" in metadata_dict:
        metadata["task_description"] = metadata_dict["task_description"]

    return metadata


def create_key_to_history_mapping(
    obs_visual: Iterable[str], obs_state: Iterable[str], n_obs_history_visual: int, n_obs_history_state: int
) -> dict[str, int]:
    """Make dictionary mapping observation key to history length."""
    key_to_n_obs_history = dict()
    for k in obs_visual:
        key_to_n_obs_history[k] = n_obs_history_visual
    for k in obs_state:
        key_to_n_obs_history[k] = n_obs_history_state
    return key_to_n_obs_history


def decode_image(png_bytes: np.uint8) -> np.ndarray:
    """Decode image bytes (could be JPG or PNG) into a numpy array image."""
    stream = io.BytesIO(png_bytes.tobytes())
    img = Image.open(stream)
    # Ensure that image data is fully loaded.
    img.load()
    return np.array(img)


def check_if_compressed(image: np.uint8) -> bool:
    """Ceck if image is compressed."""
    return len(image.shape) == 1


def process_color_observations(obs_data: np.ndarray, camera_ids: list[int]) -> np.ndarray:
    """
    Standardized function to process color observations, handling both compressed and uncompressed images.

    Args:
        obs_data: Raw observation data from h5 file, shape (n_history, n_cameras, ...)
        camera_ids: List of camera indices to process

    Returns:
        Processed images array with shape (n_history, n_cameras, h, w, c)
    """
    if check_if_compressed(obs_data[0, 0]):
        # Handle compressed images - decode them properly
        images = []
        for i in range(len(obs_data)):
            camera_images = []
            for j in camera_ids:
                decoded_img = decode_image(obs_data[i][j])
                camera_images.append(decoded_img)
            images.append(camera_images)
        return np.array(images)
    else:
        # Handle uncompressed images - just select camera views
        return obs_data[:, camera_ids]


def get_dataset_metadata(data_path: str, local_data_source: DataSource) -> dict:
    """Retrieve dataset metadata. Metadata is expected to be in a JSON file located at the
    root of the local dataset folder.

    Args:
        data_path: Data path string from data config, either a GCS path or Data Platform UUID.
        local_data_source: Local data storage source of type `DataSource`.
    Returns:
        Dictionary of dataset metadata.
    """
    data_source = DataSource.from_string(data_path) if DataSource.DATA_PLATFORM else DataSource.GCS
    local_data_path = get_ray_worker_data_path(local_data_source=local_data_source)
    metadata_path = local_data_path / data_path / DATASET_METADATA_FILENAME

    try:
        with open(metadata_path) as f:
            metadata = json.load(f)
    except FileNotFoundError as e:
        print(f"FileNotFoundError: {e}. Skipping dataset metadata loading.")
        metadata = {}

    # Set additional metadata fields
    metadata["data_path"] = data_path
    metadata["data_source"] = data_source.value

    return metadata


if __name__ == "__main__":
    test_data = "bikeseat_extract_real_harriet_21082024_episode"
    local_data_source = DataSource.POD
    metadata = get_task_metadata(test_data, local_data_source)
    print(metadata)
