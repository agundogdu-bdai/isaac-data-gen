#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import h5py
import numpy as np
import psutil
import torch
from einops import rearrange
from hydra import compose, initialize
from omegaconf import DictConfig, ListConfig
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset

from visuomotor.data.transforms import (
    get_color_transforms,
    subtract_eef_pos_from_actions,
    subtract_eef_pos_from_pointcloud_obs,
)
from visuomotor.data.utils import create_key_to_history_mapping, get_task_metadata, process_color_observations
from visuomotor.logging.profiler import DATASET_CATEGORY, profile_function
from visuomotor.perception.depth_utils import extract_plane, sample_point_cloud
from visuomotor.ray_train.ray_tqdm_utils import tqdm_ray_newline
from visuomotor.utils.normalizer import EquidiffLinearNormalizer, LinearNormalizer
from visuomotor.utils.paths import DataSource, get_datasets_path, get_ray_worker_data_path
from visuomotor.utils.pose_utils import mat_to_pose10d

NORMALIZERS = {"equidiff_linear_normalizer": EquidiffLinearNormalizer}


class VisuomotorDataset(Dataset):
    """Dataset class for visuomotor data.

    Load the action and observation data from a pre-processed h5 file.
    A subset of observations can be loaded by specifying their keys in the config.
    """

    def __init__(self, config: DictConfig, ray_worker: bool = False) -> None:
        self.config = config
        self.ray_worker = ray_worker
        if type(self.config.data_path) in (ListConfig, List):
            print("WARN: Multiple data paths are not supported. Using only first one")
            self.config.data_path = self.config.data_path[0]
        self.local_data_source = DataSource(self.config.get("local_data_source_str", "pod"))
        self.data_path = self._initialize_data_paths()

        self.obs_visual = self.config.obs_keys.get("visual", list())
        self.obs_state = self.config.obs_keys.get("state", dict())
        self.obs_keys = [*self.obs_visual, *self.obs_state.keys()]
        self.data_path_basename = os.path.basename(self.data_path)

        if self.config.get("normalizer_name"):
            self.normalizer_cls = NORMALIZERS[self.config.normalizer_name]
        else:
            self.normalizer_cls = LinearNormalizer

        if "color" in self.obs_keys:
            self.color_transforms = get_color_transforms(config, inference=False)

        # The number of future actions to return. horizon=1 is the standard behavior.
        self.horizon = self.config.horizon
        assert self.horizon >= 1, f"Action horizon ({self.horizon}) must be at least 1."

        self.pad_action_mode: str | None = getattr(self.config, "pad_action", None)
        if self.pad_action_mode not in (None, "constant", "edge"):
            raise ValueError(
                "Valid modes for padding the action are 'constant' (pad with zeros) and "
                "'edge' (pad with the last action)."
            )

        # If no padding, remove timesteps at the end of the trajectory that don't
        # have at least horizon actions afterwards
        last_n_steps_to_remove = self.horizon - 1 if self.pad_action_mode is None else None

        self.metadata = get_task_metadata(
            self.data_path,
            self.local_data_source,
            max_episodes=config.max_episodes,
            last_n_steps_to_remove=last_n_steps_to_remove,
        )

        self.episode_timestep_idx = self.metadata["episode_timestep_idx"]
        # Pre-compute per-episode lengths (last index + 1) for alignment logic
        self._episode_lengths: dict[int, int] = {}
        for ep_idx, t_idx in self.episode_timestep_idx:
            # Store episode length directly as (max timestep index + 1)
            new_len = int(t_idx) + 1
            current_len = self._episode_lengths.get(ep_idx, 0)
            if new_len > current_len:
                self._episode_lengths[ep_idx] = new_len
        self.task_index = self.config.task_index

        # Configure history length
        self.n_obs_history_visual = config.get("n_obs_history_visual")
        self.n_obs_history_state = config.get("n_obs_history_state")
        self.key_to_n_obs_history = create_key_to_history_mapping(
            obs_visual=self.obs_visual,
            obs_state=self.obs_state.keys(),
            n_obs_history_visual=self.n_obs_history_visual,
            n_obs_history_state=self.n_obs_history_state,
        )
        if self.config.get("action_convert_7d_to_10d"):
            from visuomotor.data.rotation_transformer import RotationTransformer

            self.rotation_transformer = RotationTransformer(from_rep="axis_angle", to_rep="rotation_6d")

    def _initialize_data_paths(self) -> str:
        """Initialize and possibly copy data paths for the dataset."""
        return str(
            get_ray_worker_data_path(self.local_data_source) / self.config.data_path
            if self.ray_worker
            else get_datasets_path() / self.config.data_path
        )

    def __len__(self) -> int:
        return len(self.episode_timestep_idx)

    @profile_function("__getitem__", DATASET_CATEGORY)
    def __getitem__(self, idx: int) -> dict[str, np.ndarray | torch.Tensor]:
        episode_idx, timestep_idx = self.episode_timestep_idx[idx]

        data_dict: dict[str, np.ndarray | torch.Tensor] = {}

        # Load multi-modal data
        file_path = Path(self.data_path) / f"episode_{episode_idx}" / f"episode_{episode_idx}.h5"
        raw_action, raw_obs_data = self.get_raw_data_from_h5(str(file_path), timestep_idx)

        if "task_description" in raw_obs_data:
            data_dict["task_description"] = raw_obs_data["task_description"]
        elif "task_description" in self.metadata:
            data_dict["task_description"] = self.metadata["task_description"]

        self.process_observation_data(data_dict, raw_obs_data)
        self.process_action_data(data_dict, raw_action, episode_idx, timestep_idx)

        # Apply transformations to the data
        # self._apply_transformations(data_dict, action_data)
        data_dict["task_index"] = self.task_index

        return data_dict

    def preprocess_point_cloud(self, point_cloud: np.ndarray) -> np.ndarray:
        """
        Preprocesses the point cloud
        """
        if self.config.point_cloud_remove_plane:
            point_cloud = extract_plane(point_cloud).astype(np.float32)
        if self.config.point_cloud_sampling.method:
            point_cloud = sample_point_cloud(self.config, point_cloud)

        # If point cloud is empty after all processing, pad with zeros
        # Assumes self.config.point_cloud_sampling.num_points and .use_rgb are available
        if point_cloud.shape[0] == 0:
            if hasattr(self.config.point_cloud_sampling, "num_samples"):
                num_samples = self.config.point_cloud_sampling.num_samples
                num_features = 6 if self.config.point_cloud_sampling.use_rgb else 3
                point_cloud = np.zeros((num_samples, num_features), dtype=np.float32)
            else:
                raise ValueError(
                    "Point cloud is empty after all processing and num_samples\
                          is not set in config.point_cloud_sampling"
                )

        return point_cloud

    def extract_point_cloud(self, data: h5py.Group | h5py.Dataset, timestep_idx: int) -> np.ndarray:
        """
        Extracts the point clouds from the h5 file.  This has to be handled separately from the other obs
        because the point clouds have variable numbers of points.
        """
        indices = list(range(timestep_idx - self.n_obs_history_visual + 1, timestep_idx + 1))

        # Repeats the point cloud from timestep 0 multiple times if the horizon extends beyond the
        # start of the sequence
        indices = [max(0, i) for i in indices]

        def _get_point_cloud_item(data: h5py.Group | h5py.Dataset, idx: int) -> np.array:
            if isinstance(data, h5py.Group):
                return data[str(idx)][:]
            elif isinstance(data, h5py.Dataset):
                has_rgb = self.config.point_cloud_sampling.get("has_rgb", False)
                if has_rgb:
                    pcd = data[idx].reshape(-1, 6)
                    if self.config.point_cloud_sampling.use_rgb:
                        return pcd
                    else:
                        return pcd[:, :3]
                else:
                    return data[idx].reshape(-1, 3)
            else:  # h5py.Dataset
                raise TypeError("Unsupported data type; must be an h5py Group or Dataset.")

        point_clouds = [self.preprocess_point_cloud(_get_point_cloud_item(data, i)) for i in indices]

        point_clouds = np.stack(point_clouds).astype(np.float32)

        return point_clouds

    def _should_align_history_mask(self, episode_idx: int | None, timestep_idx: int | None) -> bool:
        """
        Decide whether to align the action padding mask with temporal history.

        In practice, this is triggered in LeRobot setups that both use observation
        history (> 1) and set shift_action_with_history: true (e.g., in
        train_lerobot_diffpo_aloha.yaml). The logic is intentionally kept generic so
        it remains applicable to any future models that leverage temporal history.
        """
        h = max(
            int(getattr(self, "n_obs_history_visual", 1) or 1),
            int(getattr(self, "n_obs_history_state", 1) or 1),
        )
        return bool(
            self.config.get("shift_action_with_history", False)
            and h > 1
            and episode_idx is not None
            and timestep_idx is not None
        )

    def _build_history_pad_mask(self, ep_len: int, timestep_idx: int) -> np.ndarray:
        """LeRobot temporal windowing uses deltas starting at -1 when n_obs_steps=2.
        Build mask over horizon with target_idx = timestep_idx - 1 + k.
        """
        deltas = np.arange(self.horizon, dtype=int)
        target_indices = int(timestep_idx) - 1 + deltas
        return (target_indices >= int(ep_len)).astype(bool)

    def _load_actions_from_field(self, h5_file: h5py.File, timestep_idx: int) -> np.ndarray:
        """
        Load actions from the specified field in the dataset.

        Args:
            h5_file: Open h5py.File object
            timestep_idx: Current timestep index

        Returns:
            Available actions from the specified field
        """
        # Determine which field to load actions from
        action_field = self.config.get("action_field", "action")

        # Find the action data source
        if action_field in h5_file:
            action_data = h5_file[action_field]
        else:
            raise ValueError(
                f"Cannot find action_field='{action_field}' in dataset. " f"Available fields: {list(h5_file.keys())}"
            )

        n_timesteps = action_data.shape[0]

        # Decide if we should shift actions by one when using observation history
        shift_with_history = bool(self.config.get("shift_action_with_history", False))
        history_visual = self.n_obs_history_visual if hasattr(self, "n_obs_history_visual") else 1
        history_state = self.n_obs_history_state if hasattr(self, "n_obs_history_state") else 1
        has_history = (history_visual or 1) > 1 or (history_state or 1) > 1

        # Load actions from the determined field
        if action_field == "action":
            if shift_with_history and has_history:
                # Use future timesteps as actions to align with HF diffusion windowing when history > 1
                start_idx = timestep_idx + 1
                end_idx = min(start_idx + self.horizon, n_timesteps)
                if start_idx < n_timesteps:
                    action = action_data[start_idx:end_idx].astype(np.float32)
                else:
                    action = np.empty((0, action_data.shape[1]), dtype=np.float32)
            else:
                # For regular actions, load current timestep actions
                end_idx = min(timestep_idx + self.horizon, n_timesteps)
                action = action_data[timestep_idx:end_idx].astype(np.float32)
        else:
            # For other fields (like joint_pos, eef_pose), use future timesteps as actions
            start_idx = timestep_idx + 1
            end_idx = min(start_idx + self.horizon, n_timesteps)

            if start_idx < n_timesteps:
                # Load available future timesteps
                action = action_data[start_idx:end_idx].astype(np.float32)
            else:
                # No future timesteps available - return empty
                action = np.empty((0, action_data.shape[1]), dtype=np.float32)

        return action

    def _get_reference_value_for_edge_padding(self, episode_idx: int | None, timestep_idx: int | None) -> np.ndarray:
        """
        Get reference value for edge padding when no actions are available.

        Args:
            episode_idx: Episode index
            timestep_idx: Timestep index

        Returns:
            Reference value from current timestep of the action field
        """
        if episode_idx is None or timestep_idx is None:
            raise ValueError("episode_idx and timestep_idx must be provided for edge padding reference value")

        # Load the current timestep's value from the action field
        file_path = Path(self.data_path) / f"episode_{episode_idx}" / f"episode_{episode_idx}.h5"
        action_field = self.config.get("action_field", "action")

        with h5py.File(file_path, "r") as f:
            if action_field not in f:
                raise ValueError(
                    f"Cannot find action_field='{action_field}' in dataset. " f"Available fields: {list(f.keys())}"
                )

            action_data = f[action_field]
            if timestep_idx >= action_data.shape[0]:
                raise IndexError(
                    f"timestep_idx {timestep_idx} is out of bounds for action_field '{action_field}' "
                    f"with {action_data.shape[0]} timesteps"
                )

            # Get the current timestep's value as reference
            reference_value = action_data[timestep_idx].astype(np.float32)

        return reference_value

    def _pad_and_mask_actions(
        self,
        action: np.ndarray,
        reference_value: np.ndarray | None,
        episode_idx: int | None,
        timestep_idx: int | None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Pad action to horizon and compute action_is_pad. action_is_pad is not currently used by bc.py.

        Args:
            action: Raw action array to be padded, shape (n_available_actions, action_dim)
            reference_value: Reference value for edge padding when no actions are available.
                           Should have shape (action_dim,). Required when pad_action_mode='edge'
                           and no actions are available.

        Returns:
            Tuple of (action_padded, action_is_pad) where:
                - action_padded: Padded action array with shape (horizon, action_dim)
                - action_is_pad: Boolean mask indicating which timesteps are padded, shape (horizon,)
        """
        action_length_before_padding = int(len(action))
        pad_action_mode = self.pad_action_mode
        action_is_pad = np.zeros(self.horizon, dtype=bool)
        # Fast path: already at desired length, no padding needed
        if action_length_before_padding == self.horizon:
            return action.astype(np.float32), action_is_pad

        # Pad the action to the horizon
        if pad_action_mode is None:
            raise ValueError(
                f"Invalid action shape: {action.shape} which is less than the required horizon: {self.horizon}. "
                f"Set pad_action to enable padding."
            )

        elif pad_action_mode == "constant":
            padding_needed = self.horizon - action_length_before_padding
            if action_length_before_padding == 0:
                dim = reference_value.shape[0] if reference_value is not None else action.shape[1]
                action_padded = np.zeros((self.horizon, dim), dtype=np.float32)
            else:
                padding = np.zeros((padding_needed, action.shape[1]), dtype=np.float32)
                action_padded = np.concatenate([action, padding], axis=0)
            action_is_pad[action_length_before_padding:] = True

        elif pad_action_mode == "edge":
            padding_needed = self.horizon - action_length_before_padding
            if action_length_before_padding == 0:
                action_padded = np.tile(reference_value, (self.horizon, 1)).astype(np.float32)
            else:
                last_action = action[-1:].repeat(padding_needed, axis=0)
                action_padded = np.concatenate([action, last_action], axis=0)
            action_is_pad[action_length_before_padding:] = True
        else:
            raise ValueError(f"Unknown pad_action mode: {pad_action_mode}. Expected 'constant', 'edge', or None.")

        # LeRobot history/window mask alignment: when using shifted temporal history, align mask
        if (
            self._should_align_history_mask(episode_idx, timestep_idx)
            and episode_idx is not None
            and timestep_idx is not None
        ):
            ep_len = self._episode_lengths.get(int(episode_idx))
            if ep_len is not None:
                action_is_pad = self._build_history_pad_mask(ep_len, timestep_idx)

        return action_padded, action_is_pad

    def handle_observation_history(self, f: h5py.File, obs: dict, timestep_idx: int) -> dict:

        # Handle observation history
        for key in self.obs_keys:
            n_obs_history = self.key_to_n_obs_history[key]
            if key == "point_cloud":
                obs[key] = self.extract_point_cloud(f[key], timestep_idx)
                continue

            raw_obs = f[key][max(0, timestep_idx - n_obs_history + 1) : timestep_idx + 1]
            # If the episode is just starting, we need to pad before the very first timestep
            # by repeating it
            if (diff_obs := n_obs_history - len(raw_obs)) > 0:
                padding = [(diff_obs, 0)] + [(0, 0)] * (raw_obs.ndim - 1)
                raw_obs = np.pad(raw_obs, padding, "edge")
            obs[key] = raw_obs

        return obs

    @profile_function("get_raw_data_from_h5", DATASET_CATEGORY)
    def get_raw_data_from_h5(self, file_path: str | Path, timestep_idx: int) -> tuple[np.ndarray | torch.Tensor, dict]:
        """
        Reads the data in h5 file to extract raw data and observations.
        Pure raw data extraction - no padding or processing logic.

        Returns:
            Tuple of (raw_action, obs)
        """
        obs = {}
        file_path = Path(file_path)
        with h5py.File(file_path) as f:
            # Assumes task description is constant for the entire trajectory
            if "task_description" in f.keys():
                task_desc = f["task_description"][()]
                # Handle different storage formats for task_description
                if isinstance(task_desc, bytes):
                    obs["task_description"] = task_desc.decode()
                elif isinstance(task_desc, np.ndarray):
                    # Handle numpy array case - extract string value
                    if task_desc.dtype.kind in ["U", "S"]:  # Unicode or byte string
                        obs["task_description"] = str(task_desc.item())
                    else:
                        obs["task_description"] = str(task_desc)
                else:
                    # Already a string or other format
                    obs["task_description"] = str(task_desc)

            # Load raw actions from the determined field (no padding applied here)
            raw_action = self._load_actions_from_field(f, timestep_idx)

            obs = self.handle_observation_history(f, obs, timestep_idx)

        return raw_action, obs

    @profile_function("process_observation_data", DATASET_CATEGORY)
    def process_observation_data(self, data_dict: dict[str, np.ndarray | torch.Tensor], obs: dict) -> None:
        """
        If the key is "color", the data is processed from multiple camera views and transformed to channel first format.
        If the key is something else, the data is processed as is.
        """
        for key in self.obs_keys:
            if key == "color":
                # Use standardized function to handle both compressed and uncompressed images
                data_dict[key] = process_color_observations(obs[key], self.config.camera_ids)

                if self.color_transforms:
                    data_dict[key] = np.stack(
                        [
                            [self.color_transforms(image=timestep)["image"] for timestep in images]
                            for images in data_dict[key]
                        ]
                    )
                # If the image normalization is applied, the data is already i=n the range [0, 1]
                if self.config.get("image_randomization", {}).get("imagenet_norm", False):
                    data_dict[key] = data_dict[key].astype(np.float32)
                else:
                    data_dict[key] = data_dict[key].astype(np.float32) / 255.0
                data_dict[key] = rearrange(data_dict[key], "... h w c -> ... c h w")
            elif key == "depth":
                data_dict[key] = obs[key].astype(np.int32)
            elif key == "point_cloud":

                if self.config.get("subtract_eef_pos_from_pointcloud_obs"):
                    pc_obs_name, eef_pos_obs_name = self.config.subtract_eef_pos_from_pointcloud_obs
                    pc_obs = obs[pc_obs_name]
                    if isinstance(pc_obs, (np.ndarray, torch.Tensor)):
                        pc_obs[..., :3] = subtract_eef_pos_from_pointcloud_obs(obs, pc_obs_name, eef_pos_obs_name)
                        obs[key] = pc_obs
                    else:
                        raise ValueError(f"Unsupported type for {pc_obs_name} in obs: {type(pc_obs)}")

                data_dict[key] = obs[key]
            elif key in self.obs_state:
                data_dict[key] = obs[key].astype(np.float32)

    @profile_function("process_action_data", DATASET_CATEGORY)
    def process_action_data(
        self,
        data_dict: dict[str, np.ndarray | torch.Tensor],
        action: np.ndarray | torch.Tensor,
        episode_idx: int | None = None,
        timestep_idx: int | None = None,
    ) -> None:
        # Apply padding to actions first, before other processing
        action_length_before_padding = len(action)

        # Determine reference value if needed for edge padding when no actions available
        reference_value = None
        if action_length_before_padding == 0 and self.pad_action_mode == "edge":
            # When no actions are available, load the reference value from current timestep
            reference_value = self._get_reference_value_for_edge_padding(episode_idx, timestep_idx)

        # Unified padding + mask computation
        action, action_is_pad = self._pad_and_mask_actions(
            action=action,
            reference_value=reference_value,
            episode_idx=episode_idx,
            timestep_idx=timestep_idx,
        )

        if self.config.get("disable_action_conversion", False):
            # No data conversion.
            data_dict["action"] = action
        # If the data is 17 dimensional, it is assumed to be a 16D pose (full transformation matrix) and
        # a 1D gripper value. The pose is converted to a 10D pose and concatenated with the gripper value.
        # This is the case for the real world spot data.
        elif action.shape[1] == 17:
            # TODO: Validate mat_to_pose10d logic or migrate to RotationTransformer, see PR#226 description
            data_dict["action"] = np.concatenate(
                [mat_to_pose10d(action[:, :16].reshape(action.shape[0], 4, 4)), action[:, 16:17]], axis=1
            )
        # If the data is 7 dimensional, it is assumed to be a 6D pose (xyz_rpy) and a 1D gripper value.
        # The pose is converted to a 10D pose and concatenated with the gripper value.
        elif action.shape[1] == 7 and self.config.action_convert_7d_to_10d:
            pos = action[:, :3]
            rot = action[:, 3:6]
            gripper = action[:, 6:]
            from visuomotor.data.rotation_transformer import RotationTransformer

            # Make sure self.rotation_transformer is initialized if not already
            if not hasattr(self, "rotation_transformer"):
                self.rotation_transformer = RotationTransformer(from_rep="axis_angle", to_rep="rotation_6d")
            rot = self.rotation_transformer.forward(rot)
            data_dict["action"] = np.concatenate([pos, rot, gripper], axis=-1).astype(np.float32)
            out_dim = data_dict["action"].shape[1]
            assert out_dim == 10, "Expected action shape to be 10d after rotation transformer, got {out_dim}"
        # If the data is 32 dimensional, it is assumed that the first 16D is the pose for the end-effector
        # and the next 16D is the pose for the torso. The 32th dimension is the gripper value.
        elif action.shape[1] == 33:
            # TODO: Validate mat_to_pose10d logic or migrate to RotationTransformer, see PR#226 description
            data_dict["action"] = np.concatenate(
                [
                    mat_to_pose10d(action[:, :16].reshape(action.shape[0], 4, 4)),
                    mat_to_pose10d(action[:, 16:32].reshape(action.shape[0], 4, 4)),
                    action[:, 32:33],
                ],
                axis=1,
            )
        else:
            data_dict["action"] = action

        if self.config.get("subtract_eef_pos_from_actions"):
            action_name, eef_pos_obs_name = self.config.subtract_eef_pos_from_actions
            eef_pos_obs_timesteps = self.key_to_n_obs_history[eef_pos_obs_name]
            data_dict[action_name][:, :3] = subtract_eef_pos_from_actions(
                data_dict, action_name, eef_pos_obs_name, eef_pos_obs_timesteps
            )

        # Store action_is_pad for parity matching with HF datasets
        data_dict["action_is_pad"] = action_is_pad


def config_to_limit_overrides(config: DictConfig) -> dict[str, dict[str, torch.Tensor]]:
    """Extract a dictionary of normalization limit overrides from a toplevel config."""
    limit_overrides: dict[str, dict[str, torch.Tensor]] = dict()
    overrides_config = config.data.get("norm_limit_overrides", None)
    if overrides_config is not None:
        for norm_limit in config.data.norm_limit_overrides:
            limit_overrides[norm_limit["name"]] = {
                "min": torch.Tensor(norm_limit["min"]),
                "max": torch.Tensor(norm_limit["max"]),
            }
    return limit_overrides


def unwrap_dataset(dataset: Dataset | Subset | ConcatDataset) -> Dataset:
    # If it's a Subset, unwrap it recursively.
    if isinstance(dataset, Subset):
        return unwrap_dataset(dataset.dataset)
    # If it's a ConcatDataset, assume all datasets share the same attributes and unwrap the first one.
    elif isinstance(dataset, ConcatDataset):
        return unwrap_dataset(dataset.datasets[0])
    else:
        return dataset


def get_normalizers(
    dataset: Dataset,
    keys: list[str],
    mode: str = "limits",
    force_compute: bool = False,
    batch_size: int = 64,
    limit_overrides: dict[str, dict[str, torch.Tensor]] | None = None,
    **normalizer_kwargs: Any,
) -> LinearNormalizer:
    """
    Wrapper function around get_normalizer() which hanldes multiple datasets by getting
    normalizers for each dataset and then weight-wise averaging them.
    """

    normalizers = []
    weights = []
    if hasattr(dataset, "datasets"):
        for d in dataset.datasets:
            normalizer = get_normalizer(
                d, keys, mode, force_compute, batch_size, limit_overrides=limit_overrides, **normalizer_kwargs
            )
            normalizers.append(normalizer)
            weights.append(len(d) / len(dataset))
    else:
        normalizer = get_normalizer(
            dataset, keys, mode, force_compute, batch_size, limit_overrides=limit_overrides, **normalizer_kwargs
        )
        normalizers.append(normalizer)
        weights.append(1)

    # weight-wise average datasets
    normalizers = [n * w for n, w in zip(normalizers, weights, strict=False)]
    final_normalizer = sum(normalizers) / len(normalizers)  # type: ignore
    return final_normalizer  # type: ignore


def get_normalizer(
    dataset: Dataset,
    keys: List[str],
    mode: str = "limits",
    force_compute: bool = False,
    batch_size: int = 64,
    limit_overrides: dict[str, dict[str, torch.Tensor]] | None = None,
    normalize_action_pos_only: bool = False,
    normalize_action_gripper_only: bool = False,
    gripper_idxs: Optional[list[int]] = None,
) -> "LinearNormalizer":
    """Fits a normalizer object on actions and observations.

    The normalizer should flatten the inputs so that they are two-dimensional.
    For example, a sequence of actions should be normalized so that the statistics
    are timestep independent.

    Args:
        dataset: The dataset to compute normalization over.
        keys: List of value names to normalize. If None, all supported observation keys will
            be used along with the actions.
        mode: The normalization mode. See `LinearNormalizer` for the supported modes.
        force_compute: If False, it will try looking for an existing normalizer file in
            dataset.data_path and load it if it exists. If True, it will compute it anyway.
        batch_size: The batch size to use for computing the normalization statistics.
        limit_overrides: Limits to use instead of any accumulated limits here.
            When limit_overrides is not None and non-empty, normalizer caching is disabled.
        normalize_action_pos_only: Action normalization applies to XYZ only, apply identity
            for rotation and gripper.
        normalize_action_gripper_only: Action normalization applies to gripper only, apply
            identity for XYZ and rotation.
        gripper_idxs: The indices to apply gripper normalization on

    Returns:
        Normalizer object with statistics computed over the dataset.
    """
    if limit_overrides is None:
        limit_overrides = dict()
    # Don't try loading a cached normalizer if we're using limit_overrides.
    # In principle they are compatible, but our caching implementation
    # assumes a normalizer is characterized by it's data_path and keys.
    # That's not true if we use limit_overrides.
    if len(limit_overrides) == 0:
        normalizer, normalizer_path = try_load_normalizer(dataset, keys, force_compute)
        if normalizer is not None:
            return normalizer
    else:
        normalizer_path = None

    if keys is None:
        raise ValueError("You have enabled normalization but have not provided any keys to normalize.")
    # We don't need to accumulate statistics for keys that have explicit limits set.
    keys_to_accumulate = [k for k in keys if k not in limit_overrides.keys()]
    if len(keys_to_accumulate) > 0:
        num_cpus = psutil.cpu_count(logical=False)
        assert num_cpus is not None
        data_loader = DataLoader(dataset, batch_size=batch_size, num_workers=num_cpus // 2, shuffle=False)

        data_stats, min_vals, max_vals = accumulate_statistics(data_loader, keys)

        data_final = compute_final_statistics(data_stats, min_vals, max_vals)
    else:
        data_final = dict()

    for key, limit in limit_overrides.items():
        data_final[key] = limit

    for key in data_final:
        for stat_key in data_final[key]:
            if not isinstance(data_final[key][stat_key], torch.Tensor):
                data_final[key][stat_key] = torch.tensor(data_final[key][stat_key])

    dataset = unwrap_dataset(dataset)
    normalizer = dataset.normalizer_cls()
    assert normalizer is not None
    normalizer.fit(
        data_final,
        dtype=torch.float32,
        mode=mode,
        normalize_action_pos_only=normalize_action_pos_only,
        normalize_action_gripper_only=normalize_action_gripper_only,
        gripper_idxs=gripper_idxs,
        data_path_basename=dataset.data_path_basename,
    )

    # save normalizer for future easy loading
    # Don't save it if we used limit_overrides
    if normalizer_path is not None:
        normalizer.save(str(normalizer_path))

    return normalizer


def try_load_normalizer(
    dataset: Dataset, keys: Optional[List[str]], force_compute: bool
) -> Tuple[Optional["LinearNormalizer"], Optional[Path]]:
    """Attempts to load an existing normalizer from the dataset path.

    Args:
        dataset: The dataset to check for an existing normalizer.
        keys: The list of keys used to build the normalizer filename.
        force_compute: If True, skip loading and force compute the normalizer.

    Returns:
        A tuple of (normalizer, normalizer_path).
        normalizer: The loaded normalizer if found, otherwise None.
        normalizer_path: The path to save the normalizer.
    """
    if not hasattr(dataset, "data_path"):
        return None, None

    if keys is not None:
        keys_str = "_".join(keys)
    else:
        keys_str = "all_keys"

    # Make normalizer cache action-configuration-aware
    cache_suffix = ""
    if keys is not None and "action" in keys and hasattr(dataset, "config"):
        # Include action_field in cache name to avoid conflicts between different action types
        action_field = dataset.config.get("action_field", "action")
        if action_field != "action":  # Only add suffix for non-default action fields
            cache_suffix = f"_{action_field}"

        # Also include horizon to distinguish different action sequence lengths
        if hasattr(dataset, "horizon"):
            cache_suffix += f"_h{dataset.horizon}"

    normalizer_path = Path(dataset.data_path) / f"normalizer_{keys_str}{cache_suffix}.pt"

    if not force_compute and normalizer_path.exists():
        print("Loading existing normalizer from", normalizer_path)
        normalizer = LinearNormalizer.load(normalizer_path)
        return normalizer, normalizer_path
    else:
        return None, normalizer_path


def accumulate_statistics(
    data_loader: DataLoader, keys: List[str]
) -> Tuple[Dict[str, Dict[str, torch.Tensor]], Dict[str, torch.Tensor], Dict[str, torch.Tensor]]:
    """Accumulates sum, sum_sq, count, min, and max for each key over the dataset.

    Args:
        data_loader: The DataLoader to iterate over.
        keys: The list of keys to compute statistics for.

    Returns:
        A tuple of (data_stats, min_vals, max_vals):
        - data_stats: Dictionary with sum, sum_sq, and count for each key.
        - min_vals: Dictionary with min values for each key.
        - max_vals: Dictionary with max values for each key.
    """
    data_stats = {key: {"sum": None, "sum_sq": None, "count": 0} for key in keys}
    min_vals = {key: None for key in keys}
    max_vals = {key: None for key in keys}

    total_batches = len(data_loader)
    for batch in tqdm_ray_newline(data_loader, total=total_batches, desc="Computing normalization statistics"):
        for key in keys:
            """
            Flatten batch and time dims (action horizon or obs history).
            TODO: Update to better support ndim > 3
            The current logic assumes tensors with ndim = 3, i.e. [b,h,d], e.g. actions or state observations.
            For ndim > 3, this may have unintended behavior.
            e.g. color observation returns stats per width pixels, b h i c h w -> (b h i c h) w
            """
            if batch[key].ndim != 3:
                print(
                    "Warning, calculating statistics for input.ndim != 3, this may produce unintended results."
                    f" {key} has ndim {batch[key].ndim}"
                )
            data = batch[key].view(-1, batch[key].size(-1))

            if data_stats[key]["sum"] is None:
                data_stats[key]["sum"] = data.sum(dim=0)
                data_stats[key]["sum_sq"] = (data**2).sum(dim=0)
            else:
                data_stats[key]["sum"] += data.sum(dim=0)
                data_stats[key]["sum_sq"] += (data**2).sum(dim=0)
            data_stats[key]["count"] += data.size(0)

            batch_min = data.min(dim=0)[0]
            batch_max = data.max(dim=0)[0]
            if min_vals[key] is None:
                min_vals[key] = batch_min
            else:
                min_vals[key] = torch.min(min_vals[key], batch_min)
            if max_vals[key] is None:
                max_vals[key] = batch_max
            else:
                max_vals[key] = torch.max(max_vals[key], batch_max)

    return data_stats, min_vals, max_vals


def compute_final_statistics(
    data_stats: Dict[str, Dict[str, torch.Tensor]], min_vals: Dict[str, torch.Tensor], max_vals: Dict[str, torch.Tensor]
) -> Dict[str, Dict[str, torch.Tensor]]:
    """Computes mean, std, min, and max from accumulators using the unbiased estimator.

    Args:
        data_stats: Dictionary with sum, sum_sq, and count for each key.
        min_vals: Dictionary with min values for each key.
        max_vals: Dictionary with max values for each key.

    Returns:
        data_final: Dictionary with 'min', 'max', 'mean', 'std' for each key.
    """
    data_final = {}
    for key in data_stats:
        count = data_stats[key]["count"]
        sum_ = data_stats[key]["sum"]
        sum_sq = data_stats[key]["sum_sq"]
        mean = sum_ / count

        # https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance
        # Using Bessel's correction helps the bias in the estimation of
        # population variance when using sample data.
        # This is numerically more stable than using the biased estimator: variance = (sum_sq / count) - (mean**2)
        # as it reduces the risk of floating-point cancellation errors.
        variance_numerator = sum_sq - (sum_**2) / count
        variance_denominator = count - 1 if count > 1 else 1
        variance = variance_numerator / variance_denominator

        std = torch.sqrt(variance + 1e-8)
        data_final[key] = {
            "min": min_vals[key],
            "max": max_vals[key],
            "mean": mean,
            "std": std,
        }
    return data_final


def main() -> None:
    with initialize(version_base=None, config_path="../configs/data"):
        config = compose(config_name="orange_nist_insertion_eef.yaml")
    config.data_path = config.data_path[0]
    dataset = VisuomotorDataset(config)

    for i in range(len(dataset)):
        st = time.perf_counter()
        data = dataset[i]
        print(data["action"].shape)
        print(data["color"].shape)
        print(data["arm_ee_pose"].shape)
        print(data["arm_gripper_width"].shape)
        et = time.perf_counter()
        print(f"data loading time: {et - st} s")

    print(len(dataset))


if __name__ == "__main__":
    main()
