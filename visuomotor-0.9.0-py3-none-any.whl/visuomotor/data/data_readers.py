# Copyright (c) 2025 Boston Dynamics AI Institute, Inc. All rights reserved.
"""inject these into torch datasets to interop between save formats"""

from __future__ import annotations

import dataclasses
import typing
from copy import deepcopy
from pathlib import Path
from typing import Generic, TypeVar

import h5py
import numpy as np
import numpy.random as npr


@dataclasses.dataclass
class SamplePayload:
    """Sample payload dataclass

    Args:
        sample (typing.Any): data sample
        episode_start (typing.Any): sample at beginning of episode
        episode_end (typing.Any): sample at end of episode
    """

    sample: typing.Any
    episode_start: typing.Any
    episode_end: typing.Any


T = TypeVar("T", covariant=True)


class EpisodeReader(typing.Protocol, Generic[T]):
    """episode reader interface"""

    def get_number_of_episodes(self) -> int:
        """get number of episodes in dataset

        Returns:
            int: number of episodes
        """
        raise NotImplementedError()

    def get_episode_length(self, episode_idx: int) -> int:
        """get length of an individual episode

        Args:
            episode_idx (int): index of target episode

        Returns:
            int: episode length
        """
        raise NotImplementedError()

    def load_sample(self, episode_idx: int, absolute_windows: dict[str, np.ndarray]) -> T:
        """load a sample for specified variables

        Args:
            episode_idx (int): index of target episode
            absolute_windows (dict[str, np.ndarray]): mapping from data field names to desired time indices

        Returns:
            dict[str, SamplePayload]: mapping from data field names to extracted samples
        """
        raise NotImplementedError()

    def split_by_episode(self, episode_fractions: list[float | int], random_seed: int = 0) -> list[EpisodeReader]:
        """create N new EpisodeReaders where each new EpisodeReader gets a subset of the episodes.

        Args:
            episode_fractions (list[float | int]): list element i specifies fraction of the episodes
                that should be allocated to output episode reader i. These values will be normalized.
            random_seed (int): random seed used for shuffle.

        Returns:
            list[EpisodeReader]: episode reader for each fraction of episodes.
        """
        raise NotImplementedError()


class H5EpisodeReader(EpisodeReader[dict[str, SamplePayload]]):
    """implements the EpisodeReader interface for local h5py files"""

    def __init__(self, episode_files: list[Path], reference_key: str, chunk_delimiter: int = 32):
        """

        Args:
            episode_files (list[Path]): list of file paths
            reference_key (str): episode[reference_key].shape[0] must give number of samples
                for every episode in dataset
            chunk_delimiter (int): when consecutive indices in absolute_window are separated
                by a gap greater than chunk_delimiter --> they will be loaded in separate chunks
        """

        self.episode_files = episode_files
        self._reference_key = reference_key
        self._chunk_delimiter = chunk_delimiter
        self._episode_lengths = []
        for full_path in episode_files:
            if not full_path.exists():
                raise RuntimeError(f"Unable to find file at location {full_path}")
            with h5py.File(full_path, "r") as f:
                self._episode_lengths.append(f[reference_key].shape[0])

    @classmethod
    def from_local_path(
        cls,
        local_path: Path | str | list[str] | list[Path],
        reference_key: str,
        sort_files: bool = True,
        chunk_delimiter: int = 32,
    ) -> H5EpisodeReader:
        """construct from root directory. Finds all files that follow the naming scheme: episode_{episode_idx}.h5.
            Will descend into subdirectories.

        Args:
            local_path (Path | str | list[str] | list[Path]): local path to dataset or paths to multiple local datasets.
            reference_key (str): see __init__
            sort_files (bool): if True, sorts filenames by int(episode_idx)
            chunk_delimiter (int): when consecutive indices in absolute_window are separated
                by a gap greater than chunk_delimiter --> they will be loaded in separate chunks
        """
        if isinstance(local_path, (Path, str)):
            _local_paths = [Path(local_path)]
        else:
            _local_paths = [Path(lpi) for lpi in local_path]

        all_files = []
        for root_path in _local_paths:

            files = list(root_path.rglob("episode_[0-9]*.h5"))
            if sort_files:

                def _get_idx(p: Path) -> int:
                    return int(p.stem.split("episode_")[-1])

                files = sorted(files, key=_get_idx)
            all_files.extend(files)
        return cls(all_files, reference_key, chunk_delimiter=chunk_delimiter)

    def get_number_of_episodes(self) -> int:
        """get number of episodes in dataset

        Raises:
            NotImplementedError: _description_

        Returns:
            int: number of episodes
        """
        return len(self.episode_files)

    def get_episode_length(self, episode_idx: int) -> int:
        """get length of an individual episode

        Args:
            episode_idx (int): index of target episode

        Returns:
            int: episode length
        """
        return self._episode_lengths[episode_idx]

    def _make_chunks(self, sorted_window: np.ndarray) -> list[np.ndarray]:
        """
        Splits a sorted array of indices into chunks.

        Args:
            sorted_window (np.ndarray): NumPy array of sorted indices.

        Returns:
            list[np.ndarray]: A list of NumPy arrays, each representing a chunk of contiguous indices.
        """
        # chunk bounds are the [incusive, exclusive) bounds for all chunks
        chunk_bounds = np.concatenate(
            (
                [0],
                1 + np.where((sorted_window[1:] - sorted_window[:-1]) > self._chunk_delimiter)[0],
                [len(sorted_window)],
            )
        )
        chunks = []
        for i in range(len(chunk_bounds) - 1):
            chunks.append(sorted_window[chunk_bounds[i] : chunk_bounds[i + 1]])
        return chunks

    def load_sample(self, episode_idx: int, absolute_windows: dict[str, np.ndarray]) -> dict[str, SamplePayload]:
        """load a sample for specified variables

        Args:
            episode_idx (int): index of target episode
            absolute_windows (dict[str, np.ndarray]): mapping from data field names to desired time indices

        Returns:
            dict[str, SamplePayload]: mapping from data field names to extracted samples
        """
        ret_payload = {}
        with h5py.File(self.episode_files[episode_idx], "r") as f:
            for k, window in absolute_windows.items():
                sinds = np.argsort(window)
                chunks = self._make_chunks(window[sinds])
                sub_samples = []
                for chunk in chunks:
                    range_start = np.amin(chunk)
                    range_end = np.amax(chunk) + 1
                    sub_samples.append(f[k][range_start:range_end][chunk - range_start])
                sorted_order_samples = np.concatenate(sub_samples, axis=0)
                v2 = np.zeros_like(sorted_order_samples)
                v2[sinds] = sorted_order_samples
                ret_payload[k] = SamplePayload(
                    sample=v2,
                    episode_start=f[k][0],
                    episode_end=f[k][-1],
                )

        return ret_payload

    @staticmethod
    def generate_episode_split(episode_files: list, episode_fractions: list[float | int], random_seed: int = 0) -> list:
        # split episodes according to episode_fractions. See split_by_episode() docstring for more details.
        #   sorts files to get determinism

        episode_files = sorted(episode_files)

        rng = npr.default_rng(random_seed)
        ep_files_shuffle = np.array(deepcopy(episode_files))
        rng.shuffle(ep_files_shuffle)
        ep_counts = np.floor((np.array(episode_fractions) / np.sum(episode_fractions)) * len(episode_files)).astype(
            np.int32
        )

        # randomly assign leftover files:
        for _ in range(len(ep_files_shuffle) - int(np.sum(ep_counts))):
            idx = rng.integers(0, len(ep_counts))
            ep_counts[idx] += 1

        if np.any(ep_counts < 0.5):
            raise RuntimeError("Failure in splitting episodes. Some resulting readers did not get any episodes.")

        idx0 = 0
        eps = []
        for count in ep_counts:
            idx_end = int(idx0 + count)
            eps.append(ep_files_shuffle[idx0:idx_end])
            idx0 = idx_end
        return eps

    def split_by_episode(self, episode_fractions: list[float | int], random_seed: int = 0) -> list[EpisodeReader]:
        """create N new EpisodeReaders where each new EpisodeReader gets a subset of the episodes.

        Args:
            episode_fractions (list[float | int]): list element i specifies fraction of the episodes
                that should be allocated to output episode reader i. These values will be normalized.

        Returns:
            list[EpisodeReader]: episode reader for each fraction of episodes.
        """
        eps = H5EpisodeReader.generate_episode_split(self.episode_files, episode_fractions, random_seed)
        readers: list[EpisodeReader] = []
        for ep_set in eps:
            readers.append(H5EpisodeReader(ep_set, self._reference_key))
        return readers
