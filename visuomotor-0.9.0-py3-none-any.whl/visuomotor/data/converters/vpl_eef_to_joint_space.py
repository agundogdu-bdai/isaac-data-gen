#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

"""
This script converts a VPL dataset between action spaces (joint space ↔ end-effector space), including copying videos.
It also uploads the processed data back to GCS if a bucket is specified.

NOTE: This script is for offline conversion. For most use cases, consider using the in-memory conversion
by setting action_type: "joint_pos" or action_type: "eef_pose" in your data config instead.
The in-memory conversion will only convert when action_type is explicitly specified.

Usage:
    poetry run python submit_job.py ../data/converters/vpl_eef_to_joint_space \
          --cluster agundogdu --k8s-context lam-248 --config-name train_diffpo_rl_metaflow
"""

import os
import shutil
import subprocess

import h5py
import hydra
import numpy as np
import ray
from filelock import FileLock
from omegaconf import DictConfig

from visuomotor.ray_train.data.data_copy_actor import copy_to_local
from visuomotor.ray_train.ray_tqdm_utils import tqdm_ray_newline
from visuomotor.utils.paths import get_base_gcs_path, get_ray_worker_data_path


@ray.remote(num_cpus=2, resources={"train": 0.01})
def convert_episode_to_joint_space(input_dir: str, output_dir: str, episode_idx: int) -> bool:
    """
    Convert a single episode from end-effector space to joint space, including copying videos.
    Args:
        input_dir: Path to the input dataset directory
        output_dir: Path to the output dataset directory
        episode_idx: Index of the episode to convert
    Returns:
        bool: True if conversion was successful, False if episode file was not found
    """
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Define paths
    episode_dir = f"episode_{episode_idx}"
    episode_file = f"episode_{episode_idx}.h5"

    input_episode_path = os.path.join(input_dir, episode_dir, episode_file)
    output_episode_dir = os.path.join(output_dir, episode_dir)
    output_episode_path = os.path.join(output_episode_dir, episode_file)

    # Create output episode directory
    os.makedirs(output_episode_dir, exist_ok=True)

    # Check if input episode exists
    if not os.path.exists(input_episode_path):
        print(f"Warning: Episode file {input_episode_path} not found. Skipping.")
        return False

    print(f"\nConverting {input_episode_path} to joint space")

    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(output_episode_path), exist_ok=True)

    # Open the input file and convert to joint space
    with h5py.File(input_episode_path, "r") as f_in:
        # Handle three specific dataset formats:
        # 1. VPL dataset: joint_pos directly in root
        # 2. MimicGen dataset: robot0_joint_pos directly in root
        # 3. MimicGen dataset: robot0_joint_pos in obs group
        if "joint_pos" in f_in:
            joint_pos = f_in["joint_pos"][:]
            print("Using joint_pos from root")
        elif "robot0_joint_pos" in f_in:
            joint_pos = f_in["robot0_joint_pos"][:]
            print("Using robot0_joint_pos from root")
        elif "obs" in f_in and "robot0_joint_pos" in f_in["obs"]:
            joint_pos = f_in["obs"]["robot0_joint_pos"][:]
            print("Using robot0_joint_pos from obs")
        else:
            print("ERROR: Dataset format not supported")
            print("Expected either 'joint_pos', 'robot0_joint_pos', or 'obs/robot0_joint_pos'")
            print("Please check the debug output above to see available fields")
            return False

        n_timesteps = joint_pos.shape[0]

        # Create joint space actions (each action is the next timestep's joint positions)
        joint_actions = np.zeros_like(joint_pos)
        for t in range(n_timesteps - 1):
            joint_actions[t] = joint_pos[t + 1]

        # For the last timestep, use the same joint position (no future state available)
        joint_actions[-1] = joint_pos[-1]

        # Create the output file with joint space actions
        with h5py.File(output_episode_path, "w") as f_out:
            # First, copy all datasets and attributes from the input file
            for name, _ in f_in.items():
                # Skip action dataset - we'll replace it with our joint space version
                if name == "action":
                    continue

                # Copy the dataset
                f_in.copy(name, f_out)

            # Create the new joint space action dataset
            f_out.create_dataset("action", data=joint_actions)

            # Add an attribute to indicate this is a joint space version
            f_out.attrs["action_space"] = "joint"

            # Copy all other attributes
            for attr_name, attr_value in f_in.attrs.items():
                if attr_name != "action_space":
                    f_out.attrs[attr_name] = attr_value

    # Copy videos directory if it exists
    videos_dir = os.path.join(input_dir, episode_dir, "videos")
    if os.path.exists(videos_dir):
        output_videos_dir = os.path.join(output_episode_dir, "videos")
        print(f"Copying videos directory for episode {episode_idx}")

        # Use rsync-like approach to preserve directory structure
        for camera_dir in os.listdir(videos_dir):
            input_camera_dir = os.path.join(videos_dir, camera_dir)
            output_camera_dir = os.path.join(output_videos_dir, camera_dir)

            # Ensure the output camera directory exists
            os.makedirs(output_camera_dir, exist_ok=True)

            # Copy all files in the camera directory
            for file in os.listdir(input_camera_dir):
                src = os.path.join(input_camera_dir, file)
                dst = os.path.join(output_camera_dir, file)
                shutil.copy2(src, dst)

    return True


def get_actual_episode_count(input_dir: str) -> int:
    """
    Scan the input directory to determine the actual number of episodes present.
    Args:
        input_dir: Path to the input dataset directory
    Returns:
        int: Number of episodes actually present in the dataset
    """
    if not os.path.exists(input_dir):
        return 0

    episode_count = 0
    for item in os.listdir(input_dir):
        if item.startswith("episode_") and os.path.isdir(os.path.join(input_dir, item)):
            episode_path = os.path.join(input_dir, item, f"{item}.h5")
            if os.path.exists(episode_path):
                episode_count += 1

    return episode_count


@ray.remote(num_cpus=1, resources={"train": 0.01})
def copy_metadata_files(input_dir: str, output_dir: str) -> bool:
    """
    Copy metadata files from input to output directory
    Args:
        input_dir: Path to the input dataset directory
        output_dir: Path to the output dataset directory
    Returns:
        bool: True if successful
    """
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Copy metadata files
    metadata_files = ["intrinsics.h5", "metadata.json"]
    for file in metadata_files:
        input_path = os.path.join(input_dir, file)
        output_path = os.path.join(output_dir, file)

        if os.path.exists(input_path):
            print(f"Copying {file} to output directory")
            shutil.copy2(input_path, output_path)

    return True


@ray.remote(num_cpus=1, resources={"train": 0.01})
def upload_data_to_gcs(local_path: str, gcs_path: str, bucket_name: str) -> bool:
    """
    Upload processed data from local storage to Google Cloud Storage
    Args:
        local_path: Path to the local directory containing processed data
        gcs_path: Path in GCS where the data should be uploaded
        bucket_name: GCS bucket name
    Returns:
        bool: True if upload was successful
    """
    print(f"Uploading data from {local_path} to gs://{bucket_name}/{gcs_path}")

    # Count the actual episodes in the output directory
    actual_episode_count = 0
    episode_list = []
    for item in os.listdir(local_path):
        if item.startswith("episode_") and os.path.isdir(os.path.join(local_path, item)):
            episode_file = os.path.join(local_path, item, f"{item}.h5")
            if os.path.exists(episode_file):
                actual_episode_count += 1
                episode_num = int(item.split("_")[1])
                episode_list.append(episode_num)

    episode_list.sort()
    print(f"Found {actual_episode_count} converted episodes in output directory")
    print(f"Episode numbers: {episode_list[:10]}{'...' if len(episode_list) > 10 else ''}")

    if actual_episode_count == 0:
        print("ERROR: No episodes found in output directory!")
        print("Upload canceled.")
        return False

    print(f"Proceeding with upload of {actual_episode_count} episodes.")

    # Create lock file to prevent concurrent uploads
    lock_file = f"{local_path}.upload.lock"

    with FileLock(lock_file):
        try:
            # Construct the GCS destination path
            gcs_dest = f"gs://{bucket_name}/{gcs_path}"

            # Use gcloud storage rsync command to upload data
            upload_command = f"export CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE=$GOOGLE_APPLICATION_CREDENTIALS && gcloud storage rsync -r {local_path} {gcs_dest}"  # noqa: E501

            # Execute the upload command
            process = subprocess.Popen(upload_command, shell=True)
            process.wait()

            if process.returncode == 0:
                print(f"Successfully uploaded data to {gcs_dest}")
                return True
            else:
                print(f"Failed to upload data to {gcs_dest}, return code: {process.returncode}")
                return False

        except Exception as e:
            print(f"Error during upload: {str(e)}")
            return False
        finally:
            # Remove lock file even if an error occurs
            if os.path.exists(lock_file):
                os.remove(lock_file)


@hydra.main(version_base=None, config_path="pkg://visuomotor/configs", config_name=None)
def main(config: DictConfig) -> None:

    copy_to_local(config, overwrite=False)

    data_path = next(iter(config.data.data_path))

    input_dir = get_ray_worker_data_path() / data_path
    data_path_last_part = input_dir.name
    output_dir = get_ray_worker_data_path() / input_dir.parent / f"{data_path_last_part}_joint_space"

    # Try to get max_episodes from different possible locations in config
    max_episodes = None
    if hasattr(config, "train") and hasattr(config.train, "max_episodes"):
        max_episodes = config.train.max_episodes
        print(f"Using max_episodes from config.train.max_episodes: {max_episodes}")
    elif hasattr(config, "data") and hasattr(config.data, "max_episodes"):
        max_episodes = config.data.max_episodes
        print(f"Using max_episodes from config.data.max_episodes: {max_episodes}")

    # If max_episodes is not found in config, scan the actual dataset
    if max_episodes is None:
        print("max_episodes not found in config, scanning input directory...")
        max_episodes = get_actual_episode_count(str(input_dir))
        if max_episodes == 0:
            print("ERROR: No episodes found in input directory and no max_episodes in config!")
            return
        print(f"Found {max_episodes} episodes in input directory")

    # Convert paths to strings for Ray serialization
    input_dir_str = str(input_dir)
    output_dir_str = str(output_dir)

    print(f"Input directory: {input_dir_str}")
    print(f"Output directory: {output_dir_str}")

    # Check how many episodes are actually present locally
    actual_episode_count = get_actual_episode_count(input_dir_str)
    print(f"Found {actual_episode_count} episodes locally (expected {max_episodes})")

    if actual_episode_count < max_episodes:
        print(f"WARNING: Only {actual_episode_count} out of {max_episodes} episodes are available locally")
        print("Missing episodes will be skipped during conversion")

    # Submit Ray tasks for each episode
    futures = []

    # First submit metadata copying task
    metadata_future = copy_metadata_files.remote(input_dir_str, output_dir_str)
    futures.append(metadata_future)

    # Then submit episode conversion tasks for all expected episodes
    # The conversion function will handle missing episodes gracefully
    for episode_idx in range(max_episodes):
        future = convert_episode_to_joint_space.remote(input_dir_str, output_dir_str, episode_idx)
        futures.append(future)

    # Wait for all tasks to complete with progress bar
    results = []
    for result in tqdm_ray_newline(ray.get(futures), desc="Converting episodes", total=len(futures)):
        results.append(result)

    # Count successful conversions (excluding metadata task)
    successful_conversions = sum(1 for result in results[1:] if result)  # Skip metadata task result
    print(f"\nConversion complete! Successfully converted {successful_conversions} episodes")
    print(f"Joint space dataset saved to {output_dir}")

    # Upload processed data back to GCS if bucket is specified
    if hasattr(config.data, "base_bucket") and config.data.base_bucket:
        bucket_name = config.data.base_bucket
        # Construct GCS path for the processed data
        base_gcs_path = get_base_gcs_path()
        # Create a path similar to the input path but with _joint_space suffix
        relative_data_path = f"{data_path}_joint_space"
        gcs_path = f"{base_gcs_path}/{relative_data_path}"

        print(f"Uploading processed data to GCS bucket: {bucket_name}")

        # Submit the upload task - it will determine the actual episode count itself
        upload_future = upload_data_to_gcs.remote(output_dir_str, gcs_path, bucket_name)

        # Wait for upload to complete
        if ray.get(upload_future):
            print(f"Successfully uploaded joint space dataset to gs://{bucket_name}/{gcs_path}")
        else:
            print("Failed to upload joint space dataset to GCS")


if __name__ == "__main__":
    main()
