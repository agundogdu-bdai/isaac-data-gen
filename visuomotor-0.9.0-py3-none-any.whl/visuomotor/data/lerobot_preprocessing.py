#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

"""Enhanced unified preprocessing utilities for both training and inference."""

from typing import Any, Dict, List, Optional, Union

import numpy as np
import torch

# === UNIFIED INPUT HANDLING ===


def _to_torch_tensor(data: Union[np.ndarray, torch.Tensor]) -> torch.Tensor:
    """Convert numpy array to torch tensor, preserving existing tensors."""
    if isinstance(data, np.ndarray):
        return torch.from_numpy(data)
    return data


def _to_numpy_array(data: Union[np.ndarray, torch.Tensor]) -> np.ndarray:
    """Convert torch tensor to numpy array, preserving existing arrays."""
    if isinstance(data, torch.Tensor):
        return data.detach().cpu().numpy()
    return data


# === ENHANCED COLOR PROCESSING ===


def _normalize_image_data(data: Union[np.ndarray, torch.Tensor]) -> Union[np.ndarray, torch.Tensor]:
    """Normalize uint8 image data to float in range [0, 1], handling both numpy and torch."""
    if isinstance(data, torch.Tensor):
        if data.dtype == torch.uint8:
            return data.float() / 255.0
        return data
    else:  # numpy
        if data.dtype == np.uint8:
            return data.astype(np.float32) / 255.0
        return data.astype(np.float32)


def _permute_hwc_to_chw_unified(data: Union[np.ndarray, torch.Tensor]) -> Union[np.ndarray, torch.Tensor]:
    """Permute from HWC to CHW format for both numpy and torch."""
    if isinstance(data, torch.Tensor):
        ndim = data.dim()
        if ndim < 3:
            raise ValueError(f"Tensor must have at least 3 dimensions, got {ndim}")
        perm = list(range(ndim))
        channel_dim = perm.pop(-1)  # Remove C from the end
        perm.insert(-2, channel_dim)  # Insert C before H, W
        return data.permute(*perm)
    else:  # numpy array
        ndim = data.ndim
        if ndim < 3:
            raise ValueError(f"Array must have at least 3 dimensions, got {ndim}")
        # For numpy: move last axis (C) to third-to-last position
        axes = list(range(ndim))
        channel_axis = axes.pop(-1)  # Remove C
        axes.insert(-2, channel_axis)  # Insert before H, W
        return np.transpose(data, axes)


def _handle_compressed_images(obs_data: np.ndarray, camera_ids: List[int]) -> np.ndarray:
    """Handle compressed images from H5 files (numpy only)."""
    import io

    from PIL import Image

    def decode_image(png_bytes: np.uint8) -> np.ndarray:
        stream = io.BytesIO(png_bytes.tobytes())
        img = Image.open(stream)
        img.load()
        return np.array(img)

    def check_if_compressed(image: np.uint8) -> bool:
        return len(image.shape) == 1

    if check_if_compressed(obs_data[0, 0]):
        # Handle compressed images - decode them properly
        images = []
        for i in range(len(obs_data)):
            camera_images = []
            for j in camera_ids:
                decoded_img = decode_image(obs_data[i][j])
                camera_images.append(decoded_img)
            images.append(camera_images)
        return np.array(images)
    else:
        # Handle uncompressed images - just select camera views
        return obs_data[:, camera_ids]


def process_color_observations_unified(
    color_data: Union[np.ndarray, torch.Tensor],
    camera_keys: List[str],
    camera_ids: Optional[List[int]] = None,
    return_dict: bool = True,
    normalize: bool = True,
    to_chw: bool = True,
) -> Union[Dict[str, Union[np.ndarray, torch.Tensor]], Union[np.ndarray, torch.Tensor]]:
    """
    Unified color processing for both training (numpy) and inference (torch).

    Handles different input formats:
    - numpy: From H5 files, shape (n_history, n_cameras, ...) - handles compressed/uncompressed
    - torch: From inference, shape [B, T, cam, H, W, C] or [B, cam, H, W, C] or [B, H, W, C]

    Args:
        color_data: Input color data (numpy array or torch tensor)
        camera_keys: List of camera key names (e.g., ["color_0", "color_1"])
        camera_ids: Camera indices to select (for numpy H5 data only)
        return_dict: If True, return dict mapping keys to tensors. If False, return processed data directly
        normalize: Whether to normalize to [0,1] range
        to_chw: Whether to convert from HWC to CHW format

    Returns:
        Processed color data as dict or direct array/tensor
    """
    is_torch_input = isinstance(color_data, torch.Tensor)

    # Handle numpy input (H5 files with potential compression)
    if not is_torch_input:
        if camera_ids is None:
            raise ValueError("camera_ids required for numpy input")
        # Handle compressed/uncompressed images from H5 files
        processed_data = _handle_compressed_images(color_data, camera_ids)

        if not return_dict:
            if normalize:
                processed_data = _normalize_image_data(processed_data)
            if to_chw:
                processed_data = _permute_hwc_to_chw_unified(processed_data)
            return processed_data

        # Process each camera separately for dict output
        result = {}
        for cam_idx, key in enumerate(camera_keys):
            # Take appropriate camera index, using last if not enough cameras
            actual_cam_idx = min(cam_idx, processed_data.shape[1] - 1)
            cam_data = processed_data[:, actual_cam_idx]  # [T, H, W, C]

            if normalize:
                cam_data = _normalize_image_data(cam_data)
            if to_chw:
                cam_data = _permute_hwc_to_chw_unified(cam_data)

            result[key] = cam_data
        return result

    # Handle torch input (inference scenarios)
    else:
        # Normalize to 5D format [B, cam, H, W, C]
        if color_data.dim() == 6:  # [B, T, cam, H, W, C] -> [B, cam, H, W, C]
            normalized_data = color_data[:, -1]  # Take last timestep
        elif color_data.dim() == 5:  # [B, cam, H, W, C] - already correct
            normalized_data = color_data
        elif color_data.dim() == 4:  # [B, H, W, C] -> [B, 1, H, W, C]
            normalized_data = color_data.unsqueeze(1)  # Add camera dimension
        else:
            raise ValueError(f"Unsupported torch tensor dimensions: {color_data.dim()}D. Expected 4D, 5D, or 6D.")

        if not return_dict:
            if normalize:
                normalized_data = _normalize_image_data(normalized_data)
            if to_chw:
                normalized_data = _permute_hwc_to_chw_unified(normalized_data)
            return normalized_data

        # Process each camera separately for dict output
        result = {}
        for cam_idx, key in enumerate(camera_keys):
            # Use available cameras or repeat last camera
            actual_cam_idx = min(cam_idx, normalized_data.shape[1] - 1)
            cam_data = normalized_data[:, actual_cam_idx]  # [B, H, W, C]

            if to_chw:
                cam_data = _permute_hwc_to_chw_unified(cam_data)  # [B, C, H, W]
            if normalize:
                cam_data = _normalize_image_data(cam_data)

            result[key] = cam_data
        return result


# === ENHANCED STATE PROCESSING ===


def _process_temporal_dimensions(data: Union[np.ndarray, torch.Tensor]) -> Union[np.ndarray, torch.Tensor]:
    """Process temporal dimensions, taking last timestep if needed."""
    if isinstance(data, torch.Tensor):
        if data.dim() == 3:  # [B, T, D]
            return data[:, -1]  # Take last timestep
        elif data.dim() == 2:  # [B, D]
            return data
        else:
            raise ValueError(f"Expected 2D or 3D state tensor, got {data.dim()}D")
    else:  # numpy
        if data.ndim == 3:  # [B, T, D]
            return data[:, -1]  # Take last timestep
        elif data.ndim == 2:  # [T, D]
            return data[-1]  # Take last timestep
        elif data.ndim == 1:  # [D]
            return data
        else:
            raise ValueError(f"Expected 1D, 2D or 3D state array, got {data.ndim}D")


def _concatenate_state_components(
    components: List[Union[np.ndarray, torch.Tensor]],
) -> Union[np.ndarray, torch.Tensor]:
    """Concatenate state components along last dimension."""
    if not components:
        raise ValueError("No state components to combine")

    if isinstance(components[0], torch.Tensor):
        return torch.cat(components, dim=-1)
    else:
        return np.concatenate(components, axis=-1)


def process_state_observations_unified(
    batch: Dict[str, Any],
    valid_state_keys: set[str],
    output_key: str = "observation.state",
    remove_individual_keys: bool = True,
    preserve_time: bool = False,
) -> Dict[str, Any]:
    """
    Unified state processing for both training and inference.

    TODO(ahmet): Enforce deterministic key ordering and schema validation across
    HF vs local workflows. Consider driving concatenation order from config and
    asserting per-component shapes to avoid silent mismatches.

    Args:
        batch: Dictionary containing batch data (modified in-place)
        output_key: Key to store combined state under
        remove_individual_keys: Whether to remove individual state component keys
        preserve_time: Whether to preserve the temporal dimension
        valid_state_keys: Set of valid state keys from config.

    Returns:
        Modified batch dictionary with unified state key
    """
    # Create a copy to avoid modifying during iteration
    batch_copy = dict(batch)

    # Look for individual state components
    state_components = []
    state_keys_to_remove = []

    for key, value in batch_copy.items():
        if key in valid_state_keys and isinstance(value, (np.ndarray, torch.Tensor)):
            if preserve_time:
                # Keep temporal dimension if present; expand to [T, D] when 1D
                if isinstance(value, torch.Tensor):
                    if value.dim() == 1:
                        processed_component = value.unsqueeze(0)
                    elif value.dim() == 2:
                        processed_component = value
                    else:
                        # Expect [T, D] at most for training numpy; collapse batch if given
                        processed_component = value.squeeze(0)
                else:
                    if value.ndim == 1:
                        processed_component = value[None, :]
                    elif value.ndim == 2:
                        processed_component = value
                    else:
                        processed_component = np.squeeze(value, axis=0)
            else:
                processed_component = _process_temporal_dimensions(value)
            state_components.append(processed_component)
            state_keys_to_remove.append(key)

    if state_components:
        # Combine individual components
        combined_state = _concatenate_state_components(state_components)
        batch[output_key] = combined_state

        # Remove individual state keys if requested
        if remove_individual_keys:
            for key in state_keys_to_remove:
                batch.pop(key, None)

    elif "states" in batch:
        # Fallback: process single "states" key
        states_data = batch["states"]
        if isinstance(states_data, (np.ndarray, torch.Tensor)):
            if preserve_time:
                if isinstance(states_data, torch.Tensor):
                    if states_data.dim() == 1:
                        processed_states = states_data.unsqueeze(0)
                    elif states_data.dim() == 2:
                        processed_states = states_data
                    else:
                        processed_states = states_data.squeeze(0)
                else:
                    if states_data.ndim == 1:
                        processed_states = states_data[None, :]
                    elif states_data.ndim == 2:
                        processed_states = states_data
                    else:
                        processed_states = np.squeeze(states_data, axis=0)
            else:
                processed_states = _process_temporal_dimensions(states_data)
            batch[output_key] = processed_states
            if remove_individual_keys:
                batch.pop("states")

    return batch


# === BACKWARD COMPATIBILITY FUNCTIONS ===


def process_color_observations(color_tensor: torch.Tensor, expected_image_keys: List[str]) -> Dict[str, torch.Tensor]:
    """
    Backward compatibility function for existing torch-based color processing.

    This function maintains the exact same interface as the original function
    but uses the new unified processing internally.
    """
    return process_color_observations_unified(
        color_data=color_tensor,
        camera_keys=expected_image_keys,
        return_dict=True,
        normalize=True,
        to_chw=True,
    )
