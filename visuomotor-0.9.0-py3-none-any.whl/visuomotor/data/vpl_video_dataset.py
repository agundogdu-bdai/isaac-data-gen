#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

import concurrent
from pathlib import Path

import h5py
import numpy as np
import torch

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.data.video_utils import decode_video_frames


class VPLVideoDataset(VisuomotorDataset):
    """Dataset class for VPLVideo data that inherited from VisuomotorDataset.

    Load the action and observation data from a pre-processed h5 file;
    load images from mp4 and load depth from png.
    A subset of observations can be loaded by specifying their keys in the config.
    """

    def __getitem__(self, idx: int) -> dict[str, np.ndarray | torch.Tensor]:
        data_dict: dict[str, np.ndarray | torch.Tensor] = {}

        # Get episode and timestep indices for joint space conversion
        episode_idx, timestep_idx = self.episode_timestep_idx[idx]

        # Load multi-modal data
        raw_action_data, raw_obs_data = self.get_raw_data(episode_idx, timestep_idx)

        if "task_description" in raw_obs_data:
            data_dict["task_description"] = raw_obs_data["task_description"]
        elif "task_description" in self.metadata:
            data_dict["task_description"] = self.metadata["task_description"]

        self.process_observation_data(data_dict, raw_obs_data)
        self.process_action_data(data_dict, raw_action_data, episode_idx, timestep_idx)

        # Apply transformations to the data
        # self._apply_transformations(data_dict, action_data)
        data_dict["task_index"] = self.task_index

        return data_dict

    def get_raw_data(self, episode_idx: int, timestep_idx: int) -> tuple[np.ndarray | torch.Tensor, dict]:
        file_path = Path(self.data_path) / f"episode_{episode_idx}" / f"episode_{episode_idx}.h5"

        obs = {}
        file_path = Path(file_path)
        with h5py.File(file_path) as f:
            # Assumes task description is constant for the entire trajectory
            if "task_description" in f.keys():
                task_desc = f["task_description"][()]
                # Handle different storage formats for task_description
                if isinstance(task_desc, bytes):
                    obs["task_description"] = task_desc.decode()
                elif isinstance(task_desc, np.ndarray):
                    # Handle numpy array case - extract string value
                    if task_desc.dtype.kind in ["U", "S"]:  # Unicode or byte string
                        obs["task_description"] = str(task_desc.item())
                    else:
                        obs["task_description"] = str(task_desc)
                else:
                    # Already a string or other format
                    obs["task_description"] = str(task_desc)

            # Load actions from the shared method
            action = self._load_actions_from_field(f, timestep_idx)

            # Handle special case for old VPL data format
            if action.ndim > 2 and action.shape[-2] == 1:
                action = np.squeeze(action, axis=-2)

            # Handle observation history
            for key in self.obs_keys:
                n_obs_history = self.key_to_n_obs_history[key]

                if key == "color":
                    n_obs_history = self.key_to_n_obs_history[key]
                    indices_left = max(0, timestep_idx - n_obs_history + 1)
                    indices_right = timestep_idx + 1
                    frame_indices = list(range(indices_left, indices_right))

                    # Handle padding for indices at the start of the episode
                    num_padding = n_obs_history - len(frame_indices)
                    padded_indices = [frame_indices[0]] * num_padding + frame_indices

                    raw_color = self.get_raw_color_from_video(file_path.parent, episode_idx, padded_indices)
                    obs[key] = raw_color
                    continue
                elif key == "point_cloud":
                    obs[key] = self.extract_point_cloud(f[key], timestep_idx)
                    continue

                raw_obs = f[key][max(0, timestep_idx - n_obs_history + 1) : timestep_idx + 1]
                # If the episode is just starting, we need to pad before the very first timestep
                # by repeating it
                if (diff_obs := n_obs_history - len(raw_obs)) > 0:
                    padding = [(diff_obs, 0)] + [(0, 0)] * (raw_obs.ndim - 1)
                    raw_obs = np.pad(raw_obs, padding, "edge")
                obs[key] = raw_obs

        return action, obs

    def get_raw_color_from_video(
        self, episode_base_path: Path, episode_idx: int, frame_indices: list
    ) -> np.ndarray | torch.Tensor:
        """get raw rgb images from mp4

        Args:
            episode_base_path (Path): absolute path of episode dir
            episode_idx (int): episode index
            frame_indices (list): frame index list

        Returns:
            np.ndarray | torch.Tensor: _description_
        """
        # Get video parameters from config
        fps = self.config.get("video_fps", 30.0)
        timestamps = [idx / fps for idx in frame_indices]

        # Convert timestamps to tuple for caching
        timestamps_tuple = tuple(timestamps)

        def _read_from_single_camera(camera_id: int) -> np.array:
            """Process a single camera's video in a separate thread."""
            video_path = episode_base_path / "videos" / f"camera_{camera_id}" / f"episode_{episode_idx}.mp4"

            try:
                frames_tensor = decode_video_frames(
                    video_path=str(video_path), timestamps_tuple=timestamps_tuple, frame_indices_list=frame_indices
                )
                frames = (frames_tensor.permute(0, 2, 3, 1).cpu().numpy()).astype(np.uint8)
                return frames
            except Exception as e:
                print(f"Error loading video for camera {camera_id}: {e}")
                return None

        # Use ThreadPoolExecutor to process cameras in parallel
        max_workers = min(len(self.config.camera_ids), 8)  # Limit max threads
        all_camera_frames = []

        # Process all cameras in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:  # type: ignore[attr-defined]
            # Submit all camera processing tasks
            future_to_camera = {
                executor.submit(_read_from_single_camera, camera_id): camera_id for camera_id in self.config.camera_ids
            }

            # Collect results as they complete, but store them by camera_id
            camera_frames_dict = {}
            for future in concurrent.futures.as_completed(future_to_camera):  # type: ignore[attr-defined]
                camera_id = future_to_camera[future]
                try:
                    frames = future.result()
                    if frames is not None:
                        camera_frames_dict[camera_id] = frames
                    else:
                        raise ValueError(f"frame read from camera {camera_id} is None")
                except Exception as e:
                    print(f"Camera {camera_id} processing failed with error: {e}")
                    raise

            # Assemble results in the correct order based on camera_ids
            # padding with zeros for the camera_id < max(self.config.camera_ids) to avoid change in
            # process_observation_data
            frame_shape = next(iter(camera_frames_dict.values())).shape
            all_camera_frames = [
                camera_frames_dict.get(camera_id, np.zeros(frame_shape, dtype=np.uint8))
                for camera_id in range(max(self.config.camera_ids) + 1)
            ]
        result = np.array(all_camera_frames).transpose(1, 0, 2, 3, 4)
        return result.astype(np.uint8)
