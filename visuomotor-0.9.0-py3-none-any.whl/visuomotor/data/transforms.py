#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Mapping

import albumentations as A
import numpy as np
import torch
from einops import rearrange
from omegaconf import DictConfig


def get_color_transforms(config: DictConfig, inference: bool = False) -> A.Compose | None:
    # Explicit override: if data.image_transforms.enable is set to False, disable all transforms
    override_block = getattr(config, "image_transforms", None)
    if override_block is not None and hasattr(override_block, "enable"):
        if not bool(override_block.enable):
            return None

    # Get and check config parameters.
    image_randomization = config.get("image_randomization", {})
    resize = image_randomization.get("resize")
    resized_crop_scale = image_randomization.get("resized_crop_scale", None)
    crop_size = image_randomization.get("crop_size")
    random_crop_size = image_randomization.get("random_crop_size", None)
    color_jitter = image_randomization.get("color_jitter")
    imagenet_norm = image_randomization.get("imagenet_norm")

    if resize is None and resized_crop_scale is not None:
        raise ValueError("When using 'resized_crop_scale', you also need to specify 'resize'.")
    if resized_crop_scale is not None and crop_size is not None:
        raise ValueError("Do not use 'resized_crop_scale' and 'crop_size' at the same time.")
    if random_crop_size is not None and crop_size is not None:
        raise ValueError("Do not use 'random_crop_size' and 'crop_size' at the same time.")

    color_transforms: list[A.Transform] = list()

    # Resize and possibly apply resized random crop.
    if resize is not None:
        if resized_crop_scale is not None and not inference:
            ratio = resize[1] / resize[0]
            color_transforms.append(
                A.RandomResizedCrop(
                    size=(resize[0], resize[1]),
                    scale=(resized_crop_scale[0], resized_crop_scale[1]),
                    ratio=(ratio, ratio),
                )
            )
        else:
            color_transforms.append(A.Resize(height=resize[0], width=resize[1]))

    # Crop and possibly apply random crop.
    if random_crop_size is not None:
        color_transforms.append(A.RandomCrop(height=random_crop_size[0], width=random_crop_size[1]))
    if crop_size is not None:
        color_transforms.append(A.CenterCrop(height=crop_size[0], width=crop_size[1]))

    # Color jitter augmentation.
    if color_jitter is not None and not inference:
        color_transforms.append(
            A.ColorJitter(
                brightness=color_jitter.brightness,
                contrast=color_jitter.contrast,
                saturation=color_jitter.saturation,
                hue=color_jitter.hue,
            )
        )
    # Pixel value normalization.
    if imagenet_norm:
        color_transforms.append(
            A.Normalize(
                mean=config.image_randomization.imagenet_stats.mean, std=config.image_randomization.imagenet_stats.std
            )
        )
    # Compose image ops.
    if len(color_transforms) > 0:
        return A.Compose(color_transforms)
    else:
        return None


def subtract_eef_pos_from_pointcloud_obs(
    data: Mapping[str, np.ndarray | torch.Tensor],
    pc_obs_name: str = "point_cloud",
    eef_pos_obs_name: str = "robot0_eef_pos",
) -> np.ndarray | torch.Tensor:
    """Subtracts EEF position from point cloud observation."""
    assert pc_obs_name in data, f"Observation {pc_obs_name} not found in data. Cannot subtract EEF position from it."
    assert (
        eef_pos_obs_name in data
    ), f"Observation {eef_pos_obs_name} not found in data. Cannot subtract it from observation {pc_obs_name}."

    # eef pos reshaped from [n_obs_history, 3] to [n_obs_history, 1, 3]
    eef_pos = rearrange(data[eef_pos_obs_name][:], "... C -> ... 1 C")
    pc_obs = data[pc_obs_name][..., :3]

    return pc_obs - eef_pos


def subtract_eef_pos_from_actions(
    data: dict[str, np.ndarray | torch.Tensor],
    action_name: str = "action",
    eef_pos_obs_name: str = "robot0_eef_pos",
    eef_pos_obs_timesteps: int = 1,
    forward: bool = True,
) -> np.ndarray | torch.Tensor:
    """Subtracts EEF position from action. Supports forward and inverse operation."""
    assert action_name in data, f"{action_name} not found in data."
    assert (
        eef_pos_obs_name in data
    ), f"Observation {eef_pos_obs_name} not found in data, cannot subtract it from actions."

    assert data[action_name].shape[-1] in (
        7,
        10,
    ), "Subtracting EEF position from actions is only supported for input action shapes 7d or 10d"
    n_action_dims = len(data[action_name].shape)
    action = data[action_name][..., :3]
    eef_pos_obs = data[eef_pos_obs_name]

    if n_action_dims == 2:  # Without batch [horizon, action_dim]
        eef_pos_is_h = len(eef_pos_obs.shape) == 1
        eef_pos_is_t_h = len(eef_pos_obs.shape) == 2
        if eef_pos_is_h:
            eef_pos_obs = eef_pos_obs.unsqueeze(0)
        elif eef_pos_is_t_h:
            ...
        else:
            raise ValueError(f"Expected eef pos to be of shape [3] or [timestep, 3] but have: {eef_pos_obs.shape}")

    elif n_action_dims == 3:  # With batch [B, horizon, action_dim]
        eef_pos_is_bt_h = len(eef_pos_obs.shape) == 2
        eef_pos_is_b_t_h = len(eef_pos_obs.shape) == 3
        if eef_pos_is_bt_h:
            # Batch is merged with timestep. [B * timestep, 3]
            eef_pos_obs = rearrange(eef_pos_obs, "(b t) h -> b t h", t=eef_pos_obs_timesteps)
        elif eef_pos_is_b_t_h:
            ...
        else:
            raise ValueError(
                f"Expected eef pos to be of shape [B * timestep, 3] or [B, timestep, 3] but have: {eef_pos_obs.shape}"
            )
    else:
        raise ValueError(
            "Expected action to be of shape [horizon, action_dim] or [B, horizon, action_dim] but have:"
            f" {data[action_name].shape}"
        )

    assert len(eef_pos_obs.shape) == n_action_dims

    eef_pos_obs = eef_pos_obs[..., -1:, :]

    if forward:
        return action - eef_pos_obs
    else:
        return action + eef_pos_obs
