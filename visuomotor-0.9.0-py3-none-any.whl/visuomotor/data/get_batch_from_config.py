#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
"""Helper to get a batch of data based on a config. Used for tests and dev."""

import einops
import lightning as L
import omegaconf
import torch
from torch.utils.data import DataLoader

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.utils.pytorch_utils import dict_to_device


def get_batch(
    config: omegaconf.DictConfig, batch_size: int, rearrange_chanel: bool, device: torch.device | str
) -> dict:
    """Get the first batch from config's dataset. Used for dev and testing.

    Args:
        config: Full training config.
        batch_size: Number of timesteps in the batch.
        rearrange_channel: If False, the color tensor has format `b t c h w`. If True, `b t h w c`.
            You probably want False for forward and True for predict_action.
        device: torch device to load the tensors onto.

    Returns:
        The first batch in the dataset. This should be the beginning of the first episode.
    """
    L.seed_everything(seed=42, workers=True)
    dataset = VisuomotorDataset(config.data)
    dataloader = DataLoader(
        dataset,
        shuffle=False,
        batch_size=batch_size,
        pin_memory=True,
        num_workers=1,
    )
    batch = next(iter(dataloader))
    if rearrange_chanel and "color" in batch.keys():
        # predict_action wants channel at the end. training_step and forward want it before h.
        batch["color"] = einops.rearrange(batch["color"], "... c h w -> ... h w c")
    batch = dict_to_device(batch, device)
    return batch
