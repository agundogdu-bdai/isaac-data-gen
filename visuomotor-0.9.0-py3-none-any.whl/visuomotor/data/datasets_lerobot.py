#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import os
from typing import Any

import numpy as np
import torch
from lerobot.configs.types import FeatureType
from omegaconf import DictConfig

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.data.lerobot_preprocessing import (
    _normalize_image_data,
    _permute_hwc_to_chw_unified,
    process_color_observations_unified,
    process_state_observations_unified,
)


class LeVisuomotorDataset(VisuomotorDataset):

    def __init__(self, config: DictConfig, ray_worker: bool = False) -> None:
        super().__init__(config, ray_worker)
        self._build_episode_index()
        # Control whether to keep a leading time dimension when history==1
        self.keep_time_dim: bool = bool(getattr(self.config, "keep_time_dim", True))

    def __getitem__(self, idx: int) -> dict[str, np.ndarray | torch.Tensor]:
        # Get the base data from parent class
        data_dict = super().__getitem__(idx)
        # Ensure task-related metadata is present
        self._populate_task_metadata(data_dict)
        return data_dict

    def process_observation_data(self, data_dict: dict[str, np.ndarray | torch.Tensor], obs: dict) -> None:
        """Unified observation processing using enhanced preprocessing functions."""
        # Collect state data for unified processing
        state_batch = {}

        for key in self.obs_keys:
            if key == "color":
                # Use unified color processing for numpy H5 data
                # Don't convert to CHW yet if we have transforms to apply
                processed_cameras = process_color_observations_unified(
                    color_data=obs[key],
                    camera_keys=[f"color_{i}" for i in range(len(self.config.camera_ids))],
                    camera_ids=self.config.camera_ids,
                    return_dict=True,
                    normalize=False,  # Don't normalize yet if we have transforms
                    to_chw=False,  # Don't convert to CHW yet if we have transforms
                )

                # Apply transforms; keep full temporal history if requested by history > 1
                for cam_key, camera_images in processed_cameras.items():
                    hist = int(self.n_obs_history_visual) if self.n_obs_history_visual is not None else 1
                    data_dict[cam_key] = self._process_camera_images(camera_images, hist)

            elif key in self.obs_state:
                # Collect state components for unified processing
                state_batch[key] = obs[key]

        # Process state observations (unified path for both history=1 and >1)
        if state_batch:
            hist_state = int(self.n_obs_history_state) if self.n_obs_history_state is not None else 1
            processed_state_batch = process_state_observations_unified(
                state_batch,
                set(self.obs_state),
                output_key="observation.state",
                remove_individual_keys=False,
                preserve_time=(hist_state > 1),
            )

            if "observation.state" in processed_state_batch:
                state_arr = processed_state_batch["observation.state"].astype(np.float32)
                # When history==1, control presence of leading time dim via keep_time_dim
                if hist_state <= 1:
                    if self.keep_time_dim:
                        if state_arr.ndim == 1:
                            state_arr = state_arr[None, :]
                    else:
                        if state_arr.ndim == 2 and state_arr.shape[0] == 1:
                            state_arr = state_arr[0]
                data_dict["observation.state"] = state_arr

    def _populate_task_metadata(self, data_dict: dict[str, Any]) -> None:
        """Ensure `task_index` and `task` are present with minimal checks.
        Priority:
        1) Keep existing non-empty `task`
        2) Use sample `task_description` if present
        3) Fallback to `config.env.task_description`
        """
        if "task_index" not in data_dict:
            data_dict["task_index"] = torch.tensor(self.task_index, dtype=torch.long)

        # 1) Keep existing task if non-empty
        if isinstance(data_dict.get("task"), str) and data_dict["task"].strip():
            return

        # 2) From sample task_description
        if "task_description" in data_dict:
            desc = data_dict["task_description"]
            desc_str = str(desc).strip()
            if desc_str:
                data_dict["task"] = desc_str
                return

        # 3) From config.env.task_description
        env_cfg = getattr(self.config, "env", None)
        if env_cfg is not None and getattr(env_cfg, "task_description", None):
            td = str(env_cfg.task_description).strip()
            if td:
                data_dict["task"] = td
                return

        raise ValueError(
            "Missing task description. Provide `task` in the dataset sample or set `config.env.task_description`."
        )

    def _build_episode_index(self) -> None:
        """
        Build an index that maps each data point to its episode boundaries.
        This is needed for EpisodeAwareSampler to work correctly.
        """
        # Group indices by episode
        episode_groups: dict[int, list[int]] = {}
        for idx, (episode_idx, _) in enumerate(self.episode_timestep_idx):
            if episode_idx not in episode_groups:
                episode_groups[episode_idx] = []
            episode_groups[episode_idx].append(idx)

        # Create from/to boundaries
        from_indices = []
        to_indices = []
        for episode_idx in sorted(episode_groups.keys()):
            indices = episode_groups[episode_idx]
            from_indices.append(min(indices))
            to_indices.append(max(indices))

        # Store as dictionary with from/to keys
        self.episode_data_index = {"from": np.array(from_indices), "to": np.array(to_indices)}

    def _process_camera_images(self, camera_images: np.ndarray, hist: int) -> np.ndarray:
        """Process camera image sequences with optional injection hook.

        Expected input: camera_images with shape [T, H, W, C] (HWC per frame).
        Returns: CHW tensors with optional leading time dimension depending on hist/keep_time_dim.
        """
        # Default behavior
        if hist <= 1:
            # Fast path: process only the last frame
            last_img = camera_images[-1]
            if self.color_transforms:
                last_img = self.color_transforms(image=last_img)["image"]
            if self.keep_time_dim:
                last_img = _normalize_image_data(last_img[None, ...])  # [1,H,W,C]
                return _permute_hwc_to_chw_unified(last_img)  # [1,C,H,W]
            else:
                last_img = _normalize_image_data(last_img)  # [H,W,C]
                return _permute_hwc_to_chw_unified(last_img)  # [C,H,W]
        else:
            if self.color_transforms:
                camera_images = np.stack([self.color_transforms(image=t)["image"] for t in camera_images])
            camera_images = _normalize_image_data(camera_images)
            camera_images = _permute_hwc_to_chw_unified(camera_images)
            return camera_images


class CustomDatasetMetadata:
    """A minimal dataset metadata class that just uses the data path name"""

    def __init__(
        self,
        data_path: str | os.PathLike,
        input_features: dict[str, Any] | None = None,
        output_features: dict[str, Any] | None = None,
        stats: dict[str, Any] | None = None,
    ) -> None:
        self.root = data_path
        self.data_path = data_path
        self._features = {}
        self._input_features = {}
        self._output_features = {}
        self._stats = stats

        if input_features:
            for key, feature in input_features.items():
                # Store PolicyFeature objects directly
                self._input_features[key] = feature

                # Also store in legacy format for .features property
                if feature.type == FeatureType.VISUAL:
                    c, h, w = feature.shape
                    self._features[key] = {
                        "dtype": "image",
                        "shape": (h, w, c),  # Convert to H,W,C format
                        "names": ["height", "width", "channel"],
                    }
                else:
                    self._features[key] = {
                        "dtype": "float32",
                        "shape": feature.shape,
                        "names": [],
                    }

        if output_features:
            for key, feature in output_features.items():
                # Store PolicyFeature objects directly
                self._output_features[key] = feature

                # Also store in legacy format for .features property
                self._features[key] = {"dtype": "float32", "shape": feature.shape, "names": []}

    @property
    def features(self) -> dict[str, Any]:
        """Return features dict in format expected by dataset_to_policy_features"""
        return self._features

    @property
    def input_features(self) -> dict[str, Any]:
        """Return input features dict for LeRobot compatibility"""
        return self._input_features

    @property
    def output_features(self) -> dict[str, Any]:
        """Return output features dict for LeRobot compatibility"""
        return self._output_features

    @property
    def stats(self) -> dict[str, Any] | None:
        """Return empty stats dict - no normalization stats needed"""
        return self._stats

    def get_info(self) -> dict[str, Any]:
        """Return minimal dataset info"""
        return {
            "name": os.path.basename(self.data_path) if isinstance(self.data_path, str) else "custom_dataset",
            "horizon": 1,
            "version": "1.0.0",
        }

    def get_normalizer(self, *args: Any, **kwargs: Any) -> None:
        return None

    def get_features(self) -> dict[str, Any]:
        return self.features
