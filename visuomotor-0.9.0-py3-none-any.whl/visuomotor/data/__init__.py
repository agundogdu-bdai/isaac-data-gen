#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from omegaconf import DictConfig
from torch.utils.data import Dataset

from visuomotor.data.absolute_datasets import AbsoluteDataset
from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.data.vpl_video_dataset import VPLVideoDataset


def _lerobot_modules_available() -> bool:
    """
    Return **True** only if the **full** LeRobot import stack we need is present.
    """
    try:
        # Check if LeRobot is available by attempting direct import
        import lerobot.datasets.factory

        return True
    except ImportError:
        return False


try:
    from visuomotor.data.datasets_lerobot import (
        LeVisuomotorDataset,
    )

    LEROBOT_AVAILABLE = _lerobot_modules_available()
except ImportError:
    LeVisuomotorDataset = None  # type: ignore
    LEROBOT_AVAILABLE = False

MAP_TO_DATASETCLS = {
    "vplvideo": VPLVideoDataset,
    "visuomotor": VisuomotorDataset,
    "levisuomotor": LeVisuomotorDataset,
    "absolute": AbsoluteDataset,
}


def load_dataset_cls(config: DictConfig) -> Dataset:
    # TODO: need to check if we want to add this data_type param in config
    data_type = config.get("data_type", "visuomotor")
    dataset_cls = MAP_TO_DATASETCLS.get(data_type, None)
    if dataset_cls is None:
        if not LEROBOT_AVAILABLE and data_type.startswith("le"):
            raise ImportError(f"LeRobot datasets not available. Please install LeRobot dependencies to use {data_type}")
        raise NotImplementedError(f"Dataset {data_type} not implemented")
    print(f"Using dataset class {dataset_cls}")
    return dataset_cls


def is_lerobot_available() -> bool:
    """Check if LeRobot dependencies are available."""
    return LEROBOT_AVAILABLE
