#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

import importlib.util as import_util
import logging

import torch

logging.basicConfig(level=logging.INFO)


def decode_video_frames(video_path: str, timestamps_tuple: tuple, frame_indices_list: list) -> torch.Tensor:
    """decode video using torchcodec

    Args:
        video_path (str): video path
        timestamps_tuple (tuple): timestep tuple.
        frame_indices_list (list): frame index list

    Returns:
        torch.Tensor: frames that decoded from video
    """
    if import_util.find_spec("torchcodec"):
        try:
            from torchcodec.decoders import VideoDecoder  # noqa: F401

            return decode_video_frames_torchcodec(video_path, timestamps_tuple)
        except ImportError as e:
            logging.debug(f"torchcodec is found, but VideoDecoder importing failed: {e}")
            return decode_videos_frames_decord(video_path, frame_indices_list)

    else:
        logging.debug("torchcodec is not available.")
        return decode_videos_frames_decord(video_path, frame_indices_list)


def decode_video_frames_torchcodec(
    video_path: str,
    timestamps_tuple: tuple,
) -> torch.Tensor:
    """decode video using torchcodec

    Args:
        video_path (str): video path
        timestamps_tuple (tuple): timestep tuple.

    Returns:
        torch.Tensor: frames that decoded from video
    """
    # TODO: need to refactor this function to add the time tolerance
    from torchcodec.decoders import VideoDecoder

    logging.debug("Using torchcodec to decode video frames.")
    timestamps = list(timestamps_tuple)  # Convert back to list for processing
    video_path_str = str(video_path)

    # Initialize the video decoder
    decoder = VideoDecoder(video_path_str, device="cpu", seek_mode="approximate")
    # Convert timestamps from seconds to FrameBatch
    frame_batch = decoder.get_frames_played_at(seconds=timestamps)
    # Extract frames data
    frames = frame_batch.data  # This is already in the format [N, C, H, W]
    return frames


def decode_videos_frames_decord(video_path: str, indices: list) -> torch.Tensor:
    """use decord to decode video

    Args:
        video_path (str): video path
        indices (list): indieces list.


    Returns:
        torch.Tensor: frames that decoded from video
    """
    import decord
    from decord import VideoReader as DecordVideoReader
    from decord import cpu

    logging.debug("Using decord to decode video frames")

    with open(video_path, "rb") as f:
        decord_vr_cpu = DecordVideoReader(f, ctx=cpu(0))
        decord.bridge.set_bridge("torch")

        decord_cpu_frames = decord_vr_cpu.get_batch(indices)
        # to match the output of torchcodec dimension order
        decord_cpu_frames = torch.permute(decord_cpu_frames, (0, 3, 1, 2))
    return decord_cpu_frames
