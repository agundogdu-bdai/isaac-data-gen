#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any

from torch.utils.data import DataLoader

from visuomotor.logging.profiler import DATALOADER_CATEGORY, profile_function


class ProfiledDataLoaderIter:
    """
    Profiled version of base DataLoaderIter class.
    """

    @profile_function("iter", DATALOADER_CATEGORY)
    def __init__(self, dataloader: DataLoader) -> None:
        self._iter = iter(dataloader)

    def __iter__(self) -> "ProfiledDataLoaderIter":
        return self

    @profile_function("next", DATALOADER_CATEGORY)
    def __next__(self) -> Any:
        return next(self._iter)


class ProfiledDataLoader:
    """
    Profiled version of base DataLoader class.
    """

    def __init__(self, dataloader: DataLoader) -> None:
        self._dataloader = dataloader

    def __iter__(self) -> ProfiledDataLoaderIter:
        return ProfiledDataLoaderIter(self._dataloader)

    def __len__(self) -> int:
        return len(self._dataloader)
