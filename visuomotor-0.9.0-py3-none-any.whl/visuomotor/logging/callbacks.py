#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

from collections import defaultdict
from datetime import datetime
from typing import Any

import lightning.pytorch as L
import wandb
from lightning.pytorch.utilities import rank_zero_only
from wandb import Artifact

import visuomotor
from visuomotor.data.utils import DataSource, get_dataset_metadata
from visuomotor.logging.helpers import generate_wandb_dataset_artifact_name, use_wandb_artifact, wandb_artifact_exists

WANDB_DATASET_REGISTRY = "vpl-datasets"
WANDB_DATASET_REGISTRY_PROJECT = "vpl-collection-linking"
WANDB_DATASET_ARTIFACT_ALIAS = "latest"


class WandBDataRegistryCallback(L.Callback):
    """
    A callback to link a WandB dataset artifact to the current run. Dataset artifacts are pointers to dataset
    location (GCS or Data Platform) and store dataset metadata. If a dataset artifact does not exist in
    the WandB registry, it is created.
    """

    def __init__(
        self,
        data_paths: list[str],
        local_data_source: DataSource,
        tags: list[str] | None = None,
        wandb_dataset_registry: str | None = None,
        wandb_artifact_alias: str | None = None,
    ) -> None:
        """
        Args:
            data_paths: List of dataset paths to register
            local_data_source: Local data source type (DataSource enum)
            tags: Optional list of tags to add to the dataset artifact
            wandb_dataset_registry: Name of the WandB dataset registry (defaults to WANDB_DATASET_REGISTRY)
            wandb_artifact_alias: Alias for the dataset artifact (defaults to WANDB_DATASET_ARTIFACT_ALIAS)
        """
        self.data_paths = data_paths
        self.local_data_source = local_data_source
        self.tags = tags
        self.wandb_dataset_registry = wandb_dataset_registry if wandb_dataset_registry else WANDB_DATASET_REGISTRY
        self.wandb_artifact_alias = wandb_artifact_alias if wandb_artifact_alias else WANDB_DATASET_ARTIFACT_ALIAS

    def register_dataset_to_wandb(self, artifact: Artifact, registry_name: str, tags: list[str] | None = None) -> None:
        """Log dataset artifact with a new run and link to the WandB dataset registry."""
        with wandb.init(project=WANDB_DATASET_REGISTRY_PROJECT, reinit="create_new") as registry_run:
            logged_artifact = registry_run.log_artifact(
                artifact_or_path=artifact,
                type="dataset",
                tags=tags,
            )
            registry_run.link_artifact(
                artifact=logged_artifact, target_path=f"wandb-registry-{registry_name}/{artifact.name}"
            )

    @rank_zero_only
    def setup(self, trainer: L.Trainer, pl_module: L.LightningModule, stage: str) -> None:

        for data_path in self.data_paths:
            metadata = get_dataset_metadata(data_path, self.local_data_source)
            artifact_name = generate_wandb_dataset_artifact_name(data_path, metadata)

            if wandb_artifact_exists(artifact_name, self.wandb_dataset_registry, self.wandb_artifact_alias):
                print(f"Dataset {artifact_name} found in WandB dataset registry {self.wandb_dataset_registry}.")
            else:
                print(
                    f"Dataset {artifact_name} not found in WandB dataset registry {self.wandb_dataset_registry}."
                    "Constructing artifact and registering."
                )
                artifact = wandb.Artifact(name=artifact_name, metadata=metadata, type="dataset")
                self.register_dataset_to_wandb(artifact, registry_name=self.wandb_dataset_registry, tags=self.tags)

            use_wandb_artifact(artifact_name, self.wandb_dataset_registry, self.wandb_artifact_alias)


class WandBRunSummaryCallback(L.Callback):
    """
    A callback to log summary metrics, run metadata, and dataset metadata to a WandB run.
    Metadata is flattened to support nested config structures. Runs with multiple datasets
    (config.data_path) will have merged metadata with lists of values for each key.
    """

    def __init__(
        self,
        data_paths: list[str],
        local_data_source: DataSource,
        run_config: dict,
        metrics: list[dict[str, str]] | None = None,
    ) -> None:
        """
        Args:
            data_paths: List of dataset paths to register
            local_data_source: Local data source type (DataSource enum)
            run_config: Run configuration dictionary to log to WandB run summary
            metrics: List of metrics to log to WandB run summary. Each metric is a dict with keys
                'name' (str): Name of the metric
                'summary' (str): Summary operation to apply (default: 'last'). See wandb.define_metric().
        """
        self.data_paths = data_paths
        self.local_data_source = local_data_source
        self.metrics = metrics
        self.run_config = run_config

    def flatten_dict(self, data: dict, parent_key: str = "", sep: str | None = None) -> dict:
        """Flatten a nested dictionary.

        Args:
            data: The dictionary to flatten.
            parent_key: The base key string for recursion. Defaults to ''.
            sep: The separator between keys. Defaults to '.'.
        Returns:
            Flattened dictionary.
        """
        sep = sep if sep is not None else "."
        items: list[tuple[str, Any]] = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self.flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)

    def merge_dicts(self, dict_list: list[dict]) -> dict:
        """Merge a list of dictionaries.

        Args:
            dict_list: List of dictionaries to merge.
        Returns:
            Merged dictionary with lists of values for each key.
        """
        merged_dict = defaultdict(list)
        for d in dict_list:
            for key, value in d.items():
                merged_dict[key].append(value)
        return merged_dict

    @rank_zero_only
    def setup(self, trainer: L.Trainer, pl_module: L.LightningModule, stage: str) -> None:

        # Add WandB run metadata to summary
        wandb.run.summary["id"] = f"[{wandb.run.id}]({wandb.run.url})"
        wandb.run.summary["name"] = wandb.run.name
        wandb.run.summary["project"] = wandb.run.project
        wandb.run.summary["url"] = wandb.run.url
        wandb.run.summary["checkpoints"] = (
            f"[checkpoints](https://wandb.ai/bdaii/{wandb.run.project}/artifacts/model/{wandb.run.id})"
        )
        dt_object_local = datetime.fromtimestamp(wandb.run._start_time)  # noqa: SLF001
        wandb.run.summary["created_at"] = datetime.strftime(dt_object_local, "%Y%m%d-%H%M%S")

        # Add custom metrics to summary
        if self.metrics:
            print("WandB summary metrics callback - Attempting metrics parsing")
            for metric in self.metrics:
                try:
                    wandb.define_metric(metric["name"], summary=metric.get("summary", "last"))
                except wandb.Error as e:
                    print(f"wandb.Error: Caught exception while adding metric {metric}: {e}. Skipping .")
                    raise e

        # Add flattened run config to summary
        flat_config = self.flatten_dict(self.run_config)
        wandb.run.summary["vpl_version"] = visuomotor.__version__
        for k, v in flat_config.items():
            wandb.run.summary[k] = v

        # Add dataset metadata to summary
        list_of_metadata_dicts = []
        for data_path in self.data_paths:
            metadata = get_dataset_metadata(data_path, self.local_data_source)
            artifact_name = generate_wandb_dataset_artifact_name(data_path, metadata)
            metadata["datasets"] = (
                f"[{artifact_name}](https://wandb.ai/bdaii/{WANDB_DATASET_REGISTRY_PROJECT}/artifacts/dataset/{artifact_name}/latest)"
            )
            list_of_metadata_dicts.append(self.flatten_dict(metadata))
        merged_metadata = self.merge_dicts(list_of_metadata_dicts)
        for k, v in merged_metadata.items():
            wandb.run.summary[k] = v
