#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import functools
import os
import statistics
from contextlib import AbstractContextManager, nullcontext
from typing import Any, Callable, List, Optional, Tuple

from lightning.pytorch.profilers import AdvancedProfiler, SimpleProfiler
from omegaconf import DictConfig
from torch.profiler import ProfilerActivity, profile, record_function

PROFILER_NAME = "VPLProfiler"
NAME_SEPARATOR = "::"

DATALOADER_CATEGORY = "DataLoader"
DATASET_CATEGORY = "Dataset"


PROFILER_ACTIVITY_MAP = {"cpu": ProfilerActivity.CPU, "cuda": ProfilerActivity.CUDA, "xpu": ProfilerActivity.XPU}

LIGHTNING_PROFILER_MAP = {
    "simple": SimpleProfiler(),
    "advanced": AdvancedProfiler(),
    "none": None,
}


def fmt_time(t: float) -> str:
    if t >= 1e6:
        return f"{t / 1e6:.2f}s"
    elif t >= 1e3:
        return f"{t / 1e3:.2f}ms"
    return f"{t:.2f}us"


def build_name(category: str, name: str) -> str:
    """
    Build a profiler name from category and name.
    Ensures consistency across names so that we can separate them in profiling later,
    e.g. VPLProfiler::Training::Backward
    """
    return f"{PROFILER_NAME}{NAME_SEPARATOR}{category}{NAME_SEPARATOR}{name}"


def _record_function(func: Callable, name: str, category: str) -> Callable:
    """
    Wraps an arbitrary function such that the Pytorch profiler profiles it, and we can
    analyze it later. Used internally.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Callable:
        with record_function(build_name(category, name)):
            return func(*args, **kwargs)

    return wrapper


def profile_function(name: str, category: str) -> Callable:
    """
    Decorator that profiles the function it decorates. Useful for dataset/dataloader objects,
    where Pickle prevents us from changing the object directly at runtime in order to profile it.
    """

    def decorator(func: Callable) -> Callable:
        return _record_function(func, name, category)

    return decorator


def wrap_attribute_with_profiler(obj: object, method_name: str, category_name: str) -> None:
    """
    In place, wraps and replaces an attribute in an arbitrary object with its profiled version, making sure
    we profile the function whenever it's called.
    """
    original_method = getattr(obj, method_name)
    wrapper = _record_function(original_method, method_name, category_name)
    setattr(obj, method_name, wrapper)


def wrap_object_with_profiler(profiled_rank: int | None, obj: object, config: DictConfig, category_name: str) -> None:
    """
    Wraps every function specified in the config within one object with the profiler, letting us
    profile all of them. Used in e.g. setting profiling for Lightning training hooks.
    """
    if profiled_rank is not None:
        functions_to_wrap = getattr(config.profiler.functions, category_name, [])
        for func in functions_to_wrap:
            if hasattr(obj, func):
                wrap_attribute_with_profiler(obj, func, category_name)
            else:
                raise ValueError(f"Profiler wrapping failed: Function {func} not found in {obj.__class__.__name__}")


def setup_profiler(
    config: DictConfig,
) -> Tuple[Optional[int], AbstractContextManager, Optional[SimpleProfiler | AdvancedProfiler]]:
    """
    Reads from config to choose whether the Pytorch profiler should be enabled, if the Lightning profiler should be
    enabled, and which GPU is to be profiled. No-op if profiler is not enabled.
    """
    profiler_scope, rank = nullcontext(), None

    if config.get("profiler", None) is None:
        return rank, profiler_scope, None

    # if config.profiler.enabled:

    # We set CUDA_LAUNCH_BLOCKING = 1 only when profiling, so if it's set to 1 we can assume the profiler is enabled.
    profiler_enabled = os.getenv("CUDA_LAUNCH_BLOCKING", default="0") == "1"
    if profiler_enabled:
        if config.train.num_workers != 0 and "Dataset" in config.profiler.categories:
            print(
                f"{PROFILER_NAME} Warning: 'Dataset' category is profiled, but config.train.num_workers > 0, "
                "so no Dataset profiling can occur. This category will not be profiled."
            )

        rank = config.profiler.profiled_worker_rank

        import ray.train

        if rank == ray.train.get_context().get_world_rank():
            print(f"{PROFILER_NAME} enabled")
            profiler_scope = profile(
                activities=[PROFILER_ACTIVITY_MAP[act] for act in config.profiler.activities],
                record_shapes=True,
                profile_memory=True,
            )

    lightning_profiler = LIGHTNING_PROFILER_MAP.get(config.profiler.lightning_profiler, None)

    return rank, profiler_scope, lightning_profiler


def finish_profiler(profiler: profile | nullcontext, categories_to_print: List[str]) -> None:
    """
    After profiling, prints out the functions we profile in a human-readable way, tracking
    CPU time and CUDA time, including median timings.
    """
    if not isinstance(profiler, nullcontext):
        custom_profiler_events: dict[str, dict] = {}

        for event in profiler.events():
            if hasattr(event, "key") and event.key.startswith(PROFILER_NAME):
                split_key = event.key.split(NAME_SEPARATOR)
                if len(split_key) < 3:
                    continue  # skip malformed keys
                category, name = split_key[1], split_key[2]

                if category not in custom_profiler_events:
                    custom_profiler_events[category] = {}

                if name not in custom_profiler_events[category]:
                    custom_profiler_events[category][name] = {
                        "cpu_times": [],
                        "cuda_times": [],
                        "cpu_time_total": 0.0,
                        "cuda_time_total": 0.0,
                    }

                stats = custom_profiler_events[category][name]

                # Gather event times, setting negative times to 0
                event_cpu_time = max(getattr(event, "cpu_time_total", 0.0), 0.0)
                stats["cpu_times"].append(event_cpu_time)

                if hasattr(event, "device_time"):
                    event_cuda_time = max(getattr(event, "device_time", 0.0), 0.0)
                    stats["cuda_times"].append(event_cuda_time)

        for category, category_events in custom_profiler_events.items():
            for name, event_data in category_events.items():
                custom_profiler_events[category][name]["cpu_time_total"] = sum(event_data["cpu_times"])
                custom_profiler_events[category][name]["cuda_time_total"] = sum(event_data["cuda_times"])

        # Retrieve the reference fit_time for global percentage calculations
        fit_time = None
        if "Trainer" in custom_profiler_events and "fit" in custom_profiler_events["Trainer"]:
            fit_time = custom_profiler_events["Trainer"]["fit"]["cpu_time_total"]

        print("-" * 40)
        print(f"{PROFILER_NAME} Events (CPU Time, CUDA Time, Median CPU, Median CUDA):\n")

        for category, events in custom_profiler_events.items():
            if category not in categories_to_print:
                continue

            sorted_events = sorted(events.items(), key=lambda item: item[1]["cpu_time_total"], reverse=True)

            print(f"{category}:")
            max_event_len = max(len(name) for name, _ in sorted_events)

            for name, data in sorted_events:
                cpu_total = data["cpu_time_total"]
                cuda_total = data["cuda_time_total"]

                cpu_median = statistics.median(data["cpu_times"]) if data["cpu_times"] else 0.0
                cuda_median = statistics.median(data["cuda_times"]) if data["cuda_times"] else 0.0

                percent = f"({(cpu_total / fit_time) * 100:.1f}%)" if fit_time and fit_time > 0 else ""

                print(
                    f"   - {name.ljust(max_event_len)}: "
                    f"CPU {fmt_time(cpu_total)} {percent}, "
                    f"CUDA {fmt_time(cuda_total) if cuda_total > 0 else '-'}, "
                    f"Median CPU {fmt_time(cpu_median)}, "
                    f"Median CUDA {fmt_time(cuda_median) if cuda_median > 0 else '-'}"
                )

            print()

        print("-" * 40)
