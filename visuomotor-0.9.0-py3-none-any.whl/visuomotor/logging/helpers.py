#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import re
from datetime import datetime
from typing import Dict, List, Optional

import wandb
import wandb.apis.reports as wr
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.loggers import WandbLogger
from omegaconf import DictConfig, OmegaConf
from omegaconf.omegaconf import open_dict
from wandb import Artifact
from wandb.errors import CommError

from visuomotor.data.utils import DataSource
from visuomotor.utils.paths import get_checkpoints_path


def setup_resolver() -> None:
    """
    Setup resolver for $now in config. This is default in Hydra, but
    in Ray, resolver is not always available in the worker processes.
    """
    OmegaConf.register_new_resolver(
        "now",
        lambda pattern: datetime.now().strftime(pattern),
        use_cache=True,
        replace=True,
    )


def get_checkpoint_interval(config: DictConfig) -> int | None:
    """
    If running simulation and `simulation.use_checkpoints` is True,
    set to checkpoint at the sim eval interval instead of `train.checkpoint_interval`
    """
    if (
        config.get("simulation")
        and config.simulation.get("use_checkpoints", False)
        and config.simulation.get("run_sim")
    ):
        checkpoint_interval = config.simulation.run_every_n_epochs
    else:
        checkpoint_interval = config.train.checkpoint_interval
    return checkpoint_interval


def get_wandblogger_and_checkpoint_callback(config: DictConfig) -> tuple[WandbLogger, ModelCheckpoint]:

    setup_resolver()

    config = generate_run_id(config)
    checkpoint_interval_epochs = get_checkpoint_interval(config)
    checkpoint_interval_steps = config.get("train", {}).get("checkpoint_interval_steps", None)
    if checkpoint_interval_epochs is not None and checkpoint_interval_steps is not None:
        raise ValueError(
            "Both `checkpoint_interval` (epochs) and `checkpoint_interval_steps` are set. Please set only one."
        )

    if checkpoint_interval_steps is not None:
        template = config.wandb.run_id + "-{step}"
    else:
        template = config.wandb.run_id + "-{epoch}"

    save_top_k = config.train.local_save_top_k

    checkpoint_callback = ModelCheckpoint(
        dirpath=get_checkpoints_path(),
        filename=template,
        every_n_epochs=checkpoint_interval_epochs,
        every_n_train_steps=checkpoint_interval_steps,
        save_top_k=save_top_k,
    )

    wandb_init_params = get_wandb_init_params(config)
    wandb_logger_params = {
        **wandb_init_params,
        "log_model": "all",
        "checkpoint_name": config.wandb.run_id,
    }

    logger = WandbLogger(**wandb_logger_params)

    return logger, checkpoint_callback


def finish_wandb() -> None:
    # This function was moved in https://github.com/wandb/wandb/pull/6734
    # This try-except will let us support both new and old wandb versions
    try:
        # Attribute access differs by wandb version; fallback below keeps runtime compatibility.
        wandb.wandb_sdk.wandb_artifacts.get_artifacts_cache().cleanup(
            target_size=2.5e11,  # remove_temp=True
        )  # 250 GB
    except AttributeError as _:
        from wandb.sdk.artifacts.artifact_file_cache import get_artifact_file_cache

        get_artifact_file_cache().cleanup(target_size=2500000000000)

    wandb.finish()


def generate_run_id(config: DictConfig) -> DictConfig:
    if config.wandb.get("run_id") is None:
        wandb_run_id = f"{config.method_name}-{wandb.util.generate_id()}"
    else:
        wandb_run_id = f"{config.wandb.run_id}-{wandb.util.generate_id()}"
    with open_dict(config):
        config.wandb.run_id = wandb_run_id
    return config


def get_wandb_init_params(config: DictConfig) -> Dict:
    user = os.getenv("USER") or os.getenv("DOCKER_USER")
    user = user.split("_")[0] if user is not None else "unknown"

    if config.wandb.get("project"):
        wandb_project = config.wandb.project
    elif config.tune.is_tune:
        wandb_project = f"tune-{user}"
    else:
        data_label = "-".join(
            (match.group() if (match := re.search(r"[^/]+$", path)) else "") for path in iter(config.data.data_path)
        )
        if len(data_label) > 100:
            data_label = f"{len(config.data.data_path)}tasks"
        wandb_project = f"{data_label}-{user}"

    wandb_init_params = {
        "project": wandb_project,
        "name": config.wandb.get("run_id"),
        "id": config.wandb.get("run_id"),
        "tags": [p if len(p) < 64 else p[-64:] for p in list(config.data.data_path)],
        "group": None if "group" not in config else config.tune.group,
    }
    return wandb_init_params


def setup_wandb(config: DictConfig) -> wandb.run:
    wandb_init_params = get_wandb_init_params(config)
    run = wandb.init(**wandb_init_params)
    return run


def tune_columns(tune_param_dict: Dict, key_path: Optional[str] = None) -> List:
    tune_keys = []
    for key in tune_param_dict.keys():
        current_key = f"c::{key}" if key_path is None else f"{key_path}.{key}"
        if isinstance(tune_param_dict[key], dict):
            tune_keys.extend(tune_columns(tune_param_dict=tune_param_dict[key], key_path=current_key))
        else:
            tune_keys.append(current_key)
    return tune_keys


def generate_tune_report(config: DictConfig, tune_name: str, tune_param_dict: Dict) -> None:
    # create parallel coordinates plot
    project = get_wandb_init_params(config)["project"]
    tune_keys = tune_columns(tune_param_dict=tune_param_dict)
    columns = [wr.PCColumn(param) for param in tune_keys]
    columns.append(wr.PCColumn("train_loss"))
    report = wr.Report(
        project=project,
        title=f"{tune_name} tune results",
        blocks=[
            wr.PanelGrid(
                panels=[wr.ParallelCoordinatesPlot(columns=columns)],
                runsets=[wr.Runset(project=project, filters={"group": tune_name})],
            ),
        ],
    )
    report.save()


def download_checkpoint(config: DictConfig) -> str:
    artifact = wandb.Api().artifact(
        f"bdaii/{config.train.load_from_checkpoint.project_run_id}:{config.train.load_from_checkpoint.tag}",
        type="model",
    )
    artifact_dir = artifact.download()
    checkpoint_path = os.path.join(artifact_dir, "model.ckpt")
    return checkpoint_path


def wandb_artifact_exists(collection_name: str, registry_name: str, artifact_alias: str = "latest") -> bool:
    """Check if artifact exists in the WandB artifact registry."""
    artifact_name = f"bdaii-org/wandb-registry-{registry_name}/{collection_name}:{artifact_alias}"
    try:
        wandb.Api().artifact(name=artifact_name)
        return True
    except CommError as e:
        print(f"CommError raised trying to access artifact {artifact_name} from WandB: {e}.")
        return False


def use_wandb_artifact(collection_name: str, registry_name: str, artifact_alias: str = "latest") -> Artifact:
    """Retrieve a WandB artifact from the artifact registry and use it in the current run."""
    artifact_name = f"wandb-registry-{registry_name}/{collection_name}:{artifact_alias}"
    if wandb.run is None:
        raise RuntimeError(f"No active WandB run detected. Please start a WandB run to use artifact {artifact_name}.")
    try:
        artifact = wandb.run.use_artifact(artifact_or_name=artifact_name)
    except CommError as e:
        print(f"CommError raised trying to access artifact {artifact_name} from WandB: {e}.")
        raise e
    return artifact


def parse_datetime(datetime_str: str, output_fmt: str = "%Y%m%d-%H%M%S") -> str:
    """Parse a datetime string and return it in the specified output format."""
    input_fmts = [
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
    ]
    for input_fmt in input_fmts:
        try:
            dt = datetime.strptime(datetime_str, input_fmt)
            return datetime.strftime(dt, output_fmt)
        except ValueError:
            continue
    raise ValueError(f"Unable to parse datetime string: {datetime_str}")


def sanitize_wandb_artifact_name(name: str) -> str:
    """
    Sanitize artifact name. WandB artifact names may only contain alphanumeric characters, dashes,
    underscores, and dots.
    """
    return re.sub("[^a-zA-Z0-9-_.]", "-", name)


def generate_wandb_dataset_artifact_name(data_path: str, metadata: dict) -> str:
    """
    Generate a WandB artifact name for a dataset. Data Platform datasets are registerd with
    a semantically meaningful name in place of the session UUID.

    NOTE: This logic makes assumptions about the metadata schema and should be considered a
    temporary patch. DE is evaluating options for directly storing or generating semantically
    meaningful IDs for data stored in the Data Platform.
    """
    if DataSource.from_string(data_path) == DataSource.DATA_PLATFORM:
        try:
            task_name = metadata["extra_metadata"]["task_name"]
            collection_datetime = metadata["extra_metadata"]["collection_datetime"]
        except (KeyError, TypeError) as e:
            print(
                "Error raised trying to access task_name or collection_datetime from metadata. "
                f"Falling back to data_path for wandb dataset artifact name. Error: {e}."
            )
            artifact_name = data_path
        else:
            artifact_name = f"{task_name}-{parse_datetime(collection_datetime)}"
    else:
        artifact_name = data_path
    return sanitize_wandb_artifact_name(artifact_name)
