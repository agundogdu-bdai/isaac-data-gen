# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import os

from rai_tensors.logging_config import get_logger
from rai_tensors.submit_job import submit_job

import visuomotor

logger = get_logger(__name__)


def get_common_config() -> dict:
    """Returns common configuration used across all job submissions."""
    return {
        "pip_dependency_list": [
            "moviepy==1.0.3",  # remove after wandb has fixed the issue #80040
            "hyperopt",  # for ray tune hyperparameter optimization
            # "wandb[media]==0.16.5",  # for uploading sim videos
            "diffusers==0.29.0",  # remove after all clusters have been updated with new image
            "albumentations==1.4.20",  # remove after all clusters have been updated with new image
            "timm==1.0.11",  # remove after all clusters have been updated with new image
            "escnn==1.0.11",  # equidiff related
            "lie_learn==0.0.2",  # equidiff related
            "bitsandbytes>=0.45",
            "decord",  # VPLVideo related
            "torch==2.6.0",
            "lightning==2.5.1",
            "packaging",
            "onnx>=1.12.0",  # ONNX support for torch.onnx
            "onnxruntime>=1.12.0",  # ONNX runtime for model execution
            # LeRobot dependencies - use the following lines if you are using LeRobot
            "wandb[media,workspaces]>=0.16.5",
            "h5py>=3.9.0",  # Already satisfied by base dependency
            "huggingface-hub>=0.24.6",
            "transformers==4.52.3",
            "torchcodec",
            "lerobot==0.3.3",
            "gym-aloha",
            "gym_pusht",
            "pymunk==6.11.0",
            "pyserial",
            "num2words",
            "huggingface_hub[hf_transfer]",
            "accelerate",
            "grpcio==1.73.1",  # Force newer grpcio for LeRobot compatibility
        ],
        "env_vars": {
            "WANDB_API_KEY": os.getenv("WANDB_API_KEY"),
            "RAY_DATA_DISABLE_PROGRESS_BARS": "1",
            "RAY_DATA_PUSH_BASED_SHUFFLE": "1",
            "MUJOCO_GL": "egl",
            "NVIDIA_DRIVER_CAPABILITIES": "all",
            "BDAI": "/visuomotor/external/bdai",
            "HYDRA_FULL_ERROR": "1",
            "RAY_DEDUP_LOGS": "1",
            "NO_ALBUMENTATIONS_UPDATE": "1",
            "TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD": "1",
            # LeRobot variables
            "HF_TOKEN": str(os.getenv("HF_TOKEN")) if os.getenv("HF_TOKEN") is not None else "",
            "TOKENIZERS_PARALLELISM": "false",
            "HF_HUB_ENABLE_HF_TRANSFER": "1",
        },
        "py_modules": [visuomotor],
        "excludes": [
            "/datasets/",
            "/wandb/",
            "/checkpoints/",
            "/__pycache__/",
            "/.git/",
            "/.mypy_cache/",
            "/envs/spot/assets/",
            "/media/",
            "/artifacts/",
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("script_name")
    parser.add_argument("--cluster", default="ml-training-vpl")
    parser.add_argument("--ingress", action="store_true", default=False)
    parser.add_argument("--profiler", action="store_true", default=False)
    parser.add_argument("--k8s-context", default=None, choices=["gke-dev", "lam-h100", "lam-248", "wat", "cam"])
    args, unknown_args = parser.parse_known_args()
    python_args = " ".join(unknown_args)

    if args.k8s_context != "gke-dev":
        logger.info("Running on Lambda")
        is_lambda = True
    else:
        logger.info("Running on GKE")
        is_lambda = False

    if args.cluster is None and "RAY_ADDRESS" not in os.environ:
        raise ValueError(
            "Must either specify cluster in command line arguments or set `RAY_ADDRESS` environment variable."
        )
    if os.getenv("WANDB_API_KEY") is None:
        raise ValueError("Please set your WANDB_API_KEY as an env variable.")

    config = get_common_config()

    if args.profiler:
        config["env_vars"]["CUDA_LAUNCH_BLOCKING"] = "1"

    if is_lambda:
        config["env_vars"]["GOOGLE_APPLICATION_CREDENTIALS"] = "/etc/workload-identity/credential-configuration.json"

    submit_job(
        python_script_path=f"{args.script_name}.py",
        python_args=python_args,
        cluster=args.cluster,
        k8s_context=args.k8s_context,
        **config,
    )
