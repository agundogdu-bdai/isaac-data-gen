#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import ray
import ray.train
import torch
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import DataLoader, Dataset

from visuomotor.data import is_lerobot_available, load_dataset_cls
from visuomotor.ray_train.ray_tqdm_utils import tqdm_auto_ray_newline


@ray.remote
class DatasetStatisticsStore:
    """Ray actor for coordinating dataset statistics computation across workers."""

    def __init__(self) -> None:
        self.statistics: Optional[Dict] = None
        self.is_computed = False
        self.retrieval_count = 0
        self.total_workers = 0
        self.all_tasks_complete = False
        self.computation_failed = False
        self.error_message = ""

    def compute(self, dataset: Dataset, world_size: int) -> None:
        """Compute dataset statistics if not already computed."""
        if self.is_computed:
            return

        try:
            self.total_workers = world_size
            print("🚀 Ray actor: Computing dataset statistics...")
            self.statistics = _compute_dataset_statistics_implementation(dataset)
            self.is_computed = True
            print("✅ Ray actor: Dataset statistics computation completed")
        except Exception as e:
            self.computation_failed = True
            self.error_message = str(e)
            print(f"❌ Ray actor: Dataset statistics computation failed: {e}")
            raise

    def get(self) -> Optional[Dict]:
        """Get computed statistics and track retrieval."""
        if self.computation_failed:
            raise RuntimeError(f"Dataset statistics computation failed: {self.error_message}")

        if not self.is_computed:
            return None

        self.retrieval_count += 1
        if self.retrieval_count >= self.total_workers:
            self.all_tasks_complete = True

        return self.statistics

    def check_all_tasks_complete(self) -> bool:
        """Check if all workers have retrieved the statistics."""
        return self.all_tasks_complete


if is_lerobot_available():
    from lerobot.configs.types import FeatureType, PolicyFeature
    from lerobot.datasets.sampler import EpisodeAwareSampler

    from visuomotor.data.datasets_lerobot import CustomDatasetMetadata
    from visuomotor.models.policies.lerobot_utils import (
        build_dynamic_input_features,
        build_train_pipeline_config,
    )
    from visuomotor.ray_train.simulation.policy_eval_callback import (
        PolicyEvaluationCallback,
    )


def is_lerobot_workflow(config: DictConfig) -> bool:
    """
    Determine if the configuration specifies a LeRobot workflow.
    """
    return getattr(config, "method_name", "") == "lerobot"


def create_policy_evaluation_callback(config: DictConfig) -> Any:
    """
    Create policy evaluation callback for LeRobot datasets if configured.

    Note: In distributed training, the callback is created on all ranks for proper
    synchronization (all ranks must reach the barrier), but only rank 0 actually
    performs the evaluation work.

    Returns:
        PolicyEvaluationCallback instance or None
    """
    if not is_lerobot_available():
        return None

    if not ("eval" in config and config.eval.get("enabled", False)):
        return None

    # Create callback on all ranks - the callback itself handles rank 0 evaluation
    print("Creating policy evaluation callback for evaluation")

    # Get output directory safely with fallback
    output_dir = config.get("output_dir", "/root/evals/")
    if isinstance(output_dir, str):
        output_dir = Path(output_dir)
    else:
        output_dir = Path("/root/evals/")

    eval_freq = config.eval.get("frequency", 1)
    n_episodes = config.eval.get("n_episodes", 10)
    max_episodes_rendered = config.eval.get("max_episodes_rendered", 4)
    use_amp = config.train.get("use_amp", False)
    is_hf_dataset = config.data.get("is_hf_dataset", True)

    return PolicyEvaluationCallback(
        env_config=config.env,
        eval_config=config.eval,
        output_dir=output_dir,
        eval_freq=eval_freq,
        n_episodes=n_episodes,
        max_episodes_rendered=max_episodes_rendered,
        seed=config.train.seed,
        use_amp=use_amp,
        is_hf_dataset=is_hf_dataset,
    )


# TODO(ahmet): Remove this once as we don't need to compare old and new callbacks.
def create_policy_evaluation_callbacks(config: DictConfig) -> list[Any]:
    """
    Create BOTH policy evaluation callbacks (NEW and OLD) for comparison.

    Returns:
        List containing PolicyEvaluationCallback
    """
    if not is_lerobot_available():
        return []

    if not ("eval" in config and config.eval.get("enabled", False)):
        return []

    # Create both callbacks on all ranks - they handle rank 0 evaluation themselves
    print("Creating policy evaluation callback for evaluation")

    # Get output directory safely with fallback
    output_dir = config.get("output_dir", "/root/evals/")
    if isinstance(output_dir, str):
        output_dir = Path(output_dir)
    else:
        output_dir = Path("/root/evals/")

    eval_freq = config.eval.get("frequency", 1)
    n_episodes = config.eval.get("n_episodes", 10)
    max_episodes_rendered = config.eval.get("max_episodes_rendered", 4)
    use_amp = config.train.get("use_amp", False)
    is_hf_dataset = config.data.get("is_hf_dataset", True)

    # Common parameters for both callbacks
    common_params = {
        "env_config": config.env,
        "eval_config": config.eval,
        "output_dir": output_dir,
        "eval_freq": eval_freq,
        "n_episodes": n_episodes,
        "max_episodes_rendered": max_episodes_rendered,
        "seed": config.train.seed,
        "use_amp": use_amp,
        "is_hf_dataset": is_hf_dataset,
    }

    # Create NEW implementation callback
    new_callback = PolicyEvaluationCallback(**common_params)

    print("✅ Created NEW PolicyEvaluationCallback (with our fixes)")
    print("🎯 New callback will run side-by-side for comparison!")

    return [new_callback]


def flatten_visual(value: torch.Tensor) -> torch.Tensor | None:
    """
    Collapse an N-D image/video tensor to (N_total_pixels, C).

    Accepts either channel-first (..., C, H, W) or channel-last (..., H, W, C).
    Works for single, three and four channel images.
    """
    if value.ndim < 4:  # need at least (C, H, W)
        return None

    if value.shape[-1] in (1, 3, 4):  # channel-last
        # (..., H, W, C)  ->  (prod, C)
        flat = value.reshape(-1, value.shape[-1])
        return flat

    if value.shape[-3] in (1, 3, 4):  # channel-first
        # (..., C, H, W)  ->  (prod, C)
        flat = value.permute(
            *range(value.ndim - 3), value.ndim - 2, value.ndim - 1, value.ndim - 3  # keep leading dims  # H  # W
        )  # C to last
        flat = flat.reshape(-1, value.shape[-3])
        return flat

    # Could not identify a channel dim robustly
    return None


def try_load_dataset_statistics(dataset: Dataset, force_compute: bool = False) -> Tuple[Optional[Dict], Optional[Path]]:
    """Attempts to load existing dataset statistics from the dataset path.

    Checks both worker-local and canonical dataset paths to enable persistent caching
    across runs, similar to VisuomotorDataset normalization behavior.

    TODO (agundogdu): VisuomotorDataset uses LinearNormalizer with different statistics structure.
    LeRobot models require custom statistics computation with specific format.
    Goal: Merge both approaches to use unified normalizer for all model types.

    Args:
        dataset: The dataset to check for existing statistics.
        force_compute: If True, skip loading and force compute the statistics.

    Returns:
        A tuple of (stats_dict, stats_path).
        stats_dict: The loaded statistics if found, otherwise None.
        stats_path: The path to save the statistics (worker-local path).
    """
    if not hasattr(dataset, "data_path"):
        return None, None

    dataset_basename = Path(dataset.data_path).name
    candidate_paths = []

    # 1) Worker-local copy (current behavior)
    worker_stats_path = Path(dataset.data_path) / f"dataset_stats_{dataset_basename}.pt"
    candidate_paths.append(worker_stats_path)

    # 2) Canonical dataset root (shared/persistent), when available
    if hasattr(dataset, "config"):
        try:
            from visuomotor.utils.paths import get_datasets_path

            canonical_root = get_datasets_path() / dataset.config.data_path
            canonical_stats_path = canonical_root / f"dataset_stats_{dataset_basename}.pt"
            candidate_paths.append(canonical_stats_path)
        except Exception:
            # get_datasets_path not available or other error, skip canonical path
            pass

    # Try loading from any existing cache unless force_compute
    if not force_compute:
        for stats_path in candidate_paths:
            if stats_path.exists():
                print(f"Loading existing dataset statistics from {stats_path}")
                try:
                    stats_dict = torch.load(stats_path)
                    return stats_dict, worker_stats_path  # Always return worker path for saving
                except Exception as e:
                    print(
                        f"Warning: Failed to load cached statistics from {stats_path} ({e}), will continue searching..."
                    )

    # No cache found or force_compute=True
    return None, worker_stats_path


def save_dataset_statistics(stats_dict: Dict, stats_path: Path, dataset: Optional[Dataset] = None) -> None:
    """Save dataset statistics to disk.

    Saves to both worker-local and canonical dataset paths to enable persistent caching
    across runs, similar to VisuomotorDataset normalization behavior.

    TODO (agundogdu): This saves LeRobot-specific statistics format.
    VisuomotorDataset saves LinearNormalizer differently (.pt files with different structure).
    Goal: Standardize statistics saving/loading across both approaches.

    Args:
        stats_dict: The statistics dictionary to save.
        stats_path: The primary path where to save the statistics (worker-local).
        dataset: Optional dataset instance to determine canonical path for persistent caching.
    """
    paths_to_save = [stats_path]

    # Also save to canonical dataset root if available for persistent caching
    if dataset is not None and hasattr(dataset, "config"):
        try:
            from visuomotor.utils.paths import get_datasets_path

            canonical_root = get_datasets_path() / dataset.config.data_path
            canonical_stats_path = canonical_root / stats_path.name
            paths_to_save.append(canonical_stats_path)
        except Exception:
            # get_datasets_path not available or other error, skip canonical save
            pass

    # Save to all available paths
    for path in paths_to_save:
        try:
            # Ensure directory exists
            path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(stats_dict, path)
            print(f"Dataset statistics saved to {path}")
        except Exception as e:
            print(f"Warning: Failed to save dataset statistics to {path}: {e}")


def _compute_dataset_statistics_implementation(dataset: Dataset) -> Dict:
    """
    Internal implementation for computing dataset statistics.
    This is the actual computation logic separated for Ray coordination.

    TODO (agundogdu): This custom statistics computation is only for LeRobot models.
    VisuomotorDataset has its own normalizer (LinearNormalizer) with different format.
    Goal: Unify both statistics structures to use same normalizer across all model types.
    """
    print("Computing dataset statistics...")

    # Original computation logic remains unchanged
    keys = list(dataset[0].keys())
    # Use half of available CPUs for workers; keep batch size small for CI
    cpu = os.cpu_count() or 1
    num_workers = max(0, cpu // 2)
    data_loader = DataLoader(dataset, batch_size=8, num_workers=num_workers, shuffle=False)

    # Initialize statistics tracking
    stats = {}
    for key in keys:
        stats[key] = {
            "sum": 0,
            "sum_sq": 0,
            "min": None,
            "max": None,
            "count": 0,
        }

    # Handle state concatenation if needed - CRITICAL FIX
    state_component_keys = [k for k in keys if k.startswith("observation.state.") and not k.endswith("_is_pad")]
    needs_state_concatenation = state_component_keys and "observation.state" not in keys

    if needs_state_concatenation:
        # Add observation.state to keys and stats
        keys.append("observation.state")
        stats["observation.state"] = {
            "sum": 0,
            "sum_sq": 0,
            "min": None,
            "max": None,
            "count": 0,
        }
    else:
        print("✅ No state concatenation needed")

    # Accumulate statistics across all batches with progress bar
    for _, batch in enumerate(tqdm_auto_ray_newline(data_loader, desc="Computing statistics", unit="batch")):
        # CRITICAL: Handle state concatenation in each batch if needed
        if needs_state_concatenation:
            state_tensors = []
            for key in sorted(state_component_keys):  # Sort for consistency
                if key in batch:
                    state_tensors.append(batch[key])

            if state_tensors:
                # Concatenate along last dimension: [B, n_obs_steps, feat1] + [B, n_obs_steps, feat2] ->
                #   [B, n_obs_steps, feat1+feat2]
                concatenated_state = torch.cat(state_tensors, dim=-1)
                batch["observation.state"] = concatenated_state

        for key in keys:
            # Get value, ensure it's a tensor
            value = batch[key]
            if not isinstance(value, torch.Tensor):
                try:
                    value = torch.tensor(value)
                except Exception:
                    continue  # passing string or other non-tensor types

            batch_size = value.shape[0]

            # Detect visual/image keys and handle them specially
            # CRITICAL: Don't treat observation.state as visual!
            is_visual_key = (
                key.startswith(("color_", "observation.image", "observation.images"))
                or ("color" in key.lower() and not key.startswith("observation.state"))
                or ("image" in key.lower() and not key.startswith("observation.state"))
            ) and not key.startswith("observation.state")

            if is_visual_key:
                # Reshape to collapse all pixels for each channel
                flat_value = flatten_visual(value)

                if flat_value is not None:
                    # Compute statistics across all pixels for each channel
                    stats[key]["count"] += flat_value.shape[0]
                    stats[key]["sum"] += torch.sum(flat_value, dim=0)  # Sum across all pixels for each channel
                    stats[key]["sum_sq"] += torch.sum(flat_value**2, dim=0)

                    # Min/max per channel
                    batch_min, _ = torch.min(flat_value, dim=0)
                    batch_max, _ = torch.max(flat_value, dim=0)
            # Special handling for action field to match expected shape
            elif key == "action" and len(value.shape) > 2:
                # For action field with horizon - take only the first step to match pre-computed stats
                # Assuming value shape is [batch_size, horizon, action_dim]
                # Extract just the first timestep from the sequence
                value = value[:, 0]  # Take first timestep
                stats[key]["count"] += batch_size
                stats[key]["sum"] += torch.sum(value, dim=0)
                stats[key]["sum_sq"] += torch.sum(value**2, dim=0)

                # Min/max for compressed action
                batch_min, _ = torch.min(value, dim=0)
                batch_max, _ = torch.max(value, dim=0)
            else:
                # Regular handling for non-image data
                stats[key]["count"] += batch_size
                stats[key]["sum"] += torch.sum(value, dim=0)
                stats[key]["sum_sq"] += torch.sum(value**2, dim=0)

                # Regular min/max
                batch_min, _ = torch.min(value, dim=0)
                batch_max, _ = torch.max(value, dim=0)

            # Update min/max
            if stats[key]["min"] is None:
                stats[key]["min"] = batch_min
            else:
                stats[key]["min"] = torch.min(stats[key]["min"], batch_min)

            if stats[key]["max"] is None:
                stats[key]["max"] = batch_max
            else:
                stats[key]["max"] = torch.max(stats[key]["max"], batch_max)

    # Calculate final statistics
    result = {}
    for key in keys:
        # Skip keys with no data
        if stats[key]["count"] == 0:
            print(f"Warning: No valid data for key {key}, skipping")
            continue

        # Ensure count is not None and is a valid number
        count = stats[key]["count"]
        if count is None or count == 0:
            print(f"Warning: Invalid count for key {key}, skipping")
            continue

        mean = stats[key]["sum"] / count  # type: ignore

        # Calculate standard deviation
        var = (stats[key]["sum_sq"] / count) - (mean**2)  # type: ignore
        # Ensure non-negative variance (can happen due to numerical issues)
        var = torch.clamp(var, min=0.0)
        std = torch.sqrt(var)

        result[key] = {
            "mean": mean,
            "std": std,
            "min": stats[key]["min"],
            "max": stats[key]["max"],
            "count": count,
        }

    return result


# Constants for actor coordination
ACTOR_CREATION_TIMEOUT_SEC = 120  # 2 minutes for actor creation
ACTOR_CREATION_INITIAL_DELAY_SEC = 0.1  # Initial delay for exponential backoff
ACTOR_CREATION_MAX_DELAY_SEC = 2.0  # Maximum delay for exponential backoff


def _handle_single_worker_statistics(dataset: Dataset, stats_path: Optional[Path]) -> Dict:
    """
    Handle dataset statistics computation for single worker case.

    Args:
        dataset: The dataset to compute statistics for.
        stats_path: Path to save statistics cache (if available).

    Returns:
        Dictionary containing dataset statistics.
    """
    print("Single worker: computing dataset statistics directly")
    result = _compute_dataset_statistics_implementation(dataset)

    # Save computed statistics to cache
    if stats_path is not None:
        save_dataset_statistics(result, stats_path, dataset)

    return result


def _wait_for_actor_creation(actor_name: str, rank: int, timeout_sec: int = ACTOR_CREATION_TIMEOUT_SEC) -> Any:
    """
    Wait for Ray actor to be created with exponential backoff and better error handling.

    Args:
        actor_name: Name of the actor to wait for.
        rank: Current worker rank.
        timeout_sec: Maximum time to wait for actor creation.

    Returns:
        Ray actor handle.

    Raises:
        RuntimeError: If actor is not found within timeout.
    """
    print(f"Worker {rank}: Waiting for dataset statistics actor '{actor_name}'...")

    start_time = time.time()
    delay = ACTOR_CREATION_INITIAL_DELAY_SEC

    while time.time() - start_time < timeout_sec:
        try:
            store = ray.get_actor(actor_name)
            elapsed_time = time.time() - start_time
            print(f"Worker {rank}: Found dataset statistics actor after {elapsed_time:.1f}s")
            return store
        except ValueError:
            # Actor not found yet, wait with exponential backoff
            time.sleep(delay)
            delay = min(delay * 2, ACTOR_CREATION_MAX_DELAY_SEC)  # Exponential backoff with cap

    elapsed_time = time.time() - start_time
    raise RuntimeError(
        f"Worker {rank}: Failed to find dataset statistics actor '{actor_name}' "
        f"after {elapsed_time:.1f}s (timeout: {timeout_sec}s)"
    )


def _coordinate_multi_worker_statistics(
    dataset: Dataset, stats_path: Optional[Path], actor_name: str, max_retries: int, retry_delay_sec: float
) -> Dict:
    """
    Coordinate dataset statistics computation across multiple workers using Ray actor.

    Args:
        dataset: The dataset to compute statistics for.
        stats_path: Path to save statistics cache (if available).
        actor_name: Name of the Ray actor for coordination.
        max_retries: Maximum number of retries for statistics retrieval.
        retry_delay_sec: Delay between retries.

    Returns:
        Dictionary containing dataset statistics.
    """
    rank = ray.train.get_context().get_world_rank()
    world_size = ray.train.get_context().get_world_size()

    if rank == 0:
        # Rank 0 creates the actor and triggers computation
        print("Rank 0: Creating dataset statistics actor and computing...")
        store = DatasetStatisticsStore.options(name=actor_name).remote()  # type: ignore

        # Add a small delay to ensure actor is fully initialized before other workers try to find it
        time.sleep(0.5)

        # Trigger the computation
        compute_ref = store.compute.options(name=f"dataset_stats_compute_{rank}").remote(dataset, world_size)
        ray.get(compute_ref)

        # Get the computed result
        result = ray.get(store.get.options(name=f"dataset_stats_get_{rank}").remote())
        print(f"Worker {rank}: Got dataset statistics from actor")

        # Save to cache for future use
        if stats_path is not None:
            save_dataset_statistics(result, stats_path, dataset)
            print(f"Worker {rank}: Saved dataset statistics to cache")

        # Wait until all workers have retrieved the result before returning
        for i in range(max_retries):
            complete = ray.get(store.check_all_tasks_complete.options(name=f"dataset_stats_status_{rank}").remote())
            if complete:
                print(f"Worker {rank}: All workers completed, returning result")
                return result
            if i < max_retries - 1:
                time.sleep(retry_delay_sec)

        print(f"Worker {rank}: Warning - Not all workers completed, but returning result anyway")
        return result
    else:
        # Other ranks wait for the actor to be created by rank 0 with better error handling
        store = _wait_for_actor_creation(actor_name, rank)

        # Wait for the computation to complete and get the result
        print(f"Worker {rank}: Waiting for dataset statistics computation...")
        for i in range(max_retries):
            stats_result: Optional[Dict] = ray.get(store.get.options(name=f"dataset_stats_get_{rank}").remote())
            if stats_result is not None:
                elapsed_time = (i + 1) * retry_delay_sec
                print(f"Worker {rank}: Got dataset statistics after {elapsed_time:.1f}s")
                return stats_result

            # Result is None - need to wait and retry unless this is the last attempt
            is_last_attempt = i == max_retries - 1
            if not is_last_attempt:
                time.sleep(retry_delay_sec)

        raise RuntimeError(f"Worker {rank}: Failed to get dataset statistics after {max_retries} retries")


def compute_dataset_statistics(
    dataset: Dataset, force_compute: bool = False, max_retries: int = 1800, retry_delay_sec: float = 1.0
) -> Dict:
    """
    Compute dataset statistics using Ray actor coordination.

    Uses a Ray remote actor to coordinate computation across workers, eliminating
    file system race conditions and providing better error handling.

    TODO (agundogdu): This Ray-coordinated statistics computation is LeRobot-specific.
    VisuomotorDataset uses different normalization approach with LinearNormalizer.
    Goal: Merge both normalization systems to eliminate code duplication.

    Args:
        dataset: The dataset to compute statistics for.
        force_compute: If True, bypass cache and recompute statistics.
        max_retries: Maximum number of retries for actor coordination (default: 1800 = 30 minutes).
        retry_delay_sec: Delay between retries in seconds (default: 1.0).

    Returns:
        Dictionary containing dataset statistics for each key.
    """
    # Try to load from cache first (all ranks attempt this)
    cached_stats, stats_path = try_load_dataset_statistics(dataset, force_compute)
    if cached_stats is not None:
        rank = ray.train.get_context().get_world_rank()
        print(f"Worker {rank} loaded cached dataset statistics")
        return cached_stats

    # Get Ray context information
    world_size = ray.train.get_context().get_world_size()
    trial_id = ray.train.get_context().get_trial_id()
    actor_name = f"dataset_statistics_store_{trial_id}"

    if world_size == 1:
        # Single worker case - compute directly
        return _handle_single_worker_statistics(dataset, stats_path)
    else:
        # Multi-worker case: use Ray actor coordination
        return _coordinate_multi_worker_statistics(dataset, stats_path, actor_name, max_retries, retry_delay_sec)


def create_lerobot_datasets(config: DictConfig) -> Dataset:
    """
    Create LeRobot datasets (either HuggingFace or custom LeVisuomotor datasets).

    Both dataset types should handle state concatenation and action_is_pad computation
    internally.

    Returns:
        Dataset: The training dataset with metadata attached
    """
    if not is_lerobot_available():
        raise ImportError("LeRobot dependencies not available. Please install LeRobot to use LeRobot datasets.")

    # Create a TrainPipelineConfig from your config
    pipeline_config = build_train_pipeline_config(config)
    print(f"Pipeline config: {pipeline_config}")

    # Use make_dataset to create dataset if using lerobot dataset directly
    if config.data.is_hf_dataset:
        print("Creating HuggingFace dataset (should handle state concatenation and action_is_pad internally)")
        from lerobot.datasets.factory import make_dataset

        train_dataset = make_dataset(cfg=pipeline_config)
    else:
        print("Creating LeVisuomotor dataset (handles state concatenation and action_is_pad internally)")
        data_config = OmegaConf.create(config.data)
        # Ensure dataset can access env.task_description etc. without silent fallbacks
        if not hasattr(config, "env") or config.env is None:
            raise ValueError("config.env is required for LeVisuomotor datasets; set env.task_description in your YAML.")
        if not (hasattr(config.env, "task_description") and str(config.env.task_description).strip()):
            raise ValueError(
                "config.env.task_description must be set for LeVisuomotor datasets; please provide a non-empty string."
            )
        data_config.env = config.env
        data_config.data_path = next(iter(config.data.data_path))
        data_config.task_index = 0

        # Create a temporary config with the dataset_class as data_type for load_dataset_cls
        dataset_class_name = getattr(config.data, "dataset_class", "levisuomotor")
        temp_config = DictConfig({"data_type": dataset_class_name})
        DatasetClass = load_dataset_cls(temp_config)
        train_dataset = DatasetClass(config=data_config, ray_worker=True)

        # Get dataset name for statistics
        dataset_name = next(iter(config.data.data_path))
        # Check if force_compute should be enabled
        force_compute = getattr(config.data, "normalize_force_compute", False)

        # TODO (agundogdu): LeRobot models require custom statistics format, unlike VisuomotorDataset's.
        # This creates dual normalization paths. Goal: Unify to single normalizer system for all models.
        # 🚀 RAY COORDINATED STATISTICS COMPUTATION - Only rank 0 computes, others wait
        dataset_stats_cacl = compute_dataset_statistics(train_dataset, force_compute=force_compute)
        action_shape = train_dataset[0]["action"].shape
        input_features = build_dynamic_input_features(train_dataset, config)

        # Create metadata with the actual shapes from the dataset
        train_dataset_meta = CustomDatasetMetadata(
            data_path=dataset_name,
            input_features=input_features,
            output_features={"action": PolicyFeature(type=FeatureType.ACTION, shape=(action_shape[-1],))},
            stats=dataset_stats_cacl,
        )
        train_dataset.meta = train_dataset_meta

        # Show which worker computed/loaded the statistics
        rank = ray.train.get_context().get_world_rank()
        print(f"Dataset statistics ready for worker {rank}")

    # Log length only if it looks like a torch Dataset
    if hasattr(train_dataset, "__len__") and hasattr(train_dataset, "__getitem__"):
        print("Full dataset length", len(train_dataset))
    return train_dataset


def configure_lerobot_dataloader_params(train_dataset: Dataset, config: DictConfig) -> Tuple[bool, Optional[Any]]:
    """
    Configure DataLoader parameters for LeRobot datasets.

    Returns:
        Tuple of (shuffle, sampler) for DataLoader
    """
    # Configure DataLoader for LeRobot datasets
    # Use episode-aware sampler if available and configured
    sampler = None
    shuffle = False  # Don't shuffle when using a custom sampler

    try:
        # Check if we should use episode-aware sampling
        use_episode_sampler = config.data.get("use_episode_sampler", True)
        if use_episode_sampler and hasattr(train_dataset, "episode_data_index"):
            print("Using EpisodeAwareSampler for LeRobot dataset")
            sampler = EpisodeAwareSampler(
                train_dataset.episode_data_index,
                drop_n_last_frames=config.data.get("drop_n_last_frames", 0),
                shuffle=config.train.get("shuffle", True),
            )
        else:
            # Fallback to regular shuffling if episode sampler not available/configured
            shuffle = config.train.get("shuffle", True)
            print(f"Using standard DataLoader shuffling: {shuffle}")

    except Exception as e:
        print(f"Failed to create EpisodeAwareSampler, falling back to standard shuffling: {e}")
        shuffle = config.train.get("shuffle", True)

    return shuffle, sampler


def setup_cuda_device_for_lerobot(config: DictConfig) -> None:
    """
    Set up CUDA device for LeRobot workflows.
    """
    if is_lerobot_available() and hasattr(config.data, "is_hf_dataset"):
        # Only set CUDA device if we're actually using GPU
        if config.train.get("use_gpu", False) and torch.cuda.is_available():
            local_rank = ray.train.get_context().get_local_rank()
            torch.cuda.set_device(local_rank)
            print(f"Worker {ray.train.get_context().get_world_rank()} using CUDA device: {torch.cuda.current_device()}")
        else:
            print(f"Worker {ray.train.get_context().get_world_rank()} using CPU (CUDA disabled or unavailable)")
