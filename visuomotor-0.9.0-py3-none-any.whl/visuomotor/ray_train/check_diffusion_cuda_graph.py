#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import time

import hydra
import ray
import torch
from hydra import compose
from omegaconf import DictConfig, OmegaConf, open_dict

from visuomotor.models.heads.diffusion import DiffusionActionHead

torch.set_float32_matmul_precision("high")


"""
python submit_job.py check_diffusion_cuda_graph --cluster <cluster_name>
"""


@ray.remote(num_gpus=1)
def run_comparison(baseline_action_head_dict: dict, cuda_action_head_dict: dict) -> None:
    from omegaconf import DictConfig

    # Reconstruct action head configs from dictionaries
    baseline_action_head = DictConfig(baseline_action_head_dict)
    cuda_action_head = DictConfig(cuda_action_head_dict)

    device = ray.get_gpu_ids()[0]
    print(f"Using device: {device}")

    # Check CUDA availability
    if not torch.cuda.is_available():
        print("CUDA is not available. Exiting.")
        return

    time_cudas = []
    time_baselines = []
    for _ in range(10):
        # Initialize models
        torch.manual_seed(1234)
        model_baseline = DiffusionActionHead(baseline_action_head.action_head).to(device)
        torch.manual_seed(1234)
        model_cuda = DiffusionActionHead(cuda_action_head.action_head).to(device)

        # Generate random latent inputs
        B = baseline_action_head.action_head.batch_size
        H = baseline_action_head.action_head.input_dim
        latent = torch.rand(B, H, device=device)

        # -------------------------------
        # Time baseline (No CUDA Graph)
        # -------------------------------
        start_time = time.time()
        torch.manual_seed(1234)
        output_baseline = model_baseline.predict_action(latent)
        time_baseline = time.time() - start_time

        # -------------------------------
        # Time CUDA Graph version
        # -------------------------------
        start_time = time.time()
        torch.manual_seed(1234)
        output_cuda = model_cuda.predict_action(latent)
        time_cuda = time.time() - start_time

        time_cudas.append(time_cuda)
        time_baselines.append(time_baseline)

    # -------------------------------
    # Print performance comparison
    # -------------------------------
    print("\n=== Performance Comparison ===\n")
    print(f"Baseline (No CUDA Graph): {time_baseline:.4f} seconds")
    print(f"CUDA Graph:               {time_cuda:.4f} seconds")

    time_cuda = sum(time_cudas) / len(time_cudas)
    time_baseline = sum(time_baselines) / len(time_baselines)

    if time_cuda < time_baseline:
        speedup = ((time_baseline - time_cuda) / time_baseline) * 100
        print(f"Speedup: {speedup:.2f}%")
    else:
        slowdown = ((time_cuda - time_baseline) / time_baseline) * 100
        print(f"Slowdown: {slowdown:.2f}%")

    # -------------------------------
    # Validate outputs
    # -------------------------------
    print("\n=== Output Validation ===")
    print(f"Max difference: {torch.max(torch.abs(output_baseline - output_cuda)):.4f}")
    print("Sample baseline output:", output_baseline[0][0][:5])
    print("Sample CUDA output:    ", output_cuda[0][0][:5])


@hydra.main(
    version_base=None,
    config_path="pkg://visuomotor/configs",
    config_name=None,
)
def main(cfg: DictConfig) -> None:
    # Hard-coded parameters
    B, H, horizon = 32, 256, 32

    # # Create baseline config
    cfg = compose(config_name="action_head/diffusion")
    config_baseline = OmegaConf.create(cfg)

    print("1 Baseline Config:", config_baseline)
    with open_dict(config_baseline):
        config_baseline.action_head.input_dim = H
        config_baseline.action_head.horizon = horizon
        config_baseline.action_head.batch_size = B
        config_baseline.action_head.seed = 42

    # Convert to serializable dictionaries
    baseline_action_head = OmegaConf.to_container(config_baseline, resolve=True)
    config_baseline.action_head.use_cuda_graph = True
    cuda_action_head = OmegaConf.to_container(config_baseline, resolve=True)

    # Show configs
    print("Baseline Config:", baseline_action_head)
    print("CUDA Config:", cuda_action_head)

    # Initialize Ray and run comparison
    ray.init()
    future = run_comparison.remote(baseline_action_head, cuda_action_head)
    ray.get(future)


if __name__ == "__main__":
    main()
