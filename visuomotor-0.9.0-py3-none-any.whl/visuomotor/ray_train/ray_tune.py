#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Dict, Optional

import hydra
import lightning as L
import torch
import wandb
from omegaconf import DictConfig, OmegaConf
from ray import tune
from ray.data.dataset import Dataset
from ray.train import FailureConfig, RunConfig, ScalingConfig
from ray.train.torch import TorchTrainer
from ray.tune.schedulers import MedianStoppingRule
from ray.tune.search.hyperopt import HyperOptSearch

from visuomotor.logging.helpers import generate_tune_report
from visuomotor.ray_train.data.data_copy_actor import copy_to_local
from visuomotor.ray_train.ray_train import train_func


def define_search_space() -> Dict:
    # Note: The original search space is commented out
    # to focus on a specific aspect of the experiment (data simulation pairs)
    # you can uncomment it and modify it as needed.

    # search_space = {
    #     "train": {
    #         "learning_rate": {
    #             "lr": tune.loguniform(5e-5, 1e-2),
    #             "warmup_iters": tune.choice([20, 250, 10_000]),  # 10_000 to use full linear scheduler
    #         },
    #         "weight_decay": tune.choice([0, 0.001, 0.1]),
    #         "gradient_clip_val": tune.choice([None, 1.0, 2.5]),
    #     },
    #     "data": {
    #         "normalize": tune.choice([True, False]),
    #     },
    # }
    search_space = {
        "data_sim_pairs": tune.choice(
            [
                [["mimicgen/core/coffee_d0_small", "mimicgen/core/coffee_d0_small"], "coffee_d0"],
                [["mimicgen/core/hammer_cleanup_d1_small"], "hammer_cleanup_d1"],
            ]
        )
    }
    return search_space


def update_config(original: Dict, new: Dict) -> Dict:
    for key, value in new.items():
        if isinstance(value, Dict):
            original[key] = update_config(original[key], value)
        else:
            original[key] = value
    return original


def tune_model(ds: Optional[Dataset], config: DictConfig, tune_param_dict: Dict) -> None:

    # 1. Define the ray run configuration
    run_config = RunConfig(
        name=config.tune.group,
        verbose=1,
        storage_path=config.storage_path,
        failure_config=FailureConfig(
            # max_failures=2
            fail_fast=True,
        ),  # to restart failed trials up to 2 times because of pod failures
    )

    # 2. Define the ray scaling configuration
    scaling_config = ScalingConfig(
        num_workers=config.tune.num_ray_workers,
        use_gpu=config.tune.use_gpu,
        resources_per_worker={"GPU": config.tune.gpus_per_worker},
    )

    # 3. Define the ray training loop configuration
    ray_trainer = TorchTrainer(
        train_loop_per_worker=train_func,
        train_loop_config=OmegaConf.to_container(config),  # type: ignore
        scaling_config=scaling_config,
        datasets={"train": ds} if ds is not None else None,
    )

    search_alg = HyperOptSearch(
        metric="train_loss",
        mode="min",
    )

    scheduler = MedianStoppingRule(
        time_attr="epoch",
        grace_period=100,
        metric="train_loss",
        mode="min",
        min_samples_required=3,
        hard_stop=True,
    )

    # 4. Tune the model
    tuner = tune.Tuner(
        ray_trainer,
        tune_config=tune.TuneConfig(
            num_samples=config.tune.num_samples,
            max_concurrent_trials=config.tune.max_concurrent_trials,
            search_alg=search_alg,
            scheduler=scheduler,
        ),
        param_space={"train_loop_config": tune_param_dict},
        run_config=run_config,
    )

    results = tuner.fit()

    print("Best hyperparameters found were: ", results.get_best_result(metric="train_loss", mode="min"))


@hydra.main(version_base=None, config_path="pkg://visuomotor/configs", config_name="train_diffpo")
def main(config: DictConfig) -> None:
    from ray.data import DataContext

    # Disable progress bars for the tune run
    driver_ctx = DataContext.get_current()
    driver_ctx.enable_progress_bars = False
    DataContext._set_current(driver_ctx)  # noqa: SLF001
    L.seed_everything(config.train.seed)
    torch.set_float32_matmul_precision(config.train.matmul_precision)
    config.tune.is_tune = True

    tune_param_dict = define_search_space()
    print(OmegaConf.to_yaml(config))
    copy_to_local(config, overwrite=False)  # If you are sure the data is already there skip this to save time
    tune_name = f"{config.method_name}-{wandb.util.generate_id()}"
    config.tune.group = tune_name
    tune_model(ds=None, config=config, tune_param_dict=tune_param_dict)

    generate_tune_report(config, tune_name, tune_param_dict)


if __name__ == "__main__":
    main()
