#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any, Optional

import numpy as np
import pandas as pd
import torch
from einops import rearrange
from omegaconf import DictConfig

from visuomotor.perception.depth_utils import rgbd_to_point_cloud_multi
from visuomotor.utils.pose_utils import mat_to_pose10d


def get_data_version(config: DictConfig) -> str:
    data_paths = list(config.data.data_path)
    obs_visual = config.data.obs_keys.get("visual", list())
    obs_state = config.data.obs_keys.get("state", dict())
    obs_keys = [*obs_visual, *obs_state.keys()]
    horizon = config.data.horizon
    camera_ids = "-".join([str(c) for c in list(config.data.camera_ids)])
    data_version = (
        "_".join(obs_keys)
        + f"_horizon_{horizon}_cameras_{camera_ids}"
        + f"_batch_{config.train.batch_size}_max_episodes_{config.data.max_episodes}"
    )
    paths = "_".join([p.split("/")[-1] for p in data_paths])
    return f"{len(data_paths)}_DATASETS_{paths}_META_{data_version}"


def task_map_fn(row: dict, config: DictConfig) -> dict:
    """
    Map function to process the dataset.
    """
    data_paths = [p.split("/")[-1] for p in list(config.data.data_path)]
    index_map = {data_path: index for index, data_path in enumerate(data_paths)}

    row.update(
        {
            "task_index": index_map[row["task"]],
        }
    )
    return row


def generate_point_cloud(row: dict[str, Any], intrinsics_df: pd.DataFrame, config: DictConfig) -> dict:
    """
    Converts to 3D point cloud and samples if needed.
    """
    intrinsics = np.stack(intrinsics_df["intrinsics"].apply(np.array))

    if "crop_area" in config.data and config.data.crop_area:
        crop_area = [
            config.data.crop_area.min,
            config.data.crop_area.max,
        ]
    else:
        crop_area = None

    row["depth"] = row["depth"]
    row["color"] = row["color"]
    row["extrinsics"] = row["extrinsics"]
    row["path"] = row["path"].encode("utf-8") if isinstance(row["path"], np.str_) else row["path"]

    point_cloud = rgbd_to_point_cloud_multi(
        intrinsics=intrinsics,
        depth=row["depth"],
        color=row["color"],
        extrinsics=row["extrinsics"],
        crop_area=crop_area,
        camera_ids=config.data.camera_ids,
    )

    row["point_cloud"] = point_cloud

    if row["point_cloud"].shape[0] == 0:
        raise ValueError("Point cloud is empty")
    elif row["point_cloud"].shape[1] == 0:
        raise ValueError("Point cloud is empty")

    return row


def preprocess_groups(
    group: pd.DataFrame, window_size: int, obs_keys: list[str], obs_state: dict, camera_ids: list[int]
) -> dict:

    # TODO: (agundogdu) Update process_episodes function to work with point cloud
    if "point_cloud" in obs_keys:
        raise NotImplementedError(
            "Point cloud is not supported in the current pipeline. Please set user_torch_loader to True."
        )

    data = {}
    if "action" in group.keys():
        action_eef = group["action"]
    else:
        # Merging eef_pose and gripper_width to create action.
        # TODO: (agundogdu) Move this part to sample pipeline to work with point cloud
        eef_poses_list = [
            np.concatenate([mat_to_pose10d(np.array(pose)), np.array(gripper)])
            for pose, gripper in zip(group["eef_pose"], group["gripper_width"], strict=False)
        ]
        action_eef = pd.Series(eef_poses_list)

    action_gripper = group["robot0_gripper_qpos"] if "robot0_gripper_qpos" in group.keys() else group["gripper_width"]
    total_actions = action_eef.shape[0]

    assert window_size > 0, f"Window size: {window_size}"

    # Get the future action data
    future_actions = [get_window(action_eef, i, window_size, total_actions) for i in range(total_actions)]
    future_gripper = [get_window(action_gripper, i, window_size, total_actions) for i in range(total_actions)]

    if window_size == 1:
        future_actions = [x.squeeze() for x in future_actions]

    data["action"] = future_actions
    data["action_gripper"] = future_gripper

    # Get the observation data
    for key in obs_keys:
        if key == "color":
            # Convert each item in the group to a NumPy array if needed
            color = group[key].apply(lambda x: np.array(x) if not isinstance(x, np.ndarray) else x)
            color = np.array([x.astype(np.float32) / 255.0 for x in color])
            color = np.array([x[camera_ids] for x in color])
            color = np.array([rearrange(x, "n h w c -> n c h w") for x in color])
            data[key] = torch.from_numpy(np.stack(color))
        elif key == "depth":
            data[key] = group[key].apply(lambda x: np.array(x).astype(np.int32) if not isinstance(x, np.ndarray) else x)
        elif key in obs_state:
            if "robot" in group.keys():
                data[key] = group[f"robot/{key}"].apply(lambda x: np.array(x) if not isinstance(x, np.ndarray) else x)
            else:
                data[key] = group[key].apply(lambda x: np.array(x) if not isinstance(x, np.ndarray) else x)

    # Get the episode and task information
    for key in ["task", "episode"]:
        data[key] = group[key].values

    return data


def extract_episode_metadata(row: dict[str, np.ndarray]) -> Optional[dict[str, Any]]:
    # TODO (agundogdu): Use padded timestep for all datasets and remove this function.
    import re

    path = str(row["path"])
    # Regex pattern to extract task, episode, and timestep from the path
    pattern = r".*/(?P<task>(?:[^/]+/)*[^/]+)/episode_(?P<episode>\d+)/timestep_(?P<timestep>\d+)\.h5$"
    match = re.match(pattern, path)
    if match:
        task = match.group("task")
        episode = int(match.group("episode"))
        timestep = int(match.group("timestep"))
        timestep_padded = f"{timestep:05d}"

        row.update(
            {
                "id_": f"{task}_{episode}_{timestep_padded}",
                "path": path,
                "episode": episode,
            }
        )

    return row


def get_window(actions: pd.Series, index: int, window_size: int, total_actions: int) -> np.ndarray:
    # Convert the series to a numpy array first if it contains TensorArrayElement
    actions = actions.to_numpy()

    # Determine the next action index, considering the boundaries
    next_action_index = index + 1 if index + 1 < total_actions else index

    # Determine the range of actions to include in the window
    next_index = index + 1 + window_size
    if next_index <= total_actions:
        return np.stack(actions[index + 1 : next_index])

    # Collect base actions until the end of the available data
    base_actions = np.stack(actions[next_action_index:total_actions])

    # Calculate the number of actions needed to fill the window
    remaining_count = window_size - base_actions.shape[0]

    # Repeat the last action to fill the window
    repeated_actions = np.tile(actions[-1], (remaining_count,) + (1,) * (actions[-1].ndim - 1))

    # Concatenate base and repeated actions ensuring dimension compatibility
    if base_actions.ndim > 1:
        # For multi-dimensional data, ensure correct shaping for concatenation
        repeated_actions = repeated_actions.reshape((remaining_count,) + base_actions.shape[1:])
        return np.vstack([base_actions, repeated_actions])
    else:
        # For 1D data, simple concatenation works
        return np.concatenate([base_actions, repeated_actions])
