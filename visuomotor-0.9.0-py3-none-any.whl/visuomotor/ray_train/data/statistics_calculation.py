#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
"""Ray dependent utility for calculating important statistics (mean, variance, etc.) at train time"""
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import ray
import torch
from torch.utils.data import DataLoader, Dataset


@dataclass
class DatasetStatistics:
    """holds dataset statistics for a given sample/field. Supplies utilities for merging statistics across samples."""

    sample_size: int
    sample_mean: np.ndarray
    sample_variance: np.ndarray
    sample_max: np.ndarray
    sample_min: np.ndarray

    def merge_dataset_stats(self, other_stats: DatasetStatistics) -> DatasetStatistics:
        """merge self statistics with other_stats statistics

        Args:
            other_stats (DatasetStatistics): statistics from some other sample.

        Returns:
            DatasetStatistics: merged statistics.
        """
        N = self.sample_size
        M = other_stats.sample_size
        mu2 = (N / (N + M)) * self.sample_mean + (M / (N + M)) * other_stats.sample_mean
        # variance calculation
        var2 = (
            (N / (N + M)) * self.sample_variance
            + (M / (N + M) * other_stats.sample_variance)
            + ((N * M) / (N + M) ** 2.0) * (self.sample_mean - other_stats.sample_mean) ** 2.0
        )
        return DatasetStatistics(
            N + M,
            mu2,
            var2,
            np.amax(np.array([self.sample_max, other_stats.sample_max]), axis=0),
            np.amin(np.array([self.sample_min, other_stats.sample_min]), axis=0),
        )

    def merge_sample(self, sample: np.ndarray | torch.Tensor) -> DatasetStatistics:
        """merge self statistics with stats(sample)

        Args:
            sample (np.ndarray | torch.Tensor): set of samples
                Assumes: sample.shape[0] == num_sample

        Returns:
            DatasetStatistics: merged statistics
        """
        return self.merge_dataset_stats(DatasetStatistics.init_from_sample(sample=sample))

    @classmethod
    def init_from_sample(cls, sample: np.ndarray | torch.Tensor) -> DatasetStatistics:
        if isinstance(sample, torch.Tensor):
            sample = sample.numpy()
        return DatasetStatistics(
            sample_size=sample.shape[0],
            sample_mean=np.mean(sample, axis=0),
            sample_variance=np.var(sample, axis=0),
            sample_max=np.amax(sample, axis=0),
            sample_min=np.amin(sample, axis=0),
        )


@ray.remote
class StatisticsStore:
    """shared store store across ray workers"""

    def __init__(self, world_size: int) -> None:
        self.world_size = world_size
        self.stats: list[dict[str, DatasetStatistics] | None] = [None] * world_size
        self.rank_accesses: set[int] = set()

    def put(self, rank: int, data: dict[str, DatasetStatistics]) -> None:
        """add data for given worker. Will fail if overwrite attempted.

        Args:
            rank (int): worker rank
            data (dict[str, DatasetStatistics]): stats to add for given rank
        """
        if self.stats[rank] is not None:
            raise RuntimeError(f"Multiple attempted writes to store for rank {rank}")
        if not isinstance(data, dict):
            raise ValueError("Stats store requires dicts. Received {type(data)}.")
        self.stats[rank] = data

    def _merge_stats_all_fields(self, field_stats: list[dict[str, DatasetStatistics]]) -> dict[str, DatasetStatistics]:
        rx = field_stats[0]
        for fsi in field_stats[1:]:
            rx = {k: rx[k].merge_dataset_stats(fsi[k]) for k in rx}
        return rx

    def get(self, rank: int) -> tuple[dict[str, DatasetStatistics] | None, set[int] | None]:
        """get all stored data (across all workers). Returns Nones if not all ranks have reported.

        Args:
            rank (int): rank of calling worker

        Returns:
            dict[str, DatasetStatistics]: dataset statistics across all workers for each field in dataset.
            set[int]: ranks of all workers that have accessed the shared data store.
        """
        if None in self.stats:
            return None, None
        self.rank_accesses.add(rank)
        return self._merge_stats_all_fields(self.stats), self.rank_accesses  # type: ignore[arg-type]


def compute_stats_single_worker(
    dataloader: DataLoader,
    target_fields: set[str] | None = None,
) -> dict[str, DatasetStatistics]:
    """compute statistics for dataset[sample_indices] on single worker

    Args:
        dataloader (Dataloader): torch DataLoader.
            Assumes dataset yields dict[str, np.ndarray]
        target_fields (set[str] | None): if specified, only compute statistics for these fields.
            Will fail if target field not in dataloader sample.

    Returns:
        dict[str, DatasetStatistics]: statistics for each field of dataset
    """
    rx: dict[str, DatasetStatistics] = {}
    for sample in dataloader:
        if target_fields is None:
            target_fields = sample.keys()
        for k in target_fields:
            v = sample[k]
            if k not in rx:
                rx[k] = DatasetStatistics.init_from_sample(v)
            else:
                rx[k] = rx[k].merge_sample(v)
    return rx


class _DsetWrap:
    """wraps a dataset that yields either 1. a tensor, or 2. a tuple so that the wrapped
    dataset yields dictionaries. This is useful as other utilities assume dictionaries are yielded"""

    def __init__(self, dataset: Dataset) -> None:
        self._dataset = dataset

    def __len__(self) -> int:
        return len(self._dataset)

    def __getitem__(self, idx: int) -> dict[str, np.ndarray]:
        raw_sample = self._dataset[idx]
        if isinstance(raw_sample, tuple):
            return {f"field_{i}": v for i, v in enumerate(raw_sample)}
        return {"field_0": raw_sample}


def get_data_loader(
    dataset: Dataset, rank: int, world_size: int, batch_size: int = 64, num_workers: int = 8
) -> DataLoader:
    """create data loader from given rank's shard of dataset.

    Args:
        dataset (Dataset): torch dataset.
        rank (int): worker rank.
        world_size (int): world size.
        batch_size (int, optional): batch size for data loader. Defaults to 64.
        num_workers (int): argument to DataLoader.

    Returns:
        DataLoader: torch data loader.
    """
    start_idx = rank * int(len(dataset) / world_size)
    end_idx = min((rank + 1) * int(len(dataset) / world_size), len(dataset))
    return DataLoader(
        dataset=dataset, sampler=range(start_idx, end_idx), batch_size=batch_size, num_workers=num_workers
    )


def compute_statistics(
    dataset: Dataset,
    target_fields: set[str] | None = None,
    num_retries: int = 50,
    batch_size: int = 128,
    num_workers: int = 8,
) -> dict[str, DatasetStatistics]:
    """compute dataset statistics.

    When world_size > 1, each worker computes statistics for a different subset of the data.
        StatisticsStore actor is used to communicate and merge the statistics across worker.s
        Worker 0 ensures all other workers have accessed the data before existing and destroying actor.

    Args:
        dataset (Dataset): serializable torch dataset. Samples cannot be in a nested data structure.
        target_fields (set[str] | None): if specified, only compute statistics for these fields.
            Will fail if target field not in dataloader sample.
        num_retries (int): number of retries to attempt during final synchronization.
        num_workers (int): argument to DataLoader.

    Returns:
        dict[str, DatasetStatistics]: statistics for each field of dataset.
            If dataset yields single tensors: returns {'field_0': DatasetStatistics}
            If dataset yields tuple of tensors: returns {'field_i': DatasetStatistics, ...}
    """
    if not isinstance(dataset[0], dict):
        dataset = _DsetWrap(dataset=dataset)

    if ray.train.get_context().get_world_size() < 2:
        d_loader = get_data_loader(
            dataset=dataset, rank=0, world_size=1, batch_size=batch_size, num_workers=num_workers
        )
        final_stats_single = compute_stats_single_worker(dataloader=d_loader, target_fields=target_fields)
        if final_stats_single is None:
            raise RuntimeError("Error calculating statistics in single worker case")
        return final_stats_single

    rank = ray.train.get_context().get_world_rank()
    world_size = ray.train.get_context().get_world_size()

    # Get or create actor
    name = f"stats_store_{ray.train.get_context().get_trial_id()}"
    if rank == 0:
        stats_store = StatisticsStore.options(name=name).remote(world_size)  # type: ignore
    else:
        for _ in range(num_retries):
            # NOTE: waiting until rank 0 actor is created
            try:
                stats_store = ray.get_actor(name)
                break
            except:  # noqa: E722
                time.sleep(5)

    d_loader = get_data_loader(
        dataset=dataset, rank=rank, world_size=world_size, batch_size=batch_size, num_workers=num_workers
    )
    local_stats = compute_stats_single_worker(dataloader=d_loader, target_fields=target_fields)

    ray.get(stats_store.put.remote(rank, local_stats))

    final_stats: dict[str, DatasetStatistics] | None = None
    for _ in range(num_retries):
        final_stats, accesses = ray.get(stats_store.get.remote(rank))
        if final_stats is not None:
            if rank > 0:
                return final_stats
            elif len(accesses) >= world_size:
                # worker 0 waits until all other workers have accessed final result
                return final_stats
        time.sleep(5)
    raise RuntimeError(f"worker {rank} did not complete")
