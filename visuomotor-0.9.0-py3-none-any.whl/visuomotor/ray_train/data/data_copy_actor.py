#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import shutil
import subprocess
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Set, Type

import ray
from dippy.client import Client as DippyClient
from dippy.client import DatasetSelector
from dippy.client.delegates.disk import create_download_to_disk_delegate
from filelock import FileLock
from google.auth.exceptions import OAuthError
from google.cloud import storage
from omegaconf import DictConfig

from visuomotor.ray_train.data.utils import get_bucket_from_gcs_uri, get_prefix_from_gcs_uri
from visuomotor.utils.paths import (
    DATASET_METADATA_FILENAME,
    DataSource,
    get_base_gcs_path,
    get_dippy_data_path,
    get_ray_worker_data_path,
)


@dataclass
class DataCopyRefs:
    """Source and destination references for a copy operation."""

    src: str
    """Source full path or data platform session ID."""
    dst: str
    """Destination local path on the Ray worker."""


class RayCopyExecutor(ABC):

    @abstractmethod
    def execute_copy(self, src: str, dst: str) -> None:
        """Execute the copy operation with a specific client.

        Args:
            src: Source data location. May be a path or data platform session ID.
            dst: Destination data location, a local path on the Ray worker.
        """
        ...

    @abstractmethod
    def list_remote_files(self, src: str) -> Set[str]:
        """List the set of remote files in the given source path.

        Args:
            src: Source data location. May be a path or data platform session ID.
        Returns:
            A set of relative file paths found in the remote storage.
        """
        ...

    def list_local_files(self, path: str) -> Set[str]:
        """List the set of local files in the given path.

        Args:
            path: Local path to search for files.
        Returns:
            A set of relative file paths found in the directory.
        """
        local_files = set()
        for root, _, files in os.walk(path):
            for file in files:
                full_path = os.path.relpath(os.path.join(root, file), path)
                local_files.add(full_path)
        return local_files

    def validate_data(self, src: str, dst: str) -> bool:
        """Validate the .h5 episode files in the local path against remote storage.

        Args:
            src: Source data location. May be a path or data platform session ID.
            dst: Destination data location, a local path on the Ray worker.
        Returns:
            Boolean indicating whether the data is valid.
        """

        local_files = {file for file in self.list_local_files(str(dst)) if file.endswith(".h5")}
        remote_files = {file for file in self.list_remote_files(src) if file.endswith(".h5")}

        extra_in_local = local_files - remote_files
        extra_in_remote = remote_files - local_files
        if extra_in_local:
            print("Files present locally but not in remote storage (first up to 10):")
            print(f"Extra in local: {list(extra_in_local)[:10]}")
        if extra_in_remote:
            print("Files present in remote storage but not locally (first up to 10):")
            print(f"Extra in remote storage: {list(extra_in_remote)[:10]}")

        return len(extra_in_local) == 0 and len(extra_in_remote) == 0

    def copy_required(self, overwrite: bool, path_exists: bool, is_valid: bool) -> bool:
        """Determine if the copy operation is required.

        Args:
            overwrite: Boolean indicating whether to overwrite existing data.
            path_exists: Boolean indicating whether the destination path already exists.
            is_valid: Boolean indicating whether the existing data is valid.
        Returns:
            Boolean indicating whether the copy operation is required.
        """
        if overwrite:
            return True
        elif not is_valid:
            return True
        elif not path_exists:
            return True
        return False

    def copy_data_to_ray_worker(self, src: str, dst: str, overwrite: bool = False) -> None:
        """Copy the data from source to the root directory of the Ray worker.

        Args:
            src: Source data location. May be a path or data platform session ID.
            dst: Destination data location, a local path on the Ray worker.
            overwrite: Boolean indicating whether to overwrite existing data.
        """

        print(f"Copying data from {src} to {dst}")

        lock_file = Path(dst).with_suffix(".lock")
        is_valid = False
        path_exist = os.path.exists(dst)

        if path_exist and not overwrite:
            if self.validate_data(src, dst):
                is_valid = True
                if os.path.exists(lock_file):
                    print(f"Files are locked and data is valid: {dst}, cleaning lock and skipping copy.")
                    os.remove(lock_file)
                return
            else:
                print(f"Files are locked! and Data validation failed for: {dst}, retrying copy.")

        with FileLock(lock_file):
            if path_exist and not overwrite:
                print(f"Data already exists in: {dst}, validating data...")
                is_valid = self.validate_data(src, dst)
                print(f"Data validation result: {is_valid}")

            if self.copy_required(overwrite, path_exist, is_valid):
                os.makedirs(dst, exist_ok=True)

                try:
                    self.execute_copy(src, dst)
                except Exception as e:
                    print(f"Error occurred: {e}. Copy process terminated.")
                    raise

                if self.validate_data(src, dst):
                    print(f"Data is copied to: {dst}")
                else:
                    print(f"Data validation failed after copying to: {dst}")
                    os.remove(lock_file)
                    sys.exit(1)
            else:
                print(f"Data already exists in: {dst}, skipping copy.")


class GCSRayCopyExecutor(RayCopyExecutor):
    """Handles copy operations from GCS to Ray workers using a Ray remote actor."""

    def execute_copy(self, src: str, dst: str) -> None:
        """Execute the copy operation from GCS to local path.
        Args:
            src: Source GCS path.
            dst: Destination local path on the Ray worker.
        """
        env = {}
        if creds := os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"):
            env["CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE"] = creds
        copy_process = subprocess.Popen(["gcloud", "storage", "rsync", "-r", src, dst], env=env)
        try:
            copy_process.wait()
        except Exception as e:
            try:
                copy_process.terminate()
                copy_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                copy_process.kill()
                copy_process.wait()
            print(f"Error occurred during gcloud storage rsync from {src} to {dst}: {e}.")
            raise

    def list_remote_files(self, src: str) -> Set[str]:
        """List the set of remote files in the given GCS path."""
        bucket_name = get_bucket_from_gcs_uri(src)
        base_prefix = get_prefix_from_gcs_uri(src)

        # Ensure prefix ends with '/' to list directory contents (not siblings)
        # e.g., "mimicgen_v2/core/stack_d1" -> "mimicgen_v2/core/stack_d1/"
        directory_prefix = base_prefix.rstrip("/") + "/"

        storage_client = storage.Client()
        bucket = storage_client.get_bucket(bucket_name)

        # Recurse under the exact directory prefix; exclude siblings by requiring prefix match with trailing '/'
        remote_files: Set[str] = set()
        for blob in bucket.list_blobs(prefix=directory_prefix):
            name = blob.name
            if not name.startswith(directory_prefix):
                continue
            # Strip the directory prefix to return relative paths
            rel = name[len(directory_prefix) :]
            if not rel:  # skip the directory itself
                continue
            remote_files.add(rel)
        return remote_files


class DPRayCopyExecutor(RayCopyExecutor):
    """Handles copy operations from the data platform to Ray workers using a Ray remote actor."""

    def __init__(self) -> None:
        self.client = DippyClient()

    def query_data_platform(self, id_name_or_fragment: str, expected_num_results: int = 1) -> list:
        """Query the data platform for a dataset by ID, name, or fragment.

        Args:
            id_name_or_fragment: The ID, name, or fragment of the dataset to query.
            expected_num_results: The expected number of results from the query.
        Returns:
            A list of datasets matching the query.
        """
        result = self.client.query(id_name_or_fragment=id_name_or_fragment, dataset_type=DatasetSelector.RAW)
        assert len(result) == expected_num_results, f"Expected {expected_num_results} results, got {len(result)}."
        return result

    def execute_copy(self, src: str, dst: str) -> None:
        """Execute the copy operation from the data platform to local path.
        Args:
            src: Source data platform session ID.
            dst: Destination local path on the Ray worker.
        """

        # Download data and session metadata using the dippy client
        delegate = create_download_to_disk_delegate(parent_directory=Path(dst).parent, include_metadata=True)
        self.client.read(src, delegate=delegate)
        try:
            shutil.move(Path(dst) / "metadata.json", Path(dst) / DATASET_METADATA_FILENAME)
        except OSError as e:
            print(f"Error moving data platform metadata file: {e}.")
            raise

        # Remove `data` prefix imposed by dippy read/write delegates
        dippy_data_dst = get_dippy_data_path(Path(dst))
        for f in os.listdir(dippy_data_dst):
            shutil.move(dippy_data_dst / f, os.path.join(dst, f))
        os.rmdir(dippy_data_dst)

    def list_remote_files(self, src: str) -> Set[str]:
        """List the set of remote files in the given data platform session ID."""

        result = self.query_data_platform(src, expected_num_results=1)[0]
        bucket_blob_pairs = self.client.list_dataset_contents(result)
        remote_files = []
        for _, blob in bucket_blob_pairs:
            dippy_data_src = get_dippy_data_path(Path(src))
            sanitized_blob = os.path.relpath(blob, dippy_data_src)
            remote_files.append(sanitized_blob)
        return set(remote_files)


def copy_to_local(config: DictConfig, overwrite: bool = False) -> None:
    """Copy data from GCS or data platform to the local Ray worker.
    Args:
        config: DictConfig object containing data paths. Data paths may consist of paths or data platform session IDs.
        overwrite: Boolean indicating whether to overwrite existing data.
    """

    # Parse source and destination references
    srcs = list(config.data.data_path)
    if any([True for ref in srcs if ref.endswith("/")]):
        print(
            "Warning! Trailing slash in data_path: Your input has been sanitized automatically, "
            "but please remove it to silence this warning in future."
        )
        srcs = [ref.rstrip("/") for ref in srcs]

    base_bucket = config.data.base_bucket
    base_gcs_path = f"gs://{base_bucket}/{get_base_gcs_path()}"
    local_data_source = DataSource(config.data.local_data_source_str)

    gcs_data_refs = [
        # (src, dst): (gcs path, ray worker path)
        DataCopyRefs(f"{base_gcs_path}/{ref}", f"{get_ray_worker_data_path(local_data_source)}/{ref}")
        for ref in srcs
        if DataSource.from_string(ref) == DataSource.PATH  # Default data source type is mapped to a GCS path
    ]
    dp_data_refs = [
        # (src, dst): (data platform session id, ray worker path)
        DataCopyRefs(ref, f"{get_ray_worker_data_path(local_data_source)}/{ref}")
        for ref in srcs
        if DataSource.from_string(ref) == DataSource.DATA_PLATFORM
    ]
    assert len(gcs_data_refs + dp_data_refs) == len(srcs), "Failed to parse data references from data.data_path config."

    def _run_copy_to_local_with_executor(
        data_refs: list[DataCopyRefs], executor_class: Type[RayCopyExecutor], num_train_nodes: int
    ) -> None:
        """Run copy tasks for each training node and data reference using a specific RayCopyExecutor

        Args:
            data_refs: List of DataCopyRefs. DataCopyRefs contain source and destination for copy.
            executor_class: RayCopyExecutor class.
            num_train_nodes: Number of training nodes to copy to.
        """
        bundles = [{"train": 0.001, "CPU": 1} for _ in range(num_train_nodes)]
        pg = ray.util.placement_group(strategy="STRICT_SPREAD", bundles=bundles)
        ray.get(pg.ready())

        # Launch copy tasks
        executors = [
            ray.remote(executor_class).options(placement_group=pg, resources={"train": 0.001}, num_cpus=1).remote()
            for _ in range(num_train_nodes)
        ]  # type: ignore[attr-defined]

        executors_and_data_refs = [(executor, data_ref) for executor in executors for data_ref in data_refs]
        ray.get(
            [
                executor.copy_data_to_ray_worker.options(max_task_retries=3, retry_exceptions=[OAuthError]).remote(
                    data_ref.src, data_ref.dst, overwrite
                )
                for executor, data_ref in executors_and_data_refs
            ]
        )
        # Kill the executors
        for executor in executors:
            ray.kill(executor)

    # Run copy for GCS and data platform data sources
    num_train_nodes = int(ray.cluster_resources()["train"])
    print(f"Number of train nodes: {num_train_nodes}")
    if gcs_data_refs:
        _run_copy_to_local_with_executor(gcs_data_refs, GCSRayCopyExecutor, num_train_nodes)
    if dp_data_refs:
        _run_copy_to_local_with_executor(dp_data_refs, DPRayCopyExecutor, num_train_nodes)
