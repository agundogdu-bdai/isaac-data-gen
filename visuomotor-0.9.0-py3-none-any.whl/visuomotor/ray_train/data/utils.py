#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.
from google.cloud import storage
from google.cloud.exceptions import Forbidden, NotFound


def check_data_exists(bucket_name: str, data_path: str) -> bool:
    try:
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        blobs = bucket.list_blobs(prefix=data_path)
        return any(blob.name.lower().endswith(".parquet") for blob in blobs)
    except NotFound:
        print(f"Bucket '{bucket_name}' not found.")
        return False
    except Forbidden:
        print(f"Access to bucket '{bucket_name}' is forbidden.")
        return False
    except Exception as e:
        print(f"An error occurred: {e}")
        return False


def get_bucket_from_gcs_uri(uri: str) -> str:
    """Extract the bucket name from a GCS URI."""
    if uri.startswith("gs://"):
        return uri.split("gs://")[1].split("/")[0]
    raise ValueError(f"Invalid GCS URI: {uri}")


def get_prefix_from_gcs_uri(uri: str) -> str:
    """Extract the prefix from a GCS URI."""
    if uri.startswith("gs://"):
        bucket = get_bucket_from_gcs_uri(uri)
        return uri.split(f"gs://{bucket}/")[1]
    raise ValueError(f"Invalid GCS URI: {uri}")
