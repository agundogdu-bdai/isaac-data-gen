#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
from typing import Any, Iterable, Optional, Protocol

import lightning as L
from omegaconf import DictConfig


class TrainingComponentsBuilder(Protocol):

    def __call__(
        self, world_rank: int, config: DictConfig
    ) -> tuple[
        DictConfig, Iterable[dict[str, Any]], Optional[Iterable[dict[str, Any]]], L.LightningModule, dict[str, Any]
    ]:
        """build training components on demand

        Args:
            world_rank (int): distributed world rank
            config (DictConfig): training configuration

        Returns:
            DictConfig: modified configuration
            Iterable[dict[str, Any]]: training dataset
            Optional[Iterable[dict[str, Any]]]: optional validation dataset
            L.LightningModule: policy lightning module
            dict[str, Any]: lightning trainer keyword arguments
        """
        ...
