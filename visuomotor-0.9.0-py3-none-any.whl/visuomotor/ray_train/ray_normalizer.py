#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import time
from typing import Optional

import ray
import ray.train
from omegaconf import DictConfig
from torch.utils.data import Dataset

from visuomotor.data.datasets import config_to_limit_overrides, get_normalizers
from visuomotor.utils.normalizer import LinearNormalizer


@ray.remote
class NormalizerStore:
    def __init__(self) -> None:
        self.normalizer = None
        self.is_set = False
        self.retrieval_count = 0
        self.total_workers = 0
        self.all_tasks_complete = False

    def compute(self, datasets: Dataset, config: DictConfig, world_size: int) -> None:
        """Compute normalizer if not already computed."""
        if self.is_set:
            return

        try:
            self.total_workers = world_size
            limit_overrides = config_to_limit_overrides(config)
            normalizer = get_normalizers(
                dataset=datasets,
                keys=config.data.norm_keys,
                mode=config.data.norm_mode,
                force_compute=config.data.normalize_force_compute,
                batch_size=config.train.batch_size,
                limit_overrides=limit_overrides,
                normalize_action_pos_only=config.data.get("normalize_action_pos_only", False),
                normalize_action_gripper_only=config.data.get("normalize_action_gripper_only", False),
                gripper_idxs=config.data.get("gripper_idxs"),
            )
            self.normalizer = normalizer  # type: ignore
            self.is_set = True
        except Exception as e:
            print(f"[NormalizerStore] Exception in compute(): {e}")
            raise

    def get(self) -> Optional[LinearNormalizer]:
        """Get normalizer and track retrieval."""
        if not self.is_set:
            return None
        self.retrieval_count += 1
        if self.retrieval_count >= self.total_workers:
            self.all_tasks_complete = True
        return self.normalizer

    def check_all_tasks_complete(self) -> bool:
        return self.all_tasks_complete


def compute_normalizer_single_worker(
    datasets: Dataset,
    config: DictConfig,
    max_retries: int = 100,
    delay_between_retries_sec: float = 1.0,
) -> LinearNormalizer:
    """
    Get or compute normalizer using a distributed actor.
    The rank 0 worker creates the actor and triggers the computation,
    while non rank 0 workers wait (with retries) until the named actor is available.
    """
    rank = ray.train.get_context().get_world_rank()
    world_size = ray.train.get_context().get_world_size()
    trial_id = ray.train.get_context().get_trial_id()
    name = f"normalizer_store_{trial_id}"

    # Get or create actor
    if rank == 0:
        store = NormalizerStore.options(name=name).remote()  # type: ignore
    else:
        store = None
        for i in range(max_retries):
            try:
                store = ray.get_actor(name)
                break  # Found the actor, break out of the loop.
            except ValueError:
                # Optionally, you could also catch GetActorError.
                print(f"[Worker {rank}] Actor '{name}' not found, retrying ({i+1}/{max_retries})...")
                time.sleep(delay_between_retries_sec)
        if store is None:
            raise RuntimeError(f"[Worker {rank}] Failed to get the actor '{name}' after {max_retries} retries.")

    if rank == 0:
        # Trigger computation on the actor.
        compute_ref = store.compute.options(name=f"normalizer_store_compute_{rank}").remote(
            datasets, config, world_size
        )
        ray.get(compute_ref)

        # Retrieve the computed normalizer.
        result = ray.get(store.get.options(name=f"normalizer_store_get_{rank}").remote())
        print(f"[Worker {rank}] Got normalizer: {result}")

        # Wait until all workers have retrieved the result.
        for i in range(max_retries):
            complete = ray.get(
                store.check_all_tasks_complete.options(name=f"normalizer_store_get_status_{rank}").remote()
            )
            if complete:
                return result
            print(f"[Worker {rank}] Waiting for all tasks to complete ({i+1}/{max_retries})...")
            time.sleep(delay_between_retries_sec)
    else:
        # For non rank 0 workers, retry until the normalizer is available.
        for i in range(max_retries):
            result = ray.get(store.get.options(name=f"normalizer_store_get_{rank}").remote())
            if result:
                print(f"[Worker {rank}] Got normalizer: {result}")
                return result
            print(f"[Worker {rank}] Normalizer not available yet, retrying ({i+1}/{max_retries})...")
            time.sleep(delay_between_retries_sec)
    raise RuntimeError(f"[Worker {rank}] Failed to get normalizer")
