#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import math
from typing import Any, Iterable, Optional

import hydra
import lightning as L
import ray
import ray.train
import torch
from lightning.pytorch.utilities import model_summary
from omegaconf import DictConfig, OmegaConf, open_dict
from ray.data import DataContext
from torch.utils.data import DataLoader

from visuomotor.data.vpl_video_ray_dataset import create_dataset as create_ray_dataset
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.models.protocols import Policy
from visuomotor.ray_train.data.data_copy_actor import copy_to_local
from visuomotor.ray_train.ray_train_anymodel import train_vpl
from visuomotor.utils.normalizer import LinearNormalizer


class RayDatasetTrainingComponentsBuilder:

    def __call__(
        self, world_rank: int, config: DictConfig
    ) -> tuple[
        DictConfig, Iterable[dict[str, Any]], Optional[Iterable[dict[str, Any]]], L.LightningModule, dict[str, Any]
    ]:
        """build training components on demand for Ray Train

        Args:
            world_rank (int): distributed world rank
            config (DictConfig): training configuration

        Returns:
            DictConfig: updated configuration. Typically, only max_steps will be updated.
            Iterable[dict[str, Any]]: training dataset
            Optional[Iterable[dict[str, Any]]]: optional validation dataset
            L.LightningModule: policy lightning module
            dict[str, Any]: lightning trainer keyword arguments
        """
        config = OmegaConf.create(config)

        L.seed_everything(config.train.seed, workers=True)
        torch.set_float32_matmul_precision(config.train.matmul_precision)

        # 1. Fetch DataIterator
        train_ds = ray.train.get_dataset_shard("train")
        # Get information about the iterator
        train_ds_loader = train_ds.iter_torch_batches(
            batch_size=config.train.batch_size, prefetch_batches=config.train.get("prefetch_batches", 1)
        )
        valid_ds_loader: Optional[DataLoader] = None

        length_dataset = config.data.dataset_size
        if length_dataset == 0:
            raise ValueError("No data found in the dataset.")
        if config.train.max_steps is None:
            config.train.max_steps = config.train.max_epochs * math.ceil(
                length_dataset / (config.train.batch_size * config.train.num_ray_workers)
            )

        # 2. Define the model
        model: Policy = REGISTRY.create_model(config=config, model_type=ModelType.POLICY)
        assert isinstance(model, Policy)

        if config.data.normalize:
            normalizer_path = config.data.normalizer_path
            print("Loading existing normalizer from", normalizer_path)
            normalizer = LinearNormalizer.load(normalizer_path)
            model.normalizer = normalizer

        print("\nModel created")
        print(model)
        print("\n\n")
        print(model_summary.summarize(model, max_depth=1))
        print("\n\n")

        # use limit_train_batches to fix the progress bar, since we don't have len attribute,
        # this is batch per worker
        total_train_batch = math.ceil(length_dataset / (config.train.batch_size * config.train.num_ray_workers))
        trainer_kwargs = {
            "accelerator": config.train.accelerator,
            "max_epochs": config.train.max_epochs,
            "max_steps": config.train.max_steps,
            "num_nodes": config.train.num_nodes,
            "precision": config.train.precision,
            "gradient_clip_val": config.train.gradient_clip_val,
            "log_every_n_steps": config.train.log_every_n_steps,
            "enable_model_summary": config.train.enable_model_summary,
            "limit_train_batches": total_train_batch,
        }
        return config, train_ds_loader, valid_ds_loader, model, trainer_kwargs


@hydra.main(version_base=None, config_path="pkg://visuomotor/configs", config_name=None)
def main(config: DictConfig) -> None:
    ctx = DataContext.get_current()
    ctx.enable_tensor_extension_casting = False

    print(OmegaConf.to_yaml(config))
    copy_to_local(config, overwrite=False)  # If you are sure the data is already there skip this to save time

    ray_datasets, normalizer_path, total_count = ray.get(create_ray_dataset.remote(config.data, config.train.seed))

    with open_dict(config):
        config.data.dataset_size = total_count
    print(f"Total dataset size: {config.data.dataset_size}")

    if config.data.normalize:
        if normalizer_path is None:
            raise ValueError("Normalizer computation failed. Ensure the datasets and configuration are correct.")
        with open_dict(config):
            config.data.normalizer_path = normalizer_path

    train_vpl(ds=ray_datasets, config=config, train_builder_class=RayDatasetTrainingComponentsBuilder)


if __name__ == "__main__":
    main()
