#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.


from typing import Any

import ray
from lightning.pytorch.callbacks import TQDMProgressBar
from tqdm import tqdm, trange
from tqdm.auto import tqdm as tqdm_auto

TQDM_NEWLINE_BAR_FORMAT = "{l_bar}{bar}{r_bar}\n"


def tqdm_ray_newline(*args: Any, **kwargs: Any) -> Any:
    """
    Progress bar that inserts newlines between outputs when running in Ray
    """
    kwargs["bar_format"] = TQDM_NEWLINE_BAR_FORMAT if ray.is_initialized() else None
    return tqdm(*args, **kwargs)


def trange_ray_newline(*args: Any, **kwargs: Any) -> Any:
    """
    Range progress bar that inserts newlines between outputs when running in Ray
    """
    kwargs["bar_format"] = TQDM_NEWLINE_BAR_FORMAT if ray.is_initialized() else None
    return trange(*args, **kwargs)


def tqdm_auto_ray_newline(*args: Any, **kwargs: Any) -> Any:
    """
    Range progress bar that inserts newlines between outputs when running in Ray
    """
    kwargs["bar_format"] = TQDM_NEWLINE_BAR_FORMAT if ray.is_initialized() else None
    return tqdm_auto(*args, **kwargs)


class NewlineProgressBar(TQDMProgressBar):
    """
    Version of Lightning's Progress bar that outputs a separate line for each step
    """

    BAR_FORMAT = TQDMProgressBar.BAR_FORMAT + "\n"
