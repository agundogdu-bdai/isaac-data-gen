#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import datetime
from typing import Any, Dict, List, Optional

import ray.train
import wandb
import wandb.util
from lightning.pytorch.callbacks import TQDMProgressBar
from lightning.pytorch.callbacks.callback import Callback
from omegaconf import DictConfig, OmegaConf
from ray.air.integrations.wandb import WandbLoggerCallback
from ray.tune.experiment import Trial

from visuomotor.data import is_lerobot_available
from visuomotor.data.utils import DataSource
from visuomotor.logging.callbacks import WandBDataRegistryCallback, WandBRunSummaryCallback
from visuomotor.ray_train.callbacks import RayTrainReportCallbackCustom

# Conditional imports for LeRobot functionality
if is_lerobot_available():
    from visuomotor.ray_train.ray_lerobot_utils import (
        is_lerobot_workflow,
    )


class NewlineProgressBar(TQDMProgressBar):
    """
    Version of Lightning's Progress bar that outputs a separate line for each step
    """

    BAR_FORMAT = TQDMProgressBar.BAR_FORMAT + "\n"


def create_training_callbacks(config: DictConfig, checkpoint_callback: Optional[Callback]) -> list[Callback]:
    """
    Create all training callbacks safely and return them as a list.

    Args:
        config: Training configuration
        checkpoint_callback: The checkpoint callback (optional)

    Returns:
        List of callbacks to be used in Lightning trainer
    """
    callbacks = []
    if checkpoint_callback is not None:
        callbacks.append(checkpoint_callback)

    # Safely add RayTrainReportCallbackCustom if it exists
    ray_callback = RayTrainReportCallbackCustom(frequency=config.train.checkpoint_interval)
    callbacks.append(ray_callback)
    print("Added RayTrainReportCallbackCustom")

    # Add simulation callback if configured
    if "simulation" in config and config.simulation.get("run_sim", False):
        from visuomotor.ray_train.simulation.simulation_callback import SimulationValidationCallback

        if ray.train.get_context().get_world_rank() == 0:
            sim_callback = SimulationValidationCallback(
                config.simulation, max_groups_per_manager=config.simulation.get("max_groups_per_manager", 10)
            )
            callbacks.append(sim_callback)
            print("Added SimulationValidationCallback")

    # Add policy evaluation callback for LeRobot datasets
    if is_lerobot_available() and is_lerobot_workflow(config):
        from visuomotor.ray_train.ray_lerobot_utils import create_policy_evaluation_callbacks

        policy_eval_callbacks = create_policy_evaluation_callbacks(config)
        if policy_eval_callbacks:
            callbacks.extend(policy_eval_callbacks)
            print("Added PolicyEvaluationCallback")

    # Add Stochastic Weight Averaging if configured
    if config.train.stochastic_weighted_average is not None:
        try:
            from lightning.pytorch.callbacks import StochasticWeightAveraging

            from visuomotor.models.swa import prepare_swa_config

            swa_config = prepare_swa_config(config.train.stochastic_weighted_average)
            swa_callback = StochasticWeightAveraging(**swa_config)
            callbacks.append(swa_callback)
            print(f"Added StochasticWeightAveraging with config: {swa_config}")
        except (ImportError, AttributeError, ModuleNotFoundError) as e:
            print(f"StochasticWeightAveraging not available: {e}")

    # Add a callback that inserts newlines between progress bar outputs.
    # This helps avoid many "lines are too long" errors that could occur when using Fluent Bit to send
    # log messages to DataDog.
    callbacks.append(NewlineProgressBar())

    # Add a callback to register datasets to WandB
    try:
        if config["wandb"]["dataset_registry"].get("enable", False):
            callbacks.append(
                WandBDataRegistryCallback(
                    data_paths=config.data.data_path,
                    local_data_source=DataSource(config.data.local_data_source_str),
                    tags=config.wandb.dataset_registry.get("tags"),
                    wandb_dataset_registry=config.wandb.dataset_registry.get("wandb_dataset_registry"),
                    wandb_artifact_alias=config.wandb.dataset_registry.get("wandb_artifact_alias"),
                )
            )
    except KeyError as e:
        print("WandB dataset registry config not found, skipping dataset registry callback, error:", e)

    # Add a callback to add metrics and metadata to WandB run summary
    try:
        if config["wandb"]["summary"].get("enable", False):
            callbacks.append(
                WandBRunSummaryCallback(
                    data_paths=config.data.data_path,
                    local_data_source=DataSource(config.data.local_data_source_str),
                    metrics=config.wandb.summary.get("metrics"),
                    run_config=OmegaConf.to_container(config, resolve=True),
                )
            )
    except KeyError as e:
        print("WandB summary config not found, skipping run summary callback, error:", e)

    print(f"Created {len(callbacks)} training callbacks successfully")
    return callbacks


class WandbLoggerCallbackExt(WandbLoggerCallback):
    def on_experiment_end(self, trials: List["Trial"], **info: Any) -> None:
        self._cleanup_logging_actors(timeout=self._upload_timeout, kill_on_timeout=True)
        # TODO: Add option to only log the best model
        for trial in trials:
            results = trial.last_result
            cfg = trial.config
            with wandb.init(id=trial.trial_id, resume="allow", project=self.project, group=self.group):
                try:
                    if trial.checkpoint is not None:
                        checkpoint_path = trial.checkpoint.path
                        register_model(results, cfg, checkpoint=checkpoint_path)
                except Exception as e:
                    print(f"Failed to register model: {e}")


def get_wandb_callback(config: DictConfig) -> WandbLoggerCallback:
    wandb_callback = WandbLoggerCallbackExt(
        project=config.wandb.project,
        tags=[config.method_name, config.data.data_path, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
        group=wandb.util.generate_id(),
    )
    return wandb_callback


def register_model(results: Dict[str, Any], cfg: DictConfig | Dict, checkpoint: str) -> None:
    """
    Register the trained model along with metadata and tags.
    """
    cfg = OmegaConf.create(cfg)

    # Define the model artifact with extended metadata
    metadata = {
        "model_name": cfg.train_loop_config.method_name,
        "training_parameters": dict(cfg),
        "performance_metrics": results,
        "data": cfg.train_loop_config.data.raw_data_source,
        "commit_hash": "<commit-hash>",  # TODO: Get the commit hash from the git repository
    }

    model_artifact = wandb.Artifact("model", type="model", metadata=metadata)

    # Reference to the model's storage location
    gcs_path = f"gs://{checkpoint}/checkpoint.ckpt"

    model_artifact.add_reference(gcs_path)

    # Log the artifact with versioning details
    wandb.log_artifact(model_artifact, aliases=["latest"])

    if wandb.run is not None:
        wandb.finish()
