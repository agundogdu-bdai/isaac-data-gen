#  Copyright (c) 2024-2025 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import json
import os
from pathlib import Path
from typing import Any

import gcsfs
import h5py
import numpy as np
import ray


@ray.remote(num_cpus=1)
def preprocess_episode(
    fs: gcsfs.GCSFileSystem,
    dataset_path: str,
    dataset_name: str,
    episode: str,
    color_keys: list,
    other_keys: list,
    episode_num: int,
    target_gcs_path: str,
) -> None:

    processed_data_path: Path = Path(f"/root/datasets/preprocessed/{dataset_name}/")
    processed_data_path.mkdir(parents=True, exist_ok=True)
    episode_path: Path = processed_data_path / f"episode_{episode_num}"
    episode_filepath: str = f"{episode_path}/episode_{episode_num}.h5"
    target_gcs_filepath: str = f"{target_gcs_path.rstrip('/')}/episode_{episode_num}.h5"

    os.system(f"rm -r {episode_path}")
    episode_path.mkdir(parents=True, exist_ok=True)

    episode_actions = []
    episode_color = []
    episode_obs: dict = dict()

    print(f"Processing dataset {dataset_name} episode {episode} from {dataset_path}")
    with fs.open(dataset_path, "rb") as dataset:
        data = h5py.File(dataset, "r")

        episode_data = data["data/{}".format(episode)]
        num_actions = data["data/{}/actions".format(episode)].shape[0]
        print("{} has {} samples".format(episode, num_actions))
        print(data["data/{}/obs".format(episode)].keys())

        for timestep in range(num_actions):
            print(f"Processing dataset {dataset_name} episode {episode} timestep {timestep}")
            obs_t = dict()
            # each observation modality is stored as a subgroup
            for k in episode_data["obs"]:
                obs_t[k] = episode_data["obs/{}".format(k)][timestep]
                episode_obs.setdefault(k, []).append(obs_t[k])

            episode_actions.append(np.array(episode_data["actions"][timestep]).astype(np.float32))

            episode_color.append(np.array([obs_t[color_key] for color_key in color_keys]))
            # episode_states.append(demo_grp["states"][timestep])

        print(f"Writing dataset {dataset_name} episode {episode} to {episode_filepath}")
        with h5py.File(episode_filepath, "w") as f:
            f.create_dataset("action", data=np.array(episode_actions, dtype=np.float32))
            f.create_dataset("color", data=np.array(episode_color, dtype=np.uint8))
            # f.create_dataset("states", data=episode_states)
            for key in other_keys:
                f.create_dataset(key, data=np.array(episode_obs[key], dtype=np.float32))

    print(f"Copying episode {dataset_name} episode {episode} from {episode_filepath} to {target_gcs_filepath}")
    fs.put(episode_filepath, target_gcs_filepath)

    print(f"Deleting local data {episode_path}")
    os.system(f"rm -r {episode_path}")


@ray.remote(num_cpus=1)
def preprocess(
    fs: gcsfs.GCSFileSystem, dataset_path: str, target_gcs_path: str, point_cloud: bool, n_robots: int
) -> None:

    dataset_name = dataset_path.split("/")[-1].split(".hdf5")[0]
    print(f"Processing dataset {dataset_name} into VPL format")

    # Used for skipping some datasets that were processed
    done: list[str] = []

    if dataset_name in done:
        print(f"{dataset_name} done already.")
        return

    # Preprocess data into VPL format
    with fs.open(dataset_path, "rb") as dataset:

        data = h5py.File(dataset, "r")
        processed_data_path = Path(f"/root/datasets/preprocessed/{dataset_name}")
        processed_data_path.mkdir(parents=True, exist_ok=True)

        # Process Mimicgen env metadata
        env_metadata = json.loads(data["data"].attrs["env_args"])
        copy_metadata_to_gcs(
            fs=fs,
            metadata=env_metadata,
            processed_data_filepath=f"{processed_data_path}/env_metadata.json",
            target_gcs_filepath=f"{target_gcs_path.rstrip('/')}/{dataset_name}/env_metadata.json",
        )

        # each demonstration is a group under "data"
        demos = list(data["data"].keys())
        num_episodes = len(demos)

        print("hdf5 file {} has {} demonstrations".format(dataset_path, num_episodes))

        # Grab h5 keys
        valid_color_keys = ["agentview_image"]
        valid_other_keys = []
        for i in range(n_robots):
            valid_color_keys.extend([f"robot{i}_eye_in_hand_image"])
            valid_other_keys.extend([f"robot{i}_eef_pos", f"robot{i}_eef_quat", f"robot{i}_gripper_qpos"])
        if point_cloud:
            valid_other_keys.append("point_cloud")
        demo_key = demos[0]
        color_keys = sorted([key for key in data[f"data/{demo_key}/obs"].keys() if key in valid_color_keys])
        other_keys = [key for key in data[f"data/{demo_key}/obs"].keys() if key in valid_other_keys]

        # Process episodes
        num_timesteps = [-1] * num_episodes
        results = []
        for episode in demos:
            episode_num = int(episode.strip("demo_"))
            num_timesteps[episode_num] = data["data/{}/actions".format(episode)].shape[0]
            episode_target_gcs_path = f"{target_gcs_path.rstrip('/')}/{dataset_name}/episode_{episode_num}/"
            results.append(
                preprocess_episode.options(name=f"{dataset_name}_{episode}").remote(
                    fs,
                    dataset_path,
                    dataset_name,
                    episode,
                    color_keys,
                    other_keys,
                    episode_num,
                    episode_target_gcs_path,
                )
            )
        ray.get(results)

    # Process episode metadata
    ep_metadata = {
        "num_timesteps": num_timesteps,
        "num_episodes": num_episodes,
    }
    copy_metadata_to_gcs(
        fs=fs,
        metadata=ep_metadata,
        processed_data_filepath=f"{processed_data_path}/metadata.json",
        target_gcs_filepath=f"{target_gcs_path.rstrip('/')}/{dataset_name}/metadata.json",
    )

    print(f"{dataset_name} completed.")


def copy_metadata_to_gcs(
    fs: gcsfs.GCSFileSystem, metadata: dict[str, Any], processed_data_filepath: str, target_gcs_filepath: str
) -> None:
    print(f"Copying dataset metadata from {processed_data_filepath} to {target_gcs_filepath}.")
    with open(processed_data_filepath, "w") as f:
        json.dump(metadata, f)
    fs.put(processed_data_filepath, target_gcs_filepath)


def main() -> None:
    """
    Process Mimicgen raw data into VPL format. Runs on a Ray cluster with `train` and `sim` workers.

    Suggested cluster: One with `--cpu-replicas 32` and no GPU to process that quickly
    Example for processing Equidiff data with point cloud observations:
    $ python submit_job.py process_mimicgen_episode --cluster <cluster> \
    $  --source-gcs-path="gs://bdai-common-storage/visuomotor/raw/mimicgen_pc_abs/core" \
    $  --target-gcs-path="gs://bdai-common-storage/visuomotor/datasets/mimicgen_equidiff/core" \
    $  --point_cloud
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source-gcs-path",
        type=str,
        default="gs://project-dmm-main-storage/visuomotor/raw/mimicgen/core",
        help="GCS path to source Mimicgen data",
    )
    parser.add_argument(
        "--target-gcs-path",
        type=str,
        default="gs://bdai-common-storage/visuomotor/datasets/mimicgen_v2/core",
        help="GCS path to target Mimicgen data",
    )
    parser.add_argument(
        "--n-robots",
        type=int,
        default=1,
        help="Number of robots in the dataset. Typically 1 if one arm only and 2 if bimanual",
    )
    parser.add_argument("--point_cloud", action="store_true", help="Processes point cloud data")
    args = parser.parse_args()

    fs = gcsfs.GCSFileSystem()
    dataset_paths = [
        f"gs://{dataset_path}" for dataset_path in fs.ls(args.source_gcs_path) if dataset_path.endswith(".hdf5")
    ]
    results = [
        preprocess.remote(fs, dataset_path, args.target_gcs_path, args.point_cloud, args.n_robots)
        for dataset_path in dataset_paths
    ]
    ray.get(results)


if __name__ == "__main__":
    main()
