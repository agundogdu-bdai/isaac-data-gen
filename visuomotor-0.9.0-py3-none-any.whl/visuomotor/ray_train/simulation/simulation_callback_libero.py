#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from pathlib import Path
from typing import Any, Dict, List

import cv2
import lightning.pytorch as pl
import numpy as np
import robosuite.utils.transform_utils as T
import torch
import wandb
from libero.libero.envs import OffScreenRenderEnv, SubprocVectorEnv
from libero.libero.utils.video_utils import VideoWriter
from lightning import LightningModule, Trainer
from omegaconf import DictConfig


class LiberoSimulationCallback(pl.Callback):  # type: ignore
    def __init__(self, config: DictConfig) -> None:
        """Initialize the simulation callback"""
        self.config = config
        self.setup_env_args()

    def setup_env_args(self) -> None:
        """Set up the arguments for environment initialization."""
        self.load_init_paths()
        self.env_args = {
            "bddl_file_name": self.bddl_file_path,
            "camera_heights": self.config.render_img_res,
            "camera_widths": self.config.render_img_res,
        }

    def load_init_paths(self) -> None:
        """Load initial paths for BDDL and init files based on config."""
        task_name = self.config.data_path[0]
        task_name = task_name.replace("_demo", ".bddl")
        task_name = task_name.replace("_vpl", "")

        bddl_dir = Path.cwd() / self.config.init_path / "bddl_files"
        self.bddl_file_path = str(bddl_dir / task_name)

        task_name = task_name.replace(".bddl", ".pruned_init")
        init_dir = Path.cwd() / self.config.init_path / "init_files"

        self.init_file_path = str(init_dir / task_name)
        self.video_path = str(Path.cwd() / self.config.result_video_path)

    def convert_obs_to_batch(
        self, obs: List[Dict[str, Any]], device: torch.device
    ) -> Dict[int, Dict[str, torch.Tensor]]:
        "Convert observations into a format suitable for batch processing." ""
        data: Dict[int, Dict[str, torch.Tensor]] = {}
        for env_idx, observation in enumerate(obs):
            data[env_idx] = {}
            for key, value in observation.items():
                if key in [
                    "agentview_image",
                    "robot0_eef_pos",
                    "robot0_eef_quat",
                    "robot0_gripper_qpos",
                    "action",
                    "task_description",
                    "task_index",
                ]:
                    if key == "agentview_image":
                        height, width = self.config.image_randomization.resize
                        value = cv2.resize(value, (height, width))
                        value = np.transpose(value, (2, 0, 1))
                        value = np.expand_dims(value, axis=0)
                        value = np.expand_dims(value, axis=0)
                        data[env_idx]["color"] = torch.tensor(value.astype(np.float32) / 255.0).to(device)
                    elif key == "robot0_eef_quat":
                        data[env_idx][key] = torch.tensor(
                            np.expand_dims(T.quat2axisangle(value), axis=0).astype(np.float32)
                        ).to(device)
                    else:
                        data[env_idx][key] = torch.tensor(np.expand_dims(value, axis=0).astype(np.float32)).to(device)
        return data

    def on_train_epoch_end(self, trainer: Trainer, pl_module: LightningModule) -> None:
        """Triggered at the end of each training epoch for visualization."""
        # TODO: Add green/red border to visualize failed vs successful tasks
        # TODO: Plot initial data distribution
        if trainer.current_epoch % self.config.run_every_n_epochs == 0:
            env = SubprocVectorEnv(
                [lambda: OffScreenRenderEnv(**self.env_args) for _ in range(self.config.num_parallel_simulations)]
            )
            env.reset()
            env.seed(0)

            init_states = torch.load(self.init_file_path)
            indices = np.arange(self.config.num_parallel_simulations) % init_states.shape[0]
            init_states_ = init_states[indices]

            dones = [False] * self.config.num_parallel_simulations
            obs = env.set_init_state(init_states_)

            video_writer = VideoWriter(
                f"{self.video_path}/{trainer.current_epoch}", save_video=True, single_video=False
            )

            for _ in range(5):  # simulate the physics without any actions
                obs, reward, done, info = env.step(np.zeros((self.config.num_parallel_simulations, 7)))

            for _ in range(self.config.num_steps // self.config.action_execution_steps):
                data = self.convert_obs_to_batch(obs, pl_module.device)
                # Convert the observation from simulation into the camera images
                pred_actions = []
                with torch.no_grad():
                    for env_idx in range(self.config.num_parallel_simulations):
                        h = pl_module.encode(data[env_idx])  # 128 * 136
                        pred_action = pl_module.head.predict_action(h).squeeze()
                        pred_actions.append(pred_action)

                pred_actions_tensor = torch.stack(pred_actions)
                step_num = 0

                while step_num < self.config.action_execution_steps:
                    obs, reward, done, info = env.step(pred_actions_tensor[:, step_num, :].cpu().detach().numpy())
                    video_writer.append_vector_obs(obs, dones, camera_name="agentview_image")
                    step_num += 1

                    # check whether succeed
                    for k in range(self.config.num_parallel_simulations):
                        dones[k] = dones[k] or done[k]
                    if all(dones):
                        break

            for env_idx in video_writer.image_buffer.keys():
                images_list = []
                for image in video_writer.image_buffer[env_idx]:
                    images_list.append(image)
                trainer.logger.experiment.log(
                    {
                        f"libero/env_idx_{env_idx}": wandb.Video(np.array(images_list).transpose(0, 3, 1, 2), fps=25),
                    }
                )

            num_success = 0
            for k in range(self.config.num_parallel_simulations):
                num_success += int(dones[k])

            success_rate = num_success / self.config.num_parallel_simulations
            trainer.logger.experiment.log(
                {"success_rate": success_rate},
                commit=False,
            )
            if self.config.save_videos:
                video_writer.save()
