#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

MIMICGEN_TASK_STEPS = {
    "coffee": 400,
    "coffee_preparation": 800,
    "hammer_cleanup": 500,
    "kitchen": 800,
    "mug_cleanup": 500,
    "nut_assembly": 500,
    "pick_place": 1000,
    "square": 400,
    "stack": 400,
    "stack_three": 400,
    "threading": 400,
    "three_piece_assembly": 500,
}

MIMICGEN_BENCHMARK_TASKS = {
    "coffee": ["d0", "d1", "d2"],
    "coffee_preparation": ["d0", "d1"],
    "hammer_cleanup": ["d0", "d1"],
    "kitchen": ["d0", "d1"],
    "mug_cleanup": ["d0", "d1"],
    "nut_assembly": ["d0"],
    "pick_place": ["d0"],
    "square": ["d0", "d1", "d2"],
    "stack": ["d0", "d1"],
    "stack_three": ["d0", "d1"],
    "threading": ["d0", "d1", "d2"],
    "three_piece_assembly": ["d0", "d1", "d2"],
}
