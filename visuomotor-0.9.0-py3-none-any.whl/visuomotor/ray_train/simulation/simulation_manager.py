#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import math
import time

import numpy as np
import ray
import ray.util.scheduling_strategies
from lightning import LightningModule
from omegaconf import DictConfig
from ray.util.state import get_actor, list_actors

MAX_PENDING_SECONDS = 900
MAX_RESTARTING_SECONDS = 600


@ray.remote(
    scheduling_strategy=ray.util.scheduling_strategies.PlacementGroupSchedulingStrategy(placement_group=None),
    resources={"sim": 0.001},  # this schedules it on nodes designated for sim
    max_restarts=3,
)
class SimulationManager:
    """
    Manages the parallel sim runs and combines the results to log to wandb.
    """

    def __init__(self, config: DictConfig) -> None:
        self.config = config
        self.results: list = []
        self.queue: list = []
        self.latest_actors: list = []
        self.latest_actor_launch_time: float = -1.0
        self.latest_actor_restart_time: float = -1.0
        self.finished_results: dict = {}
        self.num_actors = min(
            self.config.get("ray_parallel_actors", 1),
            math.ceil(self.config.num_episodes / self.config.num_envs_per_actor),
        )
        self.save_videos = self.config.get("save_videos", True)

        # Keep track of actors that we have explicitly killed
        self.killed_actor_ids = set()  # type: ignore

        print("SimulationManager initialized")

    def start_simulations(
        self,
        actors: list,
        artifact_name: str,
        current_epoch: int,
        config: DictConfig,
        pl_module: LightningModule | None = None,
    ) -> None:
        """
        Ray does not guarantee order in submission for a long list of tasks. The queue is so that
        we submit groups of tasks to be run in order and we can make sure actors for the last epoch
        have been assigned resources before submitting new sim actors.
        """
        data = {
            "actors": actors,
            "artifact_name": artifact_name,
            "current_epoch": current_epoch,
            "config": config,
            "pl_module": pl_module,
        }
        self.queue.append(data)
        if self.resources_assigned():
            self.run_next_group()

    def resources_assigned(self) -> bool:
        """
        Check if the latest batch is still waiting for resources.
        """
        latest_actors_assigned = True
        for actor in self.latest_actors:
            actor_id = actor._actor_id.hex()  # noqa: SLF001
            state = get_actor(id=actor_id)["state"]
            if state in ["DEPENDENCIES_UNREADY", "PENDING_CREATION", "RESTARTING"]:
                print("At least one actor waiting to start, not scheduling the next group.")
                latest_actors_assigned = False

                # If it's been pending too long, kill it.
                if state == "PENDING_CREATION" and (time.time() - self.latest_actor_launch_time) > MAX_PENDING_SECONDS:
                    print(f"Actor with id {actor_id} has been PENDING_CREATION for too long, killing to restart.")
                    ray.kill(actor, no_restart=False)
                    self.latest_actor_restart_time = time.time()

                # If it's been restarting too long, kill it.
                elif state == "RESTARTING" and (time.time() - self.latest_actor_restart_time) > MAX_RESTARTING_SECONDS:
                    print(f"Actor with id {actor_id} has been RESTARTING for too long, killing to restart.")
                    ray.kill(actor, no_restart=False)
                    self.latest_actor_restart_time = time.time()

        return latest_actors_assigned

    def run_next_group(self) -> None:
        data = self.queue.pop(0)

        for env_name, task_index, sim_actor, num_steps in data["actors"]:
            self.latest_actors = [
                sim_actor.options(name=f"{env_name}_epoch{data['current_epoch']}_{i}").remote(
                    config=data["config"],
                    artifact_name=data["artifact_name"],
                    pl_module=data["pl_module"],
                    env_name=env_name,
                    current_epoch=data["current_epoch"],
                    task_index=task_index,
                    num_steps=num_steps,  # type: ignore
                )
                for i in range(self.num_actors)
            ]
            self.latest_actor_launch_time = time.time()
            results = [actor.run_simulation.remote() for actor in self.latest_actors]
            self.results.append(results)

    def get_finished(self, timeout: float = 1.0) -> list:
        """Checks to see if any sim runs have completed."""
        # If current actors have assigned resources, we can schedule the next group
        if self.resources_assigned() and len(self.queue) > 0:
            self.run_next_group()

        finished_indices = []
        all_wandb_results = []
        for index, epoch_result in enumerate(self.results[:]):
            print(f"Checking if index {index} of self.results of len {len(epoch_result)} is done")

            finished, unfinished = [], []
            for actor_result in epoch_result:
                _finished, _unfinished = ray.wait([actor_result], timeout=timeout)
                if len(_finished) == 1:
                    finished.append(_finished[0])
                elif len(_unfinished) == 1:
                    unfinished.append(_unfinished[0])
                else:
                    raise ValueError(f"Expected one object ref returned, received {len(_finished)+len(_unfinished)}.")
            self.results[index] = unfinished
            for finished_sim in finished:
                actor_id_str = finished_sim.task_id().actor_id().hex()

                # Skip if we already killed this actor
                if actor_id_str in self.killed_actor_ids:
                    print(f"Skipping result for actor {actor_id_str} because we killed it.")
                    continue

                result = ray.get(finished_sim)
                wandb_results = self.add_result(result)

                # Normally kill this actor now that it's finished
                self.kill_actor(finished_sim)
                if wandb_results is not None:
                    finished_indices.append(index)
                    all_wandb_results.append(wandb_results)
                    if self.resources_assigned() and len(self.queue) > 0:
                        self.run_next_group()

        for finished_index in reversed(finished_indices):
            del self.results[finished_index]
        return all_wandb_results

    def is_running(self) -> bool:
        return bool(self.queue or self.results)

    def add_result(self, result: dict) -> dict | None:
        """
        Store result and return combined result if all actors are done.
        """
        results_id = f"{result['epoch']}_{result['env_name']}"
        self.finished_results.setdefault(results_id, {})
        self.finished_results[results_id].setdefault("num_episodes", []).append(result["num_episodes"])
        self.finished_results[results_id].setdefault("success_count", []).append(result["success_count"])
        self.finished_results[results_id].setdefault("total_rewards", []).append(result["total_rewards"])
        self.finished_results[results_id].setdefault("episode_max_reward", []).append(result["episode_max_reward"])

        if self.save_videos:
            self.finished_results[results_id].setdefault("combined_frames", []).append(result["video"])
            if self.save_videos == "limited":
                self.finished_results[results_id]["combined_frames"] = self.finished_results[results_id][
                    "combined_frames"
                ][:1]

        # Check if we've gathered results from all actors
        if len(self.finished_results[results_id]["num_episodes"]) == self.num_actors:
            if self.save_videos:
                combined_frames_np = np.concatenate(self.finished_results[results_id]["combined_frames"], axis=0)
            total_success_count = sum(self.finished_results[results_id]["success_count"])
            total_num_episodes = sum(self.finished_results[results_id]["num_episodes"])
            total_rewards = sum(self.finished_results[results_id]["total_rewards"])
            mean_of_episode_max_reward = float(
                np.sum(self.finished_results[results_id]["episode_max_reward"]) / total_num_episodes
            )
            success_rate = float(total_success_count / total_num_episodes)
            avg_rewards = float(total_rewards / total_num_episodes)

            del self.finished_results[results_id]

            wandb_results = {
                "epoch": result["epoch"],
                "success_rate": success_rate,
                "total_num_episodes": total_num_episodes,
                "env_name": result["env_name"],
                "avg_rewards": avg_rewards,
                "mean_of_episode_max_reward": mean_of_episode_max_reward,
            }

            if self.save_videos:
                wandb_results["frames_np"] = combined_frames_np

            return wandb_results

        return None

    def kill_actor(self, result_ref: ray.ObjectRef) -> None:
        """
        Makes sure actor is killed if simulation is complete and results recorded.
        """
        actor_id = result_ref.task_id().actor_id()
        all_actors = list_actors(
            filters=[
                ("state", "=", "ALIVE"),
            ]
        )

        for actor_info in all_actors:
            if actor_info["actor_id"] == actor_id.hex():
                try:
                    # Mark as killed before actually killing
                    self.killed_actor_ids.add(actor_id.hex())
                    actor_handle = ray.get_actor(name=actor_info["name"])
                    ray.kill(actor_handle)
                    del actor_handle
                except Exception as e:
                    print(f"Failed to kill actor {actor_info['name']}: {e}. ")
                break
