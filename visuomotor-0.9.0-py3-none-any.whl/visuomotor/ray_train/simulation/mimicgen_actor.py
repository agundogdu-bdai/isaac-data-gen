#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.


import ray
import ray.util.scheduling_strategies

from visuomotor.simulation.mimicgen_actor import MimicgenActor as NonRayMimicgenActor


@ray.remote(
    num_gpus=1,
    scheduling_strategy=ray.util.scheduling_strategies.PlacementGroupSchedulingStrategy(placement_group=None),
    resources={"sim": 1, "mimicgen": 1},  # this schedules it on nodes designated for sim
    max_restarts=3,
    max_task_retries=3,
)
class MimicgenActor(NonRayMimicgenActor):
    pass


@ray.remote(
    num_gpus=1,
    scheduling_strategy=ray.util.scheduling_strategies.PlacementGroupSchedulingStrategy(placement_group=None),
    resources={"sim": 1, "dexmimicgen": 1},  # this schedules it on nodes designated for sim
    max_restarts=3,
    max_task_retries=3,
)
class DexMimicgenActor(NonRayMimicgenActor):
    pass
