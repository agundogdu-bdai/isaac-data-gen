#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

from typing import Any

import lightning.pytorch as pl
import ray
import ray.util.scheduling_strategies
from lightning import LightningModule, Trainer
from lightning.pytorch.callbacks import StochasticWeightAveraging
from lightning.pytorch.utilities import rank_zero_only
from lightning.pytorch.utilities.types import STEP_OUTPUT
from omegaconf import DictConfig

from visuomotor.logging.helpers import get_wandb_init_params
from visuomotor.simulation.simulation_validation import SimulationValidation

CHECK_INTERVAL = 300


class SimulationValidationCallback(pl.Callback):  # type: ignore
    """
    Wrapper around the SimulationValidation class to make it a Pytorch Lightning Callback.
    """

    def __init__(self, config: DictConfig, max_groups_per_manager: int = 10) -> None:
        """
        Args:
            config: `config.simulation` from toplevel config
            max_groups_per_manager: number of simulation groups per simulation manager.
                Each simulation group has its own model.
        """
        self.config = config
        self.sim_validation = SimulationValidation(config, max_groups_per_manager)
        print("SimulationValidationCallback initialized")

    @rank_zero_only
    def on_train_epoch_end(self, trainer: Trainer, pl_module: LightningModule) -> None:
        if (trainer.current_epoch + 1) % self.config["run_every_n_epochs"] == 0:

            if not self.config["use_checkpoints"]:
                pl_module_ref = ray.put(pl_module)
                # # Safe path: send a CPU-only copy so deserialization never touches CUDA here.
                # model_for_sim = self.get_model_for_sim(trainer, pl_module)
                # model_copy = deepcopy(model_for_sim).to("cpu")
                # for p in model_copy.parameters():
                #     p.requires_grad_(False)
                # pl_module_ref = ray.put(model_copy)
                artifact_name = None
            else:
                pl_module_ref = None
                checkpoint_version = int((trainer.current_epoch) / self.config["run_every_n_epochs"])
                checkpoint_id = f"{get_wandb_init_params(pl_module.config)['id']}:v{checkpoint_version}"
                wandb_project = get_wandb_init_params(pl_module.config)["project"]
                artifact_name = f"bdaii/{wandb_project}/{checkpoint_id}"

            self.sim_validation.start_sim(
                pl_module=pl_module_ref,
                epoch=trainer.current_epoch,
                artifact_name=artifact_name,
                config=pl_module.config,
            )

    @rank_zero_only
    def on_train_batch_end(
        self, trainer: Trainer, pl_module: LightningModule, outputs: STEP_OUTPUT, batch: Any, batch_idx: int
    ) -> None:
        """
        If epochs have large batches, we check for finished and start new sims too infrequently. This checks
        and starts new sims at CHECK_INTERVAL.
        """
        if batch_idx % CHECK_INTERVAL == 0 and trainer.current_epoch >= self.config["run_every_n_epochs"]:
            self.sim_validation.check_and_log_finished()

    def get_model_for_sim(self, trainer: Trainer, pl_module: LightningModule) -> LightningModule:
        """Get the model to use for the simulation evaluations.

        Returns:
            pl_module, unless StochasticWeightAveraging is being used.
        """
        swa_callbacks: list[StochasticWeightAveraging] = [
            c for c in trainer.callbacks if isinstance(c, StochasticWeightAveraging)  # type: ignore
        ]
        if len(swa_callbacks) == 0:
            print("No StochasticWeightAveraging callback found. Using standard model in sim.")
            model_for_sim = pl_module
        elif len(swa_callbacks) > 1:
            raise ValueError(
                f"We're trying to run simulations using StochasticWeightAveraging and found {len(swa_callbacks)} "
                "StochasticWeightAveraging callbacks. Please use just one."
            )
        else:

            swa_callback = swa_callbacks[0]
            # If we've started updating the swa model, use it in sim.
            if swa_callback.n_averaged is not None and swa_callback.n_averaged.item() > 0:
                print("Using StochasticWeightAveraging model in sim.")
                model_for_sim = swa_callbacks[0]._average_model  # noqa: SLF001
                assert model_for_sim is not None
            else:
                print("StochasticWeightAveraging hasn't yet started. Using non-averaged model in sim.")
                model_for_sim = pl_module
        return model_for_sim

    @rank_zero_only
    def on_train_end(self, trainer: Trainer, pl_module: LightningModule) -> None:
        """Wait for remaining simulations to complete and log."""
        self.sim_validation.run_until_end()
