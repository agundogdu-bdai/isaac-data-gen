#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
"""extends ray_train.py using dependency inversion --> allows you to use any model or dataset with
vpl ray infrastructure"""

import math
from functools import partial
from typing import Any, Iterable, Optional, Type, Union

import hydra
import lightning as L
import ray.data
import ray.train
import ray.train.torch
import torch
from lightning.pytorch.callbacks import Callback
from lightning.pytorch.loggers import WandbLogger
from omegaconf import DictConfig, OmegaConf
from ray.data import DataContext
from ray.data.dataset import Dataset
from ray.train import RunConfig, ScalingConfig
from ray.train.lightning import (
    RayDDPStrategy,
    RayLightningEnvironment,
    prepare_trainer,
)
from ray.train.torch import TorchTrainer
from torch.utils.data import ConcatDataset, DataLoader

from visuomotor.data import load_dataset_cls
from visuomotor.logging.helpers import finish_wandb, generate_run_id, get_wandblogger_and_checkpoint_callback
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.models.protocols import Policy
from visuomotor.ray_train.callbacks import RayTrainReportCallbackCustom
from visuomotor.ray_train.data.data_copy_actor import copy_to_local
from visuomotor.ray_train.protocols import TrainingComponentsBuilder
from visuomotor.ray_train.ray_normalizer import compute_normalizer_single_worker


def build_default_torch_dataset(
    config: DictConfig, world_size: int
) -> tuple[DictConfig, DataLoader, Optional[DataLoader]]:
    """build torch data loaders. No ray.

    Args:
        config (DictConfig): training configuration
        world_size (int): world size

    Raises:
        ValueError: no data found

    Returns:
        DictConfig: updated configuration. Typically, only max_steps will be updated.
        DataLoader: training data loader
        Optional[DataLoader]: validation data loader
    """
    datasets = []
    DatasetClass = load_dataset_cls(config)
    for task_index, path in enumerate(list(config.data.data_path)):
        data_config = OmegaConf.create(config.data)
        data_config.data_path = path
        data_config.task_index = task_index
        dataset = DatasetClass(config=data_config, ray_worker=True)
        datasets.append(dataset)
        print(f"loaded dataset #{task_index} from {path}. Length {len(dataset)}")
    datasets = ConcatDataset(datasets)
    print("Full dataset length", len(datasets))

    if config.train.validation_percent > 0:
        seed = torch.Generator().manual_seed(42)
        val_len = int(len(datasets) * config.train.validation_percent)
        train_len = len(datasets) - val_len
        train_dataset, val_dataset = torch.utils.data.random_split(datasets, [train_len, val_len], generator=seed)
    else:
        train_dataset = datasets
        valid_ds_loader = None

    train_ds_loader = DataLoader(
        train_dataset,
        shuffle=config.train.shuffle,
        batch_size=config.train.batch_size,
        pin_memory=config.train.pin_memory,
        num_workers=config.train.num_workers,
        persistent_workers=config.train.persistent_workers,
    )

    if config.train.max_steps is None:
        print("Calculating max steps from training dataset size")
        config.train.max_steps = config.train.max_epochs * math.ceil(
            len(train_dataset) / (config.train.batch_size * world_size)
        )

    if config.train.validation_percent > 0:
        valid_ds_loader = DataLoader(
            val_dataset,
            shuffle=False,
            batch_size=config.train.batch_size,
            pin_memory=config.train.pin_memory,
            num_workers=config.train.num_workers,
        )

    if len(train_dataset) == 0:
        raise ValueError("No data found in the dataset.")

    return config, train_ds_loader, valid_ds_loader


class DefaultRayTrainingComponentsBuilder:
    """Default builder for training components using ray datasets."""

    def __call__(
        self,
        world_rank: int,
        config: DictConfig,
    ) -> tuple[
        DictConfig, Iterable[dict[str, Any]], Optional[Iterable[dict[str, Any]]], L.LightningModule, dict[str, Any]
    ]:
        """build training components on demand

        Args:
            world_rank (int): world rank of current worker
            config (DictConfig): training configuration

        Returns:
            DictConfig: modified configuration
            Iterable[dict[str, Any]]: training dataset
            Optional[Iterable[dict[str, Any]]]: optional validation dataset
            L.LightningModule: policy lightning module
            dict[str, Any]: lightning keyword arguments
        """
        config = OmegaConf.create(config)

        L.seed_everything(config.train.seed, workers=True)
        torch.set_float32_matmul_precision(config.train.matmul_precision)

        config, train_ds_loader, valid_ds_loader = build_default_torch_dataset(
            config, ray.train.get_context().get_world_size()
        )
        if config.data.normalize:
            normalizer = compute_normalizer_single_worker(train_ds_loader.dataset, config)
            if normalizer is None:
                raise ValueError("Normalizer computation failed. Ensure the datasets and configuration are correct.")
        else:
            normalizer = None

        model: Policy = REGISTRY.create_model(config=config, model_type=ModelType.POLICY)
        assert isinstance(model, Policy)

        if config.data.normalize:
            print("Monkey Patching Normalizer")
            model.normalizer = normalizer

        print("\nModel created")
        print(model)
        print("\n\n")
        print(L.pytorch.utilities.model_summary.summarize(model, max_depth=1))
        print("\n\n")

        trainer_kwargs = {
            "accelerator": config.train.accelerator,
            "max_epochs": config.train.max_epochs,
            "max_steps": config.train.max_steps,
            "num_nodes": config.train.num_nodes,
            "precision": config.train.precision,
            "gradient_clip_val": config.train.gradient_clip_val,
            "log_every_n_steps": config.train.log_every_n_steps,
            "enable_model_summary": config.train.enable_model_summary,
        }
        return config, train_ds_loader, valid_ds_loader, model, trainer_kwargs


def train_func(config: DictConfig, train_builder_class: Optional[Type[TrainingComponentsBuilder]] = None) -> None:
    """training loop that gets executed on each ray worker.

    Args:
        config (DictConfig): training configuration
        train_builder_class (Optional[Type[TrainingComponentsBuilder]], optional): builds training assets.
            If None, uses DefaultRayTrainingComponentsBuilder.
            Defaults to None.
    """
    if train_builder_class is None:
        train_builder_class = DefaultRayTrainingComponentsBuilder

    train_builder = train_builder_class()
    wandb_logger: Union[bool, WandbLogger] = False
    checkpoint_callback = None
    if config.wandb.enable:
        wandb_logger, checkpoint_callback = get_wandblogger_and_checkpoint_callback(config)
    callbacks: list[Callback] = [
        RayTrainReportCallbackCustom(frequency=config.train.checkpoint_interval),
        *([checkpoint_callback] if checkpoint_callback else []),
    ]

    config, train_ds_loader, valid_ds_loader, model, trainer_kwargs = train_builder(
        ray.train.get_context().get_world_rank(), config
    )

    if "simulation" in config and config.simulation.run_sim:
        from visuomotor.ray_train.simulation.simulation_callback import SimulationValidationCallback

        if ray.train.get_context().get_world_rank() == 0:
            sim_callback = SimulationValidationCallback(
                config.simulation, max_groups_per_manager=config.simulation.get("max_groups_per_manager", 10)
            )
            callbacks.append(sim_callback)

    if config.train.stochastic_weighted_average is not None:
        from lightning.pytorch.callbacks import StochasticWeightAveraging

        from visuomotor.models.swa import prepare_swa_config

        swa_config = prepare_swa_config(config.train.stochastic_weighted_average)
        print(f"Setting up StochasticWeightAveraging. Config: {swa_config}")
        swa_callback = StochasticWeightAveraging(**swa_config)
        callbacks.append(swa_callback)

    # 3. Define the Lightning Trainer
    trainer = L.Trainer(
        logger=wandb_logger,
        devices="auto",
        strategy=RayDDPStrategy(),
        plugins=[RayLightningEnvironment()],
        callbacks=callbacks,
        enable_progress_bar=True,
        profiler=None,
        enable_checkpointing=True,
        **trainer_kwargs,
    )

    prepare_trainer(trainer)  # for distributed execution

    # 4. Train the model
    results = trainer.fit(model, train_dataloaders=train_ds_loader, val_dataloaders=valid_ds_loader)

    print(f"Training completed with results: {results}")

    if wandb_logger:
        finish_wandb()


def train_vpl(
    ds: Optional[Dataset],
    config: DictConfig,
    is_test: bool = False,
    train_builder_class: Optional[Type[TrainingComponentsBuilder]] = None,
) -> None:
    """ray entrypoint. Sets up ray run configurations and submits train_func to ray worker.

    Args:
        ds (Optional[Dataset]): ray dataset. If None, will try to load a torch dataset.
        config (DictConfig): training configuration.
        is_test (bool, optional): Defaults to False.
        train_builder_class (Optional[Type[TrainingComponentsBuilder]], optional): builds training assets on demand.
            If None, uses DefaultRayTrainingComponentsBuilder. Defaults to None.
    """
    # 1. Load model configuration
    if not isinstance(config, DictConfig):
        config = OmegaConf.create(config)

    config = generate_run_id(config)

    # 2. Define the ray run configuration
    run_config = RunConfig(
        storage_path=f"{config.storage_path}/ray",
    )

    # 3. Define the ray scaling configuration
    scaling_config = ScalingConfig(
        num_workers=config.train.num_ray_workers,
        use_gpu=config.train.use_gpu,
        # specifying "train" resource makes it schedule only on nodes labeled for train instead of sim
        resources_per_worker={
            "GPU": config.train.gpu_resources_per_worker,
            "train": 0.001 if not is_test else 0,
        },
    )

    # 4. Define the ray training loop configuration
    ray_trainer: TorchTrainer = TorchTrainer(
        train_loop_per_worker=partial(train_func, train_builder_class=train_builder_class),
        train_loop_config=config,
        scaling_config=scaling_config,
        run_config=run_config,
        datasets={"train": ds} if ds is not None else None,
    )

    # 5. Train the model
    ray_trainer.fit()


@hydra.main(version_base=None, config_path="pkg://visuomotor/configs", config_name=None)
def main(config: DictConfig) -> None:
    ctx = DataContext.get_current()
    ctx.enable_tensor_extension_casting = False

    print(OmegaConf.to_yaml(config))
    if config.train.use_torch_data_loader:
        copy_to_local(config, overwrite=False)  # If you are sure the data is already there skip this to save time
        train_vpl(ds=None, config=config, train_builder_class=None)
    else:
        raise ValueError("Only torch data loader is supported.")


if __name__ == "__main__":
    main()
