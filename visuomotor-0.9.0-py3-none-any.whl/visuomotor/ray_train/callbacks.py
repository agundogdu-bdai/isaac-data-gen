#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import os
import tempfile
from typing import Optional

import lightning as L
import ray
from ray.train import Checkpoint
from ray.train.lightning import RayTrainReportCallback


class RayTrainReportCallbackCustom(RayTrainReportCallback):
    def __init__(self, frequency: int = 1, storage_path: Optional[str] = None) -> None:
        super().__init__()
        self.frequency = frequency
        self.storage_path = storage_path

    def on_train_epoch_end(self, trainer: L.Trainer, module: L.LightningModule) -> None:
        """lightning callback that gets run at end of every epoch by all workers.
        Sync and save checkpoints + reports several metrics.

        Design decisions to avoid race conditions:
            1. every worker makes its own temp directories --> avoids
                case where one worker deletes the directory while others are still using it.
            2. use a barrier to sync all workers before cleanup.

        Args:
            trainer (L.Trainer): lightning trainer
            module (L.LightningModule): lightning module
        """
        if (
            self.frequency is not None
            and trainer.current_epoch % self.frequency == 0
            or trainer.current_epoch == trainer.max_epochs - 1
        ):

            # Fetch metrics
            metrics = trainer.callback_metrics
            metrics = {k: v.item() for k, v in metrics.items()}

            # (Optional) Add customized metrics
            metrics["epoch"] = trainer.current_epoch
            metrics["step"] = trainer.global_step

            with tempfile.TemporaryDirectory() as tmpdirname:
                checkpoint = None
                # NOTE: lightning performs blocking/synchronous checkpointing by default
                trainer.save_checkpoint(os.path.join(tmpdirname, "checkpoint.ckpt"), weights_only=False)
                # Report to train session
                if len(os.listdir(tmpdirname)) > 0:
                    checkpoint = Checkpoint.from_directory(tmpdirname)
                # NOTE: ray requires report to be run same number of times by all workers
                ray.train.report(metrics=metrics, checkpoint=checkpoint)
                # ensure all workers have finished writing before cleaning up directories
                trainer.strategy.barrier()
