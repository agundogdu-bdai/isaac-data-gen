#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.
import argparse

import wandb
from omegaconf import OmegaConf

from visuomotor.logging.helpers import get_checkpoint_interval
from visuomotor.simulation.simulation_validation import SimulationValidation


def run_sims(project_name: str, run_id: str, versions: list[str] | None = None) -> None:
    """
    Runs simulation evaluations on versions specified or all of the versions of an artifact and
    stores results in the same project_name under a new run. wandb was not reliably allowing us to
    store results back into the same training run, so we opted for a new run id instead.

    Assumes the artifact is stored as `bdaii/{project_name}/{wandb_run_id}`.
    For example, `bdaii/nut_assembly_d0_pc_abs-elin/diffpo-4jtf2wom-pqqeokg2.
    """
    org = "bdaii"

    artifact_name = f"{org}/{project_name}/{run_id}"

    api = wandb.Api()
    collection = api.artifact_collection(type_name="model", name=artifact_name)

    if len(collection.artifacts()) == 0:
        print("No artifacts are saved")
        return

    full_artifact_name = f"{org}/{project_name}/{collection.artifacts()[0].name}"
    run = api.run(f"{org}/{project_name}/{run_id}")
    config = OmegaConf.create(run.config)
    config.wandb.run_id = f"{run_id}"
    config.wandb.project = project_name

    wandb.init(
        project=project_name,
        entity=org,
        id=run_id + "_sim-" + wandb.util.generate_id(),
    )

    sim_runner = SimulationValidation(config=config.simulation, max_groups_per_manager=50)

    if versions is not None:
        for version in versions:
            full_artifact_name = f"{artifact_name}:v{version}"
            print(full_artifact_name)
            checkpoint_interval = get_checkpoint_interval(config)
            assert checkpoint_interval is not None, "Checkpoint interval (epochs) must be defined in the config."
            epoch = int(version) * checkpoint_interval
            sim_runner.start_sim(config=config, epoch=epoch, artifact_name=full_artifact_name)
    else:
        for artifact in collection.artifacts():
            full_artifact_name = f"{project_name}/{artifact.name}"
            checkpoint_interval = get_checkpoint_interval(config)
            assert checkpoint_interval is not None, "Checkpoint interval (epochs) must be defined in the config."
            epoch = int(artifact.version[1:]) * checkpoint_interval
            sim_runner.start_sim(config=config, epoch=epoch, artifact_name=full_artifact_name)

    sim_runner.run_until_end()


if __name__ == "__main__":
    """
    Submit to your Raycluster with:
    `python submit_job.py run_sim_evals --cluster [your-cluster-name]
        --project-name [your-project-name] --run-id [your-run-id]`
    """
    parser = argparse.ArgumentParser(description="Run simulation evaluation on checkpoints.")
    parser.add_argument("--project-name", type=str, required=True, help="wandb project name")
    parser.add_argument("--run-id", type=str, required=True, help="wandb run id")
    parser.add_argument(
        "--versions",
        type=str,
        nargs="+",
        required=False,
        help="list of checkpoint versions. If None (default), simulations are run for all versions.",
    )

    args = parser.parse_args()
    run_sims(project_name=args.project_name, run_id=args.run_id, versions=args.versions)
