#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import math
from collections.abc import Sized
from typing import Any, Dict, Optional, Union, cast

import hydra
import lightning as L
import ray.data
import ray.train
import ray.train.torch
import torch
from lightning.pytorch.loggers import WandbLogger
from lightning.pytorch.utilities import model_summary
from omegaconf import DictConfig, OmegaConf
from ray.data import DataContext
from ray.train import RunConfig, ScalingConfig
from ray.train.lightning import (
    RayDDPStrategy,
    RayLightningEnvironment,
    prepare_trainer,
)
from ray.train.torch import TorchTrainer
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset, random_split

from visuomotor.data import is_lerobot_available, load_dataset_cls
from visuomotor.logging.helpers import finish_wandb, generate_run_id, get_wandblogger_and_checkpoint_callback
from visuomotor.logging.profiler import finish_profiler, setup_profiler, wrap_object_with_profiler
from visuomotor.logging.profiler_dataloader import ProfiledDataLoader
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.models.protocols import Policy
from visuomotor.ray_train.data.data_copy_actor import copy_to_local
from visuomotor.ray_train.ray_lerobot_utils import (
    configure_lerobot_dataloader_params,
    is_lerobot_workflow,
    setup_cuda_device_for_lerobot,
)
from visuomotor.ray_train.ray_normalizer import compute_normalizer_single_worker
from visuomotor.ray_train.ray_utils import create_training_callbacks


def assert_cluster_resources_match_config(config: DictConfig) -> None:
    resource_names = set(k for k in ray.cluster_resources().keys())

    needs_sim_pods = config.get("simulation", {}).get("run_sim", False)
    if needs_sim_pods:
        env_type = config.get("simulation", {}).get("env_type")

        if env_type not in resource_names:
            raise RuntimeError(
                f"You need {env_type} pods in your cluster. Please use the appropriate flag in tensors CLI"
            )


def _create_datasets(config: DictConfig) -> tuple[Dataset, Optional[Dataset], Any]:
    """
    Create training and validation datasets based on config.
    Returns: (train_dataset, val_dataset, normalizer)
    """
    # Initialize train and validation datasets
    train_dataset: Dataset
    val_dataset: Optional[Dataset] = None

    # Determine dataset type and create datasets accordingly
    if is_lerobot_workflow(config):
        from visuomotor.ray_train.ray_lerobot_utils import create_lerobot_datasets

        print("Using LeRobot dataset workflow")
        train_dataset = create_lerobot_datasets(config)
        val_dataset = None  # LeRobot workflow doesn't support validation split currently
        normalizer = None  # LeRobot datasets handle normalization internally
    else:
        print("Using standard dataset workflow")
        # Create standard visuomotor datasets with optional validation split
        DatasetClass = load_dataset_cls(config)

        # Load and concatenate datasets from multiple paths
        datasets_list = []
        for task_index, path in enumerate(list(config.data.data_path)):
            data_config = OmegaConf.create(config.data)
            data_config.data_path = path
            data_config.task_index = task_index
            dataset = DatasetClass(config=data_config, ray_worker=True)
            datasets_list.append(dataset)
            print(f"loaded dataset #{task_index} from {path}. Length {len(dataset)}")

        concatenated_dataset: ConcatDataset = ConcatDataset(datasets_list)
        print("Full dataset length", len(concatenated_dataset))

        if config.train.validation_percent > 0:
            seed = torch.Generator().manual_seed(config.train.seed)
            val_len = int(len(concatenated_dataset) * config.train.validation_percent)
            train_len = len(concatenated_dataset) - val_len

            # Perform the split
            subsets: list[Subset] = random_split(concatenated_dataset, [train_len, val_len], generator=seed)

            # Assign subsets with explicit type annotations
            train_subset = subsets[0]
            val_subset = subsets[1]

            # Define train and validation datasets
            train_dataset = train_subset
            val_dataset = val_subset
        else:
            train_dataset = concatenated_dataset

        # Compute normalizer for standard datasets
        normalizer = None
        if config.data.normalize:
            normalizer = compute_normalizer_single_worker(train_dataset, config)
            if normalizer is None:
                raise ValueError("Normalizer computation failed. Ensure the datasets and configuration are correct.")

    return train_dataset, val_dataset, normalizer


def train_func(config: DictConfig | Dict) -> None:
    """
    Unified PyTorch Lightning training code that handles both standard VPL and LeRobot datasets.
    """
    config = OmegaConf.create(config)

    L.seed_everything(config.train.seed, workers=True)
    torch.set_float32_matmul_precision(config.train.matmul_precision)

    # 0. Setup profiler if enabled
    profiled_rank, profiler_scope, lightning_profiler = setup_profiler(config)

    # Set CUDA device for LeRobot workflows
    setup_cuda_device_for_lerobot(config)

    # Create datasets and normalizer
    train_dataset, val_dataset, normalizer = _create_datasets(config)

    # Ensure train_dataset is a Dataset and not None
    if not isinstance(train_dataset, Dataset):
        raise TypeError("train_dataset must be an instance of torch.utils.data.Dataset")

    if len(cast(Sized, train_dataset)) == 0:
        raise ValueError("No data found in the dataset.")

    # Calculate max_steps if not provided
    if config.train.max_steps is None:
        config.train.max_steps = config.train.max_epochs * math.ceil(
            len(cast(Sized, train_dataset)) / (config.train.batch_size * config.train.num_ray_workers)
        )

    # Create data loaders
    is_lerobot_dataset = hasattr(config.data, "is_hf_dataset") or hasattr(train_dataset, "meta")

    if is_lerobot_dataset and is_lerobot_available():
        shuffle, sampler = configure_lerobot_dataloader_params(train_dataset, config)
    else:
        shuffle = config.train.shuffle
        sampler = None

    train_ds_loader = DataLoader(
        train_dataset,
        shuffle=shuffle,
        sampler=sampler,
        batch_size=config.train.batch_size,
        pin_memory=config.train.pin_memory,
        num_workers=config.train.num_workers,
        persistent_workers=config.train.persistent_workers,
    )

    # Apply profiling to data loader if enabled
    if profiled_rank is not None:
        train_ds_loader = ProfiledDataLoader(train_ds_loader)

    # Create validation data loader if validation dataset exists
    valid_ds_loader = None
    if val_dataset is not None:
        valid_ds_loader = DataLoader(
            val_dataset,
            shuffle=False,
            batch_size=config.train.batch_size,
            pin_memory=config.train.pin_memory,
            num_workers=config.train.num_workers,
            multiprocessing_context=config.train.multiprocessing_context,
        )

    # Setup callbacks and logger (handles distributed training automatically)
    wandb_logger: Union[bool, WandbLogger] = False
    checkpoint_callback = None
    if config.wandb.enable:
        wandb_logger, checkpoint_callback = get_wandblogger_and_checkpoint_callback(config)

    # Create all callbacks using the centralized function
    callbacks = create_training_callbacks(config, checkpoint_callback)

    # Create the model
    ds_meta = getattr(train_dataset, "meta", None)  # LeRobot datasets have a meta attribute
    model: Policy = REGISTRY.create_model(config=config, model_type=ModelType.POLICY, ds_meta=ds_meta)
    # assert isinstance(model, Policy)

    # Set normalizer for standard datasets
    if normalizer is not None:
        model.normalizer = normalizer

    print("\nModel created")
    print(model)
    print("\n\n")
    print(model_summary.summarize(model, max_depth=1))
    print("\n\n")

    # Define the Lightning Trainer
    # 3. Define the Lightning Trainer
    trainer = L.Trainer(
        logger=wandb_logger,
        accelerator=config.train.accelerator,
        devices="auto",
        strategy=RayDDPStrategy(find_unused_parameters=config.train.find_unused_parameters),
        plugins=[RayLightningEnvironment()],
        callbacks=callbacks,
        enable_progress_bar=True,
        max_epochs=config.train.max_epochs,
        max_steps=config.train.max_steps,
        num_nodes=config.train.num_nodes,
        precision=config.train.precision,
        gradient_clip_val=config.train.gradient_clip_val,
        log_every_n_steps=config.train.log_every_n_steps,
        profiler=lightning_profiler,
        enable_checkpointing=True,
        enable_model_summary=config.train.enable_model_summary,
    )

    wrap_object_with_profiler(profiled_rank, trainer, config, "Trainer")
    wrap_object_with_profiler(profiled_rank, model, config, "Training")

    prepare_trainer(trainer)  # for distributed execution

    # Train the model with profiler scope
    with profiler_scope:
        trainer.fit(model, train_dataloaders=train_ds_loader, val_dataloaders=valid_ds_loader)

    print("Training completed with results")

    if wandb_logger:
        finish_wandb()

    if ray.train.get_context().get_world_rank() == profiled_rank:
        finish_profiler(profiler_scope, config.profiler.categories)


def train_vpl(config: DictConfig | Dict, is_test: bool = False) -> None:
    """
    Train a model using the given dataset and configuration.
    """
    # 1. Load model configuration
    if not isinstance(config, DictConfig):
        config = OmegaConf.create(config)

    config = generate_run_id(config)

    # 2. Define the ray run configuration
    run_config = RunConfig(
        storage_path=f"{config.storage_path}/ray",
    )

    # 3. Define the ray scaling configuration
    scaling_config = ScalingConfig(
        num_workers=config.train.num_ray_workers,
        use_gpu=config.train.use_gpu,
        # specifying "train" resource makes it schedule only on nodes labeled for train instead of sim
        resources_per_worker={
            "GPU": config.train.gpu_resources_per_worker,
            "train": 0.001 if not is_test else 0,
        },
    )

    # 4. Define the ray training loop configuration
    ray_trainer: TorchTrainer = TorchTrainer(
        train_loop_per_worker=train_func,
        train_loop_config=config,  # type: ignore
        scaling_config=scaling_config,
        run_config=run_config,
    )

    # 5. Train the model
    ray_trainer.fit()


@hydra.main(version_base=None, config_path="pkg://visuomotor/configs", config_name=None)
def main(config: DictConfig) -> None:
    ctx = DataContext.get_current()
    ctx.enable_tensor_extension_casting = False

    print(OmegaConf.to_yaml(config))
    ray.init(address="auto", ignore_reinit_error=True)
    assert_cluster_resources_match_config(config)
    copy_to_local(config, overwrite=False)  # If you are sure the data is already there skip this to save time
    train_vpl(config=config)


if __name__ == "__main__":
    main()
