#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

required_dependencies = [
    "ray",
    "rai_tensors",
]

missing_dependencies = []

for dep in required_dependencies:
    try:
        __import__(dep)
    except ImportError:
        missing_dependencies.append(dep)

if missing_dependencies:
    message = (
        "The 'visuomotor.ray_train' module requires additional dependencies that are not installed:\n"
        f"Missing dependencies: {', '.join(missing_dependencies)}\n\n"
        "Please install the training dependencies using:\n\n"
        "  uv sync --locked --extra torch-gpu --extra training\n\n"
        "or\n\n"
        "  uv pip install visuomotor[training]\n"
    )
    raise ImportError(message)

__all__ = [
    "data",
    "process_mimicgen_episode",
    "ray_train",
    "ray_tqdm_utils",
    "ray_tune",
    "ray_utils",
    "simulation",
    "submit_job",
]
