# Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

"""
Script to load a LeRobot checkpoint from wandb and print its weights and metadata for manual inspection.
"""

import os

import torch

from visuomotor.models.model_registry import ModelRegistry
from visuomotor.models.policies.lerobot_model import LeRobotPolicy  # Import to trigger registration

# Set WANDB API key
os.environ["WANDB_API_KEY"] = os.getenv("WANDB_API_KEY")  # type: ignore


def load_and_inspect_checkpoint() -> None:
    """Load checkpoint and print detailed information"""

    # The specific checkpoint requested
    artifact_name = "bdaii/aloha_sim_transfer_cube_human_image-agundogdu/lerobot_diffpo_aloha-s6lw3fut-wwh23fq5:v9"

    print("🔍 LOADING LEROBOT CHECKPOINT")
    print("=" * 60)
    print(f"Artifact: {artifact_name}")
    print()

    try:
        # Get the checkpoint file path (it might already be downloaded)
        checkpoint_path = f"visuomotor/checkpoints/{artifact_name}/model.ckpt"

        # If not downloaded, download it
        if not os.path.exists(checkpoint_path):
            print("📥 Downloading checkpoint...")
            registry = ModelRegistry()
            try:
                registry.build_policy_from_artifact_name(name=artifact_name)
                print("✅ Download completed!")
            except Exception as e:
                print(f"❌ Error downloading checkpoint: {e}")
                print("⚠️ Model creation failed but checkpoint should be downloaded")
        else:
            print("✅ Using existing checkpoint file!")
        print()

        if os.path.exists(checkpoint_path):
            print("📁 LOADING RAW CHECKPOINT FILE")
            print("-" * 40)
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)

            print(f"Checkpoint keys: {list(checkpoint.keys())}")
            print()

            # Print hyperparameters
            print("📋 HYPERPARAMETERS")
            print("-" * 40)
            hyper_params = checkpoint.get("hyper_parameters", {})
            for key in sorted(hyper_params.keys()):
                if key == "_lerobot_essential_info":
                    continue  # Handle this separately
                value = hyper_params[key]
                if isinstance(value, (dict, list)) and len(str(value)) > 100:
                    print(f"  {key}: <complex object - {type(value).__name__}>")
                else:
                    print(f"  {key}: {value}")
            print()

            # Print LeRobot dataset metadata (our stored metadata!)
            print("🎯 LEROBOT DATASET METADATA (Our Stored Metadata)")
            print("-" * 40)
            # Check for new naming first, then fall back to old naming for backward compatibility
            dataset_metadata = hyper_params.get("_lerobot_dataset_metadata") or hyper_params.get(
                "_lerobot_essential_info", {}
            )
            if dataset_metadata:
                for key, value in dataset_metadata.items():
                    print(f"  {key}: {value}")

                # Reconstruct the full metadata object and print statistics
                print()
                print("📊 DATASET STATISTICS (Reconstructed from Checkpoint)")
                print("-" * 40)
                try:
                    # Use the static method from LeRobotPolicy to reconstruct metadata
                    ds_meta = LeRobotPolicy.create_metadata_from_dataset_info(dataset_metadata)

                    # Print input feature statistics
                    if hasattr(ds_meta, "input_features") and ds_meta.input_features:
                        print("Input Features:")
                        for key, feature in ds_meta.input_features.items():
                            print(f"  {key}: {feature}")

                    # Print output feature statistics
                    if hasattr(ds_meta, "output_features") and ds_meta.output_features:
                        print("\nOutput Features:")
                        for key, feature in ds_meta.output_features.items():
                            print(f"  {key}: {feature}")

                    # Print statistics if available
                    if hasattr(ds_meta, "stats") and ds_meta.stats:
                        print("\nDataset Statistics:")
                        for key, stats in ds_meta.stats.items():
                            print(f"  {key}: {stats}")
                    else:
                        print("\nNo dataset statistics found in metadata")

                    # Check for other metadata attributes
                    print(f"\nMetadata attributes: {[attr for attr in dir(ds_meta) if not attr.startswith('_')]}")

                except Exception as e:
                    print(f"  ❌ Failed to reconstruct metadata: {e}")
            else:
                print("  ❌ No essential info found")
            print()

            # Print model state dict info
            print("⚖️ MODEL WEIGHTS")
            print("-" * 40)
            state_dict = checkpoint.get("state_dict", {})
            print(f"Total parameters: {len(state_dict)}")
            print("\nWeight tensor shapes:")
            for name, tensor in list(state_dict.items())[:10]:  # First 10 for brevity
                print(f"  {name}: {tensor.shape} ({tensor.dtype})")
            if len(state_dict) > 10:
                print(f"  ... and {len(state_dict) - 10} more parameters")

            # Extract actual dataset statistics from normalization buffers
            print("\n🔢 DATASET STATISTICS FROM MODEL NORMALIZATION")
            print("-" * 40)

            # Look for specific normalization patterns
            normalization_params: dict[str, dict[str, torch.Tensor]] = {}
            for param_name, tensor in state_dict.items():
                if "buffer_" in param_name and any(stat in param_name for stat in ["min", "max", "mean", "std"]):
                    # Parse pattern like "policy.normalize_targets.buffer_action.max"
                    parts = param_name.split(".")

                    # Find the buffer part and extract feature and stat
                    for _, part in enumerate(parts):
                        if part.startswith("buffer_"):
                            feature_name = part.replace("buffer_", "")
                            stat_type = parts[-1]  # min, max, mean, std

                            if feature_name not in normalization_params:
                                normalization_params[feature_name] = {}
                            normalization_params[feature_name][stat_type] = tensor
                            break

            # Print the extracted statistics
            if normalization_params:
                for feature_name, stats in normalization_params.items():
                    print(f"\n📊 {feature_name} normalization:")
                    for stat_type, values in stats.items():
                        if len(values) <= 20:  # Only show if not too many values
                            values_list = values.tolist()
                            print(f"  {stat_type}: {values_list}")
                        else:
                            print(
                                f"  {stat_type}: shape={values.shape}, mean={values.mean():.4f}, std={values.std():.4f}"
                            )
            else:
                # Fallback: show any parameter with normalization keywords
                print("Normalization-related parameters found:")
                norm_params = [
                    name
                    for name in state_dict.keys()
                    if any(kw in name for kw in ["normalize", "buffer", "min", "max"])
                ]
                for name in norm_params[:10]:  # Show first 10
                    tensor = state_dict[name]
                    print(f"  {name}: {tensor.shape}")
                    if tensor.numel() <= 20:  # Show values if not too many
                        print(f"    values: {tensor.tolist()}")
                if len(norm_params) > 10:
                    print(f"  ... and {len(norm_params) - 10} more normalization parameters")
            print()

            # Print optimizer state if present
            print("🔧 OPTIMIZER STATE")
            print("-" * 40)
            optimizer_states = checkpoint.get("optimizer_states", [])
            if optimizer_states:
                print(f"Number of optimizer states: {len(optimizer_states)}")
            else:
                print("No optimizer states found")
            print()

            # Print other checkpoint info
            print("📊 OTHER CHECKPOINT INFO")
            print("-" * 40)
            for key, value in checkpoint.items():
                if key not in ["hyper_parameters", "state_dict", "optimizer_states"]:
                    if isinstance(value, (dict, list)) and len(str(value)) > 100:
                        print(f"  {key}: <complex object - {type(value).__name__}>")
                    else:
                        print(f"  {key}: {value}")

        else:
            print(f"❌ Checkpoint file not found at: {checkpoint_path}")

    except Exception as e:
        print(f"❌ Error loading checkpoint: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    load_and_inspect_checkpoint()
