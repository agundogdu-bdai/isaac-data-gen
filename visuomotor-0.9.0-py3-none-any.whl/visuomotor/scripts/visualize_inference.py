#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse

import open3d as o3d
import torch
from spatialmath import SE3

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.utils.paths import get_checkpoints_path, get_config
from visuomotor.utils.pose_utils import pose10d_to_mat


def visualize_predicitons(args: argparse.Namespace) -> None:
    config = get_config(args.config)
    policy: torch.nn.Module = REGISTRY.create_model(config=config, model_type=ModelType.POLICY)
    checkpoint_path = get_checkpoints_path() / (args.checkpoint + ".ckpt")
    policy.load_state_dict(torch.load(checkpoint_path, map_location=args.device)["state_dict"])
    policy.eval().to(args.device)
    dataset = VisuomotorDataset(config=config.data)

    for batch in dataset:
        # remove redundant information for visualization
        del batch["task_index"]
        del batch["task_description"]

        true_action = batch["action"][0]
        del batch["action"]

        with torch.no_grad():
            pred_action = policy.predict_action(batch).squeeze().astype(float)

        pred_action = pred_action[0]

        print(f"gripper true action: {true_action[-1]}")
        print(f"gripper pred action: {pred_action[-1]}")
        pcd = o3d.geometry.PointCloud()
        if "point_cloud" in batch:
            pcd.points = o3d.utility.Vector3dVector(batch["point_cloud"][:, :3])
            pcd.colors = o3d.utility.Vector3dVector(batch["point_cloud"][:, 3:6])

        world_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.3)

        true_action = SE3(pose10d_to_mat(true_action[0:9]).reshape([4, 4]))
        pred_action = SE3(pose10d_to_mat(pred_action[0:9]).reshape([4, 4]))

        true_action_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.2).transform(true_action.A)
        pred_action_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.1).transform(pred_action.A)

        o3d.visualization.draw_geometries([pcd, world_frame, pred_action_frame, true_action_frame])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="train_diffpo", help="Path to the config file")
    parser.add_argument("--episode", type=int, default=0)
    parser.add_argument("--checkpoint", type=str, default="diffpo-9st80s5h-epoch=749")
    parser.add_argument("--device", type=str, default="cpu")
    visualize_predicitons(parser.parse_args())


if __name__ == "__main__":
    main()
