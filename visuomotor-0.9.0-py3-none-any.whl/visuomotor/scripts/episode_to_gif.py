#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse

import einops
import h5py
from PIL import Image


def save_episode_to_gif(episode_path: str, output_path: str) -> None:
    with h5py.File(episode_path) as data:
        color = data["color"][:]

    color = einops.rearrange(color, "t n y x c -> t y (n x) c")

    images = [Image.fromarray(img) for img in color]

    images[0].save(output_path, save_all=True, append_images=images[1:], duration=34, loop=0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("episode_path", type=str)
    parser.add_argument("output_path", type=str)
    args = parser.parse_args()

    save_episode_to_gif(args.episode_path, args.output_path)


if __name__ == "__main__":
    main()
