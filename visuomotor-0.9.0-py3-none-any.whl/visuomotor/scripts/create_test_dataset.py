#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import json
import os

import h5py
import numpy as np

from visuomotor.utils.paths import get_datasets_path

# Script used to create a dataset with random generated actions


def get_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-name", type=str, default="test_action_task", help="Name of the output dataset")
    parser.add_argument("--episodes", type=int, default=2, help="Total number of episodes for the task")
    return parser.parse_args()


def main() -> None:
    args = get_args()

    task_path = get_datasets_path() / args.task_name
    if task_path.exists():
        print(f"Dataset {args.task_name} already exists in {get_datasets_path()}")
        exit()
    os.makedirs(task_path, exist_ok=True)

    ## Dataset used for testing only includes a random generated action.
    ## Doesn't include any kind of observations. Code generated for the dataset is:
    timesteps = []
    for episode in range(args.episodes):
        episode_str = "episode_" + str(episode)
        episode_folder = task_path / episode_str
        os.makedirs(episode_folder, exist_ok=True)

        episode_file = episode_folder / (episode_str + ".h5")
        action = np.random.rand(10, 10).astype(np.float32)
        with h5py.File(episode_file, "w") as f:
            f.create_dataset("action", data=action)
        timesteps.append(10)

    # Create metadata based in number of episodes
    output_metadata = {"num_episodes": args.episodes, "num_timesteps": timesteps}
    output_metadata["task_description"] = "Do the task to test the action"
    metadata_file = task_path / "metadata.json"
    with open(metadata_file, "w") as outfile:
        json.dump(output_metadata, outfile)


if __name__ == "__main__":
    main()
