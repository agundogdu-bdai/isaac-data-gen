#  Copyright (c) 2025 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse

import cv2
import numpy as np
import torch
from hydra import compose, initialize
from omegaconf import ListConfig
from sklearn.decomposition import PCA

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.models.model_registry import REGISTRY, ModelType
from visuomotor.utils.paths import get_visuomotor_path


def get_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize DINOv2 features")
    parser.add_argument(
        "--config-name",
        type=str,
        default="train_dit_dinov2_pipe_fitting",
        help="Name of the config file",
    )
    parser.add_argument(
        "--fps",
        type=int,
        default=30,
        help="Frames per second for visualization",
    )
    return parser.parse_args()


def main() -> None:
    args = get_args()
    with initialize(version_base=None, config_path="../configs"):
        train_config = compose(config_name=args.config_name)
        data_config = train_config.data

    if isinstance(data_config.data_path, list) or isinstance(data_config.data_path, ListConfig):
        data_config.data_path = data_config.data_path[0]
    else:
        data_config.data_path = data_config.data_path

    data_config.image_randomization.color_jitter = None
    dataset = VisuomotorDataset(data_config)

    with initialize(version_base=None, config_path="../configs/rgb_encoder"):
        dinov2_config = compose(config_name="dino_v2")

    dinov2_config.n_cams = 4
    dinov2_config.project_features = False
    dinov2_config.return_cls_token = False
    dinov2_config.image_size = (224, 224)
    dinov2_config.model_name = "dinov2_vitl14"
    dinov2 = (
        REGISTRY.create_model(
            name="dino_v2",
            config=dinov2_config,
            model_type=ModelType.ENCODER_RGB,
        )
        .to(device="cuda:0")
        .eval()
    )

    image_folder = get_visuomotor_path() / "images"
    image_folder.mkdir(parents=True, exist_ok=True)
    for data_idx in range(10):
        pca = PCA(n_components=3)
        data = dataset[data_idx]
        color_images = data["color"][0]  # N, 3, H, W
        print(f"Color images shape: {color_images.shape}")
        color_images_cuda = torch.from_numpy(color_images).to(device="cuda:0")
        with torch.inference_mode():
            dinov2_features = dinov2(color_images_cuda)
        print(f"Dinov2 features shape: {dinov2_features.shape}")
        dinov2_features_flatten = dinov2_features.cpu().reshape(-1, dinov2_features.shape[-1])
        pca_features_flatten = pca.fit_transform(dinov2_features_flatten)
        pca_features_flatten_normalized = (pca_features_flatten - pca_features_flatten.min(axis=0)) / (
            pca_features_flatten.max(axis=0) - pca_features_flatten.min(axis=0)
        )
        pca_features = pca_features_flatten_normalized.reshape(dinov2_features.shape[0], 16, 16, 3)
        pca_features_upsampled = []

        for i in range(pca_features.shape[0]):
            pca_features_upsampled.append(cv2.resize(pca_features[i], (224, 224), interpolation=cv2.INTER_LINEAR))

        color_images = color_images.transpose(0, 2, 3, 1)  # N, H, W, 3
        color_images = np.hstack(color_images)  # H, N * W, 3
        color_images = (color_images * 255).astype(np.uint8)
        color_images = cv2.cvtColor(color_images, cv2.COLOR_RGB2BGR)

        pca_features_rgb = np.hstack(pca_features_upsampled)
        pca_features_rgb = (pca_features_rgb * 255).astype(np.uint8)

        images = np.vstack([color_images, pca_features_rgb])
        print(f"Saving images to {image_folder / f'images_{data_idx}.png'}")
        cv2.imwrite(str(image_folder / f"images_{data_idx}.png"), images)


if __name__ == "__main__":
    main()
