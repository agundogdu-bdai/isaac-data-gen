#  Copyright (c) 2024 Boston Dynamics AI Institute LLC. All rights reserved.

import argparse
import time

import cv2
import numpy as np
import open3d as o3d
from einops import rearrange
from hydra import compose, initialize
from omegaconf import ListConfig

from visuomotor.data.datasets import VisuomotorDataset
from visuomotor.data.utils import (
    get_episode_h5_path,
    get_task_metadata,
    h5_to_dict,
)
from visuomotor.perception.depth_utils import sample_point_cloud
from visuomotor.utils.paths import DataSource


def get_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize Visuomotor Dataset")
    parser.add_argument(
        "--config-name",
        type=str,
        default="isaac_spot_box_rotate_pointcloud",
        help="Name of the config file",
    )
    parser.add_argument(
        "--fps",
        type=int,
        default=30,
        help="Frames per second for visualization",
    )
    parser.add_argument(
        "--point-cloud",
        action="store_true",
        help="Visualize point cloud instead of images",
    )
    parser.add_argument(
        "--save-video",
        action="store_true",
        help="Save visualization as a video file",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        default="output_visualization.mp4",
        help="Path for the output video file (only used with --save-video)",
    )
    parser.add_argument(
        "--max-episodes",
        type=int,
        default=2,
        help="Maximum number of episodes to record (default: 5)",
    )
    return parser.parse_args()


def visualize_images(args: argparse.Namespace) -> None:
    with initialize(version_base=None, config_path="../configs/data"):
        config = compose(config_name=args.config_name)

    # Ensure single data path
    if isinstance(config.data_path, (list, ListConfig)):
        config.data_path = config.data_path[0]

    config.image_randomization.color_jitter = None

    dataset = VisuomotorDataset(config)

    max_timestep_idx = len(dataset.metadata["episode_timestep_idx"])
    timestep_idx = 0
    episodes_processed = 0

    # Video writer setup
    video_writer = None
    if args.save_video:
        print(f"Video will be saved to: {args.output_path}")
        print(f"Recording maximum {args.max_episodes} episodes")

    for episode in range(dataset.metadata["num_episodes"]):
        cv2_window_name_color = f"Color Images -- Episode {episode}"
        next_image_episode = dataset.metadata["episode_timestep_idx"][timestep_idx][0]

        # Skip episodes that have been removed
        if next_image_episode != episode:
            continue

        # Check if we've reached the maximum number of episodes for video recording
        if args.save_video and episodes_processed >= args.max_episodes:
            print(f"Reached maximum of {args.max_episodes} episodes for video recording")
            break

        episodes_processed += 1
        if args.save_video:
            print(f"Processing episode {episode} ({episodes_processed}/{args.max_episodes})")

        while next_image_episode == episode:
            # The shape of the color image is T, K, H, W, 3 where T is the number of timesteps,
            # K is the number of cameras, H is the height, W is the width, and 3 is the number of channels.
            # We want to visualize the current timestep.
            data = dataset[timestep_idx]
            color_tensor = data["color"][0]

            # Rearrange to (num_cams, height, width, channels)
            try:
                color_images = rearrange(color_tensor, "k c h w -> k h w c")
            except Exception as e:
                print(f"Error during rearrange: {e}")
                break

            # Convert to NumPy and concatenate for display
            color_images = np.concatenate(color_images, axis=1)  # Concatenate along width

            # Ensure image is in uint8 format (0-255 range) for OpenCV
            if color_images.dtype != np.uint8:
                # If values are in [0, 1] range, scale to [0, 255]
                if color_images.max() <= 1.0:
                    color_images = (color_images * 255).astype(np.uint8)
                else:
                    color_images = color_images.astype(np.uint8)

            color_images_bgr = cv2.cvtColor(color_images, cv2.COLOR_RGB2BGR)

            # Initialize video writer on first frame
            if args.save_video and video_writer is None:
                height, width = color_images_bgr.shape[:2]
                fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                video_writer = cv2.VideoWriter(args.output_path, fourcc, args.fps, (width, height))
                if not video_writer.isOpened():
                    print(f"Error: Could not open video writer for {args.output_path}")
                    args.save_video = False  # Disable video saving
                else:
                    print(f"Started recording video: {width}x{height} @ {args.fps} FPS")

            # Write frame to video if recording
            if args.save_video and video_writer is not None:
                video_writer.write(color_images_bgr)

            # Display frame (unless we're only saving video)
            if not args.save_video:
                cv2.imshow(cv2_window_name_color, color_images_bgr)
                key = cv2.waitKey(1)
                if key == 27:  # ESC key to exit early
                    cv2.destroyAllWindows()
                    if video_writer is not None:
                        video_writer.release()
                    return
            # else:
            #     # When saving video, add a small delay to control processing speed
            #     time.sleep(1 / args.fps)

            timestep_idx += 1
            if timestep_idx >= max_timestep_idx:
                break
            next_image_episode = dataset.metadata["episode_timestep_idx"][timestep_idx][0]

        if not args.save_video:
            cv2.destroyWindow(cv2_window_name_color)

    # Clean up video writer
    if video_writer is not None:
        video_writer.release()
        print(f"Video saved successfully to: {args.output_path}")

    if not args.save_video:
        cv2.destroyAllWindows()


def visualize_point_cloud(args: argparse.Namespace) -> None:
    world_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.3)
    with initialize(version_base=None, config_path="../configs/data"):
        config = compose(config_name=args.config_name)

    # Ensure single data path
    if isinstance(config.data_path, (list, ListConfig)):
        config.data_path = config.data_path[0]

    metadata = get_task_metadata(config.data_path, DataSource(config.local_data_source_str))
    vis = o3d.visualization.Visualizer()
    vis.create_window()
    vis.add_geometry(world_frame)
    point_cloud_o3d = o3d.geometry.PointCloud()

    for episode in range(metadata["num_episodes"]):
        trajectory_color = np.random.uniform(0, 1, 3)

        h5_episode_path = get_episode_h5_path(config.data_path, episode)
        data = h5_to_dict(h5_episode_path, data_keys=["point_cloud"])
        timestep_idx = 0
        for i in range(len(data["point_cloud"])):
            point_cloud = data["point_cloud"][i]
            point_cloud = point_cloud.reshape(-1, 6)

            config.point_cloud_sampling.use_rgb = True
            if config.point_cloud_sampling.method == "uniform":
                point_cloud = sample_point_cloud(config, point_cloud)

            point_cloud_o3d.points = o3d.utility.Vector3dVector(point_cloud[:, :3])
            point_cloud_o3d.colors = o3d.utility.Vector3dVector(point_cloud[:, 3:])

            if timestep_idx == 0:
                vis.add_geometry(point_cloud_o3d)
            else:
                vis.update_geometry(point_cloud_o3d)

            timestep_idx += 1

            if "eef_pose" in data:
                eef_pose = o3d.geometry.TriangleMesh.create_sphere(radius=0.005).transform(
                    data["eef_pose"][0].reshape(4, 4)
                )
                eef_pose.paint_uniform_color(trajectory_color)
                vis.add_geometry(eef_pose, reset_bounding_box=False)

            vis.poll_events()
            vis.update_renderer()
            time.sleep(1 / args.fps)

    vis.destroy_window()


def main() -> None:
    args = get_args()
    if args.point_cloud:
        visualize_point_cloud(args)
    else:
        visualize_images(args)


if __name__ == "__main__":
    main()
